import "@babel/polyfill";
import "sanitize.css/sanitize.css";

// Browser polyfill cho thư viện Node-style (sockjs-client)
if (typeof globalThis !== "undefined" && typeof globalThis.global === "undefined") {
  globalThis.global = globalThis;
}

import { ThemeProvider } from "@mui/material";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import App from "App";
import { ConnectedRouter } from "connected-react-router";
import { SnackbarProvider } from "notistack";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { ThemeProvider as StyledThemeProvider } from "styled-components";
import { MuiTheme, VPB_THEMES } from "utils/configs";
import history from "utils/history";

import configureStore from "./configureStore";

// Create redux store with history
const initialState = {};
const store = configureStore(initialState, history);
const MOUNT_NODE = document.getElementById("app");
const ROOT = createRoot(MOUNT_NODE);

// turn on concurrent mode
const render = () => {
  ROOT.render(
    <Provider store={store}>
      <SnackbarProvider
        maxSnack={5}
        style={{ borderRadius: "8px" }}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <ConnectedRouter history={history}>
            <ThemeProvider theme={MuiTheme}>
              <StyledThemeProvider theme={VPB_THEMES}>
                <App />
              </StyledThemeProvider>
            </ThemeProvider>
          </ConnectedRouter>
        </LocalizationProvider>
      </SnackbarProvider>
    </Provider>
  );
};

render();
