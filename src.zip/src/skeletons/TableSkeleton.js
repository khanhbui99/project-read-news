import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Skeleton,
} from "@mui/material";
import PropTypes from "prop-types";

const createArray = (length) => Array.from({ length }, (_, index) => index);

const TableSkeleton = ({
  rows = 5,
  columns = 4,
  showHeader = true,
  showActions = false,
  minRowHeight = 0,
}) => {
  const columnIndices = createArray(columns);
  const rowIndices = createArray(rows);

  return (
    <TableContainer component={Paper} variant="outlined">
      <Table>
        {showHeader && (
          <TableHead>
            <TableRow>
              {columnIndices.map((col) => (
                <TableCell key={`header-${col}`} sx={{ p: 1.5 }}>
                  <Skeleton variant="rounded" width="100%" height={30}/>
                </TableCell>
              ))}
              {showActions && (
                <TableCell align="right" sx={{ p: 1.5, width: 80 }}>
                  <Skeleton variant="rounded" width={80} height={30}/>
                </TableCell>
              )}
            </TableRow>
          </TableHead>
        )}
        <TableBody>
          {rowIndices.map((row) => (
            <TableRow key={`row-${row}`}>
              {columnIndices.map((col) => (
                <TableCell key={`cell-${row}-${col}`} sx={{ p: 1.5 }}>
                  <Box
                    minHeight={minRowHeight}
                    display="flex"
                    alignItems="center"
                  >
                    <Skeleton variant="rounded" width="100%" height={30}/>
                  </Box>
                </TableCell>
              ))}
              {showActions && (
                <TableCell align="right" sx={{ p: 1.5 }}>
                  <Skeleton variant="rectangular" width={80} height={30} />
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

TableSkeleton.propTypes = {
  rows: PropTypes.number,
  columns: PropTypes.number,
  showHeader: PropTypes.bool,
  showActions: PropTypes.bool,
  minRowHeight: PropTypes.number,
};

export default TableSkeleton;
