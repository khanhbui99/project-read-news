import { Box, Grid, Skeleton, Stack } from "@mui/material";

import TableSkeleton from "./TableSkeleton";

const ListSkeleton = () => {
  return (
    <Stack spacing={3}>
      {/* Header Section: Title + Button */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ marginBottom: 4 }}
      >
        <Skeleton variant="rounded" width="60%" height={48} />
        <Skeleton variant="rounded" width={200} height={48} />
      </Stack>

      {/* Filter Section */}
      <Grid container spacing={1} sx={{ mb: 2 }}>
        <Grid item xs={12} md={4} sx={{ pl: "0 !important" }}>
          <Skeleton variant="text" width="50%" height={14} />
          <Skeleton variant="rounded" height={40} />
        </Grid>

        <Grid item xs={12} md={2}>
          <Skeleton variant="text" width="50%" height={14} />
          <Skeleton variant="rounded" height={40} />
        </Grid>

        <Grid item xs={12} md={2}>
          <Skeleton variant="text" width="50%" height={14} />
          <Skeleton variant="rounded" height={40} />
        </Grid>

        <Grid item xs={12} md={2}>
          <Skeleton variant="text" width="50%" height={14} />
          <Skeleton variant="rounded" height={40} />
        </Grid>

        {/* Nút Tìm kiếm - col-span-1 */}
        <Grid item xs={12} md={1}>
          <Box sx={{ pt: 1.7 }}>
            <Skeleton variant="rounded" width="100%" height={40} />
          </Box>
        </Grid>
      </Grid>

      {/* Table Section */}
      <TableSkeleton rows={10} columns={6} showHeader showActions />
    </Stack>
  );
};

export default ListSkeleton;
