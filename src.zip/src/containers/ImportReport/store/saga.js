import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import { all, put as dispatch, takeLatest } from "redux-saga/effects";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { responseCode } from "utils/constants";

import * as importReportAction from "./actions";

export function* downloadTemplateReportSaga() {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(importReportAction.downloadTemplateReportAction.request());

    const request = {
      url: urlApi.managementService.report.downloadTemplate,
      method: "GET",
    };

    yield ApiReq.download({
      url: request.url,
      method: "GET",
      folderName: `Template_BaoCao.xlsx`,
    });

    yield dispatch(importReportAction.downloadTemplateReportAction.success({}));
    yield dispatch(
      setMessageByFieldAction("success", {
        message: "Tải template thành công",
      })
    );
  } catch (err) {
    yield dispatch(importReportAction.downloadTemplateReportAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* importReportSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(importReportAction.importReportAction.request());

    const { file } = payload;

    if (!file) {
      yield dispatch(
        setMessageByFieldAction("error", {
          message: "Vui lòng chọn file để import",
        })
      );
      yield dispatch(importReportAction.importReportAction.failure({}));
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    const request = {
      url: urlApi.managementService.report.import,
      data: formData,
      multipart: true,
    };

    const { data: res = {} } = yield ApiReq.post(request);
    const { meta = {}, data } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield dispatch(importReportAction.importReportAction.success(data));
        yield dispatch(
          setMessageByFieldAction("success", {
            message: "Import báo cáo thành công",
          })
        );
        break;
      default:
        yield dispatch(importReportAction.importReportAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(importReportAction.importReportAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(importReportAction.importReportAction.TRIGGER, importReportSaga),
    takeLatest(
      importReportAction.downloadTemplateReportAction.TRIGGER,
      downloadTemplateReportSaga
    ),
  ]);
}

