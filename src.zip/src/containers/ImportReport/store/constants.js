import injectKey from "utils/injectKey";

export const key = injectKey.importReport;

// Saga actions
export const IMPORT_REPORT_ACTION = `app/${key}/IMPORT_REPORT_ACTION`;
export const DOWNLOAD_TEMPLATE_REPORT_ACTION = `app/${key}/DOWNLOAD_TEMPLATE_REPORT_ACTION`;

// File upload constants
export const SUPPORTED_FORMATS = [
  { type: "PDF", ext: ".pdf" },
  { type: "Excel", ext: ".xlsx, .xls" },
  { type: "Word", ext: ".docx, .doc" },
];

export const ACCEPTED_FILE_TYPES = ".xlsx,.xls,.docx,.doc";

export const VALID_EXTENSIONS = SUPPORTED_FORMATS.map((fmt) => fmt.ext)
  .join(",")
  .split(",")
  .map((ext) => ext.trim());

