import { createRoutine } from "redux-saga-routines";

import * as importReportConst from "./constants";

export const importReportAction = createRoutine(importReportConst.IMPORT_REPORT_ACTION);
export const downloadTemplateReportAction = createRoutine(importReportConst.DOWNLOAD_TEMPLATE_REPORT_ACTION);

