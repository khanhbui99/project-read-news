import { produce } from "immer";

import * as importReportAction from "./actions";

export const initialState = {};

const reducer = (state = initialState, { payload = {}, type }) =>
  produce(state, (dr) => {
    const draft = dr;
    switch (type) {
      // ---------- Redux And Saga ------- //
      case importReportAction.importReportAction.REQUEST: {
        break;
      }
      case importReportAction.importReportAction.SUCCESS: {
        break;
      }
      case importReportAction.importReportAction.FAILURE: {
        break;
      }

      case importReportAction.downloadTemplateReportAction.REQUEST: {
        break;
      }
      case importReportAction.downloadTemplateReportAction.SUCCESS: {
        break;
      }
      case importReportAction.downloadTemplateReportAction.FAILURE: {
        break;
      }

      default:
        break;
    }
  });

export default reducer;

