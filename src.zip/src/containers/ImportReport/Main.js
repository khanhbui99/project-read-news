import AppHeader from "components/common/AppHeader";
import React from "react";

import DownloadTemplate from "./components/DownloadTemplate";
import ImportSection from "./components/ImportSection";
import { ContainerStyled, ContentWrapper } from "./Styled";

const Main = () => {
  return (
    <React.Fragment>
      <AppHeader isHiddenBtn componentName="ImportReport" />
      <ContainerStyled>
        <ContentWrapper>
          <DownloadTemplate />

          <ImportSection />
        </ContentWrapper>
      </ContainerStyled>
    </React.Fragment>
  );
};

export default Main;

