import { Box, Paper } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled(Box)`
  padding: 2rem;
  min-height: 100vh;
  border-radius: 24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.gray[100]} 0%,
    #e8eef3 100%
  );

  @media (max-width: 768px) {
    padding: 0;
    border-radius: 16px;
    background: none;

    .btn {
      width: 100%;
    }

    .partWrapper {
      padding: 16px;
    }
  }
`;

export const ContentWrapper = styled(Box)`
  max-width: 1400px;
  margin: 0 auto;

  @media (max-width: 1200px) {
    max-width: 100%;
    padding: 0 1rem;
  }

  @media (max-width: 768px) {
    padding: 0;
  }
`;

export const SectionTitleStyled = styled(Box)`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;

  .step-number {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(
      135deg,
      ${VPB_THEMES.colors.green} 0%,
      ${VPB_THEMES.colors.blue} 100%
    );
    color: white;
    font-weight: 700;
    font-size: 0.9rem;
  }

  @media (max-width: 768px) {
    gap: 0.75rem;
    margin-bottom: 1.5rem;

    .step-number {
      width: 28px;
      height: 28px;
      font-size: 0.8rem;
    }
  }
`;

export const DropZoneStyled = styled(Paper)`
  border: 3px dashed ${VPB_THEMES.colors.green};
  border-radius: 16px;
  padding: 4rem 2rem;
  text-align: center;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(
      circle at 30% 70%,
      rgba(0, 173, 83, 0.05) 0%,
      transparent 50%
    );
    pointer-events: none;
  }

  &:hover {
    background: linear-gradient(135deg, #f0f9f5 0%, #e8f5f0 100%);
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 16px 48px rgba(0, 173, 83, 0.2);
  }

  &.dragover {
    background: linear-gradient(135deg, #e8f5f0 0%, #e0f2eb 100%);
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 20px 60px rgba(0, 173, 83, 0.3);
    transform: scale(1.01);
  }

  @media (max-width: 768px) {
    padding: 3rem 1.5rem;
    border-width: 2px;
  }
`;

export const DropZoneContentStyled = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  position: relative;
  z-index: 1;

  svg {
    font-size: 5rem;
    color: ${VPB_THEMES.colors.green};
    opacity: 0.8;
    animation: float 3s ease-in-out infinite;
  }

  @keyframes float {
    0%,
    100% {
      transform: translateY(0px);
    }
    50% {
      transform: translateY(-10px);
    }
  }

  h3 {
    color: #1a1a1a;
    margin: 0;
    font-size: 1.3rem;
    font-weight: 700;
  }

  p {
    color: #666;
    margin: 0;
    font-size: 1rem;
  }

  @media (max-width: 768px) {
    gap: 1rem;

    svg {
      font-size: 4rem;
    }

    h3 {
      font-size: 1.1rem;
    }

    p {
      font-size: 0.9rem;
    }
  }
`;

export const FileItemStyled = styled(Box)`
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  border-radius: 12px;
  margin-bottom: 1rem;
  padding: 1.25rem;
  border-left: 5px solid ${VPB_THEMES.colors.green};
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 1rem;

  &:hover {
    box-shadow: 0 8px 24px rgba(0, 173, 83, 0.15);
    transform: translateX(8px);
  }

  @media (max-width: 768px) {
    padding: 1rem;
    border-left-width: 4px;
  }
`;

export const PreviewContainer = styled(Box)`
  position: relative;
  min-height: 400px;
  border-radius: 8px;
  transition: all 0.3s ease;

  &.drag-over {
    background-color: rgba(0, 173, 83, 0.05);
    border: 2px dashed ${VPB_THEMES.colors.green};
    border-radius: 8px;
  }

  .editor-wrapper {
    border-radius: 8px;
    overflow: hidden;
  }
`;

export const TableListContainer = styled(Box)`
  padding: 1rem 0;
  max-height: 600px;
  overflow-y: auto;
  overflow-x: hidden;
  
  /* Custom scrollbar */
  &::-webkit-scrollbar {
    width: 8px;
  }
  
  &::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: ${VPB_THEMES.colors.gray[400]};
    border-radius: 4px;
    
    &:hover {
      background: ${VPB_THEMES.colors.gray[500]};
    }
  }
`;

export const TableItemStyled = styled(Paper)`
  display: flex;
  align-items: center;
  padding: 1.25rem;
  cursor: grab;
  transition: all 0.3s ease;
  border-left: 4px solid ${VPB_THEMES.colors.blue};

  &:hover {
    transform: translateX(8px);
    box-shadow: 0 8px 24px rgba(0, 123, 255, 0.15);
  }

  &:active {
    cursor: grabbing;
  }

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;

export const DragGhostStyled = styled(Box)`
  position: fixed;
  pointer-events: none;
  z-index: 9999;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1rem;
  background: rgba(255, 255, 255, 0.95);
  border: 2px solid ${VPB_THEMES.colors.blue};
  border-radius: 8px;
  box-shadow: 0 8px 24px rgba(0, 123, 255, 0.3);
  transform: translate(-50%, -50%);
  transition: none;
`;

export const TwoColumnLayout = styled(Box)`
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  margin-top: 2rem;

  @media (max-width: 1200px) {
    grid-template-columns: 1fr;
  }
`;

export const PreviewModalContent = styled(Box)`
  width: 100%;
  height: 70vh;
  min-height: 500px;
  border: 1px solid ${VPB_THEMES.colors.gray[300]};
  border-radius: 8px;
  overflow: hidden;
  background: #fff;
`;

export const PreviewIframe = styled.iframe`
  width: 100%;
  height: 100%;
  border: none;
`;

export const PreviewContent = styled.div`
  max-width: 816px;
  margin: 0 auto;
  padding: 96px;
  background: #fff;
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.1);
  min-height: 1056px; /* A4 height at 96 DPI */

  /* Word-like styling */
  font-family: "Times New Roman", Times, serif;
  font-size: 12pt;
  line-height: 1.5;
  color: #000;

  p {
    margin: 0 0 12pt 0;
  }

  table {
    border-collapse: collapse;
    width: 100%;
    margin: 12pt 0;

    td,
    th {
      border: 1px solid #000;
      padding: 8pt;
      text-align: left;
    }

    th {
      background-color: #f0f0f0;
      font-weight: bold;
    }
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    margin: 12pt 0;
    font-weight: bold;
  }

  ul,
  ol {
    margin: 12pt 0;
    padding-left: 36pt;
  }

  img {
    max-width: 100%;
    height: auto;
  }
`;

