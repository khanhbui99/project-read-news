import { createRoutine } from "redux-saga-routines";

import * as wordEditorConst from "./constants";

export const readWordFileAction = createRoutine(wordEditorConst.READ_WORD_FILE_ACTION);
export const updateWordContentAction = createRoutine(wordEditorConst.UPDATE_WORD_CONTENT_ACTION);
export const addTableToContentAction = createRoutine(wordEditorConst.ADD_TABLE_TO_CONTENT_ACTION);
export const convertToWordAction = createRoutine(wordEditorConst.CONVERT_TO_WORD_ACTION);
export const loadStudentQualityTableAction = createRoutine(wordEditorConst.LOAD_STUDENT_QUALITY_TABLE_ACTION);
export const getSchoolListAction = createRoutine(wordEditorConst.GET_SCHOOL_LIST_ACTION);
export const exportWordV2Action = createRoutine(wordEditorConst.EXPORT_WORD_V2_ACTION);
export const removeTableAction = createRoutine(wordEditorConst.REMOVE_TABLE_ACTION);
export const clearDataAction = createRoutine(wordEditorConst.CLEAR_DATA_ACTION);

