// Mock data cho các bảng có thể kéo thả - mỗi item chỉ có 1 bảng duy nhất
export const MOCK_TABLES = [
  {
    id: "mock-table-1",
    name: "Bảng Thông Tin Sinh Viên",
    html: `<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
<thead>
<tr style="background-color: #f0f0f0;">
<th style="border: 1px solid #000; padding: 8px;">STT</th>
<th style="border: 1px solid #000; padding: 8px;">Mã SV</th>
<th style="border: 1px solid #000; padding: 8px;">Họ và Tên</th>
<th style="border: 1px solid #000; padding: 8px;">Lớp</th>
<th style="border: 1px solid #000; padding: 8px;">Điểm TB</th>
</tr>
</thead>
<tbody>
<tr>
<td style="border: 1px solid #000; padding: 8px;">1</td>
<td style="border: 1px solid #000; padding: 8px;">SV001</td>
<td style="border: 1px solid #000; padding: 8px;">Nguyễn Văn A</td>
<td style="border: 1px solid #000; padding: 8px;">CNTT01</td>
<td style="border: 1px solid #000; padding: 8px;">8.5</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">2</td>
<td style="border: 1px solid #000; padding: 8px;">SV002</td>
<td style="border: 1px solid #000; padding: 8px;">Trần Thị B</td>
<td style="border: 1px solid #000; padding: 8px;">CNTT01</td>
<td style="border: 1px solid #000; padding: 8px;">9.0</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">3</td>
<td style="border: 1px solid #000; padding: 8px;">SV003</td>
<td style="border: 1px solid #000; padding: 8px;">Lê Văn C</td>
<td style="border: 1px solid #000; padding: 8px;">CNTT02</td>
<td style="border: 1px solid #000; padding: 8px;">7.8</td>
</tr>
</tbody>
</table>`,
  },
  {
    id: "mock-table-2",
    name: "Bảng Lịch Học",
    html: `<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
<thead>
<tr style="background-color: #e8f4f8;">
<th style="border: 1px solid #000; padding: 8px;">Thứ</th>
<th style="border: 1px solid #000; padding: 8px;">Tiết</th>
<th style="border: 1px solid #000; padding: 8px;">Môn Học</th>
<th style="border: 1px solid #000; padding: 8px;">Phòng</th>
<th style="border: 1px solid #000; padding: 8px;">Giảng Viên</th>
</tr>
</thead>
<tbody>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Thứ 2</td>
<td style="border: 1px solid #000; padding: 8px;">1-3</td>
<td style="border: 1px solid #000; padding: 8px;">Lập trình Web</td>
<td style="border: 1px solid #000; padding: 8px;">P301</td>
<td style="border: 1px solid #000; padding: 8px;">Thầy Nguyễn Văn X</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Thứ 3</td>
<td style="border: 1px solid #000; padding: 8px;">4-6</td>
<td style="border: 1px solid #000; padding: 8px;">Cơ sở dữ liệu</td>
<td style="border: 1px solid #000; padding: 8px;">P302</td>
<td style="border: 1px solid #000; padding: 8px;">Cô Trần Thị Y</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Thứ 5</td>
<td style="border: 1px solid #000; padding: 8px;">1-3</td>
<td style="border: 1px solid #000; padding: 8px;">Mạng máy tính</td>
<td style="border: 1px solid #000; padding: 8px;">P303</td>
<td style="border: 1px solid #000; padding: 8px;">Thầy Lê Văn Z</td>
</tr>
</tbody>
</table>`,
  },
  {
    id: "mock-table-3",
    name: "Bảng Điểm Chi Tiết",
    html: `<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
<thead>
<tr style="background-color: #fff4e6;">
<th style="border: 1px solid #000; padding: 8px;" rowspan="2">Mã SV</th>
<th style="border: 1px solid #000; padding: 8px;" rowspan="2">Họ Tên</th>
<th style="border: 1px solid #000; padding: 8px;" colspan="3">Điểm Thành Phần</th>
<th style="border: 1px solid #000; padding: 8px;" rowspan="2">Điểm TB</th>
</tr>
<tr style="background-color: #fff4e6;">
<th style="border: 1px solid #000; padding: 8px;">Chuyên Cần</th>
<th style="border: 1px solid #000; padding: 8px;">Giữa Kỳ</th>
<th style="border: 1px solid #000; padding: 8px;">Cuối Kỳ</th>
</tr>
</thead>
<tbody>
<tr>
<td style="border: 1px solid #000; padding: 8px;">SV001</td>
<td style="border: 1px solid #000; padding: 8px;">Nguyễn Văn A</td>
<td style="border: 1px solid #000; padding: 8px;">9</td>
<td style="border: 1px solid #000; padding: 8px;">8.5</td>
<td style="border: 1px solid #000; padding: 8px;">8.0</td>
<td style="border: 1px solid #000; padding: 8px;">8.3</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">SV002</td>
<td style="border: 1px solid #000; padding: 8px;">Trần Thị B</td>
<td style="border: 1px solid #000; padding: 8px;">10</td>
<td style="border: 1px solid #000; padding: 8px;">9.0</td>
<td style="border: 1px solid #000; padding: 8px;">9.5</td>
<td style="border: 1px solid #000; padding: 8px;">9.4</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">SV003</td>
<td style="border: 1px solid #000; padding: 8px;">Lê Văn C</td>
<td style="border: 1px solid #000; padding: 8px;">8</td>
<td style="border: 1px solid #000; padding: 8px;">7.5</td>
<td style="border: 1px solid #000; padding: 8px;">8.0</td>
<td style="border: 1px solid #000; padding: 8px;">7.8</td>
</tr>
</tbody>
</table>`,
  },
  {
    id: "mock-table-4",
    name: "Bảng Thống Kê",
    html: `<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
<thead>
<tr style="background-color: #f0f0f0;">
<th style="border: 1px solid #000; padding: 8px;">Danh Mục</th>
<th style="border: 1px solid #000; padding: 8px;">Số Lượng</th>
<th style="border: 1px solid #000; padding: 8px;">Tỷ Lệ (%)</th>
<th style="border: 1px solid #000; padding: 8px;">Ghi Chú</th>
</tr>
</thead>
<tbody>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Tổng số sinh viên</td>
<td style="border: 1px solid #000; padding: 8px;">150</td>
<td style="border: 1px solid #000; padding: 8px;">100%</td>
<td style="border: 1px solid #000; padding: 8px;">-</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Sinh viên giỏi</td>
<td style="border: 1px solid #000; padding: 8px;">45</td>
<td style="border: 1px solid #000; padding: 8px;">30%</td>
<td style="border: 1px solid #000; padding: 8px;">Điểm TB ≥ 8.0</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Sinh viên khá</td>
<td style="border: 1px solid #000; padding: 8px;">60</td>
<td style="border: 1px solid #000; padding: 8px;">40%</td>
<td style="border: 1px solid #000; padding: 8px;">Điểm TB từ 6.5 - 7.9</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Sinh viên trung bình</td>
<td style="border: 1px solid #000; padding: 8px;">35</td>
<td style="border: 1px solid #000; padding: 8px;">23.3%</td>
<td style="border: 1px solid #000; padding: 8px;">Điểm TB từ 5.0 - 6.4</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Sinh viên yếu</td>
<td style="border: 1px solid #000; padding: 8px;">10</td>
<td style="border: 1px solid #000; padding: 8px;">6.7%</td>
<td style="border: 1px solid #000; padding: 8px;">Điểm TB < 5.0</td>
</tr>
</tbody>
</table>`,
  },
  {
    id: "mock-table-5",
    name: "Bảng Kế Hoạch Học Tập",
    html: `<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
<thead>
<tr style="background-color: #e8f5e9;">
<th style="border: 1px solid #000; padding: 8px;">Học Kỳ</th>
<th style="border: 1px solid #000; padding: 8px;">Mã HP</th>
<th style="border: 1px solid #000; padding: 8px;">Tên Học Phần</th>
<th style="border: 1px solid #000; padding: 8px;">TC</th>
<th style="border: 1px solid #000; padding: 8px;">Loại</th>
<th style="border: 1px solid #000; padding: 8px;">Ghi Chú</th>
</tr>
</thead>
<tbody>
<tr>
<td style="border: 1px solid #000; padding: 8px;">HK1</td>
<td style="border: 1px solid #000; padding: 8px;">CS101</td>
<td style="border: 1px solid #000; padding: 8px;">Nhập môn lập trình</td>
<td style="border: 1px solid #000; padding: 8px;">3</td>
<td style="border: 1px solid #000; padding: 8px;">Bắt buộc</td>
<td style="border: 1px solid #000; padding: 8px;">-</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">HK1</td>
<td style="border: 1px solid #000; padding: 8px;">CS102</td>
<td style="border: 1px solid #000; padding: 8px;">Cấu trúc dữ liệu</td>
<td style="border: 1px solid #000; padding: 8px;">3</td>
<td style="border: 1px solid #000; padding: 8px;">Bắt buộc</td>
<td style="border: 1px solid #000; padding: 8px;">-</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">HK2</td>
<td style="border: 1px solid #000; padding: 8px;">CS201</td>
<td style="border: 1px solid #000; padding: 8px;">Lập trình hướng đối tượng</td>
<td style="border: 1px solid #000; padding: 8px;">3</td>
<td style="border: 1px solid #000; padding: 8px;">Bắt buộc</td>
<td style="border: 1px solid #000; padding: 8px;">-</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">HK2</td>
<td style="border: 1px solid #000; padding: 8px;">CS202</td>
<td style="border: 1px solid #000; padding: 8px;">Cơ sở dữ liệu</td>
<td style="border: 1px solid #000; padding: 8px;">3</td>
<td style="border: 1px solid #000; padding: 8px;">Bắt buộc</td>
<td style="border: 1px solid #000; padding: 8px;">-</td>
</tr>
</tbody>
</table>`,
  },
  {
    id: "mock-table-6",
    name: "Bảng Đơn Giản",
    html: `<table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
<tr>
<th style="border: 1px solid #000; padding: 8px; background-color: #f0f0f0;">Cột 1</th>
<th style="border: 1px solid #000; padding: 8px; background-color: #f0f0f0;">Cột 2</th>
<th style="border: 1px solid #000; padding: 8px; background-color: #f0f0f0;">Cột 3</th>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Dữ liệu 1</td>
<td style="border: 1px solid #000; padding: 8px;">Dữ liệu 2</td>
<td style="border: 1px solid #000; padding: 8px;">Dữ liệu 3</td>
</tr>
<tr>
<td style="border: 1px solid #000; padding: 8px;">Dữ liệu 4</td>
<td style="border: 1px solid #000; padding: 8px;">Dữ liệu 5</td>
<td style="border: 1px solid #000; padding: 8px;">Dữ liệu 6</td>
</tr>
</table>`,
  },
];
