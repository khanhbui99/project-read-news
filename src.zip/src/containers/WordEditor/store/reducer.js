import { produce } from "immer";

import * as wordEditorAction from "./actions";

export const initialState = {
  wordContent: "",
  wordHtml: "",
  tables: [],
  tablesAll: [],
  fileName: "",
  file: "",
  wordBlobUrl: null,
  wordBlob: null,
  previewHtml: null, // HTML đã được format để preview (giống với file Word)
  isPreviewModalOpen: false,
  schoolOptions: [], // Danh sách trường học từ API
  yearOptions: [], // Danh sách năm học
};

const reducer = (state = initialState, { payload = {}, type }) =>
  produce(state, (dr) => {
    const draft = dr;
    switch (type) {
      // ---------- Redux And Saga ------- //
      case wordEditorAction.exportWordV2Action.SUCCESS: {
        return { ...initialState };
      }
      
      case wordEditorAction.readWordFileAction.REQUEST: {
        break;
      }
      case wordEditorAction.readWordFileAction.SUCCESS: {
        draft.wordContent = payload.content || "";
        draft.wordHtml = payload.html || "";
        draft.fileName = payload.fileName || "";
        draft.file = payload.file;
        break;
      }
      case wordEditorAction.readWordFileAction.FAILURE: {
        break;
      }

      case wordEditorAction.updateWordContentAction.REQUEST: {
        draft.wordContent = payload.content || draft.wordContent;
        draft.wordHtml = payload.html || draft.wordHtml;
        break;
      }
      case wordEditorAction.updateWordContentAction.SUCCESS: {
        break;
      }
      case wordEditorAction.updateWordContentAction.FAILURE: {
        break;
      }

      case wordEditorAction.addTableToContentAction.REQUEST: {
        draft.tables = payload.tables || draft.tables;
        break;
      }
      case wordEditorAction.addTableToContentAction.SUCCESS: {
        break;
      }
      case wordEditorAction.addTableToContentAction.FAILURE: {
        break;
      }

      case wordEditorAction.convertToWordAction.REQUEST: {
        break;
      }
      case wordEditorAction.convertToWordAction.SUCCESS: {
        draft.wordBlobUrl = payload.blobUrl || null;
        draft.wordBlob = payload.blob || null;
        draft.previewHtml =
          payload.previewHtml || payload.html || draft.wordHtml; // Lưu HTML đã format
        draft.isPreviewModalOpen = true;
        break;
      }
      case wordEditorAction.convertToWordAction.FAILURE: {
        draft.isPreviewModalOpen = false;
        break;
      }
      case "CLOSE_PREVIEW_MODAL": {
        draft.isPreviewModalOpen = false;
        if (draft.wordBlobUrl) {
          URL.revokeObjectURL(draft.wordBlobUrl);
          draft.wordBlobUrl = null;
        }
        draft.previewHtml = null; // Clear preview HTML khi đóng modal
        break;
      }

      case wordEditorAction.loadStudentQualityTableAction.REQUEST: {
        draft.tables = [];
        draft.tablesAll = [];
        break;
      }
      case wordEditorAction.loadStudentQualityTableAction.SUCCESS: {
        draft.tables = payload.tables;
        draft.tablesAll = payload.tables;
        break;
      }
      case wordEditorAction.loadStudentQualityTableAction.FAILURE: {
        break;
      }

      case wordEditorAction.getSchoolListAction.REQUEST: {
        break;
      }
      case wordEditorAction.getSchoolListAction.SUCCESS: {
        if (payload?.schoolOptions) {
          draft.schoolOptions = Array.isArray(payload.schoolOptions)
            ? payload.schoolOptions
            : [];
        }
        if (payload?.yearOptions) {
          draft.yearOptions = Array.isArray(payload.yearOptions)
            ? payload.yearOptions
            : [];
        }
        break;
      }
      case wordEditorAction.getSchoolListAction.FAILURE: {
        break;
      }

      case wordEditorAction.removeTableAction.REQUEST: {
        const { tableId } = payload;
        if (tableId) {
          draft.tables = draft.tables.filter((t) => t.id != tableId);
        }
        break;
      }
      case wordEditorAction.removeTableAction.SUCCESS: {
        break;
      }
      case wordEditorAction.removeTableAction.FAILURE: {
        break;
      }

      case wordEditorAction.clearDataAction.REQUEST: {
        // Clear tất cả data về trạng thái ban đầu
        draft.wordContent = "";
        draft.wordHtml = "";
        draft.tables = [];
        draft.fileName = "";
        if (draft.wordBlobUrl) {
          URL.revokeObjectURL(draft.wordBlobUrl);
        }
        draft.wordBlobUrl = null;
        draft.wordBlob = null;
        draft.isPreviewModalOpen = false;
        break;
      }
      case wordEditorAction.clearDataAction.SUCCESS: {
        break;
      }
      case wordEditorAction.clearDataAction.FAILURE: {
        break;
      }

      default:
        break;
    }
  });

export default reducer;
