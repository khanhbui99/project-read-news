import injectKey from "utils/injectKey";

export const key = injectKey.wordEditor;

// Saga actions
export const READ_WORD_FILE_ACTION = `app/${key}/READ_WORD_FILE_ACTION`;
export const UPDATE_WORD_CONTENT_ACTION = `app/${key}/UPDATE_WORD_CONTENT_ACTION`;
export const ADD_TABLE_TO_CONTENT_ACTION = `app/${key}/ADD_TABLE_TO_CONTENT_ACTION`;
export const CONVERT_TO_WORD_ACTION = `app/${key}/CONVERT_TO_WORD_ACTION`;

// File upload constants
export const ACCEPTED_FILE_TYPES = ".docx,.doc";
export const VALID_EXTENSIONS = [".docx", ".doc"];

// Action để load mock tables
export const LOAD_MOCK_TABLES_ACTION = `app/${key}/LOAD_MOCK_TABLES_ACTION`;
export const LOAD_STUDENT_QUALITY_TABLE_ACTION = `app/${key}/LOAD_STUDENT_QUALITY_TABLE_ACTION`;
export const GET_SCHOOL_LIST_ACTION = `app/${key}/GET_SCHOOL_LIST_ACTION`;
export const EXPORT_WORD_V2_ACTION = `app/${key}/EXPORT_WORD_V2_ACTION`;
export const REMOVE_TABLE_ACTION = `app/${key}/REMOVE_TABLE_ACTION`;
export const CLEAR_DATA_ACTION = `app/${key}/CLEAR_DATA_ACTION`;

