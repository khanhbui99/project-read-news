import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import {
  all,
  put as dispatch,
  takeLatest,
  call,
  select,
} from "redux-saga/effects";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { responseCode } from "utils/constants";
import { createYearOpt } from "utils/helpers";
import injectKey from "utils/injectKey";

import * as wordEditorAction from "./actions";
import { convertDataToHtmlTable } from "../helpers";

// Helper function để đọc file Word
async function readWordFile(file) {
  // Kiểm tra file có hợp lệ không
  if (!file || (!(file instanceof File) && !(file instanceof Blob))) {
    throw new Error("File không hợp lệ");
  }

  // Kiểm tra kích thước file (tối đa 50MB)
  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
  if (file.size > MAX_FILE_SIZE) {
    throw new Error("File quá lớn. Vui lòng chọn file nhỏ hơn 50MB");
  }

  if (file.size === 0) {
    throw new Error("File rỗng hoặc không hợp lệ");
  }

  try {
    // Dynamic import mammoth để code splitting
    const mammothModule = await import("mammoth");
    const mammoth = mammothModule.default || mammothModule;

    // Đọc file dưới dạng ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();

    // Kiểm tra ArrayBuffer có hợp lệ không
    if (!arrayBuffer || arrayBuffer.byteLength === 0) {
      throw new Error(
        "Không thể đọc file. File có thể bị hỏng hoặc không phải file Word hợp lệ"
      );
    }

    // Convert sang HTML sử dụng cấu hình mặc định của mammoth
    // Giống như demo web của mammoth để đảm bảo kết quả giống nhau
    // Mammoth sẽ tự động preserve inline styles (font-family, font-size, color, etc.)
    const result = await mammoth.convertToHtml(
      { arrayBuffer },
      {
        // Sử dụng default style map của mammoth (giống demo web)
        includeDefaultStyleMap: true,
        // Convert images nếu có (base64)
        convertImage: mammoth.images.imgElement((image) => {
          return image.read("base64").then((imageBuffer) => {
            return {
              src: `data:${image.contentType};base64,${imageBuffer.toString(
                "base64"
              )}`,
            };
          });
        }),
      }
    );

    // Mammoth sẽ tự động preserve inline styles từ Word:
    // - font-family, font-size, color, font-weight, font-style
    // - text-align, line-height, margin, padding
    // - và tất cả các styles khác

    return result;
  } catch (error) {
    // Xử lý lỗi cụ thể từ mammoth
    const errorMessage = error.message || "";

    // Kiểm tra xem file có phải là HTML được đổi tên thành .docx không
    // Nếu file bắt đầu bằng <!DOCTYPE hoặc <html, có thể là HTML
    // Cho phép import lại file HTML được tải xuống từ hệ thống
    try {
      const textPreview = await file.slice(0, 100).text();
      if (
        textPreview.trim().startsWith("<!DOCTYPE") ||
        textPreview.trim().startsWith("<html")
      ) {
        // File là HTML, không phải Word
        // Nhưng có thể là file HTML được tải xuống từ hệ thống, cho phép import lại
        const htmlContent = await file.text();
        return {
          value: htmlContent,
          messages: [
            {
              type: "info",
              message: "File này là HTML, đã được import thành công",
            },
          ],
        };
      }
    } catch {
      // Không thể đọc preview, tiếp tục với error gốc
    }

    // Kiểm tra magic bytes để xác định file có phải Word hợp lệ không
    try {
      const arrayBuffer = await file.slice(0, 4).arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      const isValidDocx = uint8Array[0] === 0x50 && uint8Array[1] === 0x4b; // PK header

      if (!isValidDocx) {
        // File không có magic bytes hợp lệ, có thể là HTML được đổi tên
        // Thử đọc như HTML
        try {
          const htmlContent = await file.text();
          if (
            htmlContent.trim().startsWith("<!DOCTYPE") ||
            htmlContent.trim().startsWith("<html")
          ) {
            return {
              value: htmlContent,
              messages: [
                {
                  type: "info",
                  message: "File này là HTML, đã được import thành công",
                },
              ],
            };
          }
        } catch {
          // Không thể đọc như HTML, tiếp tục với error gốc
        }
      }
    } catch {
      // Không thể kiểm tra magic bytes, tiếp tục với error gốc
    }

    if (errorMessage.includes("zip") || errorMessage.includes("ZIP")) {
      throw new Error(
        "File không phải là file Word hợp lệ (.docx). File có thể bị hỏng hoặc không đúng định dạng."
      );
    }
    if (errorMessage.includes("central directory")) {
      throw new Error(
        "File Word bị hỏng hoặc không đầy đủ. Vui lòng kiểm tra lại file."
      );
    }

    // Nếu là lỗi khác, giữ nguyên error message
    throw error;
  }
}

// Helper function để extract tables từ HTML
function extractTablesFromHtml(html) {
  if (typeof window === "undefined") return [];

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const tables = doc.querySelectorAll("table");
  const extractedTables = [];

  tables.forEach((table, index) => {
    extractedTables.push({
      id: `table-${index}`,
      name: `Bảng ${index + 1}`,
      html: table.outerHTML,
    });
  });

  return extractedTables;
}

export function* readWordFileSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(wordEditorAction.readWordFileAction.request());

    const { file } = payload;

    if (!file) {
      yield dispatch(
        setMessageByFieldAction("error", {
          message: "Vui lòng chọn file Word để đọc",
        })
      );
      yield dispatch(wordEditorAction.readWordFileAction.failure({}));
      return;
    }

    // Validate file extension - nhưng không reject ngay, sẽ thử đọc file trước
    const fileName = file.name.toLowerCase();
    const isValidExtension =
      fileName.endsWith(".docx") || fileName.endsWith(".doc");

    // Chỉ cảnh báo nếu extension không đúng, nhưng vẫn cho phép thử đọc
    // Vì file được tải xuống từ hệ thống có thể có extension đúng nhưng format khác
    if (!isValidExtension) {
      console.warn(
        "File extension không phải .docx hoặc .doc, nhưng sẽ thử đọc file"
      );
    }

    // Đọc file Word và convert sang HTML
    // Nếu file không phải Word hợp lệ, mammoth sẽ throw error và chúng ta sẽ xử lý
    const result = yield call(readWordFile, file);
    const html = result.value;
    const messages = result.messages;

    if (!html) {
      yield dispatch(
        setMessageByFieldAction("error", {
          message:
            "Không thể đọc nội dung từ file Word. File có thể bị hỏng hoặc không hợp lệ.",
        })
      );
      yield dispatch(wordEditorAction.readWordFileAction.failure({}));
      return;
    }

    // Lưu HTML và extract tables
    const tables = extractTablesFromHtml(html);

    yield dispatch(
      wordEditorAction.readWordFileAction.success({
        file,
        content: html,
        html: html,
        fileName: file.name,
        tables: tables,
      })
    );

    if (messages.length > 0) {
      yield dispatch(
        setMessageByFieldAction("warning", {
          message: `Đã đọc file thành công. Có ${messages.length} cảnh báo.`,
        })
      );
    } else {
      yield dispatch(
        setMessageByFieldAction("success", {
          message: "Đọc file Word thành công",
        })
      );
    }
  } catch (err) {
    yield dispatch(wordEditorAction.readWordFileAction.failure(err));
    yield dispatch(
      setMessageByFieldAction("error", {
        message: err.message || "Không thể đọc file Word",
      })
    );
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* updateWordContentSaga({ payload }) {
  try {
    yield dispatch(wordEditorAction.updateWordContentAction.request(payload));
    yield dispatch(wordEditorAction.updateWordContentAction.success({}));
  } catch (err) {
    yield dispatch(wordEditorAction.updateWordContentAction.failure(err));
  }
}

export function* addTableToContentSaga({ payload }) {
  try {
    yield dispatch(wordEditorAction.addTableToContentAction.request(payload));
    yield dispatch(wordEditorAction.addTableToContentAction.success({}));
  } catch (err) {
    yield dispatch(wordEditorAction.addTableToContentAction.failure(err));
  }
}

// Helper function để clean và format HTML trước khi convert
// Đảm bảo HTML được format đúng để Word có thể render giống preview
function prepareHtmlForWord(html) {
  if (!html) return "";

  // Tạo một DOM parser để xử lý HTML
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  // Lấy body content - giữ nguyên nội dung từ CKEditor
  const body = doc.body || doc.documentElement;

  // Clean HTML: loại bỏ các attributes không cần thiết và đảm bảo format đúng
  // html-docx-js sẽ convert HTML thành Word format, không hiển thị HTML tags
  let bodyContent = body.innerHTML;

  // Đảm bảo HTML được clean và format đúng cho Word
  // Word sẽ render HTML như nội dung, không hiển thị tags

  // Đảm bảo HTML có cấu trúc đầy đủ cho Word với styles giống preview
  // Sử dụng cùng styles như trong PreviewContent component
  const fullHtml = `<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
<meta charset='utf-8'>
<title>Document</title>
<!--[if gte mso 9]>
<xml>
<w:WordDocument>
<w:View>Print</w:View>
<w:Zoom>90</w:Zoom>
<w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml>
<![endif]-->
<style>
body {
  font-family: 'Times New Roman', Times, serif;
  font-size: 12pt;
  line-height: 1.5;
  color: #000;
  margin: 0;
  padding: 96px;
  max-width: 816px;
  margin: 0 auto;
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.1);
  min-height: 1056px;
}
p {
  margin: 0 0 12pt 0;
}
table {
  border-collapse: collapse;
  width: 100%;
  margin: 12pt 0;
}
td, th {
  border: 1px solid #000;
  padding: 8pt;
  text-align: left;
}
th {
  background-color: #f0f0f0;
  font-weight: bold;
}
h1, h2, h3, h4, h5, h6 {
  margin: 12pt 0;
  font-weight: bold;
}
ul, ol {
  margin: 12pt 0;
  padding-left: 36pt;
}
img {
  max-width: 100%;
  height: auto;
}
</style>
</head>
<body>
${bodyContent}
</body>
</html>`;

  return fullHtml;
}

// Helper function để convert HTML sang Word
async function convertHtmlToWord(html, fileName = "document.docx") {
  try {
    // Chuẩn bị HTML cho Word
    const preparedHtml = prepareHtmlForWord(html);

    // Dynamic import html-docx-js với error handling
    let htmlDocx;
    let converted;

    try {
      // Thử import html-docx-js
      // Sử dụng import() với ?url để tránh lỗi require
      const htmlDocxModule = await import("html-docx-js/dist/html-docx.js");
      htmlDocx = htmlDocxModule.default || htmlDocxModule;

      // Nếu không có default, thử lấy từ module
      if (!htmlDocx) {
        htmlDocx = htmlDocxModule;
      }

      // Kiểm tra htmlDocx có hợp lệ không
      if (!htmlDocx) {
        throw new Error("html-docx-js module không hợp lệ");
      }

      // Sử dụng html-docx-js để convert HTML sang Word
      // html-docx-js sẽ convert HTML thành Word format (.docx)
      // Word sẽ render HTML như nội dung, không hiển thị HTML tags
      // html-docx-js sử dụng altChunk để nhúng HTML vào Word, Word sẽ render HTML như nội dung
      if (typeof htmlDocx.asBlob === "function") {
        // Sử dụng asBlob method
        // html-docx-js sẽ tự động convert HTML thành Word XML format
        // File Word được tạo sẽ không hiển thị HTML tags, chỉ hiển thị nội dung đã được render
        converted = htmlDocx.asBlob(preparedHtml);
      } else if (typeof htmlDocx === "function") {
        // Nếu htmlDocx là một function
        converted = htmlDocx(preparedHtml);
      } else if (htmlDocx.asBlob) {
        // Thử truy cập trực tiếp
        converted = htmlDocx.asBlob(preparedHtml);
      } else {
        throw new Error("html-docx-js API không hợp lệ");
      }

      // Kiểm tra converted có phải là Blob không
      if (!(converted instanceof Blob)) {
        throw new Error("Kết quả convert không phải là Blob");
      }

      // Kiểm tra file có phải là Word hợp lệ không bằng magic bytes
      // File .docx phải bắt đầu với PK (0x50 0x4B) - ZIP format
      try {
        const arrayBuffer = await converted.slice(0, 4).arrayBuffer();
        const uint8Array = new Uint8Array(arrayBuffer);
        const isValidDocx = uint8Array[0] === 0x50 && uint8Array[1] === 0x4b; // PK header

        if (!isValidDocx) {
          console.warn(
            "File được tạo không có magic bytes hợp lệ (PK header), có thể không phải file Word thực sự"
          );
          // Vẫn tiếp tục vì có thể html-docx-js tạo file hợp lệ nhưng magic bytes khác
          // Hoặc file được tạo không đúng định dạng
        }
      } catch (checkErr) {}
    } catch (importErr) {
      // Fallback: Không thể tạo file Word hợp lệ từ HTML đơn giản
      // html-docx-js là cách duy nhất để tạo file Word hợp lệ từ HTML trong browser
      throw new Error(
        "Không thể tạo file Word hợp lệ. Vui lòng thử lại hoặc liên hệ hỗ trợ."
      );
    }

    // Tạo blob URL để preview - sử dụng cùng HTML đã được format như Word
    // Để preview giống với file Word sẽ được tải xuống
    const previewHtml = preparedHtml; // Sử dụng cùng HTML đã được format
    const htmlBlob = new Blob([previewHtml], { type: "text/html" });
    const blobUrl = URL.createObjectURL(htmlBlob);

    return { blob: converted, blobUrl, fileName, html: previewHtml };
  } catch (err) {
    // Fallback cuối cùng: trả về HTML blob
    const htmlBlob = new Blob([html], { type: "text/html" });
    const blobUrl = URL.createObjectURL(htmlBlob);
    return { blob: htmlBlob, blobUrl, fileName, html };
  }
}

export function* convertToWordSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(wordEditorAction.convertToWordAction.request());

    const { html, fileName = "document.docx" } = payload;

    if (!html) {
      yield dispatch(
        setMessageByFieldAction("error", {
          message: "Không có nội dung để convert",
        })
      );
      yield dispatch(wordEditorAction.convertToWordAction.failure({}));
      return;
    }

    // Convert HTML sang Word
    const result = yield call(convertHtmlToWord, html, fileName);

    yield dispatch(
      wordEditorAction.convertToWordAction.success({
        blobUrl: result.blobUrl,
        blob: result.blob,
        fileName: result.fileName,
        previewHtml: result.html, // Lưu HTML đã được format để preview
      })
    );

    yield dispatch(
      setMessageByFieldAction("success", {
        message: "Convert sang Word thành công",
      })
    );
  } catch (err) {
    yield dispatch(wordEditorAction.convertToWordAction.failure(err));
    yield dispatch(
      setMessageByFieldAction("error", {
        message: err.message || "Không thể convert sang Word",
      })
    );
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* getSchoolListSaga() {
  try {
    yield dispatch(wordEditorAction.getSchoolListAction.request());

    // Lấy danh sách school từ API
    const schoolRequest = {
      url: urlApi.managementService.school.search,
      method: "GET",
    };

    const { data: schoolRes = {} } = yield call(ApiReq.get, schoolRequest);

    // Xử lý response - có thể là array hoặc object với data
    let schoolList = [];
    if (Array.isArray(schoolRes)) {
      schoolList = schoolRes;
    } else if (schoolRes?.data && Array.isArray(schoolRes.data)) {
      schoolList = schoolRes.data;
    } else if (schoolRes?.meta?.code === responseCode["IL-200"]) {
      schoolList = Array.isArray(schoolRes.data) ? schoolRes.data : [];
    }

    // Map school list thành options format: { value: code, label: name }
    const schoolOptions = schoolList.map((school) => ({
      value: school.code || school.schoolCode || String(school.id || ""),
      label: school.name || school.schoolName || "",
      ...school,
    }));

    // Tạo year options từ helper function
    const yearOptions = createYearOpt(false);

    yield dispatch(
      wordEditorAction.getSchoolListAction.success({
        schoolOptions,
        yearOptions,
      })
    );
  } catch (err) {
    yield dispatch(wordEditorAction.getSchoolListAction.failure(err));
  }
}

export function* loadStudentQualityTableSaga() {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(wordEditorAction.loadStudentQualityTableAction.request());

    const request = {
      url: urlApi.managementService.report.reportDefinition,
    };

    const { data: res = {} } = yield call(ApiReq.get, request);
    const { meta = {}, data = [] } = res;

    if (meta.code === responseCode["IL-200"]) {
      const tables = [];

      data.forEach((elem) => {
        elem.html = convertDataToHtmlTable(elem);
        tables.push(elem);
      });

      yield dispatch(
        wordEditorAction.loadStudentQualityTableAction.success({ tables })
      );

      yield dispatch(
        setMessageByFieldAction("success", {
          message: "Tải dữ liệu chất lượng học sinh thành công",
        })
      );
    } else {
      yield dispatch(
        wordEditorAction.loadStudentQualityTableAction.failure(meta)
      );
      yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(wordEditorAction.loadStudentQualityTableAction.failure(err));
    yield dispatch(
      setMessageByFieldAction("error", {
        message: err.message || "Không thể tải dữ liệu chất lượng học sinh",
      })
    );
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* removeTableSaga({ payload }) {
  try {
    yield dispatch(wordEditorAction.removeTableAction.request(payload));
    yield dispatch(wordEditorAction.removeTableAction.success({}));
  } catch (err) {
    yield dispatch(wordEditorAction.removeTableAction.failure(err));
  }
}

export function* clearDataSaga() {
  try {
    yield dispatch(wordEditorAction.clearDataAction.request());
    yield dispatch(wordEditorAction.clearDataAction.success({}));
  } catch (err) {
    yield dispatch(wordEditorAction.clearDataAction.failure(err));
  }
}

// Helper function để loại bỏ tất cả HTML tags, chỉ giữ lại text content
function cleanHtml(html) {
  if (!html || typeof html !== "string") {
    return "";
  }

  try {
    // Kiểm tra xem DOMParser có sẵn không (có thể không có trong Node.js environment)
    if (typeof DOMParser === "undefined") {
      // Fallback: sử dụng regex để loại bỏ tất cả HTML tags
      return html
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "")
        .replace(/<[^>]+>/g, "") // Loại bỏ tất cả HTML tags
        .replace(/&nbsp;/g, " ") // Thay &nbsp; bằng space
        .replace(/&amp;/g, "&") // Decode HTML entities
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/\s+/g, " ") // Normalize whitespace
        .trim();
    }

    // Tạo một DOM parser để parse HTML
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    // Lấy text content từ body (tự động loại bỏ tất cả HTML tags)
    const body = doc.body || doc.documentElement;
    const textContent = body.textContent || body.innerText || "";

    // Normalize whitespace và trim
    return textContent.replace(/\s+/g, " ").trim();
  } catch (err) {
    // Fallback: sử dụng regex để loại bỏ tất cả HTML tags
    return html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "")
      .replace(/<[^>]+>/g, "") // Loại bỏ tất cả HTML tags
      .replace(/&nbsp;/g, " ") // Thay &nbsp; bằng space
      .replace(/&amp;/g, "&") // Decode HTML entities
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, " ") // Normalize whitespace
      .trim();
  }
}

export function* exportWordV2Saga() {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(wordEditorAction.exportWordV2Action.request());

    // Lấy wordHtml từ store
    const state = yield select((state) => state);
    const wordHtml = state[injectKey.wordEditor]?.wordHtml || "";
    const previewHtml = state[injectKey.wordEditor]?.previewHtml || "";
    const tablesAll = state[injectKey.wordEditor]?.tablesAll || [];
    const file = state[injectKey.wordEditor]?.file;

    // Sử dụng previewHtml nếu có, nếu không thì dùng wordHtml
    let htmlContent = previewHtml || wordHtml;

    if (!htmlContent) {
      yield dispatch(wordEditorAction.exportWordV2Action.failure({}));
      yield dispatch(
        setMessageByFieldAction("error", {
          message: "Không có nội dung để gửi",
        })
      );
      return;
    }

    const idReportDefinition = [];

    tablesAll.forEach((_tab) => {
      const _html = convertDataToHtmlTable(_tab, true);

      if (htmlContent.includes(_html)) {
        idReportDefinition.push(_tab.id);

        htmlContent = htmlContent.replace(_html, "");
      }
    });

    // Làm sạch HTML trước khi gửi
    // const cleanedTemplate = cleanHtml(htmlContent);

    const formData = new FormData();

    formData.append("template", file);

    const request = {
      url: urlApi.managementService.report.exportWordV2,
      method: "POST",
      params: {
        idReportDefinition: idReportDefinition.join(),
      },
      data: formData,
      multipart: true,
      responseType: "blob", // Để nhận file blob từ API
    };

    const response = yield call(ApiReq.post, request);
    const { data: res, headers = {} } = response || {};

    if (res) {
      yield dispatch(wordEditorAction.exportWordV2Action.success(res));

      // Tự động download file
      try {
        let blob;
        let fileName = "bao-cao.docx";

        // Kiểm tra nếu response.data là Blob (khi responseType: "blob")
        if (res instanceof Blob) {
          blob = res;
        } else if (res.data && res.data instanceof Blob) {
          blob = res.data;
        } else if (response.data instanceof Blob) {
          // Nếu response.data trực tiếp là Blob
          blob = response.data;
        }

        // Lấy tên file từ Content-Disposition header nếu có
        const contentDisposition = headers["content-disposition"] || headers["Content-Disposition"];
        if (contentDisposition) {
          const fileNameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
          if (fileNameMatch && fileNameMatch[1]) {
            fileName = fileNameMatch[1].replace(/['"]/g, "");
            // Decode filename nếu là URL encoded
            try {
              fileName = decodeURIComponent(fileName);
            } catch {
              // Nếu không decode được, giữ nguyên
            }
          }
        }

        // Nếu có blob, tự động download
        if (blob) {
          const blobUrl = window.URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = blobUrl;
          link.download = fileName;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          // Cleanup blob URL sau một chút để đảm bảo download đã bắt đầu
          setTimeout(() => {
            window.URL.revokeObjectURL(blobUrl);
          }, 100);
        }
      } catch (downloadErr) {
        // Nếu không thể download, chỉ log error nhưng vẫn hiển thị success message
        // Không throw error để không làm gián đoạn flow
         
        console.error("Error downloading file:", downloadErr);
      }

      yield dispatch(
        setMessageByFieldAction("success", {
          message: "Gửi báo cáo thành công",
        })
      );
    } else {
      yield dispatch(wordEditorAction.exportWordV2Action.failure({}));
      yield dispatch(
        setMessageByFieldAction("error", {
          message: "Không nhận được phản hồi từ server",
        })
      );
    }
  } catch (err) {
    yield dispatch(wordEditorAction.exportWordV2Action.failure(err));
    yield dispatch(
      setMessageByFieldAction("error", {
        message: err.message || "Không thể gửi báo cáo",
      })
    );
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(wordEditorAction.readWordFileAction.TRIGGER, readWordFileSaga),
    takeLatest(
      wordEditorAction.updateWordContentAction.TRIGGER,
      updateWordContentSaga
    ),
    takeLatest(
      wordEditorAction.addTableToContentAction.TRIGGER,
      addTableToContentSaga
    ),
    takeLatest(wordEditorAction.convertToWordAction.TRIGGER, convertToWordSaga),
    takeLatest(wordEditorAction.getSchoolListAction.TRIGGER, getSchoolListSaga),
    takeLatest(
      wordEditorAction.loadStudentQualityTableAction.TRIGGER,
      loadStudentQualityTableSaga
    ),
    takeLatest(wordEditorAction.exportWordV2Action.TRIGGER, exportWordV2Saga),
    takeLatest(wordEditorAction.removeTableAction.TRIGGER, removeTableSaga),
    takeLatest(wordEditorAction.clearDataAction.TRIGGER, clearDataSaga),
  ]);
}
