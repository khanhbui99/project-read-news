export function convertDataToHtmlTable(item, isRemoveTable) {
  if(isRemoveTable) return `<h3>${item.name}</h3><figure class="table"><table><thead><tr><th>Cột 1</th><th>Cột 2</th><th>Cột 3</th></tr></thead><tbody><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></figure>`
  // ${item.markedData}

  let html = `
  <table style="width: 100%; border-collapse: collapse; border: 1px solid #ddd; font-size: 13px; table-layout: fixed;">
    <h3>${item.name}</h3>
    <thead>
      <tr style="background: linear-gradient(135deg, #f0f0f0, #e0e0e0);">
        <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Cột 1</th>
        <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Cột 2</th>
        <th style="border: 1px solid #ddd; padding: 10px; text-align: center;">Cột 3</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style="border: 1px solid #ddd; padding: 10px; height: 32px;"></td>
        <td style="border: 1px solid #ddd; padding: 10px; height: 32px;"></td>
        <td style="border: 1px solid #ddd; padding: 10px; height: 32px;"></td>
      </tr>
    </tbody>
  </table>
  `;

  return html;
}
