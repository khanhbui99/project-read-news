import AppHeader from "components/common/AppHeader";
import React, { useCallback, useEffect } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import TableList from "./components/TableList";
import WordPreview from "./components/WordPreview";
import WordPreviewModal from "./components/WordPreviewModal";
import WordUpload from "./components/WordUpload";
import { removeTableAction } from "./store/actions";
import { ContainerStyled, ContentWrapper, TwoColumnLayout } from "./Styled";

const Main = () => {
  const fileName = useOneState(injectKey.wordEditor, "fileName");
  const rqRemoveTable = useDispatchRedux(removeTableAction);

  const handleTableDropped = useCallback(
    (tableId) => {
      // Remove table khỏi danh sách sau khi drop thành công
      rqRemoveTable({ tableId });
    },
    [rqRemoveTable]
  );

  return (
    <React.Fragment>
      <AppHeader isHiddenBtn componentName="WordEditor" />
      <ContainerStyled>
        <ContentWrapper>
          <WordUpload />

          {/* Chỉ hiển thị phần 2 và 3 khi có file được upload */}
          {fileName && (
            <TwoColumnLayout>
              <WordPreview onTableDropped={handleTableDropped} />
              <TableList />
            </TwoColumnLayout>
          )}
        </ContentWrapper>
      </ContainerStyled>
      <WordPreviewModal />
    </React.Fragment>
  );
};

export default Main;

