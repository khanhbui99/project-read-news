import { createRoutine } from "redux-saga-routines";

import * as classroomManagementConst from "./constants";

export const resetStoreClassroomManagementAction = () => {
  return {
    type: classroomManagementConst.RESET_STORE_CLASSROOM_MANAGEMENT_ACTION,
  };
};

export const setFieldValueStoreClassroomManagementAction = (field, value) => {
  return {
    type: classroomManagementConst.SET_FIELD_VALUE_STORE_CLASSROOM_MANAGEMENT_ACTION,
    payload: { field, value },
  };
};

export const queryClassroomManagementAction = createRoutine(classroomManagementConst.QUERY_CLASSROOM_MANAGEMENT_ACTION);
export const getClassroomManagementDetailAction = createRoutine(classroomManagementConst.GET_CLASSROOM_MANAGEMENT_DETAIL_ACTION);
export const createClassroomManagementAction = createRoutine(classroomManagementConst.CREATE_CLASSROOM_MANAGEMENT_ACTION);
export const updateClassroomManagementAction = createRoutine(classroomManagementConst.UPDATE_CLASSROOM_MANAGEMENT_ACTION);
export const deleteClassroomManagementAction = createRoutine(classroomManagementConst.DELETE_CLASSROOM_MANAGEMENT_ACTION);

