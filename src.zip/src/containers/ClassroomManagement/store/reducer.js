import { produce } from "immer";

import * as classroomManagementAction from "./actions";
import {
  RESET_STORE_CLASSROOM_MANAGEMENT_ACTION,
  SET_FIELD_VALUE_STORE_CLASSROOM_MANAGEMENT_ACTION,
} from "./constants";

export const initialState = {
  total: 0,
  items: [],
  size: 10,
  page: 0,

  detail: {
    id: 0,
    code: "",
    name: "",
    description: "",
    teacherId: null,
    year: "",
    semester: null,
    subjectId: null,
  },

  selectedTeacherId: null,

  isModalCreateOrUpdate: false,
};

const reducer = (state = initialState, { payload = {}, type }) =>
  produce(state, (dr) => {
    const draft = dr;
    switch (type) {
      // ------------ Redux ------------ //
      case RESET_STORE_CLASSROOM_MANAGEMENT_ACTION: {
        return { ...initialState };
      }
      case SET_FIELD_VALUE_STORE_CLASSROOM_MANAGEMENT_ACTION: {
        draft[payload.field] = payload.value;
        break;
      }

      // ---------- Redux And Saga ------- //
      // list
      case classroomManagementAction.queryClassroomManagementAction.REQUEST: {
        break;
      }
      case classroomManagementAction.queryClassroomManagementAction.SUCCESS: {
        draft.items = payload.items || payload.data || [];
        draft.total = payload.total || payload.meta?.total || 0;
        break;
      }
      case classroomManagementAction.queryClassroomManagementAction.FAILURE: {
        break;
      }

      // detail
      case classroomManagementAction.getClassroomManagementDetailAction.REQUEST: {
        break;
      }
      case classroomManagementAction.getClassroomManagementDetailAction.SUCCESS: {
        draft.detail = payload.data || payload;
        draft.isModalCreateOrUpdate = true;
        break;
      }
      case classroomManagementAction.getClassroomManagementDetailAction.FAILURE: {
        break;
      }

      // create
      case classroomManagementAction.createClassroomManagementAction.REQUEST: {
        break;
      }
      case classroomManagementAction.createClassroomManagementAction.SUCCESS: {
        draft.total = state.total + 1;
        draft.items.unshift(payload.data || payload);
        draft.isModalCreateOrUpdate = false;
        break;
      }
      case classroomManagementAction.createClassroomManagementAction.FAILURE: {
        break;
      }

      // update
      case classroomManagementAction.updateClassroomManagementAction.REQUEST: {
        break;
      }
      case classroomManagementAction.updateClassroomManagementAction.SUCCESS: {
        const index = state.items.findIndex((el) => el.id === payload.id || (payload.data && el.id === payload.data.id));

        if (index === -1) return;

        draft.items[index] = { ...state.items[index], ...(payload.data || payload) };
        draft.isModalCreateOrUpdate = false;
        break;
      }
      case classroomManagementAction.updateClassroomManagementAction.FAILURE: {
        break;
      }

      // delete
      case classroomManagementAction.deleteClassroomManagementAction.REQUEST: {
        break;
      }
      case classroomManagementAction.deleteClassroomManagementAction.SUCCESS: {
        draft.items = state.items.filter((el) => el.id !== payload);
        draft.total = state.total - 1;
        break;
      }
      case classroomManagementAction.deleteClassroomManagementAction.FAILURE: {
        break;
      }

      default:
        break;
    }
  });

export default reducer;

