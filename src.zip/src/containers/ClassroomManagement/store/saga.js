import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import { all, put as dispatch, select, takeLatest } from "redux-saga/effects";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { responseCode } from "utils/constants";
import injectKey from "utils/injectKey";

import * as classroomManagementAction from "./actions";

export function* queryClassroomManagementSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      classroomManagementAction.queryClassroomManagementAction.request()
    );

    const request = {
      url: urlApi.classRooms.listByTeacher(payload?.teacherId),
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // Mapping thêm subjectName và teacherName cho danh sách
        const state = yield select();
        const subjectOpt = state[injectKey.GLOBAL]?.subjectOpt || [];
        const userOpt = state[injectKey.GLOBAL]?.userOpt || [];

        const mappedItems = data.map((item) => {
          const subject = subjectOpt.find(
            (s) => String(s.id) === String(item.subjectId)
          );
          const teacher = userOpt.find(
            (u) => String(u.id) === String(item.teacherId)
          );

          return {
            ...item,
            subjectName:
              subject?.name || subject?.subjectName || item.subjectName || "",
            teacherName:
              teacher?.name || teacher?.userName || item.teacherName || "",
          };
        });

        yield dispatch(
          classroomManagementAction.queryClassroomManagementAction.success({
            items: mappedItems,
            total: meta.total || mappedItems.length,
            ...meta,
          })
        );
        break;
      }
      default:
        yield dispatch(
          classroomManagementAction.queryClassroomManagementAction.failure(meta)
        );
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(
      classroomManagementAction.queryClassroomManagementAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* getClassroomManagementDetailSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      classroomManagementAction.getClassroomManagementDetailAction.request()
    );

    const request = {
      url: urlApi.classRooms.detail(payload),
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield dispatch(
          classroomManagementAction.getClassroomManagementDetailAction.success(
            data
          )
        );
        break;
      default:
        yield dispatch(
          classroomManagementAction.getClassroomManagementDetailAction.failure(
            meta
          )
        );
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(
      classroomManagementAction.getClassroomManagementDetailAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* createClassroomManagementSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      classroomManagementAction.createClassroomManagementAction.request()
    );

    const request = {
      url: urlApi.classRooms.create,
      data: payload,
    };

    const { data: res = {} } = yield ApiReq.post(request);
    const { meta = {}, data } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // Mapping thêm subjectName và teacherName
        const state = yield select();
        const subjectOpt = state[injectKey.GLOBAL]?.subjectOpt || [];
        const userOpt = state[injectKey.GLOBAL]?.userOpt || [];

        const subject = subjectOpt.find(
          (s) => String(s.id) === String(payload.subjectId)
        );
        const teacher = userOpt.find(
          (u) => String(u.id) === String(payload.teacherId)
        );

        const mappedData = {
          ...data,
          subjectName: subject?.name || subject?.subjectName || "",
          teacherName: teacher?.name || teacher?.userName || "",
        };

        yield dispatch(
          classroomManagementAction.createClassroomManagementAction.success(
            mappedData
          )
        );
        yield dispatch(setMessageByFieldAction("success", meta));
        break;
      }
      default: {
        yield dispatch(
          classroomManagementAction.createClassroomManagementAction.failure(
            meta
          )
        );
        yield dispatch(setMessageByFieldAction("error", meta));
      }
    }
  } catch (err) {
    yield dispatch(
      classroomManagementAction.createClassroomManagementAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* updateClassroomManagementSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      classroomManagementAction.updateClassroomManagementAction.request()
    );

    const { id, ...data } = payload;

    const request = {
      url: urlApi.classRooms.update(id),
      data,
    };

    const { data: res = {} } = yield ApiReq.put(request);
    const { meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // Mapping thêm subjectName và teacherName
        const state = yield select();
        const subjectOpt = state[injectKey.GLOBAL]?.subjectOpt || [];
        const userOpt = state[injectKey.GLOBAL]?.userOpt || [];

        const subject = subjectOpt.find(
          (s) => String(s.id) === String(payload.subjectId)
        );
        const teacher = userOpt.find(
          (u) => String(u.id) === String(payload.teacherId)
        );

        const mappedPayload = {
          ...payload,
          subjectName: subject?.name || subject?.subjectName || "",
          teacherName: teacher?.name || teacher?.userName || "",
        };

        yield dispatch(
          classroomManagementAction.updateClassroomManagementAction.success(
            mappedPayload
          )
        );
        yield dispatch(setMessageByFieldAction("success", meta));
        break;
      }

      default: {
        yield dispatch(
          classroomManagementAction.updateClassroomManagementAction.failure(
            meta
          )
        );
        yield dispatch(setMessageByFieldAction("error", meta));
      }
    }
  } catch (err) {
    yield dispatch(
      classroomManagementAction.updateClassroomManagementAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* deleteClassroomManagementSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      classroomManagementAction.deleteClassroomManagementAction.request()
    );

    const request = {
      url: urlApi.classRooms.delete(payload),
    };

    const { data: res = {} } = yield ApiReq.del(request);
    const { meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        yield dispatch(
          classroomManagementAction.deleteClassroomManagementAction.success(
            payload
          )
        );
        yield dispatch(setMessageByFieldAction("success", meta));
        yield dispatch(
          classroomManagementAction.queryClassroomManagementAction()
        );
        break;
      }

      default: {
        yield dispatch(
          classroomManagementAction.deleteClassroomManagementAction.failure(
            meta
          )
        );
        yield dispatch(setMessageByFieldAction("error", meta));
      }
    }
  } catch (err) {
    yield dispatch(
      classroomManagementAction.deleteClassroomManagementAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(
      classroomManagementAction.queryClassroomManagementAction.TRIGGER,
      queryClassroomManagementSaga
    ),
    takeLatest(
      classroomManagementAction.getClassroomManagementDetailAction.TRIGGER,
      getClassroomManagementDetailSaga
    ),
    takeLatest(
      classroomManagementAction.createClassroomManagementAction.TRIGGER,
      createClassroomManagementSaga
    ),
    takeLatest(
      classroomManagementAction.updateClassroomManagementAction.TRIGGER,
      updateClassroomManagementSaga
    ),
    takeLatest(
      classroomManagementAction.deleteClassroomManagementAction.TRIGGER,
      deleteClassroomManagementSaga
    ),
  ]);
}
