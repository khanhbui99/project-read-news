import { getAllSubjectAction } from "App/store/actions";
import React, { useEffect, useMemo } from "react";
import { isSystemAdmin } from "utils/helpers";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import Header from "./components/Header";
import ModalCreateUpdate from "./components/ModalCreateUpdate";
import Table from "./components/Table";
import {
  resetStoreClassroomManagementAction,
} from "./store/actions";

const Main = () => {
  const fetchGetAllSubjects = useDispatchRedux(getAllSubjectAction);
  const resetClassroomManagementStore = useDispatchRedux(
    resetStoreClassroomManagementAction
  );

  const subjectOpt = useOneState(injectKey.GLOBAL, "subjectOpt");

  const isAdmin = useMemo(() => isSystemAdmin(), []);

  useEffect(() => {
    fetchGetAllSubjects();

    return () => {
      resetClassroomManagementStore();
    };
  }, []);

  return (
    <React.Fragment>
      <Header isSystemAdmin={isAdmin}/>
      <Table />
      <ModalCreateUpdate subjectOpt={subjectOpt} isSystemAdmin={isAdmin} />
    </React.Fragment>
  );
};

export default Main;
