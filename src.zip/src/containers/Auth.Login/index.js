import LoadingIndicator from 'components/common/LoadingIndicator';
import loadable from 'utils/loadable';

const Provider = ({ children }) => <>{children}</>;

const Login = loadable(() => import('./Login'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export default Login;
