import { cleanErrorMessage, loginAction } from "App/store/actions";
import { useFormik } from "formik";
import { useSnackbar } from "notistack";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import BrandingSection from "./components/BrandingSection";
import LoginFormSection from "./components/LoginFormSection";
import { LoginStyle, LoginContainer } from "./LoginStyle";
import SigninSchema from "./Validation";

const Login = () => {
  const dispatch = useDispatch();
  const errorMessage = useSelector((state) => state.global?.errorMessage);
  const { enqueueSnackbar } = useSnackbar();

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
      // rememberMe: false,
    },
    validationSchema: SigninSchema,
    onSubmit: async (data) => {
      dispatch(loginAction({ ...data }));
    },
  });

  useEffect(() => {
    if (!errorMessage) return;

    enqueueSnackbar(errorMessage, {
      variant: "error",
    });
    dispatch(cleanErrorMessage());
  }, [errorMessage, enqueueSnackbar, dispatch]);

  return (
    <LoginStyle>
      <LoginContainer>
        <BrandingSection />

        <LoginFormSection
          formik={formik}
        />
      </LoginContainer>
    </LoginStyle>
  );
};

export default Login;
