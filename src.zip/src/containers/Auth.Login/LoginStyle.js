import styled, { keyframes, css } from 'styled-components';
import { VPB_THEMES } from 'utils/configs';

// Animations
const pulse = keyframes`
  0%, 100% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.1);
    opacity: 0.5;
  }
`;

const slideDown = keyframes`
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;

const spin = keyframes`
  to { transform: translateY(-50%) rotate(360deg); }
`;

// Main container
export const LoginStyle = styled.div`
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: linear-gradient(315deg, ${VPB_THEMES.colors.secondaryBlue} 0%, ${VPB_THEMES.colors.lightBlue} 50%, ${VPB_THEMES.colors.white} 100%);
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  contain: layout style paint;
  isolation: isolate;


  /* Disable animations if user prefers reduced motion */
  @media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }
`;

// Main login container
export const LoginContainer = styled.div`
  position: relative;
  z-index: 10;
  width: 100%;
  max-width: 1200px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  background: white;
  border-radius: 24px;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  margin: 20px;
  contain: layout style paint;
  will-change: auto;

  @media (max-width: 968px) {
    grid-template-columns: 1fr;
    max-width: 500px;
  }

  @media (max-width: 480px) {
    margin: 10px;
    border-radius: 16px;
  }
`;

// Left side - Branding
export const BrandingSection = styled.div`
  background: ${VPB_THEMES.gradient['1']};
  padding: 60px 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    width: 500px;
    height: 500px;
    background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
    top: -200px;
    right: -200px;
    border-radius: 50%;
  }

  &::after {
    content: '';
    position: absolute;
    width: 300px;
    height: 300px;
    background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
    bottom: -100px;
    left: -100px;
    border-radius: 50%;
  }

  @media (max-width: 968px) {
    padding: 40px 30px;
  }

  @media (max-width: 480px) {
    padding: 30px 20px;
  }
`;

export const LogoContainer = styled.div`
  position: relative;
  z-index: 2;
  text-align: center;
  margin-bottom: 40px;
`;

export const LogoWrapper = styled.div`
  background: white;
  width: 120px;
  height: 120px;
  border-radius: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 24px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
  position: relative;

  &::before {
    content: '';
    position: absolute;
    width: 140px;
    height: 140px;
    border: 3px solid rgba(255,255,255,0.3);
    border-radius: 28px;
    ${css`animation: ${pulse} 2s ease-in-out infinite;`}
  }

  @media (max-width: 480px) {
    width: 90px;
    height: 90px;
  }
`;

export const LogoIconWrapper = styled.div`
  font-size: 64px;
  color: ${VPB_THEMES.colors.primaryBlue};
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;

  @media (max-width: 480px) {
    font-size: 48px;
  }
`;

export const BrandTitle = styled.h1`
  color: white;
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 16px;
  text-shadow: 0 2px 4px rgba(0,0,0,0.1);

  @media (max-width: 968px) {
    font-size: 24px;
  }

  @media (max-width: 480px) {
    font-size: 20px;
  }
`;

export const BrandSubtitle = styled.p`
  color: rgba(255,255,255,0.95);
  font-size: 18px;
  font-weight: 500;
  line-height: 1.6;
  max-width: 400px;
  margin: 0 auto;
  text-align: center;

  @media (max-width: 968px) {
    font-size: 16px;
  }

  @media (max-width: 480px) {
    font-size: 14px;
  }
`;

export const FeaturesList = styled.div`
  position: relative;
  z-index: 2;
  margin-top: 50px;
  text-align: left;
  width: 100%;

  @media (max-width: 968px) {
    display: none;
  }
`;

export const FeatureItem = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 20px;
  color: white;
`;

export const FeatureIcon = styled.div`
  width: 48px;
  height: 48px;
  background: rgba(255,255,255,0.2);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  
  svg {
    font-size: 20px;
    color: white;
  }
`;

export const FeatureText = styled.div`
  font-size: 14px;
  line-height: 1.6;

  strong {
    display: block;
    margin-bottom: 4px;
    font-size: 15px;
  }
`;

// Right side - Login form
export const LoginSection = styled.div`
  padding: 60px 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;

  @media (max-width: 968px) {
    padding: 40px 30px;
  }

  @media (max-width: 480px) {
    padding: 30px 20px;
  }
`;

export const LoginHeader = styled.div`
  margin-bottom: 40px;

  h2 {
    font-size: 32px;
    color: ${VPB_THEMES.colors.textDark};
    margin-bottom: 12px;
    font-weight: 700;

    @media (max-width: 480px) {
      font-size: 24px;
    }
  }

  p {
    color: ${VPB_THEMES.colors.textLight};
    font-size: 15px;
  }
`;

export const LoginForm = styled.form`
  width: 100%;
`;

export const FormGroup = styled.div`
  margin-bottom: 24px;
`;

export const FormLabel = styled.label`
  display: block;
  font-size: 14px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark};
  margin-bottom: 8px;
`;

export const Required = styled.span`
  color: ${VPB_THEMES.colors.red};
`;

export const InputWrapper = styled.div`
  position: relative;
`;

export const InputIconWrapper = styled.div`
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: ${VPB_THEMES.colors.textLight};
  font-size: 18px;
  z-index: 1;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const FormControl = styled.input`
  width: 100%;
  padding: 14px 16px 14px 48px;
  border: 2px solid ${VPB_THEMES.colors.gray[200]};
  border-radius: 12px;
  font-size: 15px;
  transition: border-color 0.2s, background-color 0.2s, box-shadow 0.2s;
  background: ${VPB_THEMES.colors.lightBg};
  font-family: inherit;
  will-change: auto;

  &:focus {
    outline: none;
    border-color: ${VPB_THEMES.colors.primaryBlue};
    background: ${VPB_THEMES.colors.white};
    box-shadow: 0 0 0 4px ${VPB_THEMES.colors.primaryBlue}1A;
  }

  &::placeholder {
    color: ${VPB_THEMES.colors.textLight};
  }
`;

export const PasswordToggle = styled.button`
  position: absolute;
  right: 16px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: ${VPB_THEMES.colors.textLight};
  cursor: pointer;
  font-size: 18px;
  padding: 4px;
  transition: color 0.3s;
  z-index: 1;

  &:hover {
    color: ${VPB_THEMES.colors.primaryBlue};
  }
`;

export const FormFooter = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
`;

export const RememberMe = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;

  input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: ${VPB_THEMES.colors.primaryBlue};
  }

  label {
    font-size: 14px;
    color: ${VPB_THEMES.colors.textDark};
    cursor: pointer;
    user-select: none;
  }
`;

export const ForgotPassword = styled.a`
  font-size: 14px;
  color: ${VPB_THEMES.colors.primaryBlue};
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s;

  &:hover {
    color: ${VPB_THEMES.colors.darkBlue};
    text-decoration: underline;
  }
`;

export const BtnLogin = styled.button`
  width: 100%;
  padding: 16px;
  background: ${VPB_THEMES.gradient['1']};
  color: ${VPB_THEMES.colors.white};
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 4px 12px ${VPB_THEMES.colors.primaryBlue}4D;
  position: relative;
  overflow: hidden;
  font-family: inherit;
  will-change: auto;

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
    will-change: left;
  }

  &:hover::before {
    left: 100%;
  }

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px ${VPB_THEMES.colors.primaryBlue}66;
  }

  &:active {
    transform: translateY(0);
  }

  &.loading {
    pointer-events: none;
    position: relative;

    &::after {
      content: '';
      position: absolute;
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255,255,255,0.3);
      border-top-color: white;
      border-radius: 50%;
      right: 16px;
      top: 50%;
      transform: translateY(-50%);
      ${css`animation: ${spin} 0.6s linear infinite;`}
      will-change: transform;
    }
  }
`;

export const Divider = styled.div`
  display: flex;
  align-items: center;
  margin: 32px 0;
  color: ${VPB_THEMES.colors.textLight};
  font-size: 14px;

  &::before,
  &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: ${VPB_THEMES.colors.gray[200]};
  }

  &::before {
    margin-right: 16px;
  }

  &::after {
    margin-left: 16px;
  }
`;

export const DemoAccounts = styled.div`
  background: ${VPB_THEMES.colors.lightBg};
  padding: 20px;
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
`;

export const DemoAccountsTitle = styled.h3`
  font-size: 14px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark};
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
`;

export const DemoAccount = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
  font-size: 13px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
  cursor: pointer;
  transition: background-color 0.3s;

  &:last-child {
    border-bottom: none;
  }

  &:hover {
    background-color: ${VPB_THEMES.colors.primaryBlue}1A;
  }
`;

export const DemoLabel = styled.span`
  color: ${VPB_THEMES.colors.textDark};
  font-weight: 500;
`;

export const DemoCredentials = styled.div`
  display: flex;
  gap: 12px;
  color: ${VPB_THEMES.colors.primaryBlue};
  font-weight: 600;

  @media (max-width: 480px) {
    flex-direction: column;
    gap: 4px;
    align-items: flex-end;
  }
`;

export const LoginFooter = styled.div`
  margin-top: 30px;
  text-align: center;
  font-size: 13px;
  color: ${VPB_THEMES.colors.textLight};
`;

export const Alert = styled.div`
  padding: 12px 16px;
  border-radius: 8px;
  margin-bottom: 20px;
  display: ${props => props.show ? 'block' : 'none'};
  ${css`animation: ${slideDown} 0.3s ease;`}

  &.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
  }

  &.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
  }
`;

export default LoginStyle;
