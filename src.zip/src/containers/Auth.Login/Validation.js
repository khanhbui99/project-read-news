import * as Yup from 'yup';

const SigninSchema = Yup.object().shape({
  email: Yup.string().required('Vui lòng nhập email'),
  password: Yup.string().required('Vui lòng nhập mật khẩu'),
});

export default SigninSchema;
