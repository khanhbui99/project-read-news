import {
  School as SchoolIcon,
  TrendingUp as TrendingUpIcon,
  Psychology as PsychologyIcon,
  Assignment as AssignmentIcon,
} from "@mui/icons-material";
import { memo } from "react";

import {
  BrandingSection,
  LogoContainer,
  LogoWrapper,
  LogoIconWrapper,
  BrandTitle,
  BrandSubtitle,
  FeaturesList,
  FeatureItem,
  FeatureIcon,
  FeatureText,
} from "../LoginStyle";

// Move features array outside component to avoid recreation on every render
const features = [
  {
    icon: <SchoolIcon />,
    title: "Quản lý trường học toàn diện",
    description: "Số hóa mọi quy trình quản trị từ hành chính đến học vụ",
  },
  {
    icon: <TrendingUpIcon />,
    title: "Nâng cao chất lượng học sinh",
    description: "Theo dõi, phân tích và cải thiện kết quả học tập liên tục",
  },
  {
    icon: <PsychologyIcon />,
    title: "Phát triển giáo dục toàn diện",
    description: "Hỗ trợ giảng dạy hiện đại, phương pháp sư phạm tiên tiến",
  },
  {
    icon: <AssignmentIcon />,
    title: "Đánh giá & Báo cáo thông minh",
    description: "Dữ liệu thời gian thực, báo cáo chi tiết, ra quyết định chính xác",
  },
];

const BrandingSectionComponent = memo(() => {

  return (
    <BrandingSection>
      <LogoContainer>
        <LogoWrapper>
          <LogoIconWrapper>
            <SchoolIcon style={{ fontSize: "inherit", color: "inherit" }} />
          </LogoIconWrapper>
        </LogoWrapper>
        <BrandTitle>THCS CẦU GIẤY</BrandTitle>
        <BrandSubtitle>
          Hệ Thống Quản Trị<br />
          Trường Học Số - Cầu Giấy Digital School
        </BrandSubtitle>
      </LogoContainer>

      <FeaturesList>
        {features.map((feature, index) => (
          <FeatureItem key={index}>
            <FeatureIcon>{feature.icon}</FeatureIcon>
            <FeatureText>
              <strong>{feature.title}</strong>
              {feature.description}
            </FeatureText>
          </FeatureItem>
        ))}
      </FeaturesList>
    </BrandingSection>
  );
});

BrandingSectionComponent.displayName = "BrandingSection";

export default BrandingSectionComponent;

