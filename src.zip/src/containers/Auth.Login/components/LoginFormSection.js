import {
  Person as PersonIcon,
  Lock as LockIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  Login as LoginIcon,
} from "@mui/icons-material";
import { FocusError } from "focus-formik-error";
import get from "lodash/get";
import PropTypes from "prop-types";
import { memo, useState, useCallback } from "react";
import { VPB_THEMES } from "utils/configs";

import {
  LoginSection,
  LoginHeader,
  LoginForm,
  FormGroup,
  FormLabel,
  Required,
  InputWrapper,
  InputIconWrapper,
  FormControl,
  PasswordToggle,
  BtnLogin,
} from "../LoginStyle";

const LoginFormSection = memo(({ formik }) => {
  const [showPassword, setShowPassword] = useState(false);

  const errMessage = useCallback((name) =>
    get(formik, `touched[${name}]`)
      ? get(formik, `errors[${name}]`)
      : undefined,
    [formik]
  );

  const handlePasswordToggle = useCallback(() => {
    setShowPassword((prev) => !prev);
  }, []);

  return (
    <LoginSection>
      <LoginHeader>
        <h2>Đăng nhập</h2>
        <p>Chào mừng trở lại! Vui lòng đăng nhập để tiếp tục.</p>
      </LoginHeader>

      <LoginForm onSubmit={formik.handleSubmit}>
        <FocusError formik={formik} />

        <FormGroup>
          <FormLabel>
            Tên đăng nhập <Required>*</Required>
          </FormLabel>
          <InputWrapper>
            <InputIconWrapper>
              <PersonIcon style={{ fontSize: "18px" }} />
            </InputIconWrapper>
            <FormControl
              type="text"
              name="email"
              placeholder="Nhập tên đăng nhập"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              autoComplete="username"
            />
          </InputWrapper>
          {errMessage("email") && (
            <div
              style={{ color: VPB_THEMES.colors.red, fontSize: "12px", marginTop: "4px" }}
            >
              {errMessage("email")}
            </div>
          )}
        </FormGroup>

        <FormGroup>
          <FormLabel>
            Mật khẩu <Required>*</Required>
          </FormLabel>
          <InputWrapper>
            <InputIconWrapper>
              <LockIcon style={{ fontSize: "18px" }} />
            </InputIconWrapper>
            <FormControl
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="Nhập mật khẩu"
              value={formik.values.password}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              autoComplete="current-password"
            />
            <PasswordToggle type="button" onClick={handlePasswordToggle}>
              {showPassword ? (
                <VisibilityOffIcon style={{ fontSize: "18px" }} />
              ) : (
                <VisibilityIcon style={{ fontSize: "18px" }} />
              )}
            </PasswordToggle>
          </InputWrapper>
          {errMessage("password") && (
            <div
              style={{ color: VPB_THEMES.colors.red, fontSize: "12px", marginTop: "4px" }}
            >
              {errMessage("password")}
            </div>
          )}
        </FormGroup>

        <BtnLogin type="submit">
          <LoginIcon style={{ fontSize: "18px", marginRight: "8px" }} />
          Đăng nhập
        </BtnLogin>
      </LoginForm>
    </LoginSection>
  );
});

LoginFormSection.displayName = "LoginFormSection";

LoginFormSection.propTypes = {
  formik: PropTypes.object.isRequired,
  onDemoAccountClick: PropTypes.func.isRequired,
};

export default LoginFormSection;
