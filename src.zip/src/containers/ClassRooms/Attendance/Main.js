import { Tab } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import AttendanceHistory from "./components/AttendanceHistory";
import AttendanceStatistics from "./components/AttendanceStatistics";
import Header from "./components/Header";
import ManualAttendance from "./components/ManualAttendance";
import QRCodeAttendance from "./components/QRCodeAttendance";
import {
  queryAttendanceAction,
  resetStoreAttendanceAction,
  setFieldValueStoreAttendanceAction,
} from "./store/actions";
import {
  ContainerStyled,
  ContentWrapper,
  TabPanelStyled,
  TabsStyled,
} from "./Styled";

const Main = () => {
  const [currentTab, setCurrentTab] = useState(0);
  const [selectedClassId, setSelectedClassId] = useState("");

  // Mock data - sẽ thay thế bằng API call sau
  const classOptions = [
    { value: "1", label: "Lớp 10A1" },
    { value: "2", label: "Lớp 10A2" },
    { value: "3", label: "Lớp 10A3" },
    { value: "4", label: "Lớp 11A1" },
    { value: "5", label: "Lớp 11A2" },
    { value: "6", label: "Lớp 12A1" },
  ];

  const setFieldValue = useDispatchRedux(setFieldValueStoreAttendanceAction);
  const fetchAttendance = useDispatchRedux(queryAttendanceAction);
  const resetStore = useDispatchRedux(resetStoreAttendanceAction);

  useEffect(() => {
    if (selectedClassId) {
      fetchAttendance({ classId: selectedClassId });
    }

    return () => {
      resetStore();
    };
  }, [selectedClassId]);

  useEffect(() => {
    // Set default class
    if (!selectedClassId && classOptions.length > 0) {
      setSelectedClassId(classOptions[0].value);
    }
  }, []);

  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
    setFieldValue("currentTab", newValue);
  };

  const handleClassChange = (event) => {
    const newClassId = event.target.value;
    setSelectedClassId(newClassId);
    setFieldValue("selectedClassId", newClassId);
  };

  return (
    <React.Fragment>
      <Header
        selectedClassId={selectedClassId}
        classOptions={classOptions}
        onClassChange={handleClassChange}
      />
      <ContainerStyled>
        <ContentWrapper>

          <TabsStyled value={currentTab} onChange={handleTabChange}>
            <Tab label="Điểm danh QR Code" />
            <Tab label="Điểm danh thủ công" />
            <Tab label="Lịch sử" />
            <Tab label="Thống kê" />
          </TabsStyled>

          <TabPanelStyled>
            {currentTab === 0 && <QRCodeAttendance />}
            {currentTab === 1 && <ManualAttendance />}
            {currentTab === 2 && <AttendanceHistory />}
            {currentTab === 3 && <AttendanceStatistics />}
          </TabPanelStyled>
        </ContentWrapper>
      </ContainerStyled>
    </React.Fragment>
  );
};

export default Main;

