import { Box, Paper, Tab, Tabs } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled(Box)`
  padding: 2rem;
  min-height: 100vh;
  border-radius: 24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.gray[100]} 0%,
    #e8eef3 100%
  );

  @media (max-width: 768px) {
    padding: 1rem;
    border-radius: 16px;
  }
`;

export const ContentWrapper = styled(Box)`
  max-width: 1200px;
  margin: 0 auto;

  @media (max-width: 1200px) {
    max-width: 100%;
  }
`;

export const HeaderStyled = styled(Box)`
  margin-bottom: 2rem;

  .header-title {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    margin-bottom: 0.5rem;
    flex-wrap: wrap;

    h1 {
      font-size: 2rem;
      font-weight: 700;
      color: ${VPB_THEMES.colors.textColor};
      margin: 0;
    }
  }

  .header-subtitle {
    font-size: 1rem;
    color: ${VPB_THEMES.colors.secondaryText};
    margin: 0;
    font-weight: 500;
  }

  @media (max-width: 768px) {
    .header-title {
      flex-direction: column;
      align-items: flex-start;
      gap: 1rem;

      h1 {
        font-size: 1.5rem;
      }
    }
  }
`;

export const TabsStyled = styled(Tabs)`
  margin-bottom: 2rem;
  background: white;
  border-radius: 12px;
  padding: 0.5rem;

  .MuiTab-root {
    text-transform: none;
    font-weight: 600;
    font-size: 1rem;
    color: ${VPB_THEMES.colors.secondaryText};
    min-height: 48px;

    &.Mui-selected {
      color: ${VPB_THEMES.colors.green};
    }
  }

  .MuiTabs-indicator {
    background: ${VPB_THEMES.colors.green};
    height: 3px;
    border-radius: 3px 3px 0 0;
  }
`;

export const TabPanelStyled = styled(Box)`
  padding: 2rem 0;
`;

export const CardStyled = styled(Paper)`
  padding: 2rem;
  border-radius: 16px;
  background: white;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  margin-bottom: 2rem;

  @media (max-width: 768px) {
    padding: 1.5rem;
    border-radius: 12px;
  }
`;

export const QRCodeContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
  padding: 2rem;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  border-radius: 16px;
  border: 2px solid ${VPB_THEMES.colors.green}30;

  @media (max-width: 768px) {
    padding: 1.5rem;
    gap: 1.5rem;
  }
`;

export const QRCodeBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 300px;
  height: 300px;
  background: white;
  border-radius: 12px;
  padding: 1rem;
  box-shadow: 0 8px 24px rgba(0, 173, 83, 0.15);

  @media (max-width: 768px) {
    width: 250px;
    height: 250px;
  }

  @media (max-width: 480px) {
    width: 200px;
    height: 200px;
  }
`;

export const StatsGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
  margin-top: 2rem;

  @media (max-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
  }
`;

export const StatCard = styled(Paper)`
  padding: 1.5rem;
  border-radius: 12px;
  text-align: center;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  border: 2px solid ${(props) => props.bordercolor || VPB_THEMES.colors.green}30;

  .stat-value {
    font-size: 2rem;
    font-weight: 700;
    color: ${(props) => props.valuecolor || VPB_THEMES.colors.green};
    margin: 0.5rem 0;
  }

  .stat-label {
    font-size: 0.9rem;
    color: ${VPB_THEMES.colors.secondaryText};
    font-weight: 600;
  }

  @media (max-width: 768px) {
    padding: 1rem;

    .stat-value {
      font-size: 1.5rem;
    }
  }
`;


