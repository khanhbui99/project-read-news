import { useSnackbar } from 'notistack';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import Filter from './components/Filter';
import FormModal from './components/FormModal';
import Header from './components/Header';
import Pagination from './components/Pagination';
import Table from './components/Table';
import { cleanErrorMessage, cleanSuccessMessage, getChildTabCodeAction, queryActionRoot } from './store/actions';
import { key } from './store/constants';

const Main = () => {
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const { errorMessage, successMessage } = useSelector(state => state[key] || {});

  useEffect(() => {
    if (!successMessage) return;

    enqueueSnackbar(successMessage, {
      variant: 'success',
    });
    dispatch(cleanSuccessMessage());
  }, [successMessage]);

  useEffect(() => {
    if (!errorMessage) return;

    enqueueSnackbar(errorMessage, {
      variant: 'error',
    });
    dispatch(cleanErrorMessage());
  }, [errorMessage]);

  useEffect(() => {
    dispatch(getChildTabCodeAction());
    dispatch(queryActionRoot());
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Filter />
      <Table />
      <Pagination />
      <FormModal />
    </React.Fragment>
  );
};

export default Main;
