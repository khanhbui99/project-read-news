export { default as MenuConfig } from "./Menu";
export { default as MenuTabConfig } from "./MenuTab";
export { default as PermissionConfig } from "./Permission";
export { default as FormPermissionConfig } from "./Permission/components/AddPermission";
export { default as GroupPermissionConfig } from "./GroupPermission";
export { default as TopicConfig } from "./Topic";
export { default as SubjectConfig } from "./Subject";
