import { getAllSubjectAction } from "App/store/actions";
import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Header from "./components/Header";
import ModalCreateUpdate from "./components/ModalCreateUpdate";
import Table from "./components/Table";
import { queryTopicAction, resetStoreTopicAction } from "./store/actions";

const Main = () => {
  const fetchTopicList = useDispatchRedux(queryTopicAction);
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const resetTopicStore = useDispatchRedux(resetStoreTopicAction);

  useEffect(() => {
    fetchAllSubject();

    setTimeout(() => {
      fetchTopicList();
    }, 100);

    // Cleanup function to reset the store when unmounting
    return () => {
      resetTopicStore();
    };
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Table />
      <ModalCreateUpdate />
    </React.Fragment>
  );
};

export default Main;
