import { addPath, detailPath, editPath } from "utils/constants";
import { toAccentVietnamese } from "utils/helpers";

import { UrlType } from "./store/constants";

export const getPath = (name, parentUrl, type) => {
  let url = `${parentUrl}/${toAccentVietnamese(name.replaceAll(" ", "-"))}`;

  if (type === UrlType.ADD) url = `${url}${addPath}`;

  if (type === UrlType.EDIT) url = `${url}${editPath}/:id`;

  if (type === UrlType.DETAIL) url = `${url}${detailPath}/:id`;

  return url;
};

