import { useSnackbar } from "notistack";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import Header from "./components/Header";
import Table from "./components/Table";
import {
  cleanErrorMessage,
  cleanSuccessMessage,
  queryAction,
  queryAddPathAction,
} from "./store/actions";
import { key } from "./store/constants";

const Main = () => {
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const { errorMessage, successMessage } = useSelector(
    (state) => state[key] || {}
  );

  useEffect(() => {
    if (!successMessage) return;

    enqueueSnackbar(successMessage, {
      variant: "success",
    });
    dispatch(cleanSuccessMessage());
  }, [successMessage]);

  useEffect(() => {
    if (!errorMessage) return;

    enqueueSnackbar(errorMessage, {
      variant: "error",
    });
    dispatch(cleanErrorMessage());
  }, [errorMessage]);

  useEffect(() => {
    dispatch(queryAction());
    dispatch(queryAddPathAction({ componentName: "AddGroupPermission" }));
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Table />
    </React.Fragment>
  );
};

export default Main;
