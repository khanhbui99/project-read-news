import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Header from "./components/Header";
import ModalCreateUpdate from "./components/ModalCreateUpdate";
import Table from "./components/Table";
import { querySubjectAction, resetStoreSubjectAction } from "./store/actions";

const Main = () => {
  const fetchSubjectList = useDispatchRedux(querySubjectAction);
  const resetSubjectStore = useDispatchRedux(resetStoreSubjectAction);

  useEffect(() => {
    setTimeout(() => {
      fetchSubjectList();
    }, 100);

    // Cleanup function to reset the store when unmounting
    return () => {
      resetSubjectStore();
    };
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Table />
      <ModalCreateUpdate />
    </React.Fragment>
  );
};

export default Main;
