import AppHeader from "components/common/AppHeader";
import React from "react";

import CreateForm from "./components/Form";

const Create = () => {
  return (
    <React.Fragment>
      <AppHeader componentName="AddAccountOrgchart" isHiddenBtn />
      <CreateForm />
    </React.Fragment>
  );
};

export default Create;
