import getLd from 'lodash/get';

export const convertDataRequestAccount = (values) => {
  const payload = {};

  if(values.isAccountInSalesChannel === '1'){
    payload.nonOrgChart = {
      authorityId: values.nonOrgChart.authorityId,
      isChartDefault: values.nonOrgChart.isChartDefault,
      branchIds: values.nonOrgChart.isSupported ? values.nonOrgChart.branchIds : [],
    }
  }

  if(values.isAccountInSalesChannel === '2'){
    payload.orgChartDetails = values.orgChartDetails.map(item => {
      if(!item.accountCodeManagers){
        item.codeManagers = []
      }

      item.accountCodeManagers = [...item.codeManagers];
      item.branchIds = item.branchIds.map(_b => (_b.id));
      item.productIds = item.productIds.map(_p => (_p.id));
      item.channelIds = [item.channelIds]

      delete item.regionNames;
      delete item.highestLevels;
      delete item.codeManagers;

      return {...item}
    })
  }

  payload.id = getLd(values, 'id') || null;
  payload.dao = getLd(values, 'dao') || null;
  payload.name = getLd(values, 'name') || null;
  payload.phone = getLd(values, 'phone') || null;
  payload.email = getLd(values, 'email') || null;
  payload.ticket = getLd(values, 'ticket') || null;
  payload.saleCode = getLd(values, 'saleCode') || null;
  payload.userName = getLd(values, 'userName') || null;
  payload.employeeCode = getLd(values, 'employeeCode') || null;

  return payload;
}

export const getAccountCodeFromTree  = (tree = []) => {
  let code = [];

  tree.forEach(node => {
    code.push(node.accountCode);

    if (node.accountManagers && node.accountManagers.length > 0) {
      code = code.concat(getAccountCodeFromTree(node.accountManagers)); // Duyệt qua children
    }
  });

  return code;
}