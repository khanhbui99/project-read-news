import { getAllDepartmentsAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useEffect } from "react";
import { findMenuByComponentName } from "utils/helpers";
import history from "utils/history";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Filter from "./components/Filter";
import Pagination from "./components/Pagination";
import Table from "./components/Table";

const Main = () => {
  const handleCreate = () => {
    history.push({
      pathname: findMenuByComponentName("AddAccountOrgchart")?.url || "",
    });
  };

  const rqAllDepartments = useDispatchRedux(getAllDepartmentsAction);

  useEffect(() => {
    rqAllDepartments();
  }, []);

  return (
    <React.Fragment>
      <AppHeader
        componentName="AccountOrgchart"
        btnName="Thêm tài khoản"
        handleBtnClick={handleCreate}
      />

      <Filter />
      <Table />
      <Pagination />
    </React.Fragment>
  );
};

export default Main;
