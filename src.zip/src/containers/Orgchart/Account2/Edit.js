import AppHeader from "components/common/AppHeader";
import React from "react";

import CreateForm from "./components/Form";

const Edit = () => {
  return (
    <React.Fragment>
      <AppHeader componentName="EditAccountOrgchart" isHiddenBtn />
      <CreateForm mode="edit" />
    </React.Fragment>
  );
};

export default Edit;
