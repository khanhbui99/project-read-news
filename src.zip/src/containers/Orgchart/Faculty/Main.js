import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Header from "./components/Header";
import ModalCreateUpdate from "./components/ModalCreateUpdate";
import Table from "./components/Table";
import { queryAction, resetStoreFacultyAction } from "./store/actions";

const Main = () => {
  const fetchFacultyList = useDispatchRedux(queryAction);
  const resetFacultyStore = useDispatchRedux(resetStoreFacultyAction);

  useEffect(() => {
    setTimeout(() => {
      fetchFacultyList();
    }, 100);

    // Cleanup function to reset the store when unmounting
    return () => {
      resetFacultyStore();
    };
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Table />
      <ModalCreateUpdate />
    </React.Fragment>
  );
};

export default Main;
