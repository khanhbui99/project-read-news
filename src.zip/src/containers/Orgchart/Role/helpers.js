import get from "lodash/get";
import isArray from "lodash/isArray";
import { compareVietnamese } from "utils/helpers";

export function groupPermissionDetailData(data) {
  return Object.values(
    data.reduce((acc, item) => {
      const parentId = item.groupId ?? 0;
      acc[parentId] ??= {
        id: parentId,
        groupName: item.groupName || "Default",
        permissions: [],
      };
      acc[parentId].permissions.push(item);
      return acc;
    }, {})
  );
}

export function groupMenuDetailData(data) {
  return Object.values(
    data.reduce((acc, item) => {
      const parentId = item.type ?? 0;
      acc[parentId] ??= {
        id: parentId,
        name: parentId,
        queue: [],
      };
      acc[parentId].queue.push(item);
      return acc;
    }, {})
  ).map((item) => {
    const newGroup = new Map();
    return {
      ...item,
      queue: item.queue
        .reduce((acc, item) => {
          const newItem = { ...item, child: [] };
          newGroup.set(item.id, newItem);

          if (item.parentId) {
            newGroup.get(item.parentId)?.child.push(newItem);
          } else {
            acc.push(newGroup.get(item.id));
          }
          return acc;
        }, [])
        .sort((prev, curr) => (prev.orders < curr.orders ? -1 : 1)),
    };
  });
}

export function groupPermissionsByGroupId(permissions) {
  return permissions.reduce((acc, permission) => {
    const groupId = permission.groupId !== null ? permission.groupId : 0;
    if (!acc[groupId]) {
      acc[groupId] = [];
    }
    acc[groupId].push(String(permission.id));
    return acc;
  }, {});
}

export function groupMenuByType(data) {
  if (!isArray(data)) {
    return {};
  }
  return data.reduce((acc, { type, parentId, id }) => {
    if (!type) return acc;

    acc[type] ||= {};
    const typeGroup = acc[type];
    if (parentId) {
      (typeGroup[parentId] ||= []).push(String(id));
    } else {
      typeGroup[id] ||= [];
    }

    return acc;
  }, {});
}

export function searchMenu(data, searchKey) {
  if (!searchKey) {
    return data;
  }
  return data.map((item) => ({
    ...item,
    queue: item.queue
      .map((menu) => ({
        ...menu,
        child: menu.child.filter((child) =>
          compareVietnamese(child.name, searchKey)
        ),
      }))
      .filter(
        (menu) =>
          compareVietnamese(menu.name, searchKey) || menu.child.length > 0
      ),
  }));
}

export function searchPermissions(data, searchKey) {
  if (!searchKey) {
    return data;
  }

  return (data || []).map((item) => ({
    ...item,
    permissions: (get(item, "permissions", []) || []).filter(
      (permission) =>
        compareVietnamese(get(permission, "name", ""), searchKey) ||
        compareVietnamese(get(permission, "action", ""), searchKey)
    ),
  }));
}

export function chunkDataByColumn(data, columnCount) {
  if (!Array.isArray(data) || columnCount <= 0) {
    return data;
  }

  const result = [];

  for (let i = 0; i < data.length; i += columnCount) {
    const chunk = data.slice(i, i + columnCount);
    result.push({
      data: chunk,
    });
  }

  return result;
}
