import { useSnackbar } from 'notistack';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import CreateForm from './components/CreateForm';
import Header from './components/Header';
import {
  cleanErrorMessage,
  cleanSuccessMessage,
  groupDefaultOpsAction,
  groupOpsAction,
  menuOpsAction,
} from './store/actions';
import { key } from './store/constants';

const Create = () => {
  const dispatch = useDispatch();
  const { enqueueSnackbar } = useSnackbar();
  const { errorMessage, successMessage } = useSelector(state => state[key] || {});

  useEffect(() => {
    if (!successMessage) return;

    enqueueSnackbar(successMessage, {
      variant: 'success',
    });
    dispatch(cleanSuccessMessage());
  }, [successMessage]);

  useEffect(() => {
    if (!errorMessage) return;

    enqueueSnackbar(errorMessage, {
      variant: 'error',
    });
    dispatch(cleanErrorMessage());
  }, [errorMessage]);

  useEffect(() => {
    dispatch(menuOpsAction());
    dispatch(groupOpsAction());
    dispatch(groupDefaultOpsAction());
  }, []);

  return (
    <React.Fragment>
      <Header />
      <CreateForm />
    </React.Fragment>
  );
};

export default Create;
