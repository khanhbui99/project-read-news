import LoadingIndicator from 'components/common/LoadingIndicator';
import React from 'react';
import { useInjectReducer } from 'utils/injectReducer';
import { useInjectSaga } from 'utils/injectSaga';
import loadable from 'utils/loadable';

import { key } from './store/constants';
import reducer from './store/reducer';
import saga from './store/saga';

const Provider = ({ children }) => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });

  return <>{children}</>;
};

const RoleOrgChart = loadable(() => import('./Main'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});


const AddRoleOrgChart = loadable(() => import('./Create'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

const EditRoleOrgChart = loadable(() => import('./Edit'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export { RoleOrgChart, AddRoleOrgChart, EditRoleOrgChart };
