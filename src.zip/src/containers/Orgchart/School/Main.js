import { getAllDistrictsAction } from "App/store/actions";
import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Header from "./components/Header";
import ModalCreateUpdate from "./components/ModalCreateUpdate";
import Table from "./components/Table";
import {
  queryDepartmentAction,
  resetStoreDepartmentAction,
} from "./store/actions";

const Main = () => {
  const fetchDepartmentList = useDispatchRedux(queryDepartmentAction);
  const resetDepartmentStore = useDispatchRedux(resetStoreDepartmentAction);
  const fetchAllDistricts = useDispatchRedux(getAllDistrictsAction);

  useEffect(() => {
    fetchAllDistricts();

    setTimeout(() => {
      fetchDepartmentList();
    }, 100);

    // Cleanup function to reset the store when unmounting
    return () => {
      resetDepartmentStore();
    };
  }, []);

  return (
    <React.Fragment>
      <Header />
      <Table />
      <ModalCreateUpdate />
    </React.Fragment>
  );
};

export default Main;
