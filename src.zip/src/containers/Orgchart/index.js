export {
  RoleOrgChart,
  AddRoleOrgChart,
  EditRoleOrgChart,
} from "containers/Orgchart/Role";

export {
  AccountOrgchart,
  AddAccountOrgchart,
  EditAccountOrgchart,
} from "containers/Orgchart/Account3";

export { default as FacultyOrgChart } from "containers/Orgchart/Faculty";
export { default as DepartmentOrgChart } from "containers/Orgchart/Department";
export { default as OrgChart } from "containers/Orgchart/Chart/List";
export { default as AddOrgChart } from "containers/Orgchart/Chart/Form";
export { default as EditOrgChart } from "containers/Orgchart/Chart/Form";
export { default as SchoolOrgChart } from "containers/Orgchart/School";
