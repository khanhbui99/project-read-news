import { getAllRolesAction, getAllOrgChartAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useMemo, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useDispatchRedux } from "utils/hooks/useRedux";

import FormAccount from "./components/Form";
import { convertDataRequestAccount } from "./helpers";
import {
  editAction,
  createAction,
  detailAction,
  resetDetailAction,
} from "./store/actions";

const FormAccountOrgChart = () => {
  const { id } = useParams();

  const rqEditAccount = useDispatchRedux(editAction);
  const rqDetailAccount = useDispatchRedux(detailAction);
  const rqCreateAccount = useDispatchRedux(createAction);
  const fetchAllRoles = useDispatchRedux(getAllRolesAction);
  const fetchAllOrgChart = useDispatchRedux(getAllOrgChartAction);
  const resetDetailStoreAccount = useDispatchRedux(resetDetailAction);
  const componentName = useMemo(
    () => (id ? "EditAccountOrgchart" : "AddAccountOrgchart"),
    [id]
  );

  useEffect(() => {
    fetchAllRoles();
    fetchAllOrgChart();

    if (id) rqDetailAccount(id);

    return () => {
      resetDetailStoreAccount();
    };
  }, []);

  const handleChange = (values) => {
    const payload = convertDataRequestAccount({ ...values });

    if (values?.id) {
      rqEditAccount(payload);
      return;
    }
    rqCreateAccount(payload);
  };

  return (
    <React.Fragment>
      <AppHeader isHiddenBtn componentName={componentName} />
      <FormAccount mode={id ? "edit" : "add"} onSubmit={handleChange} />
    </React.Fragment>
  );
};

export default FormAccountOrgChart;
