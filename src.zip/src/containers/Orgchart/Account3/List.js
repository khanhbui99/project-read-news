import { getAllDepartmentsAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Filter from "./components/List/Filter";
import Pagination from "./components/List/Pagination";
import Table from "./components/List/Table";

const Main = () => {

  const rqAllDepartments = useDispatchRedux(getAllDepartmentsAction);

  useEffect(() => {
    rqAllDepartments();
  }, []);

  return (
    <React.Fragment>
      <AppHeader
        componentName="AccountOrgchart"
        componentNameAdd="AddAccountOrgchart"
        btnName="Thêm tài khoản"
      />

      <Filter />
      <Table />
      <Pagination />
    </React.Fragment>
  );
};

export default Main;
