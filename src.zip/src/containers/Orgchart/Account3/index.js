import LoadingIndicator from 'components/common/LoadingIndicator';
import { useInjectReducer } from 'utils/injectReducer';
import { useInjectSaga } from 'utils/injectSaga';
import loadable from 'utils/loadable';

import { key } from './store/constants';
import reducer from './store/reducer';
import saga from './store/saga';

const Provider = ({ children }) => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });

  window.log = localStorage.getItem(`enabledLog${key}`)
    ? window.backupLogFunc
    : () => {};

  return <>{children}</>;
};

const AccountOrgchart = loadable(() => import('./List'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

const AddAccountOrgchart = loadable(() => import('./Form'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

const EditAccountOrgchart = loadable(() => import('./Form'), {
  fallback: <LoadingIndicator />,
  provider: Provider,
});

export { AccountOrgchart, AddAccountOrgchart, EditAccountOrgchart };
