import getLd from "lodash/get";

export const convertDataRequestAccount = (values) => {
  const val = { ...values };
  const payload = {};

  if (val.accountNormalAndAdmin == 2) {
    payload.nonOrgChart = {
      authorityId: val.nonOrgChart.authorityId,
      isChartDefault: val.nonOrgChart.isChartDefault,
    };
  }

  if (val.accountNormalAndAdmin == 1) {
    payload.orgChartDetails = val.orgChartDetails.map((item) => {
      if ((item?.accountCodeManagers || []).length) {
        item.accountCodeManagers = [item.accountCodeManagers];
      } else {
        item.accountCodeManagers = [];
      }

      delete item.highestLevels;
      // delete item.codeManagers;

      return {
        ...item,
        channelIds: [],
        departmentIds: [...item.departmentIds].map((_d) => _d.id),
      };
    });
  }

  payload.id = getLd(val, "id") || null;
  payload.name = getLd(val, "name") || null;
  payload.phone = getLd(val, "phone") || null;
  payload.email = getLd(val, "email") || null;
  payload.userName = getLd(val, "userName") || null;
  payload.employeeCode = getLd(values, "employeeCode") || null;

  return payload;
};

export const getAccountCodeFromTree = (tree = []) => {
  let code = [];

  tree.forEach((node) => {
    code.push(node.accountCode);

    if (node.accountManagers && node.accountManagers.length > 0) {
      code = code.concat(getAccountCodeFromTree(node.accountManagers)); // Duyệt qua children
    }
  });

  return code;
};
