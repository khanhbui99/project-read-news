import { produce } from "immer";

import * as dashboardAction from "./actions";
import {
  RESET_STORE_DASHBOARD_ACTION,
  SET_FIELD_VALUE_STORE_DASHBOARD_ACTION,
} from "./constants";

export const initialState = {
  // Category QM - 3.1.1: Tổng số trường THPT/THCS/TH
  selectedWardsSchoolsByWard: [], // Filter districts cho biểu đồ SchoolsByWard
  schoolsByWardData: [], // Data cho biểu đồ cột chồng/cột bình thường
  
  selectedWardsSchoolType: [], // Filter riêng cho biểu đồ SchoolType
  schoolTypeData: {}, // Data cho biểu đồ tròn (công lập/tư thục/tự chủ)

  // Category QM - 3.1.2: Kế hoạch giáo dục
  selectedWardsEducationPlan: [], // Filter riêng cho biểu đồ EducationPlan
  educationPlanData: [], // Data cho biểu đồ cột ngang chồng
  educationPlanSchools: [], // Danh sách trường khi drill-down
  selectedWardForPlan: null, // Phường/xã được chọn để drill-down
  selectedPlanStatus: null, // "hasPlan" hoặc "noPlan"

  // Category HS-AN
  selectedWardsStudentByLevel: [], // Filter riêng cho biểu đồ StudentByLevel
  studentByLevelData: [], // Tổng số học sinh theo cấp học
  
  selectedWardsStudentBySchoolType: [], // Filter riêng cho biểu đồ StudentBySchoolType
  studentBySchoolTypeData: {}, // Số lượng học sinh theo loại hình trường

  // Category GV
  selectedWardsTeacherBySchoolType: [], // Filter riêng cho biểu đồ TeacherBySchoolType
  teacherBySchoolTypeData: {}, // Số lượng giáo viên theo loại hình trường
  selectedWardsTotalStaff: [], // Filter cho biểu đồ TotalStaff
  selectedStaffTypes: ["BGH", "GV", "NV"], // Loại nhân sự được chọn (mặc định: BGH, GV, NV)
  selectedLevel: "C1", // Cấp được chọn (C1, C2, C3) - mặc định C1
  totalStaffData: [], // Data cho biểu đồ tổng số BGH/GV/NV & CV
  selectedWardsStaffChange: [], // Filter cho biểu đồ StaffChange
  staffChangeData: [], // Data cho biểu đồ biến động nhân sự

  // Category QTDH - Dạy học & Kết quả giáo dục
  selectedWardsTotalStudent: [], // Filter cho tổng số học sinh
  totalStudentEvaluatedData: {}, // Tổng số học sinh được đánh giá
  selectedWardsAcademicPerformance: [], // Filter cho tỷ lệ học lực
  academicPerformanceData: {}, // Tỷ lệ học lực
  selectedWardsConductPerformance: [], // Filter cho tỷ lệ rèn luyện
  conductPerformanceData: {}, // Tỷ lệ rèn luyện
  selectedWardsAcademicPerformanceByGrade: [], // Filter cho tỷ lệ học lực theo khối
  academicPerformanceByGradeData: [], // Tỷ lệ học lực theo khối
  selectedWardsConductPerformanceByGrade: [], // Filter cho tỷ lệ rèn luyện theo khối
  conductPerformanceByGradeData: [], // Tỷ lệ rèn luyện theo khối
};

const reducer = (state = initialState, { payload = {}, type }) =>
  produce(state, (dr) => {
    const draft = dr;
    switch (type) {
      case RESET_STORE_DASHBOARD_ACTION:
        return initialState;

      case SET_FIELD_VALUE_STORE_DASHBOARD_ACTION: {
        const { field, value } = payload;
        draft[field] = value;
        break;
      }

      case dashboardAction.getSchoolsByWardAction.REQUEST:
        break;

      case dashboardAction.getSchoolsByWardAction.SUCCESS:
        draft.schoolsByWardData = payload.schoolsByWardData || [];
        draft.schoolTypeData = payload.schoolTypeData || {};
        break;

      case dashboardAction.getSchoolsByWardAction.FAILURE:
        break;

      case dashboardAction.getSchoolTypeDataAction.REQUEST:
        break;

      case dashboardAction.getSchoolTypeDataAction.SUCCESS:
        draft.schoolTypeData = payload.schoolTypeData || {};
        break;

      case dashboardAction.getSchoolTypeDataAction.FAILURE:
        break;

      case dashboardAction.getEducationPlanDataAction.REQUEST:
        break;

      case dashboardAction.getEducationPlanDataAction.SUCCESS:
        draft.educationPlanData = payload.educationPlanData || [];
        break;

      case dashboardAction.getEducationPlanDataAction.FAILURE:
        break;

      case dashboardAction.getEducationPlanSchoolsAction.REQUEST:
        break;

      case dashboardAction.getEducationPlanSchoolsAction.SUCCESS:
        draft.educationPlanSchools = payload.schools || [];
        break;

      case dashboardAction.getEducationPlanSchoolsAction.FAILURE:
        break;

      case dashboardAction.getStudentByLevelAction.REQUEST:
        break;

      case dashboardAction.getStudentByLevelAction.SUCCESS:
        draft.studentByLevelData = payload.studentByLevelData || [];
        draft.studentBySchoolTypeData = payload.studentBySchoolTypeData || {};
        break;

      case dashboardAction.getStudentByLevelAction.FAILURE:
        break;

      case dashboardAction.getStudentBySchoolTypeAction.REQUEST:
        break;

      case dashboardAction.getStudentBySchoolTypeAction.SUCCESS:
        draft.studentBySchoolTypeData = payload.studentBySchoolTypeData || {};
        break;

      case dashboardAction.getStudentBySchoolTypeAction.FAILURE:
        break;

      case dashboardAction.getTeacherBySchoolTypeAction.REQUEST:
        break;

      case dashboardAction.getTeacherBySchoolTypeAction.SUCCESS:
        draft.teacherBySchoolTypeData = payload.teacherBySchoolTypeData || {};
        break;

      case dashboardAction.getTeacherBySchoolTypeAction.FAILURE:
        break;

      case dashboardAction.getTotalStaffDataAction.REQUEST:
        break;

      case dashboardAction.getTotalStaffDataAction.SUCCESS:
        draft.totalStaffData = payload.totalStaffData || [];
        break;

      case dashboardAction.getTotalStaffDataAction.FAILURE:
        break;

      case dashboardAction.getStaffChangeDataAction.REQUEST:
        break;

      case dashboardAction.getStaffChangeDataAction.SUCCESS:
        draft.staffChangeData = payload.staffChangeData || [];
        break;

      case dashboardAction.getStaffChangeDataAction.FAILURE:
        break;

      // Category QTDH
      case dashboardAction.getTotalStudentEvaluatedAction.REQUEST:
        break;

      case dashboardAction.getTotalStudentEvaluatedAction.SUCCESS:
        draft.totalStudentEvaluatedData = payload.totalStudentEvaluatedData || {};
        break;

      case dashboardAction.getTotalStudentEvaluatedAction.FAILURE:
        break;

      case dashboardAction.getAcademicPerformanceDataAction.REQUEST:
        break;

      case dashboardAction.getAcademicPerformanceDataAction.SUCCESS:
        draft.academicPerformanceData = payload.academicPerformanceData || {};
        break;

      case dashboardAction.getAcademicPerformanceDataAction.FAILURE:
        break;

      case dashboardAction.getConductPerformanceDataAction.REQUEST:
        break;

      case dashboardAction.getConductPerformanceDataAction.SUCCESS:
        draft.conductPerformanceData = payload.conductPerformanceData || {};
        break;

      case dashboardAction.getConductPerformanceDataAction.FAILURE:
        break;

      case dashboardAction.getAcademicPerformanceByGradeDataAction.REQUEST:
        break;

      case dashboardAction.getAcademicPerformanceByGradeDataAction.SUCCESS:
        draft.academicPerformanceByGradeData = payload.academicPerformanceByGradeData || [];
        break;

      case dashboardAction.getAcademicPerformanceByGradeDataAction.FAILURE:
        break;

      case dashboardAction.getConductPerformanceByGradeDataAction.REQUEST:
        break;

      case dashboardAction.getConductPerformanceByGradeDataAction.SUCCESS:
        draft.conductPerformanceByGradeData = payload.conductPerformanceByGradeData || [];
        break;

      case dashboardAction.getConductPerformanceByGradeDataAction.FAILURE:
        break;

      default:
        break;
    }
  });

export default reducer;
