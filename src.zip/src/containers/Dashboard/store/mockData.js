/**
 * Mock data cho Dashboard
 * Các hàm này tạo dữ liệu giả lập cho các biểu đồ
 * NOTE: Wards/districts được lấy từ API, không còn mock nữa
 */

// Giới hạn số lượng phường/xã hiển thị khi chọn "all" để tối ưu performance
const MAX_WARDS_DISPLAY = 50;

// Mock data cho biểu đồ kế hoạch giáo dục
export const generateEducationPlanData = (wardIds = [], wardOptions = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  const selectedWards = isAll 
    ? wardOptions.slice(0, MAX_WARDS_DISPLAY) // Chỉ lấy 50 đầu tiên
    : wardIds.map((id) => {
        const ward = wardOptions.find((w) => w.id === id);
        return ward || { id, name: `Phường/Xã ${id}` };
      });

  return selectedWards.map((ward) => {
    const total = Math.floor(Math.random() * 20) + 5; // 5-24 trường
    const hasPlan = Math.floor(total * (0.7 + Math.random() * 0.2)); // 70-90% có kế hoạch
    const noPlan = total - hasPlan;

    return {
      id: ward.id,
      name: ward.name,
      hasPlan,
      noPlan,
      total,
    };
  });
};

// Mock data cho danh sách trường khi drill-down
export const generateEducationPlanSchools = (wardId, planStatus) => {
  const wardNumber = wardId?.split("_")[1] || "1";
  const count = planStatus === "hasPlan" 
    ? Math.floor(Math.random() * 15) + 5 // 5-19 trường có kế hoạch
    : Math.floor(Math.random() * 5) + 1; // 1-5 trường không có kế hoạch

  const schools = [];
  const levels = ["THPT", "THCS", "TH"];

  for (let i = 1; i <= count; i++) {
    schools.push({
      id: `school_${wardId}_${i}`,
      name: `Trường ${planStatus === "hasPlan" ? "có" : "không có"} kế hoạch ${i} - Phường ${wardNumber}`,
      code: `SCH${wardNumber.padStart(3, "0")}${i.toString().padStart(3, "0")}`,
      level: levels[Math.floor(Math.random() * 3)],
      wardId,
      planStatus,
    });
  }

  return schools;
};

// Mock data cho biểu đồ học sinh theo cấp học
export const generateStudentByLevelData = (wardIds = [], wardOptions = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  const selectedWards = isAll 
    ? wardOptions.slice(0, MAX_WARDS_DISPLAY) // Chỉ lấy 50 đầu tiên
    : wardIds.map((id) => {
        const ward = wardOptions.find((w) => w.id === id);
        return ward || { id, name: `Phường/Xã ${id}` };
      });

  return selectedWards.map((ward) => ({
    id: ward.id,
    ward: ward.name,
    thpt: Math.floor(Math.random() * 500) + 800, // 800-1299 học sinh THPT
    thcs: Math.floor(Math.random() * 600) + 1000, // 1000-1599 học sinh THCS
    th: Math.floor(Math.random() * 400) + 600, // 600-999 học sinh TH
  }));
};

// Mock data cho biểu đồ học sinh theo loại hình trường
export const generateStudentBySchoolTypeData = (wardIds = [], wardOptions = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  
  // Tính tổng số học sinh từ studentByLevelData
  const studentsData = generateStudentByLevelData(wardIds, wardOptions);
  const totalStudents = studentsData.reduce(
    (sum, item) => sum + item.thpt + item.thcs + item.th,
    0
  );

  // Phân bổ: công lập ~65%, tự chủ ~20%, tư thục ~15%
  const publicCount = Math.floor(totalStudents * 0.65);
  const autonomousCount = Math.floor(totalStudents * 0.2);
  const privateCount = totalStudents - publicCount - autonomousCount;

  return {
    public: publicCount,
    autonomous: autonomousCount,
    private: privateCount,
    total: totalStudents,
  };
};

// Mock data cho biểu đồ giáo viên theo loại hình trường
export const generateTeacherBySchoolTypeData = (wardIds = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  const wardCount = isAll ? 5 : wardIds.length;
  
  // Tính tổng số giáo viên dựa trên số lượng phường/xã
  // Giả sử mỗi phường/xã có khoảng 200-400 giáo viên
  const baseTeachers = wardCount * 300;
  const totalTeachers = baseTeachers + Math.floor(Math.random() * (wardCount * 100));

  // Phân bổ: công lập ~70%, tự chủ ~15%, tư thục ~15%
  const publicCount = Math.floor(totalTeachers * 0.7);
  const autonomousCount = Math.floor(totalTeachers * 0.15);
  const privateCount = totalTeachers - publicCount - autonomousCount;

  return {
    public: publicCount,
    autonomous: autonomousCount,
    private: privateCount,
    total: totalTeachers,
  };
};

// Mock data cho biểu đồ tổng số BGH/GV/NV & CV
export const generateTotalStaffData = (wardIds = [], staffTypes = ["BGH", "GV", "NV"], level = "C1", wardOptions = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  const selectedWards = isAll 
    ? wardOptions.slice(0, MAX_WARDS_DISPLAY) // Chỉ lấy 50 đầu tiên
    : wardIds.map((id) => {
        const ward = wardOptions.find((w) => w.id === id);
        return ward || { id, name: `Phường/Xã ${id}` };
      });

  return selectedWards.map((ward) => {
    // Tạo dữ liệu ngẫu nhiên cho mỗi phường/xã
    const bgh = Math.floor(Math.random() * 10) + 3; // 3-12 BGH
    const gv = Math.floor(Math.random() * 50) + 30; // 30-79 GV
    const nv = Math.floor(Math.random() * 15) + 5; // 5-19 NV
    
    // CV data theo từng cấp
    const c1 = Math.floor(Math.random() * 10) + 1; // 1-10 CV C1
    const c2 = Math.floor(Math.random() * 8) + 1; // 1-8 CV C2
    const c3 = Math.floor(Math.random() * 6) + 1; // 1-6 CV C3

    return {
      id: ward.id,
      ward: ward.name,
      name: ward.name, // Cũng có thể dùng name
      bgh,
      BGH: bgh, // Để tương thích với code hiện tại
      gv,
      GV: gv,
      nv,
      NV: nv,
      nhanVien: nv, // Để tương thích
      NhanVien: nv,
      c1,
      c2,
      c3,
    };
  });
};

// Mock data cho biểu đồ biến động nhân sự
export const generateStaffChangeData = (wardIds = [], wardOptions = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  const selectedWards = isAll 
    ? wardOptions.slice(0, MAX_WARDS_DISPLAY) // Chỉ lấy 50 đầu tiên
    : wardIds.map((id) => {
        const ward = wardOptions.find((w) => w.id === id);
        return ward || { id, name: `Phường/Xã ${id}` };
      });

  return selectedWards.map((ward) => {
    // Tạo dữ liệu ngẫu nhiên cho mỗi phường/xã
    // Đầu năm và cuối năm có sự thay đổi nhỏ
    const generateChange = (base) => {
      const start = base + Math.floor(Math.random() * 3) - 1; // ±1
      const change = Math.floor(Math.random() * 5) - 2; // -2 đến +2
      const end = Math.max(1, start + change); // Đảm bảo >= 1
      return { start, end };
    };

    const cbqlBase = Math.floor(Math.random() * 10) + 3; // 3-12
    const gvBase = Math.floor(Math.random() * 50) + 30; // 30-79
    const nvBase = Math.floor(Math.random() * 15) + 5; // 5-19
    const hdBase = Math.floor(Math.random() * 8) + 2; // 2-9

    return {
      id: ward.id,
      ward: ward.name,
      name: ward.name,
      cbql: generateChange(cbqlBase),
      gv: generateChange(gvBase),
      nv: generateChange(nvBase),
      hd: generateChange(hdBase),
    };
  });
};

// Mock data cho tổng số học sinh được đánh giá
export const generateTotalStudentEvaluatedData = (wardIds = []) => {
  const isAll = wardIds.length === 0 || wardIds.includes("all");
  const wardCount = isAll ? 5 : wardIds.length;
  
  // Tính tổng số học sinh dựa trên số lượng phường/xã
  // Giả sử mỗi phường/xã có khoảng 250-450 học sinh
  const baseStudents = wardCount * 300;
  const totalStudents = baseStudents + Math.floor(Math.random() * (wardCount * 200));

  return {
    total: totalStudents,
  };
};

// Mock data cho tỷ lệ học lực
export const generateAcademicPerformanceData = (wardIds = []) => {
  // Mock data từ BC03: Tốt 35.92%, Khá 52.22%, Đạt 10.14%, Chưa đạt 1.72%
  return {
    excellent: 35.92,
    good: 52.22,
    average: 10.14,
    weak: 1.72,
  };
};

// Mock data cho tỷ lệ rèn luyện
export const generateConductPerformanceData = (wardIds = []) => {
  // Mock data từ BC03: Tốt 88.67%, Khá 8.81%, Đạt 0.80%, Chưa đạt 1.72%
  return {
    excellent: 88.67,
    good: 8.81,
    average: 0.80,
    weak: 1.72,
  };
};

// Mock data cho tỷ lệ học lực theo khối (trả về empty vì không có dữ liệu phân tách)
export const generateAcademicPerformanceByGradeData = (wardIds = []) => {
  // Không có dữ liệu phân tách theo khối
  return [];
};

// Mock data cho tỷ lệ rèn luyện theo khối (trả về empty vì không có dữ liệu phân tách)
export const generateConductPerformanceByGradeData = (wardIds = []) => {
  // Không có dữ liệu phân tách theo khối
  return [];
};

// Danh sách tên trường thực tế ở Hà Nội và Việt Nam
// Bao gồm các tên danh nhân, địa danh, và tên phổ biến
const SCHOOL_NAME_PREFIXES = {
  THPT: [
    "THPT",
    "THPT Chuyên",
    "THPT Dân lập",
    "THPT Tư thục",
    "THPT Công lập",
    "THPT Tự chủ",
  ],
  THCS: [
    "THCS",
    "THCS Công lập",
    "THCS Tư thục",
    "THCS Dân lập",
  ],
  TH: [
    "Tiểu học",
    "Tiểu học Công lập",
    "Tiểu học Tư thục",
    "Tiểu học Dân lập",
  ],
  MN: [
    "Mầm non",
    "Mẫu giáo",
    "Mầm non Công lập",
    "Mẫu giáo Tư thục",
  ],
};

// Danh sách tên danh nhân, địa danh thường dùng để đặt tên trường
const HERO_NAMES = [
  "Nguyễn Trãi",
  "Lê Lợi",
  "Trần Hưng Đạo",
  "Quang Trung",
  "Nguyễn Du",
  "Hai Bà Trưng",
  "Lý Thường Kiệt",
  "Phan Đình Phùng",
  "Hoàng Diệu",
  "Nguyễn Huệ",
  "Bà Triệu",
  "Đinh Tiên Hoàng",
  "Lê Duẩn",
  "Hồ Chí Minh",
  "Võ Nguyên Giáp",
  "Nguyễn Thị Minh Khai",
  "Nguyễn Văn Cừ",
  "Lê Hồng Phong",
  "Trần Phú",
  "Nguyễn Thái Học",
  "Nguyễn Đình Chiểu",
  "Nguyễn Khuyến",
  "Nguyễn Bỉnh Khiêm",
  "Chu Văn An",
  "Lương Thế Vinh",
  "Lê Quý Đôn",
  "Nguyễn Trường Tộ",
  "Phan Bội Châu",
  "Phan Châu Trinh",
  "Nguyễn Ái Quốc",
];

// Danh sách số thứ tự và tên phụ phổ biến
const SCHOOL_NUMBER_SUFFIXES = [
  "A",
  "B",
  "C",
  "D",
  "1",
  "2",
  "3",
  "I",
  "II",
  "III",
];

// Danh sách tên đường/phố phổ biến để tạo địa chỉ trường
const STREET_NAMES = [
  "Nguyễn Trãi",
  "Lê Lợi",
  "Trần Hưng Đạo",
  "Hoàng Diệu",
  "Lý Thường Kiệt",
  "Phan Đình Phùng",
  "Điện Biên Phủ",
  "Hoàng Hoa Thám",
  "Nguyễn Du",
  "Hai Bà Trưng",
  "Lê Duẩn",
  "Đinh Tiên Hoàng",
  "Quang Trung",
  "Nguyễn Huệ",
  "Bà Triệu",
  "Đội Cấn",
  "Kim Mã",
  "Giảng Võ",
  "Cống Vị",
  "Điện Biên",
];

/**
 * Generate danh sách trường thực tế cho một phường/xã
 * Đảm bảo tổng số học sinh của các trường khớp với số học sinh của phường/xã
 * @param {string} wardName - Tên phường/xã
 * @param {string} wardId - ID phường/xã
 * @param {Object} wardData - Dữ liệu phường/xã chứa số học sinh (thpt, thcs, th)
 * @param {number} minSchools - Số trường tối thiểu (mặc định 8)
 * @param {number} maxSchools - Số trường tối đa (mặc định 25)
 * @returns {Array} Danh sách trường
 */
export const generateSchoolsByWard = (
  wardName = "",
  wardId = "",
  wardData = {},
  minSchools = 15,
  maxSchools = 35
) => {
  // Lấy số học sinh từ wardData
  const totalTHPT = Number(wardData.thpt) || 0;
  const totalTHCS = Number(wardData.thcs) || 0;
  const totalTH = Number(wardData.th) || 0;
  
  // Tính số trường - Đảm bảo luôn có nhiều trường cho mỗi cấp học
  // Số trường tối thiểu: THPT: 2-5, THCS: 3-6, TH: 4-8, MN: 2-4
  // Số trường sẽ được tính dựa trên số học sinh, nhưng luôn đảm bảo tối thiểu
  
  let thptCount, thcsCount, thCount, mnCount;
  
  if (totalTHPT > 0) {
    // Tính số trường dựa trên số học sinh (mỗi trường ~400-600 học sinh)
    const calculated = Math.ceil(totalTHPT / 500);
    thptCount = Math.max(2, Math.min(5, calculated)); // Tối thiểu 2, tối đa 5
  } else {
    // Nếu không có học sinh, vẫn tạo ít nhất 2 trường
    thptCount = 2;
  }
  
  if (totalTHCS > 0) {
    const calculated = Math.ceil(totalTHCS / 400);
    thcsCount = Math.max(3, Math.min(6, calculated)); // Tối thiểu 3, tối đa 6
  } else {
    thcsCount = 3;
  }
  
  if (totalTH > 0) {
    const calculated = Math.ceil(totalTH / 300);
    thCount = Math.max(4, Math.min(8, calculated)); // Tối thiểu 4, tối đa 8
  } else {
    thCount = 4;
  }
  
  // Mầm non: ít nhất 2, tối đa 4
  mnCount = Math.max(2, Math.min(4, Math.ceil((thCount + thcsCount + thptCount) * 0.2)));
  
  const schoolCount = thptCount + thcsCount + thCount + mnCount;
  const schools = [];
  const usedNames = new Set();

  // Tính số học sinh trung bình mỗi trường để phân bổ
  const avgStudentsPerTH = thCount > 0 ? Math.floor(totalTH / thCount) : 0;
  const avgStudentsPerTHCS = thcsCount > 0 ? Math.floor(totalTHCS / thcsCount) : 0;
  const avgStudentsPerTHPT = thptCount > 0 ? Math.floor(totalTHPT / thptCount) : 0;

  // Biến để theo dõi tổng số học sinh đã phân bổ
  let allocatedTH = 0;
  let allocatedTHCS = 0;
  let allocatedTHPT = 0;

  let schoolIndex = 1;

  // Tạo trường Tiểu học (TH)
  for (let i = 0; i < thCount; i++) {
    const prefix = SCHOOL_NAME_PREFIXES.TH[Math.floor(Math.random() * SCHOOL_NAME_PREFIXES.TH.length)];
    const heroName = HERO_NAMES[Math.floor(Math.random() * HERO_NAMES.length)];
    const useHeroName = Math.random() < 0.6; // 60% dùng tên danh nhân
    
    let schoolName = useHeroName 
      ? `Trường ${prefix} ${heroName}`
      : `Trường ${prefix} ${wardName}`;
    
    // Nếu tên đã tồn tại, thêm số thứ tự hoặc suffix
    if (usedNames.has(schoolName)) {
      const suffix = SCHOOL_NUMBER_SUFFIXES[Math.floor(Math.random() * SCHOOL_NUMBER_SUFFIXES.length)];
      schoolName = useHeroName
        ? `Trường ${prefix} ${heroName} ${suffix}`
        : `Trường ${prefix} ${wardName} ${suffix}`;
    }
    usedNames.add(schoolName);

    const streetName = STREET_NAMES[Math.floor(Math.random() * STREET_NAMES.length)];
    const streetNumber = Math.floor(Math.random() * 200) + 1;

    // Phân bổ số học sinh để đảm bảo tổng khớp
    let students;
    if (i === thCount - 1) {
      // Trường cuối cùng: lấy phần còn lại để đảm bảo tổng khớp
      students = Math.max(50, totalTH - allocatedTH); // Đảm bảo ít nhất 50 học sinh
    } else {
      // Các trường khác: phân bổ với độ lệch ±30% so với trung bình
      const deviation = Math.max(50, Math.floor(avgStudentsPerTH * 0.3));
      students = avgStudentsPerTH + Math.floor(Math.random() * (deviation * 2 + 1)) - deviation;
      // Đảm bảo mỗi trường có ít nhất 50 học sinh và không vượt quá phần còn lại
      const remaining = totalTH - allocatedTH;
      const minForRemaining = Math.max(50, Math.floor(remaining / (thCount - i))); // Đảm bảo các trường còn lại cũng có đủ
      students = Math.max(minForRemaining, Math.min(students, remaining));
    }
    allocatedTH += students;

    schools.push({
      id: `school_${wardId}_${schoolIndex}`,
      schoolName,
      code: `TH${wardId?.slice(-3) || "000"}${String(schoolIndex).padStart(3, "0")}`,
      level: "TH",
      levelName: "Tiểu học",
      address: `Số ${streetNumber} đường ${streetName}, ${wardName}`,
      wardId,
      wardName,
      students,
      // Loại hình trường: 70% công lập, 20% tự chủ, 10% tư thục
      schoolType: Math.random() < 0.7 ? "public" : Math.random() < 0.85 ? "autonomous" : "private",
      schoolTypeName: Math.random() < 0.7 ? "Công lập" : Math.random() < 0.85 ? "Tự chủ" : "Tư thục",
    });
    schoolIndex++;
  }

  // Tạo trường THCS
  for (let i = 0; i < thcsCount; i++) {
    const prefix = SCHOOL_NAME_PREFIXES.THCS[Math.floor(Math.random() * SCHOOL_NAME_PREFIXES.THCS.length)];
    const heroName = HERO_NAMES[Math.floor(Math.random() * HERO_NAMES.length)];
    const useHeroName = Math.random() < 0.7; // 70% dùng tên danh nhân
    
    let schoolName = useHeroName
      ? `Trường ${prefix} ${heroName}`
      : `Trường ${prefix} ${wardName}`;
    
    if (usedNames.has(schoolName)) {
      const suffix = SCHOOL_NUMBER_SUFFIXES[Math.floor(Math.random() * SCHOOL_NUMBER_SUFFIXES.length)];
      schoolName = useHeroName
        ? `Trường ${prefix} ${heroName} ${suffix}`
        : `Trường ${prefix} ${wardName} ${suffix}`;
    }
    usedNames.add(schoolName);

    const streetName = STREET_NAMES[Math.floor(Math.random() * STREET_NAMES.length)];
    const streetNumber = Math.floor(Math.random() * 200) + 1;

    // Phân bổ số học sinh để đảm bảo tổng khớp
    let students;
    if (i === thcsCount - 1) {
      // Trường cuối cùng: lấy phần còn lại để đảm bảo tổng khớp
      students = Math.max(100, totalTHCS - allocatedTHCS); // Đảm bảo ít nhất 100 học sinh
    } else {
      // Các trường khác: phân bổ với độ lệch ±30% so với trung bình
      const deviation = Math.max(100, Math.floor(avgStudentsPerTHCS * 0.3));
      students = avgStudentsPerTHCS + Math.floor(Math.random() * (deviation * 2 + 1)) - deviation;
      // Đảm bảo mỗi trường có ít nhất 100 học sinh và không vượt quá phần còn lại
      const remaining = totalTHCS - allocatedTHCS;
      const minForRemaining = Math.max(100, Math.floor(remaining / (thcsCount - i))); // Đảm bảo các trường còn lại cũng có đủ
      students = Math.max(minForRemaining, Math.min(students, remaining));
    }
    allocatedTHCS += students;

    schools.push({
      id: `school_${wardId}_${schoolIndex}`,
      schoolName,
      code: `THCS${wardId?.slice(-3) || "000"}${String(schoolIndex).padStart(3, "0")}`,
      level: "THCS",
      levelName: "Trung học cơ sở",
      address: `Số ${streetNumber} đường ${streetName}, ${wardName}`,
      wardId,
      wardName,
      students,
      schoolType: Math.random() < 0.7 ? "public" : Math.random() < 0.85 ? "autonomous" : "private",
      schoolTypeName: Math.random() < 0.7 ? "Công lập" : Math.random() < 0.85 ? "Tự chủ" : "Tư thục",
    });
    schoolIndex++;
  }

  // Tạo trường THPT
  for (let i = 0; i < thptCount; i++) {
    const prefix = SCHOOL_NAME_PREFIXES.THPT[Math.floor(Math.random() * SCHOOL_NAME_PREFIXES.THPT.length)];
    const heroName = HERO_NAMES[Math.floor(Math.random() * HERO_NAMES.length)];
    const useHeroName = Math.random() < 0.75; // 75% dùng tên danh nhân
    
    let schoolName = useHeroName
      ? `Trường ${prefix} ${heroName}`
      : `Trường ${prefix} ${wardName}`;
    
    if (usedNames.has(schoolName)) {
      const suffix = SCHOOL_NUMBER_SUFFIXES[Math.floor(Math.random() * SCHOOL_NUMBER_SUFFIXES.length)];
      schoolName = useHeroName
        ? `Trường ${prefix} ${heroName} ${suffix}`
        : `Trường ${prefix} ${wardName} ${suffix}`;
    }
    usedNames.add(schoolName);

    const streetName = STREET_NAMES[Math.floor(Math.random() * STREET_NAMES.length)];
    const streetNumber = Math.floor(Math.random() * 200) + 1;

    // Phân bổ số học sinh để đảm bảo tổng khớp
    let students;
    if (i === thptCount - 1) {
      // Trường cuối cùng: lấy phần còn lại để đảm bảo tổng khớp
      students = Math.max(150, totalTHPT - allocatedTHPT); // Đảm bảo ít nhất 150 học sinh
    } else {
      // Các trường khác: phân bổ với độ lệch ±30% so với trung bình
      const deviation = Math.max(150, Math.floor(avgStudentsPerTHPT * 0.3));
      students = avgStudentsPerTHPT + Math.floor(Math.random() * (deviation * 2 + 1)) - deviation;
      // Đảm bảo mỗi trường có ít nhất 150 học sinh và không vượt quá phần còn lại
      const remaining = totalTHPT - allocatedTHPT;
      const minForRemaining = Math.max(150, Math.floor(remaining / (thptCount - i))); // Đảm bảo các trường còn lại cũng có đủ
      students = Math.max(minForRemaining, Math.min(students, remaining));
    }
    allocatedTHPT += students;

    schools.push({
      id: `school_${wardId}_${schoolIndex}`,
      schoolName,
      code: `THPT${wardId?.slice(-3) || "000"}${String(schoolIndex).padStart(3, "0")}`,
      level: "THPT",
      levelName: "Trung học phổ thông",
      address: `Số ${streetNumber} đường ${streetName}, ${wardName}`,
      wardId,
      wardName,
      students,
      schoolType: Math.random() < 0.65 ? "public" : Math.random() < 0.85 ? "autonomous" : "private",
      schoolTypeName: Math.random() < 0.65 ? "Công lập" : Math.random() < 0.85 ? "Tự chủ" : "Tư thục",
    });
    schoolIndex++;
  }

  // Tạo trường Mầm non
  for (let i = 0; i < mnCount; i++) {
    const prefix = SCHOOL_NAME_PREFIXES.MN[Math.floor(Math.random() * SCHOOL_NAME_PREFIXES.MN.length)];
    const heroName = HERO_NAMES[Math.floor(Math.random() * HERO_NAMES.length)];
    const useHeroName = Math.random() < 0.4; // 40% dùng tên danh nhân (ít hơn cho mầm non)
    
    let schoolName = useHeroName
      ? `Trường ${prefix} ${heroName}`
      : `Trường ${prefix} ${wardName}`;
    
    if (usedNames.has(schoolName)) {
      const suffix = SCHOOL_NUMBER_SUFFIXES[Math.floor(Math.random() * SCHOOL_NUMBER_SUFFIXES.length)];
      schoolName = useHeroName
        ? `Trường ${prefix} ${heroName} ${suffix}`
        : `Trường ${prefix} ${wardName} ${suffix}`;
    }
    usedNames.add(schoolName);

    const streetName = STREET_NAMES[Math.floor(Math.random() * STREET_NAMES.length)];
    const streetNumber = Math.floor(Math.random() * 200) + 1;

    schools.push({
      id: `school_${wardId}_${schoolIndex}`,
      schoolName,
      code: `MN${wardId?.slice(-3) || "000"}${String(schoolIndex).padStart(3, "0")}`,
      level: "MN",
      levelName: "Mầm non",
      address: `Số ${streetNumber} đường ${streetName}, ${wardName}`,
      wardId,
      wardName,
      // Số học sinh mầm non: 100-300 học sinh
      students: Math.floor(Math.random() * 200) + 100,
      schoolType: Math.random() < 0.6 ? "public" : Math.random() < 0.8 ? "autonomous" : "private",
      schoolTypeName: Math.random() < 0.6 ? "Công lập" : Math.random() < 0.8 ? "Tự chủ" : "Tư thục",
    });
    schoolIndex++;
  }

  // Sắp xếp lại theo thứ tự: MN, TH, THCS, THPT
  const levelOrder = { MN: 0, TH: 1, THCS: 2, THPT: 3 };
  schools.sort((a, b) => levelOrder[a.level] - levelOrder[b.level]);

  return schools;
};
