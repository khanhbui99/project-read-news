import { createRoutine } from "redux-saga-routines";

import * as dashboardConst from "./constants";

export const resetStoreDashboardAction = () => {
  return {
    type: dashboardConst.RESET_STORE_DASHBOARD_ACTION,
  };
};

export const setFieldValueStoreDashboardAction = (field, value) => {
  return {
    type: dashboardConst.SET_FIELD_VALUE_STORE_DASHBOARD_ACTION,
    payload: { field, value },
  };
};

export const getSchoolsByWardAction = createRoutine(dashboardConst.GET_SCHOOLS_BY_WARD_ACTION);
export const getSchoolTypeDataAction = createRoutine(dashboardConst.GET_SCHOOL_TYPE_DATA_ACTION);
export const getEducationPlanDataAction = createRoutine(dashboardConst.GET_EDUCATION_PLAN_DATA_ACTION);
export const getEducationPlanSchoolsAction = createRoutine(dashboardConst.GET_EDUCATION_PLAN_SCHOOLS_ACTION);
export const getStudentByLevelAction = createRoutine(dashboardConst.GET_STUDENT_BY_LEVEL_ACTION);
export const getStudentBySchoolTypeAction = createRoutine(dashboardConst.GET_STUDENT_BY_SCHOOL_TYPE_ACTION);
export const getTotalStaffDataAction = createRoutine(dashboardConst.GET_TOTAL_STAFF_DATA_ACTION);
export const getStaffChangeDataAction = createRoutine(dashboardConst.GET_STAFF_CHANGE_DATA_ACTION);
export const getTeacherBySchoolTypeAction = createRoutine(dashboardConst.GET_TEACHER_BY_SCHOOL_TYPE_ACTION);

// Category QTDH - Dạy học & Kết quả giáo dục
export const getTotalStudentEvaluatedAction = createRoutine(dashboardConst.GET_TOTAL_STUDENT_EVALUATED_ACTION);
export const getAcademicPerformanceDataAction = createRoutine(dashboardConst.GET_ACADEMIC_PERFORMANCE_DATA_ACTION);
export const getConductPerformanceDataAction = createRoutine(dashboardConst.GET_CONDUCT_PERFORMANCE_DATA_ACTION);
export const getAcademicPerformanceByGradeDataAction = createRoutine(dashboardConst.GET_ACADEMIC_PERFORMANCE_BY_GRADE_DATA_ACTION);
export const getConductPerformanceByGradeDataAction = createRoutine(dashboardConst.GET_CONDUCT_PERFORMANCE_BY_GRADE_DATA_ACTION);

