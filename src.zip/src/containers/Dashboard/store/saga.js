import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import { all, put as dispatch, select, takeLatest } from "redux-saga/effects";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { responseCode } from "utils/constants";
import injectKey from "utils/injectKey";

import * as dashboardAction from "./actions";
import {
  generateEducationPlanData,
  generateEducationPlanSchools,
  generateTotalStaffData,
  generateStaffChangeData,
  generateTotalStudentEvaluatedData,
  generateAcademicPerformanceData,
  generateConductPerformanceData,
  generateAcademicPerformanceByGradeData,
  generateConductPerformanceByGradeData,
} from "./mockData";

/**
 * Saga để lấy dữ liệu trường theo phường/xã (cho QM 3.1.1)
 */
export function* getSchoolsByWardSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getSchoolsByWardAction.request());

    const districtCodes = payload?.districtCodes || [];

    const request = {
      url: urlApi.dashboard?.schoolsByWard,
      params: {
        districtCode: districtCodes.length > 0 ? districtCodes.join(",") : undefined,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // API trả về format: { "districtCode": [{ levelCode, totalSchools, ... }] }
        // Map về format: [{ id, ward, thpt, thcs, th }]
        const schoolsByWardData = [];

        // Lấy districts từ global store để map districtCode sang districtName
        const globalState = yield select();
        const globalKey = injectKey.GLOBAL;
        const districts = globalState[globalKey]?.districtOpt || [];
        const districtMap = new Map(); // Map districtCode -> districtName

        districts.forEach((district) => {
          const code =
            district.code || district.districtCode || String(district.id || "");
          districtMap.set(code, district.name || district.districtName || "");
        });

        // Tạo Set từ districtCodes đã được chọn để kiểm tra
        const selectedDistrictCodes = new Set(
          districtCodes.map((code) => String(code))
        );

        // Xử lý data từ API - chỉ lấy totalSchools theo levelCode
        const processedDistrictCodes = new Set();

        if (data && typeof data === "object") {
          Object.keys(data).forEach((districtCode) => {
            const districtData = data[districtCode];
            if (!Array.isArray(districtData)) return;

            const normalizedCode = String(districtCode);

            // Khởi tạo object cho district này
            const districtInfo = {
              id: normalizedCode,
              ward:
                districtMap.get(normalizedCode) ||
                `Phường/Xã ${normalizedCode}`,
              thpt: 0,
              thcs: 0,
              th: 0,
            };

            // Chỉ lấy totalSchools theo levelCode
            districtData.forEach((item) => {
              const { levelCode, totalSchools = 0 } = item;

              if (levelCode === "THPT") {
                districtInfo.thpt = totalSchools;
              } else if (levelCode === "THCS") {
                districtInfo.thcs = totalSchools;
              } else if (levelCode === "TH") {
                districtInfo.th = totalSchools;
              }
            });

            schoolsByWardData.push(districtInfo);
            processedDistrictCodes.add(normalizedCode);
          });
        }

        // Thêm các phường/xã đã chọn nhưng không có data từ API (hiển thị 0)
        selectedDistrictCodes.forEach((districtCode) => {
          // Kiểm tra xem đã được xử lý chưa
          if (!processedDistrictCodes.has(districtCode)) {
            schoolsByWardData.push({
              id: districtCode,
              ward:
                districtMap.get(districtCode) || `Phường/Xã ${districtCode}`,
              thpt: 0,
              thcs: 0,
              th: 0,
            });
            processedDistrictCodes.add(districtCode);
          }
        });

        yield dispatch(
          dashboardAction.getSchoolsByWardAction.success({
            schoolsByWardData,
          })
        );
        break;
      }
      default:
        yield dispatch(dashboardAction.getSchoolsByWardAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(dashboardAction.getSchoolsByWardAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu loại hình trường
 */
export function* getSchoolTypeDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getSchoolTypeDataAction.request());

    const districtCodes = payload?.districtCodes || [];

    const request = {
      url: urlApi.dashboard?.schoolsByWard,
      params: {
        districtCode: districtCodes.length > 0 ? districtCodes.join(",") : undefined,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // API trả về format: { "districtCode": [{ levelCode, totalSchools, publicCount, privateCount, autonomousCount, ... }] }
        // Tổng hợp publicCount, privateCount, autonomousCount từ tất cả districts
        let totalPublic = 0;
        let totalPrivate = 0;
        let totalAutonomous = 0;

        if (data && typeof data === "object") {
          Object.keys(data).forEach((districtCode) => {
            const districtData = data[districtCode];
            if (!Array.isArray(districtData)) return;

            districtData.forEach((item) => {
              totalPublic += item.publicCount || 0;
              totalPrivate += item.privateCount || 0;
              totalAutonomous += item.autonomousCount || 0;
            });
          });
        }

        const schoolTypeData = {
          public: totalPublic,
          private: totalPrivate,
          autonomous: totalAutonomous,
          total: totalPublic + totalPrivate + totalAutonomous,
        };

        yield dispatch(
          dashboardAction.getSchoolTypeDataAction.success({
            schoolTypeData,
          })
        );
        break;
      }
      default:
        yield dispatch(dashboardAction.getSchoolTypeDataAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(dashboardAction.getSchoolTypeDataAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu kế hoạch giáo dục (cho QM 3.1.2)
 */
export function* getEducationPlanDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getEducationPlanDataAction.request());

    const wardIds = payload?.wardIds || [];
    const state = yield select();
    const globalKey = injectKey.GLOBAL;
    const districts = state[globalKey]?.districtOpt || [];
    const wardOptions = districts
      .map((district) => ({
        id: district.id || district.code || String(district.districtId || ""),
        name: district.name || district.districtName || "",
      }))
      .filter((ward) => ward.id && ward.name);

    // Mock data
    const educationPlanData = generateEducationPlanData(wardIds, wardOptions);

    yield dispatch(
      dashboardAction.getEducationPlanDataAction.success({
        educationPlanData,
      })
    );

    // Uncomment để sử dụng API thực tế:
    /*
    const request = {
      url: urlApi.dashboard?.educationPlan || "management-service/v2/api/public/dashboard/education-plan",
      params: {
        wardIds: wardIds,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield dispatch(
          dashboardAction.getEducationPlanDataAction.success({
            educationPlanData: data.educationPlanData || [],
          })
        );
        break;
      default:
        yield dispatch(dashboardAction.getEducationPlanDataAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
    */
  } catch (err) {
    yield dispatch(dashboardAction.getEducationPlanDataAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy danh sách trường khi drill-down từ biểu đồ kế hoạch giáo dục
 */
export function* getEducationPlanSchoolsSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getEducationPlanSchoolsAction.request());

    const { wardId, planStatus } = payload;

    // Mock data
    const schools = generateEducationPlanSchools(wardId, planStatus);

    yield dispatch(
      dashboardAction.getEducationPlanSchoolsAction.success({
        schools,
      })
    );

    // Uncomment để sử dụng API thực tế:
    /*
    const request = {
      url: urlApi.dashboard?.educationPlanSchools || "management-service/v2/api/public/dashboard/education-plan-schools",
      params: {
        wardId: wardId,
        planStatus: planStatus,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield dispatch(
          dashboardAction.getEducationPlanSchoolsAction.success({
            schools: data,
          })
        );
        break;
      default:
        yield dispatch(dashboardAction.getEducationPlanSchoolsAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
    */
  } catch (err) {
    yield dispatch(dashboardAction.getEducationPlanSchoolsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu học sinh theo cấp học (cho HS-AN)
 */
export function* getStudentByLevelSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getStudentByLevelAction.request());

    const districtCodes = payload?.districtCodes || [];

    const request = {
      url: urlApi.dashboard?.students,
      params: {
        districtCode: districtCodes.length > 0 ? districtCodes.join(",") : undefined,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // API trả về format: { "districtCode": [{ levelCode, totalStudents, publicCount, privateCount, autonomousCount, ... }] }
        // Map về format: [{ id, ward, thpt, thcs, th }]
        const studentByLevelData = [];

        // Lấy districts từ global store để map districtCode sang districtName
        const globalState = yield select();
        const globalKey = injectKey.GLOBAL;
        const districts = globalState[globalKey]?.districtOpt || [];
        const districtMap = new Map(); // Map districtCode -> districtName

        districts.forEach((district) => {
          const code =
            district.code || district.districtCode || String(district.id || "");
          districtMap.set(code, district.name || district.districtName || "");
        });

        // Tạo Set từ districtCodes đã được chọn để kiểm tra
        const selectedDistrictCodes = new Set(
          districtCodes.map((code) => String(code))
        );

        // Xử lý data từ API - lấy totalStudents theo levelCode
        const processedDistrictCodes = new Set();

        if (data && typeof data === "object") {
          Object.keys(data).forEach((districtCode) => {
            const districtData = data[districtCode];
            if (!Array.isArray(districtData)) return;

            const normalizedCode = String(districtCode);

            // Khởi tạo object cho district này
            const districtInfo = {
              id: normalizedCode,
              ward:
                districtMap.get(normalizedCode) ||
                `Phường/Xã ${normalizedCode}`,
              thpt: 0,
              thcs: 0,
              th: 0,
            };

            // Lấy totalStudents theo levelCode
            districtData.forEach((item) => {
              const {
                levelCode,
                totalStudents = 0,
              } = item;

              if (levelCode === "THPT") {
                districtInfo.thpt = totalStudents;
              } else if (levelCode === "THCS") {
                districtInfo.thcs = totalStudents;
              } else if (levelCode === "TH") {
                districtInfo.th = totalStudents;
              }
            });

            studentByLevelData.push(districtInfo);
            processedDistrictCodes.add(normalizedCode);
          });
        }

        // Thêm các phường/xã đã chọn nhưng không có data từ API (hiển thị 0)
        selectedDistrictCodes.forEach((districtCode) => {
          // Kiểm tra xem đã được xử lý chưa
          if (!processedDistrictCodes.has(districtCode)) {
            studentByLevelData.push({
              id: districtCode,
              ward:
                districtMap.get(districtCode) || `Phường/Xã ${districtCode}`,
              thpt: 0,
              thcs: 0,
              th: 0,
            });
            processedDistrictCodes.add(districtCode);
          }
        });

        // Tạo dữ liệu theo loại hình trường - tính tổng từ studentByLevelData
        const totalStudents = studentByLevelData.reduce(
          (sum, item) => sum + (item.thpt || 0) + (item.thcs || 0) + (item.th || 0),
          0
        );
        
        const studentBySchoolTypeData = {
          public: 0,
          private: 0,
          autonomous: 0,
          total: totalStudents,
        };

        yield dispatch(
          dashboardAction.getStudentByLevelAction.success({
            studentByLevelData,
            studentBySchoolTypeData,
          })
        );
        break;
      }
      default:
        yield dispatch(dashboardAction.getStudentByLevelAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(dashboardAction.getStudentByLevelAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu học sinh theo loại hình trường
 */
export function* getStudentBySchoolTypeSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getStudentBySchoolTypeAction.request());

    const districtCodes = payload?.districtCodes || [];

    const request = {
      url:
        urlApi.dashboard?.students ||
        "management-service/v2/api/api/report/students",
      params: {
        districtCode: districtCodes.length > 0 ? districtCodes.join(",") : undefined,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // API trả về format: { "districtCode": [{ levelCode, totalStudents, publicCount, privateCount, autonomousCount, ... }] }
        // Tổng hợp publicCount, privateCount, autonomousCount từ tất cả districts
        let totalPublic = 0;
        let totalPrivate = 0;
        let totalAutonomous = 0;

        if (data && typeof data === "object") {
          Object.keys(data).forEach((districtCode) => {
            const districtData = data[districtCode];
            if (!Array.isArray(districtData)) return;

            districtData.forEach((item) => {
              totalPublic += item.publicStudents || 0;
              totalPrivate += item.privateStudents || 0;
              totalAutonomous += item.autonomousStudents || 0;
            });
          });
        }

        const studentBySchoolTypeData = {
          public: totalPublic,
          private: totalPrivate,
          autonomous: totalAutonomous,
          total: totalPublic + totalPrivate + totalAutonomous,
        };

        yield dispatch(
          dashboardAction.getStudentBySchoolTypeAction.success({
            studentBySchoolTypeData,
          })
        );
        break;
      }
      default:
        yield dispatch(
          dashboardAction.getStudentBySchoolTypeAction.failure(meta)
        );
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(dashboardAction.getStudentBySchoolTypeAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu giáo viên theo loại hình trường
 */
export function* getTeacherBySchoolTypeSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getTeacherBySchoolTypeAction.request());

    const wardIds = payload?.wardIds || [];
    const districtCodes = Array.isArray(wardIds) ? wardIds : [];

    const request = {
      url: urlApi.dashboard?.staff,
      params: {
        districtCode: districtCodes.length > 0 ? districtCodes.join(",") : undefined,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        // API trả về format: { "districtCode": [{ districtCode, year, levelCode, totalStaff, publicStaff, privateStaff, autonomousStaff, ... }] }
        // Tổng hợp publicStaff, privateStaff, autonomousStaff từ tất cả districts
        let totalPublic = 0;
        let totalPrivate = 0;
        let totalAutonomous = 0;

        if (data && typeof data === "object") {
          Object.keys(data).forEach((districtCode) => {
            const districtData = data[districtCode];
            if (!Array.isArray(districtData)) return;

            districtData.forEach((item) => {
              // Lấy trực tiếp từ các field publicStaff, privateStaff, autonomousStaff
              totalPublic += Number(item.publicStaff || 0);
              totalPrivate += Number(item.privateStaff || 0);
              totalAutonomous += Number(item.autonomousStaff || 0);
            });
          });
        }

        const teacherBySchoolTypeData = {
          public: totalPublic,
          private: totalPrivate,
          autonomous: totalAutonomous,
          total: totalPublic + totalPrivate + totalAutonomous,
        };

        yield dispatch(
          dashboardAction.getTeacherBySchoolTypeAction.success({
            teacherBySchoolTypeData,
          })
        );
        break;
      }
      default:
        yield dispatch(dashboardAction.getTeacherBySchoolTypeAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield dispatch(dashboardAction.getTeacherBySchoolTypeAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu tổng số BGH/GV/NV & CV
 */
export function* getTotalStaffDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getTotalStaffDataAction.request());

    const wardIds = payload?.wardIds || [];
    const staffTypes = payload?.staffTypes || ["BGH", "GV", "NV"];
    const level = payload?.level || "C1";
    const state = yield select();
    const globalKey = injectKey.GLOBAL;
    const districts = state[globalKey]?.districtOpt || [];
    const wardOptions = districts
      .map((district) => ({
        id: district.id || district.code || String(district.districtId || ""),
        name: district.name || district.districtName || "",
      }))
      .filter((ward) => ward.id && ward.name);

    // Mock data
    const totalStaffData = generateTotalStaffData(
      wardIds,
      staffTypes,
      level,
      wardOptions
    );

    yield dispatch(
      dashboardAction.getTotalStaffDataAction.success({
        totalStaffData,
      })
    );

    // Uncomment để sử dụng API thực tế:
    /*
    const request = {
      url: urlApi.dashboard?.totalStaff || "management-service/v2/api/public/dashboard/total-staff",
      params: {
        wardIds: wardIds,
        staffTypes: staffTypes,
        level: level,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield dispatch(
          dashboardAction.getTotalStaffDataAction.success({
            totalStaffData: data.totalStaffData || [],
          })
        );
        break;
      default:
        yield dispatch(dashboardAction.getTotalStaffDataAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
    */
  } catch (err) {
    yield dispatch(dashboardAction.getTotalStaffDataAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy dữ liệu biến động nhân sự
 */
export function* getStaffChangeDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getStaffChangeDataAction.request());

    const wardIds = payload?.wardIds || [];
    const state = yield select();
    const globalKey = injectKey.GLOBAL;
    const districts = state[globalKey]?.districtOpt || [];
    const wardOptions = districts
      .map((district) => ({
        id: district.id || district.code || String(district.districtId || ""),
        name: district.name || district.districtName || "",
      }))
      .filter((ward) => ward.id && ward.name);

    // Mock data
    const staffChangeData = generateStaffChangeData(wardIds, wardOptions);

    yield dispatch(
      dashboardAction.getStaffChangeDataAction.success({
        staffChangeData,
      })
    );

    // Uncomment để sử dụng API thực tế:
    /*
    const request = {
      url: urlApi.dashboard?.staffChange || "management-service/v2/api/public/dashboard/staff-change",
      params: {
        wardIds: wardIds,
      },
    };

    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield dispatch(
          dashboardAction.getStaffChangeDataAction.success({
            staffChangeData: data.staffChangeData || [],
          })
        );
        break;
      default:
        yield dispatch(dashboardAction.getStaffChangeDataAction.failure(meta));
        yield dispatch(setMessageByFieldAction("error", meta));
    }
    */
  } catch (err) {
    yield dispatch(dashboardAction.getStaffChangeDataAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy tổng số học sinh được đánh giá
 */
export function* getTotalStudentEvaluatedSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getTotalStudentEvaluatedAction.request());

    const wardIds = payload?.wardIds || [];

    // Mock data
    const totalStudentEvaluatedData =
      generateTotalStudentEvaluatedData(wardIds);

    yield dispatch(
      dashboardAction.getTotalStudentEvaluatedAction.success({
        totalStudentEvaluatedData,
      })
    );
  } catch (err) {
    yield dispatch(dashboardAction.getTotalStudentEvaluatedAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy tỷ lệ học lực
 */
export function* getAcademicPerformanceDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getAcademicPerformanceDataAction.request());

    const wardIds = payload?.wardIds || [];

    // Mock data
    const academicPerformanceData = generateAcademicPerformanceData(wardIds);

    yield dispatch(
      dashboardAction.getAcademicPerformanceDataAction.success({
        academicPerformanceData,
      })
    );
  } catch (err) {
    yield dispatch(
      dashboardAction.getAcademicPerformanceDataAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy tỷ lệ rèn luyện
 */
export function* getConductPerformanceDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(dashboardAction.getConductPerformanceDataAction.request());

    const wardIds = payload?.wardIds || [];

    // Mock data
    const conductPerformanceData = generateConductPerformanceData(wardIds);

    yield dispatch(
      dashboardAction.getConductPerformanceDataAction.success({
        conductPerformanceData,
      })
    );
  } catch (err) {
    yield dispatch(
      dashboardAction.getConductPerformanceDataAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy tỷ lệ học lực theo khối
 */
export function* getAcademicPerformanceByGradeDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      dashboardAction.getAcademicPerformanceByGradeDataAction.request()
    );

    const wardIds = payload?.wardIds || [];

    // Mock data - không có dữ liệu phân tách theo khối
    const academicPerformanceByGradeData =
      generateAcademicPerformanceByGradeData(wardIds);

    yield dispatch(
      dashboardAction.getAcademicPerformanceByGradeDataAction.success({
        academicPerformanceByGradeData,
      })
    );
  } catch (err) {
    yield dispatch(
      dashboardAction.getAcademicPerformanceByGradeDataAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

/**
 * Saga để lấy tỷ lệ rèn luyện theo khối
 */
export function* getConductPerformanceByGradeDataSaga({ payload = {} }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(
      dashboardAction.getConductPerformanceByGradeDataAction.request()
    );

    const wardIds = payload?.wardIds || [];

    // Mock data - không có dữ liệu phân tách theo khối
    const conductPerformanceByGradeData =
      generateConductPerformanceByGradeData(wardIds);

    yield dispatch(
      dashboardAction.getConductPerformanceByGradeDataAction.success({
        conductPerformanceByGradeData,
      })
    );
  } catch (err) {
    yield dispatch(
      dashboardAction.getConductPerformanceByGradeDataAction.failure(err)
    );
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* watchAll() {
  yield all([
    takeLatest(
      dashboardAction.getSchoolsByWardAction.TRIGGER,
      getSchoolsByWardSaga
    ),
    takeLatest(
      dashboardAction.getSchoolTypeDataAction.TRIGGER,
      getSchoolTypeDataSaga
    ),
    takeLatest(
      dashboardAction.getEducationPlanDataAction.TRIGGER,
      getEducationPlanDataSaga
    ),
    takeLatest(
      dashboardAction.getEducationPlanSchoolsAction.TRIGGER,
      getEducationPlanSchoolsSaga
    ),
    takeLatest(
      dashboardAction.getStudentByLevelAction.TRIGGER,
      getStudentByLevelSaga
    ),
    takeLatest(
      dashboardAction.getStudentBySchoolTypeAction.TRIGGER,
      getStudentBySchoolTypeSaga
    ),
    takeLatest(
      dashboardAction.getTeacherBySchoolTypeAction.TRIGGER,
      getTeacherBySchoolTypeSaga
    ),
    takeLatest(
      dashboardAction.getTotalStaffDataAction.TRIGGER,
      getTotalStaffDataSaga
    ),
    takeLatest(
      dashboardAction.getStaffChangeDataAction.TRIGGER,
      getStaffChangeDataSaga
    ),
    takeLatest(
      dashboardAction.getTotalStudentEvaluatedAction.TRIGGER,
      getTotalStudentEvaluatedSaga
    ),
    takeLatest(
      dashboardAction.getAcademicPerformanceDataAction.TRIGGER,
      getAcademicPerformanceDataSaga
    ),
    takeLatest(
      dashboardAction.getConductPerformanceDataAction.TRIGGER,
      getConductPerformanceDataSaga
    ),
    takeLatest(
      dashboardAction.getAcademicPerformanceByGradeDataAction.TRIGGER,
      getAcademicPerformanceByGradeDataSaga
    ),
    takeLatest(
      dashboardAction.getConductPerformanceByGradeDataAction.TRIGGER,
      getConductPerformanceByGradeDataSaga
    ),
  ]);
}
