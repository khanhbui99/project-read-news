import { Tab } from "@mui/material";
import { getAllDistrictsAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useEffect, useState } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import CategoryGV from "./components/CategoryGV";
import CategoryHSAN from "./components/CategoryHSAN";
import CategoryQM from "./components/CategoryQM";
// import CategoryQTDH from "./components/CategoryQTDH";
import {
  resetStoreDashboardAction,
  setFieldValueStoreDashboardAction,
} from "./store/actions";
import {
  ContainerStyled,
  ContentWrapper,
  TabPanelStyled,
  TabsStyled,
} from "./Styled";

const Main = () => {
  const [currentTab, setCurrentTab] = useState(0);
  const resetStore = useDispatchRedux(resetStoreDashboardAction);
  const setFieldValue = useDispatchRedux(setFieldValueStoreDashboardAction);
  const getAllDistricts = useDispatchRedux(getAllDistrictsAction);

  useEffect(() => {
    getAllDistricts();

    return () => resetStore();
  }, []);

  const handleTabChange = (event, newValue) => {
    setCurrentTab(newValue);
    setFieldValue("currentCategory", newValue);
  };

  return (
    <React.Fragment>
      <AppHeader componentName="Dashboard" isHiddenBtn />
      <ContainerStyled>
        <ContentWrapper>
          <TabsStyled
            value={currentTab}
            onChange={handleTabChange}
            variant="scrollable"
            scrollButtons="auto"
            allowScrollButtonsMobile
          >
            <Tab label="Quy hoạch – Tổ chức – Quản trị hệ thống (QM)" />
            <Tab label="Học sinh & An sinh giáo dục (HS, AN)" />
            <Tab label="Đội ngũ nhà giáo & cán bộ quản lý – nhân sự (GV)" />
            {/* <Tab label="Dạy học & Kết quả giáo dục (QTDH, KQ)" /> */}
          </TabsStyled>

          <TabPanelStyled>
            {currentTab === 0 && <CategoryQM />}
            {currentTab === 1 && <CategoryHSAN />}
            {currentTab === 2 && <CategoryGV />}
            {/* {currentTab === 3 && <CategoryQTDH />} */}
          </TabPanelStyled>
        </ContentWrapper>
      </ContainerStyled>
    </React.Fragment>
  );
};

export default Main;
