import { Box, Tab, Tabs } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled(Box)`
  padding: 2rem;
  min-height: 100vh;
  border-radius: 24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.gray[100]} 0%,
    #e8eef3 100%
  );

  @media (max-width: 1024px) {
    padding: 1.5rem;
  }

  @media (max-width: 768px) {
    padding: 1rem;
    border-radius: 16px;
  }

  @media (max-width: 480px) {
    padding: 0.75rem;
    border-radius: 12px;
  }
`;

export const ContentWrapper = styled(Box)`
  max-width: 1400px;
  margin: 0 auto;

  @media (max-width: 1400px) {
    max-width: 100%;
  }
`;

export const TabsStyled = styled(Tabs)`
  margin-bottom: 2rem;
  background: white;
  border-radius: 12px;
  padding: 0.5rem;
  overflow-x: auto;
  overflow-y: hidden;
  
  /* Style cho scrollbar */
  &::-webkit-scrollbar {
    height: 8px;
  }
  
  &::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 4px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 4px;
    
    &:hover {
      background: #555;
    }
  }
  
  /* Firefox scrollbar */
  scrollbar-width: thin;
  scrollbar-color: #888 #f1f1f1;

  .MuiTab-root {
    text-transform: none;
    font-weight: 600;
    font-size: 1rem;
    color: ${VPB_THEMES.colors.secondaryText};
    min-height: 48px;
    padding: 12px 16px;
    white-space: nowrap;
    flex-shrink: 0;

    &.Mui-selected {
      color: ${VPB_THEMES.colors.green};
    }
  }

  .MuiTabs-indicator {
    background: ${VPB_THEMES.colors.green};
    height: 3px;
    border-radius: 3px 3px 0 0;
  }

  @media (max-width: 1024px) {
    .MuiTab-root {
      font-size: 0.9rem;
      padding: 12px 12px;
    }
  }

  @media (max-width: 768px) {
    padding: 0.25rem;
    
    .MuiTab-root {
      font-size: 0.85rem;
      padding: 10px 8px;
      min-width: auto;
    }
  }

  @media (max-width: 480px) {
    .MuiTab-root {
      font-size: 0.8rem;
      padding: 8px 6px;
    }
  }
`;

export const TabPanelStyled = styled(Box)`
  padding: 0;

  @media (max-width: 768px) {
    padding: 0;
  }
`;

export const ChartContainerStyled = styled(Box)`
  width: 100%;
  margin-bottom: 2rem;

  @media (max-width: 768px) {
    margin-bottom: 1.5rem;
  }
`;

export const ChartHeaderStyled = styled(Box)`
  width: 100%;
`;

export const ChartContentStyled = styled(Box)`
  width: 100%;
  min-height: 400px;
  position: relative;

  @media (max-width: 768px) {
    min-height: 300px;
  }
`;

