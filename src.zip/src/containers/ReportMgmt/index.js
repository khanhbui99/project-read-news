export { DocumentReport, AddDocumentReport } from "./Document";

export { default as SchoolDashReport } from "./SchoolDash";
export { default as SchoolImpTempReport } from "./SchoolImpTemp";
export { default as EducationOwnershipDashReport } from "./EducationOwnershipDash";
export { default as StudentDashReport } from "./StudentDash";
export { default as MaterialDashReport } from "./MaterialDash";
export { default as KpiDashReport } from "./KpiDash";
