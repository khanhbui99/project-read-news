import AppHeader from "components/common/AppHeader";
import DistrictSummaryReport from "components/common/DistrictSummaryReport";

import { ChartsGridContainer, DistrictSummaryDashWarp } from "./Styled";

const Main = () => {
  return (
    <DistrictSummaryDashWarp>
      <AppHeader componentName="StudentDashReport" isHiddenBtn />

      <ChartsGridContainer>
        <DistrictSummaryReport
          categoryName="STUDENT_QUALITY"
          title="Biểu đồ kết quả học tập"
          description="Biểu đồ chất lượng học sinh theo từng phường"
          metricField={[
            {
              value: "GOOD",
              label: "Giỏi",
              color: "#10b981",
            },
            {
              value: "FAIR",
              label: "Khá",
              color: "#f59e0b",
            },
            {
              value: "PASS",
              label: "Đạt",
              color: "#3b82f6",
            },
            {
              value: "FAIL",
              label: "Chưa Đạt",
              color: "#ef4444",
            },
          ]}
        />

        <DistrictSummaryReport
          categoryName="STUDENT_RESULT_SUMMARY"
          title="Biểu đồ kết quả rèn luyện"
          description="Biểu đồ kết quả rèn luyện theo từng phường"
          metricField={[
            {
              value: "GOOD",
              label: "Giỏi",
              color: "#10b981",
            },
            {
              value: "FAIR",
              label: "Khá",
              color: "#f59e0b",
            },
            {
              value: "PASS",
              label: "Đạt",
              color: "#3b82f6",
            },
            {
              value: "FAIL",
              label: "Chưa Đạt",
              color: "#ef4444",
            },
          ]}
        />

        <DistrictSummaryReport
          categoryName="STUDENT_MOBILITY"
          title="Biểu đồ Số học sinh chuyển trường, thôi học"
          description="Biểu đồ Số học sinh chuyển trường, thôi học theo từng phường"
          metricField={[
            {
              value: "INCOMING",
              label: "Học sinh chuyển đến",
              color: "#22c55e",
            },
            {
              value: "OUTGOING",
              label: "Học sinh chuyển đi",
              color: "#0077be",
            },
            {
              value: "DROPOUT",
              label: "Học sinh bỏ học",
              color: "#dc2626",
            },
          ]}
        />

        <DistrictSummaryReport
          categoryName="STUDENT_SPECIAL_GROUP"
          title="Biểu đồ Nhóm học sinh đặc biệt"
          description="Biểu đồ Nhóm học sinh đặc biệt theo từng phường"
          metricField={[
            {
              value: "ETHNIC_MINORITY",
              label: "Học sinh dân tộc thiểu số",
              color: "#22c55e",
            },
            {
              value: "DISABLED",
              label: "Học sinh khuyết tật",
              color: "#f59e0b",
            },
            {
              value: "ORPHAN",
              label: "Học sinh mồ côi",
              color: "#8b5cf6",
            },
            {
              value: "POOR_HOUSEHOLD",
              label: "Học sinh hộ nghèo",
              color: "#e11d48",
            },
            {
              value: "NEAR_POOR_HOUSEHOLD",
              label: "Học sinh hộ cận nghèo",
              color: "#0077be",
            },
            {
              value: "MARTYR_CHILD",
              label: "Con liệt sĩ",
              color: "#be123c",
            },
          ]}
        />
      </ChartsGridContainer>
    </DistrictSummaryDashWarp>
  );
};

export default Main;
