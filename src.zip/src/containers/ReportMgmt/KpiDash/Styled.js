import { Box } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const DistrictSummaryDashWarp = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

export const FilterCont = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;

  button {
    background-color: ${VPB_THEMES.colors.table.headerBg};
  }
  .groupProduct {
    label {
      color: ${VPB_THEMES.colors.darkBlue} !important;
      font-size: 13px !important;
      margin-bottom: 0px !important;
      font-weight: 500;
    }
    .MuiAutocomplete-root {
      min-width: 176.5px;
      border-radius: 8px;
      color: ${VPB_THEMES.colors.darkBlue};
      background: ${VPB_THEMES.colors.shade};

      .MuiInputBase-root {
        height: 40px;
        padding-left: 16px;
        border-radius: 8px;
      }

      input {
        padding: 0 !important;
        font-size: 16px;
      }
      fieldset {
        border: unset;
      }
    }
  }
`;

export const ChartsGridContainer = styled(Box)`
  display: grid;
  grid-template-columns: 1fr;
  gap: 24px;
  width: 100%;

  @media (max-width: 1200px) {
    grid-template-columns: 1fr;
    gap: 20px;
  }

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 16px;
  }
`;

export const ChartContainerStyled = styled(Box)`
  width: 100%;
  margin-bottom: 0;

  @media (max-width: 768px) {
    margin-bottom: 0;
  }
`;

export const ChartHeaderStyled = styled(Box)`
  width: 100%;
`;

export const ChartContentStyled = styled(Box)`
  width: 100%;
  min-height: 400px;
  position: relative;

  @media (max-width: 768px) {
    min-height: 300px;
  }
`;

