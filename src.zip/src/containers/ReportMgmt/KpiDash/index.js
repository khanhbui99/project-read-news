import ListSkeleton from "skeletons/ListSkeleton";
import loadable from "utils/loadable";

const DistrictSummaryDashReport = loadable(() => import("./Main"), {
  fallback: <ListSkeleton />,
});

export default DistrictSummaryDashReport;

