import AppHeader from "components/common/AppHeader";

import BudgetEfficiencyChart from "./components/BudgetEfficiencyChart";
import { ChartsGridContainer, DistrictSummaryDashWarp } from "./Styled";

const Main = () => {
  return (
    <DistrictSummaryDashWarp>
      <AppHeader componentName="MaterialDashReport" isHiddenBtn />

      <ChartsGridContainer>
        <BudgetEfficiencyChart />
      </ChartsGridContainer>
    </DistrictSummaryDashWarp>
  );
};

export default Main;
