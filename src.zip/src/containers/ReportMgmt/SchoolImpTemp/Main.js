import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import AppButton from "components/common/AppButton";
import AppHeader from "components/common/AppHeader";
import DownloadTemplate from "components/ImportTemp/DownloadTemplate";
import ImportSection from "components/ImportTemp/ImportSection";
import { ContainerStyled, ContentWrapper } from "components/ImportTemp/Styled";
import React from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import {
  importReportAction,
  downloadTemplateReportAction,
} from "./store/actions";
import { VALID_EXTENSIONS, ACCEPTED_FILE_TYPES } from "./store/constants";

const Main = () => {
  const setMessageByField = useDispatchRedux(setMessageByFieldAction);
  const setLoadingPage = useDispatchRedux(setLoadingAction);
  const rqImportReport = useDispatchRedux(importReportAction);
  const rqDownloadTemplateReport = useDispatchRedux(
    downloadTemplateReportAction
  );

  const handleSendKpiReport = ({ removeFile }) => {
    setLoadingPage(true);

    localStorage.setItem("kpi2025", "1207");

    setTimeout(() => {
      setLoadingPage(false);
      removeFile();
      setMessageByField("success", {
        message: "Gửi báo cáo KPI thành công",
      });
    }, 1000);
  };

  return (
    <React.Fragment>
      <AppHeader isHiddenBtn componentName="SchoolImpTempReport" />
      <ContainerStyled>
        <ContentWrapper>
          <DownloadTemplate handleDownloadTemp={rqDownloadTemplateReport} />
          <ImportSection
            externalAction={({removeFile}) => (
              <AppButton
                style={{ marginRight: 8 }}
                onClick={() => handleSendKpiReport({removeFile})}
              >
                Gửi báo cáo KPI
              </AppButton>
            )}
            validExtensions={VALID_EXTENSIONS}
            acceptedFileTypes={ACCEPTED_FILE_TYPES}
            hanldeImportFile={rqImportReport}
          />
        </ContentWrapper>
      </ContainerStyled>
    </React.Fragment>
  );
};

export default Main;
