import AppHeader from "components/common/AppHeader";
import DistrictSummaryReport from "components/common/DistrictSummaryReport";

import { ChartsGridContainer, DistrictSummaryDashWarp } from "./Styled";

const Main = () => {
  return (
    <DistrictSummaryDashWarp>
      <AppHeader componentName="MaterialDashReport" isHiddenBtn />

      <ChartsGridContainer>

        <DistrictSummaryReport
          categoryName="CLASSROOM"
          title="Cơ sở vật chất phòng học"
          description="Biểu đồ Cơ sở vật chất phòng học theo từng phường"
          metricField={[
            {
              value: "ROOM_NORMAL",
              label: "Phòng học thường",
              color: "#2563eb",
            },
            {
              value: "ROOM_IT",
              label: "Phòng học Tin học",
              color: "#22c55e",
            },
            {
              value: "FOREIGN",
              label: "Phòng học Ngoại ngữ",
              color: "#f59e0b",
            },
            {
              value: "SCIENCE",
              label: "Phòng học Khoa học",
              color: "#a855f7",
            },
            {
              value: "TECH",
              label: "Phòng học Kỹ thuật",
              color: "#06b6d4",
            },
            {
              value: "MUSIC",
              label: "Phòng học Âm nhạc",
              color: "#f43f5e",
            },
            {
              value: "LIBRARY",
              label: "Thư viện",
              color: "#14b8a6",
            },
            {
              value: "SUPPORT",
              label: "Phòng hỗ trợ",
              color: "#64748b",
            },
          ]}
        />

        <DistrictSummaryReport
          categoryName="SCHOOL_STANDARD"
          title="Biểu đồ Trường đạt chuẩn"
          description="Biểu đồ Trường đạt chuẩn theo từng phường"
          metricField={[
            {
              value: "TOTAL_PUBLIC_SCHOOL",
              label: "Tổng số trường công lập",
              color: "#2563eb",
            },
            {
              value: "QG_LEVEL_1",
              label: "Trường đạt chuẩn Quốc gia mức độ 1",
              color: "#22c55e",
            },
            {
              value: "QG_LEVEL_2",
              label: "Trường đạt chuẩn Quốc gia mức độ 2",
              color: "#10b981",
            },
            {
              value: "KDCL_RATE",
              label: "Tỷ lệ kiểm định chất lượng",
              color: "#f59e0b",
            },
            {
              value: "ADV_LIBRARY",
              label: "Thư viện tiên tiến",
              color: "#8b5cf6",
            },
            {
              value: "GREEN_CLEAN",
              label: "Trường xanh - sạch - đẹp",
              color: "#14b8a6",
            },
          ]}
        />

        <DistrictSummaryReport
          categoryName="R_GV_LOP"
          title="Biểu đồ Tỉ lệ giáo viên / lớp trung bình"
          description="Biểu đồ Tỉ lệ giáo viên / lớp trung bình theo từng quận/huyện"
          metricField={[
            {
              value: "AVG_TEACHER_PER_CLASS",
              label: "Tỷ lệ giáo viên / lớp trung bình",
              color: "#2563eb",
            },
          ]}
        />

        <DistrictSummaryReport
          categoryName="PROCUREMENT"
          title="Biểu đồ Đấu thầu mua sắm"
          description="Biểu đồ Đấu thầu mua sắm theo từng quận/huyện"
          metricField={[
            {
              value: "TOTAL_PACKAGE",
              label: "Tổng số gói thầu",
              color: "#2563eb",
            },
            {
              value: "TOTAL_PACKAGE_PRICE",
              label: "Tổng giá trị gói thầu",
              color: "#22c55e",
            },
            {
              value: "TOTAL_WIN_PRICE",
              label: "Tổng giá trị trúng thầu",
              color: "#10b981",
            },
            {
              value: "SAVING_RATE",
              label: "Tỷ lệ tiết kiệm",
              color: "#f59e0b",
            },
          ]}
        />
      </ChartsGridContainer>
    </DistrictSummaryDashWarp>
  );
};

export default Main;
