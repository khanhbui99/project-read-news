import AppHeader from "components/common/AppHeader";
import PropTypes from "prop-types";
import { useEffect } from "react";
import { isSystemAdmin } from "utils/helpers";
import { useDispatchRedux } from "utils/hooks/useRedux";

import { ListExamGenerateWrapper } from "./components/List/Styled";
import Table from "./components/List/Table";
import {
  queryTemplateMgmttAction,
  resetStoreTemplateMgmttAction,
} from "./store/actions";

const ListExamGenerate = () => {
  const resetStoreTemplateMgmtt = useDispatchRedux(
    resetStoreTemplateMgmttAction
  );
  const fetchAllTemplateMgmt = useDispatchRedux(queryTemplateMgmttAction);

  const isAccountAdmin = isSystemAdmin();

  useEffect(() => {
    fetchAllTemplateMgmt();
    return () => resetStoreTemplateMgmtt();
  }, []);

  return (
    <ListExamGenerateWrapper>
      <AppHeader
        btnName="Tạo báo cáo mới"
        isHiddenBtn={!isAccountAdmin}
        componentName="DocumentReport"
        componentNameAdd="AddDocumentReport"
      />

      <Table isAccountAdmin={isAccountAdmin}/>
    </ListExamGenerateWrapper>
  );
};

ListExamGenerate.propTypes = {
  historyPathCreate: PropTypes.string,
  historyPathEdit: PropTypes.string,
};

export default ListExamGenerate;
