import AppHeader from "components/common/AppHeader";
import { useState } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import DocumentForm from "./components/Form";
import { createTemplateMgmttAction } from "./store/actions";

const DocumentFormContainer = () => {
  const [wordFile, setWordFile] = useState(null);
  const [wordHtml, setWordHtml] = useState("");

  const rqCreateTemplate = useDispatchRedux(createTemplateMgmttAction);

  const handleSubmit = async (values) => {
    // Dispatch action to create template
    rqCreateTemplate({
      file: wordFile,
      templateCode: values.code,
      templateName: values.name,
      // yearId: values.academicYearId,
      yearId: 1,
      chartIds: values.schools || [],
    });
  };

  return (
    <>
      <AppHeader isHiddenBtn componentName="AddDocumentReport" />

      <DocumentForm
        onSubmit={handleSubmit}
        wordFile={wordFile}
        setWordFile={setWordFile}
        wordHtml={wordHtml}
        setWordHtml={setWordHtml}
      />
    </>
  );
};

export default DocumentFormContainer;
