import { getAllDistrictsAction } from "App/store/actions";
import { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Filter from "./components/Filter";
import SchoolDetailModal from "./components/SchoolDetailModal";
import StaffChangesChart from "./components/StaffChangesChart";
import StaffDistributionChart from "./components/StaffDistributionChart";
import StudentCountChart from "./components/StudentCountChart";
import { allSchoolAction } from "./store/actions";
import { EducationOwnershipDashWarp, ChartsGridContainer } from "./Styled";

const Main = () => {
  const fetchAllDistricts = useDispatchRedux(getAllDistrictsAction);
  const fetchAllSchool = useDispatchRedux(allSchoolAction);

  useEffect(() => {
    fetchAllSchool();
    fetchAllDistricts();
  }, []);

  return (
    <EducationOwnershipDashWarp>
      <Filter />

      <ChartsGridContainer>
        <StudentCountChart />
        <StaffDistributionChart />
        <StaffChangesChart />
      </ChartsGridContainer>

      <SchoolDetailModal />
    </EducationOwnershipDashWarp>
  );
};

export default Main;
