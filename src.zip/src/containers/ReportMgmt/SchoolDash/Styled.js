import { Box, Stack } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const SchoolDashWarp = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

export const FilterCont = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;

  button {
    background-color: ${VPB_THEMES.colors.table.headerBg};
  }
  .groupProduct {
    label {
      color: ${VPB_THEMES.colors.darkBlue} !important;
      font-size: 13px !important;
      margin-bottom: 0px !important;
      font-weight: 500;
    }
    .MuiAutocomplete-root {
      min-width: 176.5px;
      border-radius: 8px;
      color: ${VPB_THEMES.colors.darkBlue};
      background: ${VPB_THEMES.colors.shade};

      .MuiInputBase-root {
        height: 40px;
        padding-left: 16px;
        border-radius: 8px;
      }

      input {
        padding: 0 !important;
        font-size: 16px;
      }
      fieldset {
        border: unset;
      }
    }
  }
`;

export const CardItemStyle = styled(Stack)`
  flex: 1;
  padding: 24px 16px;
  border-radius: 16px;
  min-width: 200px;
  width: max-content;
  cursor: pointer;
  background: ${({ $bg = VPB_THEMES.colors.white }) => $bg};
  // background-image: url(${({ $img = "" }) => $img});
  // background-size: cover;
  // background-repeat: no-repeat;
  // background-position: center;
  @media (min-width: 1920px) {
    height: 120px;
  }

  &:hover {
    box-shadow: 0px 8px 16px 0px #00000014;
  }
`;

export const StackScroll = styled(Stack)`
  overflow-y: auto;
  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* IE 10+ */

  &::-webkit-scrollbar {
    display: none; /* Chrome, Safari */
  }
`;

// Styled components cho charts độc lập (giống Dashboard)
export const ChartsGridContainer = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
  gap: 24px;
  width: 100%;

  @media (max-width: 1200px) {
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
  }

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 16px;
  }
`;

export const ChartContainerStyled = styled(Box)`
  width: 100%;
  margin-bottom: 0;

  @media (max-width: 768px) {
    margin-bottom: 0;
  }
`;

export const ChartHeaderStyled = styled(Box)`
  width: 100%;
`;

export const ChartContentStyled = styled(Box)`
  width: 100%;
  min-height: 400px;
  position: relative;

  @media (max-width: 768px) {
    min-height: 300px;
  }
`;

// Styled components cho Summary section
export const SummaryGridContainer = styled(Box)`
  display: flex;
  flex-direction: row;
  gap: 20px;
  width: 100%;
  overflow-x: auto;
  overflow-y: hidden;
  padding-bottom: 8px;
  scroll-behavior: smooth;
  -webkit-overflow-scrolling: touch;

  /* Chrome/Safari/Edge - Ẩn scrollbar hoàn toàn */
  &::-webkit-scrollbar {
    width: 0;
    height: 0;
    background: transparent;
  }

  &::-webkit-scrollbar-track {
    display: none;
  }

  &::-webkit-scrollbar-thumb {
    display: none;
  }

  /* Firefox và các trình duyệt khác - Scrollbar nhỏ nhất có thể */
  scrollbar-width: thin;
  scrollbar-color: transparent transparent;

  @media (max-width: 768px) {
    gap: 16px;
  }
`;

export const SummaryCardStyled = styled(Box)`
  position: relative;
  padding: 24px;
  border-radius: 16px;
  background: ${({ $gradient }) => $gradient || "#ffffff"} !important;
  border: ${({ $gradient }) => ($gradient ? "none" : "1px solid #e8eef3")};
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
  cursor: pointer;
  min-height: 160px;
  min-width: 300px;
  width: 300px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  justify-content: space-between;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    border-color: ${({ $accentColor, $gradient }) =>
      $gradient ? "transparent" : $accentColor || "#e8eef3"};
  }

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: ${({ $accentColor }) => $accentColor || "transparent"};
    opacity: ${({ $gradient }) => ($gradient ? "0.8" : "1")};
  }

  @media (max-width: 768px) {
    padding: 20px;
    min-height: 140px;
    min-width: 260px;
    width: 260px;
  }

  @media (max-width: 480px) {
    min-width: 240px;
    width: 240px;
  }
`;

export const SummaryCardHeader = styled(Box)`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 16px;
`;

export const SummaryCardIcon = styled(Box)`
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: ${({ $bgColor }) => $bgColor || "#f0f9f4"};
  flex-shrink: 0;
  margin-right: 16px;

  svg {
    font-size: 28px;
    color: ${({ $iconColor }) => $iconColor || "#00AD53"};
  }

  @media (max-width: 768px) {
    width: 48px;
    height: 48px;
    margin-right: 12px;

    svg {
      font-size: 24px;
    }
  }
`;

export const SummaryCardContent = styled(Box)`
  flex: 1;
  display: flex;
  flex-direction: column;
`;

export const SummaryCardValue = styled(Box)`
  font-size: clamp(1.75rem, 3vw, 2.25rem);
  font-weight: 700;
  line-height: 1.2;
  color: ${({ $textColor }) => $textColor || "#0B263D"};
  margin-bottom: 8px;
  word-break: break-word;
  letter-spacing: -0.02em;
`;

export const SummaryCardLabel = styled(Box)`
  font-size: clamp(0.875rem, 1.2vw, 1rem);
  font-weight: 600;
  line-height: 1.4;
  color: ${({ $textColor }) => $textColor || "#526779"};
  margin-bottom: 8px;
`;

export const SummaryCardSubtitle = styled(Box)`
  font-size: clamp(0.75rem, 1vw, 0.875rem);
  font-weight: 400;
  line-height: 1.5;
  color: ${({ $textColor }) => $textColor || "#8a9ba8"};
  margin-top: 4px;
`;

export const SummaryCardTrend = styled(Box)`
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 12px;
  padding: 6px 10px;
  border-radius: 8px;
  background: ${({ $trendBg }) => $trendBg || "#f0f9f4"};
  width: fit-content;
  font-size: 0.8125rem;
  font-weight: 600;
  color: ${({ $trendColor }) => $trendColor || "#00AD53"};
`;

export const SummaryTitle = styled(Box)`
  font-size: clamp(1.5rem, 2.5vw, 1.75rem);
  font-weight: 700;
  color: #0B263D;
  margin-bottom: 24px;
  letter-spacing: -0.01em;

  @media (max-width: 768px) {
    margin-bottom: 20px;
  }
`;

export const SummaryCardFooter = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #f0f4f8;
`;

export const SummaryCardComparison = styled(Box)`
  font-size: 0.8125rem;
  font-weight: 500;
  color: ${({ $textColor }) => $textColor || "#8a9ba8"};
`;
