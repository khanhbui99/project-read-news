import ClassesPerGradeChart from "./components/ClassesPerGradeChart";
import Filter from "./components/Filter";
import RevenueChart from "./components/RevenueChart";
import StaffChangesChart from "./components/StaffChangesChart";
import StaffDistributionChart from "./components/StaffDistributionChart";
import StudentsPerClassChart from "./components/StudentsPerClassChart";
// import StudentChart from "./components/StudentChart";
import Summary from "./components/Sumarry";
import { SchoolDashWarp, ChartsGridContainer } from "./Styled";

const Main = () => {
  return (
    <SchoolDashWarp>
      <Filter />
      <Summary />

      {/* <StudentChart /> */}
      <ChartsGridContainer>
        <StudentsPerClassChart />
        {/* <StaffDistributionChart /> */}
        <StaffChangesChart />
        {/* <ClassesPerGradeChart />
        <RevenueChart /> */}
      </ChartsGridContainer>
    </SchoolDashWarp>
  );
};

export default Main;
