import React from 'react';
import { useInjectReducer } from 'utils/injectReducer';
import { useInjectSaga } from 'utils/injectSaga';

import CourseDetail from './components/CourseDetail';
import { key } from './store/constants';
import reducer from './store/reducer';
import saga from './store/saga';

const CourseManagementDetail = () => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });

  return <CourseDetail />;
};

export default CourseManagementDetail;
