/**
 * Sorting helpers
 */

export const sortLessonsByOrderIndex = (lessons) => {
  if (!Array.isArray(lessons)) return [];
  return [...lessons].sort((a, b) => a.orderIndex - b.orderIndex);
};

export const sortMaterialsByOrderIndex = (materials) => {
  if (!Array.isArray(materials)) return [];
  return [...materials].sort((a, b) => a.orderIndex - b.orderIndex);
};

/**
 * Validation helpers
 */

export const validateCourseForm = (values) => {
  const errors = {};

  if (!values.name || values.name.trim() === '') {
    errors.name = 'Tên bài giảng là bắt buộc';
  }

  if (!values.subjectId) {
    errors.subjectId = 'Môn học là bắt buộc';
  }

  if (!values.description || values.description.trim() === '') {
    errors.description = 'Mô tả là bắt buộc';
  }

  if (!values.status) {
    errors.status = 'Trạng thái là bắt buộc';
  } else if (!['ACTIVE', 'INACTIVE'].includes(values.status)) {
    errors.status = 'Trạng thái không hợp lệ';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

export const validateLessonForm = (values) => {
  const errors = {};

  if (!values.title || values.title.trim() === '') {
    errors.title = 'Tiêu đề bài học là bắt buộc';
  }

  if (!values.orderIndex || values.orderIndex < 1) {
    errors.orderIndex = 'Thứ tự phải lớn hơn 0';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

export const validateMaterialForm = (values) => {
  const errors = {};

  if (!values.title || values.title.trim() === '') {
    errors.title = 'Tiêu đề tài liệu là bắt buộc';
  }

  if (!values.materialType) {
    errors.materialType = 'Loại tài liệu là bắt buộc';
  } else if (!['VIDEO', 'DOCUMENT', 'FILE'].includes(values.materialType)) {
    errors.materialType = 'Loại tài liệu không hợp lệ';
  }

  if (!values.content || values.content.trim() === '') {
    errors.content = 'Vui lòng upload file hoặc nhập URL';
  }

  if (!values.orderIndex || values.orderIndex < 1) {
    errors.orderIndex = 'Thứ tự phải lớn hơn 0';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

/**
 * File upload helpers
 */

const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
const ALLOWED_DOCUMENT_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
];
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/avi', 'video/mov', 'video/quicktime'];

const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_DOCUMENT_SIZE = 50 * 1024 * 1024; // 50MB

export const validateFileType = (file, allowedTypes = ALLOWED_IMAGE_TYPES) => {
  if (!file) return false;
  return allowedTypes.includes(file.type);
};

export const validateFileSize = (file, maxSize = MAX_IMAGE_SIZE) => {
  if (!file) return false;
  return file.size <= maxSize;
};

export const validateFileUpload = (file, fileType = 'image') => {
  const errors = [];

  if (!file) {
    errors.push('Vui lòng chọn file');
    return { isValid: false, errors };
  }

  let allowedTypes = ALLOWED_IMAGE_TYPES;
  let maxSize = MAX_IMAGE_SIZE;

  switch (fileType) {
    case 'document':
      allowedTypes = ALLOWED_DOCUMENT_TYPES;
      maxSize = MAX_DOCUMENT_SIZE;
      break;
    case 'video':
      allowedTypes = ALLOWED_VIDEO_TYPES;
      maxSize = MAX_DOCUMENT_SIZE;
      break;
    case 'material':
      allowedTypes = [...ALLOWED_IMAGE_TYPES, ...ALLOWED_DOCUMENT_TYPES, ...ALLOWED_VIDEO_TYPES];
      maxSize = MAX_DOCUMENT_SIZE;
      break;
    default:
      break;
  }

  if (!validateFileType(file, allowedTypes)) {
    errors.push('Loại file không được hỗ trợ');
  }

  if (!validateFileSize(file, maxSize)) {
    const maxSizeMB = maxSize / (1024 * 1024);
    errors.push(`Kích thước file phải nhỏ hơn ${maxSizeMB}MB`);
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

export const formatMultipartFormData = (data, fileField = 'file') => {
  const formData = new FormData();

  Object.keys(data).forEach((key) => {
    if (key === fileField && data[key] instanceof File) {
      formData.append(fileField, data[key]);
    } else if (data[key] !== null && data[key] !== undefined) {
      formData.append(key, data[key]);
    }
  });

  return formData;
};
