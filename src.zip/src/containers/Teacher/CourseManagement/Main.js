import React, { useEffect, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { useDispatchRedux } from 'utils/hooks/useRedux';

import CourseDetail from './components/CourseDetail';
import CourseList from './components/CourseList';
import Header from './components/Header';
import ModalCourse from './components/ModalCourse';
import ModalLesson from './components/ModalLesson';
import ModalMaterial from './components/ModalMaterial';
import { querySubjects, queryCourses, getCourseDetail, resetStore } from './store/actions';

const CourseManagementMain = () => {
  const location = useLocation();
  
  const fetchSubjects = useDispatchRedux(querySubjects);
  const fetchCourses = useDispatchRedux(queryCourses);
  const fetchCourseDetail = useDispatchRedux(getCourseDetail);
  const resetStoreData = useDispatchRedux(resetStore);

  // Get courseId from query params
  const courseId = useMemo(() => {
    const params = new URLSearchParams(location.search);
    return params.get('courseId');
  }, [location.search]);

  useEffect(() => {
    // Load subjects after saga is injected
    fetchSubjects();
    
    // Load courses or course detail based on courseId
    if (!courseId) {
      fetchCourses();
    } else {
      fetchCourseDetail(Number(courseId));
    }
  }, [courseId]);

  useEffect(() => {
    // Cleanup function to reset the store when unmounting
    return () => {
      console.log('[Main] Unmounting - resetting store');
      resetStoreData();
    };
  }, []);

  // Show detail page if courseId exists
  if (courseId) {
    return (
      <React.Fragment>
        <CourseDetail />
        <ModalLesson />
        <ModalMaterial />
      </React.Fragment>
    );
  }

  // Show list page
  return (
    <React.Fragment>
      <Header />
      <CourseList />
      <ModalCourse />
      <ModalLesson />
      <ModalMaterial />
    </React.Fragment>
  );
};

export default CourseManagementMain;
