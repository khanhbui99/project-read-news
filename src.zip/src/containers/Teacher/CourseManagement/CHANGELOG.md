# Changelog - Course Management UI Updates

## Thay đổi API

### 1. Media Management API (Mới)
- **POST** `/public/media/upload` - Upload file mới
- **GET** `/public/media` - Lấy danh sách files (hỗ trợ filter theo type, keyword)
- **GET** `/public/media/{id}` - Lấy chi tiết file
- **DELETE** `/public/media/{id}` - Xóa file

### 2. Course API (Cập nhật)
- **Thay đổi**: Thay vì gửi file ảnh trực tiếp, giờ gửi `thumbnailId`
- **Request body**:
  ```json
  {
    "name": "string",
    "subjectId": 0,
    "description": "string",
    "status": "ACTIVE",
    "thumbnailId": 0  // ID của file từ media library
  }
  ```
- **Response**: Trả về object `thumbnail` với thông tin file đầy đủ

### 3. Material API (Cập nhật)
- **Thay đổi**: Hỗ trợ cả `mediaFileId` và `content` (URL)
- **Request body**:
  ```json
  {
    "title": "string",
    "materialType": "VIDEO",
    "content": "string",  // URL (optional)
    "mediaFileId": 0,     // ID của file từ media library (optional)
    "orderIndex": 0
  }
  ```
- **Response**: Trả về object `mediaFile` với thông tin file đầy đủ

## Thay đổi UI

### 1. Component mới: MediaLibraryPicker
**Vị trí**: `src/containers/Teacher/CourseManagement/components/MediaLibraryPicker/index.js`

**Chức năng**:
- Hiển thị danh sách files từ thư viện media
- Hỗ trợ filter theo loại file (IMAGE, VIDEO, DOCUMENT)
- Tìm kiếm theo tên file
- Upload file mới trực tiếp từ picker
- Chọn file và trả về thông tin file đã chọn

**Props**:
- `open`: Boolean - Hiển thị/ẩn dialog
- `onClose`: Function - Callback khi đóng dialog
- `onSelect`: Function - Callback khi chọn file
- `fileType`: String - Loại file mặc định ('IMAGE', 'VIDEO', 'DOCUMENT', 'ALL')
- `title`: String - Tiêu đề dialog

### 2. ModalCourse (Cập nhật)
**Thay đổi**:
- Loại bỏ `AppUploadImageField`
- Thêm `MediaLibraryPicker` để chọn ảnh đại diện
- Hiển thị preview ảnh đã chọn
- Gửi `thumbnailId` thay vì file/URL

**State mới**:
- `showMediaPicker`: Boolean - Hiển thị media picker
- `selectedThumbnail`: Object - Thông tin file ảnh đã chọn

### 3. ModalMaterial (Cập nhật)
**Thay đổi**:
- Loại bỏ `AppUploadImageField`
- Thêm `MediaLibraryPicker` để chọn file tài liệu
- Hỗ trợ cả chọn file từ thư viện và nhập URL trực tiếp
- Hiển thị thông tin file đã chọn
- Gửi `mediaFileId` hoặc `content`

**State mới**:
- `showMediaPicker`: Boolean - Hiển thị media picker
- `selectedFile`: Object - Thông tin file đã chọn

### 4. CourseCard (Cập nhật)
**Thay đổi**:
- Cập nhật hiển thị thumbnail từ `course.thumbnail.fileUrl` thay vì `course.thumbnailUrl`

### 5. MaterialList (Cập nhật)
**Thay đổi**:
- Cập nhật download/view file từ `material.mediaFile.fileUrl` hoặc `material.content`

## Thay đổi Redux Saga

### Cập nhật các saga functions:
1. **createCourseSaga**: Gửi JSON data thay vì FormData
2. **updateCourseSaga**: Gửi JSON data thay vì FormData
3. **createMaterialSaga**: Gửi JSON data thay vì FormData
4. **updateMaterialSaga**: Gửi JSON data thay vì FormData

## Thay đổi API URLs

**File**: `src/services/api.url.js`

**Thêm mới**:
```javascript
media: {
  list: "management-service/v2/api/public/media",
  upload: "management-service/v2/api/public/media/upload",
  detail: (id) => `management-service/v2/api/public/media/${id}`,
  delete: (id) => `management-service/v2/api/public/media/${id}`,
}
```

## Lợi ích của thay đổi

1. **Tái sử dụng file**: Không cần upload lại file đã có
2. **Quản lý tập trung**: Tất cả files được quản lý ở một nơi
3. **Tiết kiệm storage**: Tránh duplicate files
4. **Dễ dàng quản lý**: Có thể xem, xóa files không dùng
5. **Tốc độ**: Chọn file nhanh hơn upload mới

## Migration Guide

### Nếu có dữ liệu cũ:
1. Các course có `thumbnailUrl` cũ vẫn hoạt động (fallback)
2. Các material có `content` cũ vẫn hoạt động (fallback)
3. Khi edit, nên chọn lại file từ thư viện để chuẩn hóa dữ liệu

## URL Handling

### Helper Function: `getAbsoluteUrl`
**Vị trí**: `src/utils/helpers.js`

**Chức năng**:
- Chuyển đổi relative URL thành absolute URL
- Sử dụng `VITE_ROOT_URI` từ environment variables
- Tự động detect và giữ nguyên absolute URLs

**Ví dụ**:
```javascript
// Input: "/management-service/v2/api/uploads/image.jpg"
// Output: "https://haohv-mona.cloud/management-service/v2/api/uploads/image.jpg"

// Input: "https://example.com/image.jpg"
// Output: "https://example.com/image.jpg" (không thay đổi)
```

**Sử dụng trong**:
- MediaLibraryPicker: Hiển thị preview ảnh
- ModalCourse: Hiển thị thumbnail preview
- CourseCard: Hiển thị thumbnail trong danh sách
- MaterialList: Download/view files

## Testing Checklist

- [ ] Upload file mới vào media library
- [ ] Chọn file từ media library cho course thumbnail
- [ ] Chọn file từ media library cho material
- [ ] Nhập URL trực tiếp cho material
- [ ] Edit course và thay đổi thumbnail
- [ ] Edit material và thay đổi file
- [ ] Xóa file từ media library
- [ ] Filter files theo type
- [ ] Search files theo keyword
- [ ] Preview ảnh trong course card (kiểm tra URL đầy đủ)
- [ ] Download/view material files (kiểm tra URL đầy đủ)
- [ ] Kiểm tra ảnh hiển thị đúng với VITE_ROOT_URI
