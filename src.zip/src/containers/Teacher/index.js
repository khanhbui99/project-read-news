export {
  AddQuestionTeacher,
  EditQuestionTeacher,
  QuestionBankTeacher,
  AddQuestionBankTeacher,
  EditQuestionBankTeacher,
} from "./QuestionBank";

export {
  ExamTemplateTeacher,
  AddExamTemplateTeacher,
  EditExamTemplateTeacher,
} from "./ExamTemplate";

export {
  ExamGenerateTeacher,
  AddExamGenerateTeacher,
  EditExamGenerateTeacher,
} from "./ExamGenerate";

export { CourseManagementTeacher } from "./CourseManagement";
export { default as CourseManagementDetailTeacher } from "./CourseManagement/Detail";
export { MediaManagementTeacher } from "./MediaManagement";
export { default as ImportQuestionTeacher } from "./ImportQuestion";
export { default as MediaProfileManagementTeacher } from "./MediaProfileManagement";
