import {
  Search as SearchIcon,
  FilterList as FilterListIcon,
  Share as ShareIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
  ViewModule as ViewModuleIcon,
  ViewList as ViewListIcon,
} from "@mui/icons-material";
import {
  Box,
  Stack,
  Grid,
  Paper,
  TextField,
  Button,
  IconButton,
  Tabs,
  Tab,
  Pagination,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Divider,
  Checkbox,
} from "@mui/material";
import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import EmptyComponent from "components/common/EmptyComponent";
import LoadingIndicator from "components/common/LoadingIndicator";
import ModalShareFolder from "components/common/Modal/ModalShareFolder";
import { Title } from "components/Styled";
import { HeaderButtonStyle } from "components/styles/Header/style";
import { useEffect, useCallback, useRef, useState, useMemo } from "react";
import * as ApiReq from "services/api.request";
import { useOneState, useDispatchRedux } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";
import localStorageService from "utils/services/service.localStorage";

import ContextMenu from "./components/ContextMenu";
import CreateEditFolderModal from "./components/CreateFolderModal";
import FolderBreadcrumb from "./components/FolderBreadcrumb";
import FolderCard from "./components/FolderCard";
import FolderListView from "./components/FolderListView";
import Header from "./components/Header";
import MediaCard from "./components/MediaCard";
import MediaDetailModal from "./components/MediaDetailModal";
import ModalMove from "./components/ModalMove";
import {
  queryMedia,
  queryFolderContents,
  uploadMedia,
  deleteMedia,
  deleteFolder,
  createFolder,
  setFilter,
  setPage,
  setPageSize,
  setSort,
  openDetailModal,
  closeDetailModal,
  openCreateFolderModal,
  closeCreateFolderModal,
  openContextMenu,
  closeContextMenu,
  resetStore,
} from "./store/actions";
import { key } from "./store/constants";

const FILE_TYPE_TABS = [
  { value: "", label: "Tất cả" },
  // { value: 'KEHOACHDAYHOC', label: 'Kế hoạch dạy học' },
  // { value: 'SOCHUNHIEM', label: 'Sổ chủ nhiệm' },
  // { value: 'HOSOTOCHUYENMON', label: 'Hồ sơ tổ/nhóm chuyên môn' },
];

const MediaManagementMain = () => {
  const fileInputRef = useRef(null);
  const folderUploadInputRef = useRef(null);
  const [activeFolder, setActiveFolder] = useState(null);
  const [isModalMoveFolder, setIsModalMoveFolder] = useState(false);
  const [isModalShareFolder, setIsModalShareFolder] = useState(false);
  const [selectedItems, setSelectedItems] = useState(new Set()); // Set of {type: 'folder'|'file', id}
  const [viewMode, setViewMode] = useState("list"); // 'grid' | 'list'

  // Redux state
  const media = useOneState(key, "media");
  const folders = useOneState(key, "folders");
  const currentFolder = useOneState(key, "currentFolder");
  const breadcrumb = useOneState(key, "breadcrumb");
  const uploading = useOneState(key, "uploading");
  const filters = useOneState(key, "filters");
  const pagination = useOneState(key, "pagination");
  const modal = useOneState(key, "modal");
  const contextMenuState = useOneState(key, "contextMenu");
  const teachers = useOneState(injectKey.GLOBAL, "teachersOpt");

  // Dispatch actions
  const fetchMedia = useDispatchRedux(queryMedia);
  const fetchFolderContents = useDispatchRedux(queryFolderContents);
  const uploadFile = useDispatchRedux(uploadMedia);
  const deleteFile = useDispatchRedux(deleteMedia);
  const removeFolderAction = useDispatchRedux(deleteFolder);
  const createNewFolder = useDispatchRedux(createFolder);
  const updateFilter = useDispatchRedux(setFilter);
  const updatePage = useDispatchRedux(setPage);
  const updatePageSize = useDispatchRedux(setPageSize);
  const updateSort = useDispatchRedux(setSort);
  const openModal = useDispatchRedux(openDetailModal);
  const closeModal = useDispatchRedux(closeDetailModal);
  const openFolderModal = useDispatchRedux(openCreateFolderModal);
  const closeFolderModal = useDispatchRedux(closeCreateFolderModal);
  const showContextMenu = useDispatchRedux(openContextMenu);
  const hideContextMenu = useDispatchRedux(closeContextMenu);
  const resetStoreData = useDispatchRedux(resetStore);
  const setLoadingPage = useDispatchRedux(setLoadingAction);
  const setMessageByField = useDispatchRedux(setMessageByFieldAction);

  // Derived state
  const folderItems = folders?.items || [];
  const fileItems = media?.items || [];
  const total = media?.total || 0;
  const loading = media?.loading || folders?.loading || false;
  const page = pagination?.page || 0;
  const pageSize = pagination?.pageSize || 24;
  const sort = pagination?.sort;
  const detailModal = modal?.detail || {};
  const createFolderModalOpen = modal?.createFolder?.open || false;

  const totalPages = Math.ceil(total / pageSize);
  const currentSort = sort || "default";
  const currentUserId = useMemo(() => localStorageService.auth.id(), []);

  const teacherNameMap = useMemo(() => {
    const map = new Map();
    (teachers || []).forEach((t) => {
      if (!t?.accountId) return;
      map.set(String(t.accountId), t.fullName || t.name || t.teacherName || "");
    });
    return map;
  }, [teachers]);

  // Initial fetch - get folder contents (root by default)
  useEffect(() => {
    fetchFolderContents(null); // Start at root

    return () => {
      resetStoreData();
    };
  }, []);

  const handleOpenFolder = useCallback(
    (folder) => {
      setSelectedItems(new Set());
      fetchFolderContents(folder.id);
    },
    [fetchFolderContents],
  );

  const handleBreadcrumbNavigate = useCallback(
    (folderId) => {
      setSelectedItems(new Set());
      fetchFolderContents(folderId);
    },
    [fetchFolderContents],
  );

  // Search handlers
  const handleSearch = useCallback(() => {
    fetchMedia();
  }, [fetchMedia]);

  const handleKeywordChange = useCallback(
    (event) => {
      updateFilter("keyword", event.target.value || null);
    },
    [updateFilter],
  );

  const handleKeywordKeyPress = useCallback(
    (event) => {
      if (event.key === "Enter") {
        handleSearch();
      }
    },
    [handleSearch],
  );

  const handleTypeChange = useCallback(
    (event, newValue) => {
      updateFilter("type", newValue || null);
      fetchFolderContents(currentFolder?.id);
    },
    [updateFilter, fetchFolderContents, currentFolder],
  );

  // Pagination handlers
  const handlePageChange = useCallback(
    (event, newPage) => {
      updatePage(newPage - 1);
      fetchMedia();
    },
    [updatePage, fetchMedia],
  );

  const handlePageSizeChange = useCallback(
    (event) => {
      updatePageSize(event.target.value);
      fetchMedia();
    },
    [updatePageSize, fetchMedia],
  );

  const handleSortChange = useCallback(
    (event) => {
      const value = event.target.value;
      updateSort(value === "default" ? null : value);
      fetchMedia();
    },
    [updateSort, fetchMedia],
  );

  // Upload handlers
  const handleUpload = useCallback(
    (event) => {
      const files = Array.from(event.target.files || []);
      if (files.length === 0) return;

      // Upload từng file một cách tuần tự
      files.forEach((file, index) => {
        setTimeout(() => {
          uploadFile(file, currentFolder?.id);
        }, index * 300);
      });

      event.target.value = "";
    },
    [uploadFile, currentFolder],
  );

  const handleUploadToFolder = useCallback((folder) => {
    // Trigger file input and save folder reference
    folderUploadInputRef.current?.click();
    folderUploadInputRef.current.targetFolderId = folder.id;
  }, []);

  // Permission checks
  const isFolderOwner = useCallback(
    (folder) => {
      if (!folder || !currentUserId) return false;
      const listAccountOwner = [
        Number(folder.createdBy),
        ...(folder.listAccountOwner || []),
      ]
      return listAccountOwner.includes(currentUserId);
    },
    [currentUserId],
  );

  const selectedFoldersOwned = useMemo(() => {
    return Array.from(selectedItems)
      .filter(item => item.type === 'folder')
      .map(item => folderItems.find(f => f.id === item.id))
      .filter(folder => folder && isFolderOwner(folder));
  }, [selectedItems, folderItems, isFolderOwner]);

  // Share single folder from context menu
  const handleShareSingleFolder = async (val) => {
    try {
      setLoadingPage(true);
      if (!val) return setIsModalShareFolder(false);
      
      if (val?.listAccountRemoved?.listAccountOwner || val?.listAccountRemoved?.listAccountShared) {
        await ApiReq.post({
          url: `management-service/v2/api/public/folders/un-share-folder/${activeFolder.id}`,
          params: { typeDocument: 'MANAGEMENT', ...val.listAccountRemoved }
        });
      }

      if (val?.listAccountShared || val?.listAccountOwner) {
        delete val.listAccountRemoved;

        const result = await ApiReq.post({
          url: `management-service/v2/api/public/folders/share-folder/${activeFolder.id}`,
          params: { typeDocument: 'MANAGEMENT', ...val }
        });

        if (result?.data?.meta?.code !== "LMS-200") {
          throw new Error("Lỗi khi chia sẻ thư mục");
        }
      }

      setMessageByField('success', `Thực hiện thao tác thành công trên thư mục "${activeFolder.name}"`);
      setActiveFolder(null);
      setIsModalShareFolder(false);
      fetchFolderContents(currentFolder?.id);
    }
    catch(err){
      setMessageByField('error', err?.message || 'Lỗi khi chia sẻ thư mục');
    } finally {
      setLoadingPage(false);
    }
  };

  // Share multiple folders from checkbox selection
  const handleShare = async val => {
    try {
      setLoadingPage(true);
      if(!val?.listAccountShared && !val?.listAccountOwner) return setIsModalShareFolder(false);

      const folderIds = selectedFoldersOwned.map(f => f.id);
      const sharePromises = folderIds.map(folderId => 
        ApiReq.post({
          url: `management-service/v2/api/public/folders/share-folder/${folderId}`,
          params: { typeDocument: 'MANAGEMENT', ...val }
        })
      );

      const results = await Promise.all(sharePromises);
      const hasError = results.some(res => res?.data?.meta?.code !== "LMS-200");
      
      if (hasError) {
        throw new Error("Lỗi khi chia sẻ thư mục");
      }

      setMessageByField('success', `Chia sẻ ${folderIds.length} thư mục thành công`);
      setIsModalShareFolder(false);
      setSelectedItems(new Set());
      fetchFolderContents(currentFolder?.id);
    }
    catch(err){
      setMessageByField('error', err?.message || 'Lỗi khi chia sẻ thư mục');
    } finally {
      setLoadingPage(false);
    }
  }

  const handleBulkDelete = useCallback(async () => {
    if (selectedItems.size === 0) return;
    
    const foldersToDelete = selectedFoldersOwned.map(f => f.id);
    const filesToDelete = Array.from(selectedItems)
      .filter(item => item.type === 'file')
      .map(item => item.id);
    
    if (foldersToDelete.length === 0 && filesToDelete.length === 0) {
      setMessageByField('error', 'Bạn chỉ có thể xóa các thư mục bạn sở hữu');
      return;
    }
    
    if (!window.confirm(`Bạn có chắc chắn muốn xóa ${foldersToDelete.length + filesToDelete.length} item đã chọn?`)) {
      return;
    }

    try {
      setLoadingPage(true);
      
      const folderPromises = foldersToDelete.map(folderId => 
        ApiReq.del({
          url: `management-service/v2/api/public/folders/${folderId}`,
          params: { typeDocument: 'MANAGEMENT' }
        })
      );

      const filePromises = filesToDelete.map(fileId => 
        ApiReq.del({
          url: `management-service/v2/api/public/media/${fileId}`,
          params: { typeDocument: 'MANAGEMENT' }
        })
      );

      await Promise.all([...folderPromises, ...filePromises]);
      
      setMessageByField('success', `Xóa ${foldersToDelete.length + filesToDelete.length} item thành công`);
      setSelectedItems(new Set());
      fetchFolderContents(currentFolder?.id);
    } catch (err) {
      setMessageByField('error', err?.message || 'Lỗi khi xóa');
    } finally {
      setLoadingPage(false);
    }
  }, [selectedItems, selectedFoldersOwned, setLoadingPage, setMessageByField, fetchFolderContents, currentFolder]);

  const handleSelectItem = useCallback(
    (id, type, checked) => {
      if (type === "folder") {
        const folder = folderItems.find((f) => f.id === id);
        if (!folder || !isFolderOwner(folder)) return;
      }

      setSelectedItems((prev) => {
        const newSet = new Set(prev);
        if (checked) {
          newSet.add({ type, id });
        } else {
          const itemsToRemove = Array.from(newSet).filter(
            (item) => item.type === type && item.id === id,
          );
          itemsToRemove.forEach((item) => newSet.delete(item));
        }
        return newSet;
      });
    },
    [folderItems, isFolderOwner],
  );

  const handleFolderUpload = useCallback(
    (event) => {
      const files = Array.from(event.target.files || []);
      const targetFolderId = event.target.targetFolderId;
      
      if (files.length === 0 || !targetFolderId) {
        event.target.value = "";
        event.target.targetFolderId = null;
        return;
      }

      // Upload từng file một cách tuần tự
      files.forEach((file, index) => {
        setTimeout(() => {
          uploadFile(file, targetFolderId);
        }, index * 300);
      });

      event.target.value = "";
      event.target.targetFolderId = null;
    },
    [uploadFile],
  );

  // View and delete handlers
  const handleView = useCallback(
    (mediaItem) => {
      openModal(mediaItem);
    },
    [openModal],
  );

  const handleDelete = useCallback(
    (id) => {
      if (window.confirm("Bạn có chắc chắn muốn xóa file này?")) {
        deleteFile(id);
      }
    },
    [deleteFile],
  );

  const handleDeleteFolder = useCallback(
    (folder) => {
      console.log(folder, folders);
      if (
        window.confirm(
          `Bạn có chắc chắn muốn xóa thư mục "${folder.name}"? Thư mục phải trống mới xóa được.`,
        )
      ) {
        removeFolderAction(folder.id);
      }
    },
    [removeFolderAction],
  );

  // Modal handlers
  const handleCloseModal = useCallback(() => {
    closeModal();
  }, [closeModal]);

  const handleCreateFolder = useCallback(
    (data) => {
      createNewFolder(data);
    },
    [createNewFolder],
  );

  // Context menu handlers
  const handleFolderContextMenu = useCallback(
    (event, folder) => {
      event.preventDefault();
      showContextMenu({
        type: "folder",
        item: folder,
        x: event.clientX,
        y: event.clientY,
      });
    },
    [showContextMenu],
  );

  const handleFileContextMenu = useCallback(
    (event, file) => {
      event.preventDefault();
      showContextMenu({
        type: "file",
        item: file,
        x: event.clientX,
        y: event.clientY,
      });
    },
    [showContextMenu],
  );

  const handleCopyUrl = useCallback((item) => {
    if (item.fileUrl) {
      navigator.clipboard.writeText(item.fileUrl);
      // Could add toast notification here
    }
  }, []);

  const handleDownload = useCallback((item) => {
    if (item.fileUrl) {
      window.open(item.fileUrl, "_blank");
    }
  }, []);

  const handleRename = (_f) => {
    setActiveFolder(_f);
    openFolderModal();
  };

  const getCreatorName = useCallback(
    (entity) => {
      if (!entity) return "--";
      const id =
        entity.createdBy ??
        entity.userId ??
        entity.ownerId ??
        entity.created_by ??
        entity.user_id;
      const idStr = id != null ? String(id) : null;
      const mapped =
        (idStr && teacherNameMap.get(idStr)) ||
        entity.createdByName ||
        entity.ownerName ||
        entity.ownerFullName;
      return mapped || "--";
    },
    [teacherNameMap],
  );

  return (
    <Box>
      {/* Header */}
      <Header
        uploading={uploading}
        onCreateFolder={() => openFolderModal()}
        onUpload={
          <input
            ref={fileInputRef}
            type="file"
            hidden
            multiple
            accept="application/pdf,.pdf"
            onChange={handleUpload}
            disabled={uploading}
          />
        }
      />

      {/* Breadcrumb Navigation */}
      <FolderBreadcrumb
        breadcrumb={breadcrumb}
        onNavigate={handleBreadcrumbNavigate}
      />

      {/* Filter Section */}
      <Paper
        elevation={0}
        sx={{
          p: 2.5,
          bgcolor: "#f8f9fa",
          borderRadius: 2,
          border: "1px solid #e0e0e0",
          mb: 2.5,
        }}
      >
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
          <FilterListIcon sx={{ color: "#666", fontSize: 18 }} />
          <Title $size={14} $weight={600} style={{ margin: 0 }}>
            Tìm kiếm
          </Title>
        </Stack>

        <Grid container spacing={2} alignItems="flex-end">
          <Grid item xs={12} md={10}>
            <TextField
              fullWidth
              size="small"
              placeholder="Tìm kiếm theo tên file..."
              value={filters?.keyword || ""}
              onChange={handleKeywordChange}
              onKeyPress={handleKeywordKeyPress}
              InputProps={{
                startAdornment: (
                  <SearchIcon sx={{ color: "#999", mr: 1, fontSize: 20 }} />
                ),
              }}
            />
          </Grid>

          <Grid item xs={12} md={2}>
            <HeaderButtonStyle
              wFull
              onClick={handleSearch}
              aria-label="Tìm kiếm"
              sx={{ height: "40px" }}
            >
              <SearchIcon sx={{ mr: 0.5, fontSize: 18 }} />
              Tìm kiếm
            </HeaderButtonStyle>
          </Grid>
        </Grid>
      </Paper>

      {/* File Type Tabs and Controls */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 2.5,
          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Tabs
          value={filters?.type || ""}
          onChange={handleTypeChange}
          sx={{
            minHeight: 42,
            "& .MuiTab-root": {
              minHeight: 42,
              fontSize: "14px",
            },
          }}
        >
          {FILE_TYPE_TABS.map((tab) => (
            <Tab key={tab.value} label={tab.label} value={tab.value} />
          ))}
        </Tabs>

        <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
          <Box sx={{ color: "text.secondary", fontSize: "13px" }}>
            <strong>{folderItems.length}</strong> thư mục,{" "}
            <strong>{total}</strong> file
          </Box>
          <FormControl size="small" sx={{ minWidth: 180 }}>
            <InputLabel sx={{ fontSize: "13px" }}>Sắp xếp</InputLabel>
            <Select
              value={currentSort}
              label="Sắp xếp"
              onChange={handleSortChange}
              sx={{ fontSize: "13px" }}
            >
              <MenuItem value="default">Ngày tạo mới nhất</MenuItem>
              <MenuItem value="createdAt,asc">Ngày tạo cũ nhất</MenuItem>
              <MenuItem value="originalName,asc">Tên A-Z</MenuItem>
              <MenuItem value="originalName,desc">Tên Z-A</MenuItem>
              <MenuItem value="fileSize,desc">Kích thước lớn nhất</MenuItem>
              <MenuItem value="fileSize,asc">Kích thước nhỏ nhất</MenuItem>
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 90 }}>
            <InputLabel sx={{ fontSize: "13px" }}>Hiển thị</InputLabel>
            <Select
              value={pageSize}
              label="Hiển thị"
              onChange={handlePageSizeChange}
              sx={{ fontSize: "13px" }}
            >
              <MenuItem value={12}>12</MenuItem>
              <MenuItem value={24}>24</MenuItem>
              <MenuItem value={48}>48</MenuItem>
              <MenuItem value={96}>96</MenuItem>
            </Select>
          </FormControl>
          <Divider orientation="vertical" flexItem sx={{ mx: 0.5 }} />
          <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
            <IconButton
              size="small"
              onClick={() => setViewMode("grid")}
              color={viewMode === "grid" ? "primary" : "default"}
              sx={{
                borderRadius: 1,
                border: "1px solid",
                borderColor:
                  viewMode === "grid" ? "primary.main" : "divider",
                bgcolor:
                  viewMode === "grid" ? "action.selected" : "transparent",
              }}
            >
              <ViewModuleIcon fontSize="small" />
            </IconButton>
            <IconButton
              size="small"
              onClick={() => setViewMode("list")}
              color={viewMode === "list" ? "primary" : "default"}
              sx={{
                borderRadius: 1,
                border: "1px solid",
                borderColor:
                  viewMode === "list" ? "primary.main" : "divider",
                bgcolor:
                  viewMode === "list" ? "action.selected" : "transparent",
              }}
            >
              <ViewListIcon fontSize="small" />
            </IconButton>
          </Box>
        </Box>
      </Box>

      {/* Content Grid */}
      {loading ? (
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            minHeight: "400px",
          }}
        >
          <LoadingIndicator />
        </Box>
      ) : folderItems.length === 0 && fileItems.length === 0 ? (
        <EmptyComponent title="Thư mục trống" />
      ) : (
        <>
          {/* Folders Section */}
          {folderItems.length > 0 && (
            <Box sx={{ mb: 3 }}>
              <Box 
                sx={{ 
                  mb: 2,
                  p: 1.5,
                  borderRadius: 2,
                  background: 'linear-gradient(135deg, rgba(255, 193, 7, 0.05) 0%, rgba(255, 193, 7, 0.02) 100%)',
                  border: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: selectedItems.size > 0 && Array.from(selectedItems).some(item => item.type === 'folder') ? 1.5 : 0 }}>
                  <Typography
                    variant="subtitle1"
                    sx={{
                      fontWeight: 700,
                      fontSize: '16px',
                      color: 'text.primary',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                    }}
                  >
                    <Box
                      component="span"
                      sx={{
                        width: 4,
                        height: 20,
                        borderRadius: 1,
                        background: 'linear-gradient(135deg, #ffc107 0%, #ff9800 100%)',
                      }}
                    />
                    Thư mục ({folderItems.length})
                  </Typography>

                  <Stack direction="row" spacing={1.5} sx={{ mt: 1.5 }}>
                  {selectedFoldersOwned.length > 0 && (
                  <>
                    <Button
                      variant="contained"
                      size="medium"
                      startIcon={<ShareIcon />}
                      onClick={() => setIsModalShareFolder(true)}
                      sx={{
                        background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
                        boxShadow: '0 4px 12px rgba(25, 118, 210, 0.3)',
                        borderRadius: 2,
                        px: 2.5,
                        py: 1,
                        fontWeight: 600,
                        textTransform: 'none',
                        transition: 'all 0.3s',
                        '&:hover': {
                          transform: 'translateY(-2px)',
                          boxShadow: '0 6px 16px rgba(25, 118, 210, 0.4)',
                        },
                      }}
                    >
                      Chia sẻ ({selectedFoldersOwned.length})
                    </Button>
                    <Button
                      variant="contained"
                      size="medium"
                      startIcon={<DeleteIcon />}
                      onClick={handleBulkDelete}
                      sx={{
                        background: 'linear-gradient(135deg, #d32f2f 0%, #c62828 100%)',
                        boxShadow: '0 4px 12px rgba(211, 47, 47, 0.3)',
                        borderRadius: 2,
                        px: 2.5,
                        py: 1,
                        fontWeight: 600,
                        textTransform: 'none',
                        transition: 'all 0.3s',
                        '&:hover': {
                          transform: 'translateY(-2px)',
                          boxShadow: '0 6px 16px rgba(211, 47, 47, 0.4)',
                        },
                      }}
                    >
                      Xóa ({selectedFoldersOwned.length})
                    </Button>
                  </>
                )}

                  <Checkbox
                    checked={
                      folderItems.length > 0 &&
                      folderItems.filter((f) => isFolderOwner(f)).length > 0 &&
                      folderItems
                        .filter((f) => isFolderOwner(f))
                        .every((folder) =>
                          Array.from(selectedItems).some(
                            (item) =>
                              item.type === "folder" && item.id === folder.id,
                          ),
                        )
                    }
                    indeterminate={
                      folderItems
                        .filter((f) => isFolderOwner(f))
                        .some((folder) =>
                          Array.from(selectedItems).some(
                            (item) =>
                              item.type === "folder" && item.id === folder.id,
                          ),
                        ) &&
                      !folderItems
                        .filter((f) => isFolderOwner(f))
                        .every((folder) =>
                          Array.from(selectedItems).some(
                            (item) =>
                              item.type === "folder" && item.id === folder.id,
                          ),
                        )
                    }
                    disabled={
                      folderItems.filter((f) => isFolderOwner(f)).length === 0
                    }
                    onChange={(e) => {
                      folderItems
                        .filter((f) => isFolderOwner(f))
                        .forEach((folder) => {
                          handleSelectItem(
                            folder.id,
                            "folder",
                            e.target.checked,
                          );
                        });
                    }}
                    sx={{
                      color: 'primary.main',
                      '&.Mui-checked': {
                        color: 'primary.main',
                      },
                    }}
                  />
                  </Stack>
                </Box>
              </Box>
              {viewMode === "grid" ? (
                <Grid container spacing={2}>
                  {folderItems.map((folder) => (
                    <Grid item xs={12} sm={6} md={4} lg={3} key={folder.id}>
                      <FolderCard
                        folder={folder}
                        onOpen={handleOpenFolder}
                        onContextMenu={handleFolderContextMenu}
                        selected={Array.from(selectedItems).some(
                          (item) =>
                            item.type === "folder" && item.id === folder.id,
                        )}
                        onSelectChange={(id, checked) =>
                          handleSelectItem(id, "folder", checked)
                        }
                        canSelect={isFolderOwner(folder)}
                        isOwner={isFolderOwner(folder)}
                      />
                    </Grid>
                  ))}
                </Grid>
              ) : (
                <FolderListView
                  folderItems={folderItems}
                  selectedItems={selectedItems}
                  onOpenFolder={handleOpenFolder}
                  onContextMenu={handleFolderContextMenu}
                  onSelectItem={handleSelectItem}
                  isFolderOwner={isFolderOwner}
                />
              )}
            </Box>
          )}

          {/* Divider if both folders and files exist */}
          {folderItems.length > 0 && fileItems.length > 0 && (
            <Divider sx={{ my: 3 }} />
          )}

          {/* Files Section */}
          {fileItems.length > 0 && (
            <Box>
              <Box 
                sx={{ 
                  mb: 2,
                  p: 1.5,
                  borderRadius: 2,
                  background: 'linear-gradient(135deg, rgba(33, 150, 243, 0.05) 0%, rgba(33, 150, 243, 0.02) 100%)',
                  border: '1px solid',
                  borderColor: 'divider',
                }}
              >
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: selectedItems.size > 0 && Array.from(selectedItems).some(item => item.type === 'file') ? 1.5 : 0 }}>
                  <Typography
                    variant="subtitle1"
                    sx={{
                      fontWeight: 700,
                      fontSize: '16px',
                      color: 'text.primary',
                      display: 'flex',
                      alignItems: 'center',
                      gap: 1,
                    }}
                  >
                    <Box
                      component="span"
                      sx={{
                        width: 4,
                        height: 20,
                        borderRadius: 1,
                        background: 'linear-gradient(135deg, #2196f3 0%, #1976d2 100%)',
                      }}
                    />
                    Files ({fileItems.length})
                  </Typography>
                  <Checkbox
                    checked={fileItems.length > 0 && fileItems.every(file => 
                      Array.from(selectedItems).some(item => item.type === 'file' && item.id === file.id)
                    )}
                    indeterminate={
                      fileItems.some(file => 
                        Array.from(selectedItems).some(item => item.type === 'file' && item.id === file.id)
                      ) && !fileItems.every(file => 
                        Array.from(selectedItems).some(item => item.type === 'file' && item.id === file.id)
                      )
                    }
                    onChange={(e) => {
                      fileItems.forEach(file => {
                        handleSelectItem(file.id, 'file', e.target.checked);
                      });
                    }}
                    sx={{
                      color: 'primary.main',
                      '&.Mui-checked': {
                        color: 'primary.main',
                      },
                    }}
                  />
                </Box>
                {(selectedFoldersOwned.length > 0 || Array.from(selectedItems).some(item => item.type === 'file')) && (
                  <Stack direction="row" spacing={1.5} sx={{ mt: 1.5 }}>
                    {selectedFoldersOwned.length > 0 && (
                      <Button
                        variant="contained"
                        size="medium"
                        startIcon={<ShareIcon />}
                        onClick={() => setIsModalShareFolder(true)}
                        sx={{
                          background: 'linear-gradient(135deg, #1976d2 0%, #1565c0 100%)',
                          boxShadow: '0 4px 12px rgba(25, 118, 210, 0.3)',
                          borderRadius: 2,
                          px: 2.5,
                          py: 1,
                          fontWeight: 600,
                          textTransform: 'none',
                          transition: 'all 0.3s',
                          '&:hover': {
                            transform: 'translateY(-2px)',
                            boxShadow: '0 6px 16px rgba(25, 118, 210, 0.4)',
                          },
                        }}
                      >
                        Chia sẻ ({selectedFoldersOwned.length})
                      </Button>
                    )}
                    {(selectedFoldersOwned.length > 0 || Array.from(selectedItems).some(item => item.type === 'file')) && (
                      <Button
                        variant="contained"
                        size="medium"
                        startIcon={<DeleteIcon />}
                        onClick={handleBulkDelete}
                        sx={{
                          background: 'linear-gradient(135deg, #d32f2f 0%, #c62828 100%)',
                          boxShadow: '0 4px 12px rgba(211, 47, 47, 0.3)',
                          borderRadius: 2,
                          px: 2.5,
                          py: 1,
                          fontWeight: 600,
                          textTransform: 'none',
                          transition: 'all 0.3s',
                          '&:hover': {
                            transform: 'translateY(-2px)',
                            boxShadow: '0 6px 16px rgba(211, 47, 47, 0.4)',
                          },
                        }}
                      >
                        Xóa ({selectedFoldersOwned.length + Array.from(selectedItems).filter(item => item.type === 'file').length})
                      </Button>
                    )}
                  </Stack>
                )}
              </Box>
              {viewMode === "grid" ? (
                <Grid container spacing={3}>
                  {fileItems.map((item) => (
                    <Grid
                      item
                      xs={12}
                      sm={6}
                      md={4}
                      lg={3}
                      xl={2}
                      key={item.id}
                    >
                      <MediaCard
                        media={item}
                        onView={handleView}
                        onDelete={handleDelete}
                        onContextMenu={handleFileContextMenu}
                        selected={Array.from(selectedItems).some(
                          (selected) =>
                            selected.type === "file" && selected.id === item.id,
                        )}
                        onSelectChange={(id, checked) =>
                          handleSelectItem(id, "file", checked)
                        }
                        isOwner={isFolderOwner(item)}
                      />
                    </Grid>
                  ))}
                </Grid>
              ) : (
                <Box
                  sx={{
                    borderRadius: 2,
                    border: "1px solid",
                    borderColor: "divider",
                    overflow: "hidden",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      px: 2,
                      py: 1,
                      bgcolor: "grey.100",
                      borderBottom: "1px solid",
                      borderColor: "divider",
                      fontSize: 13,
                      fontWeight: 600,
                    }}
                  >
                    <Box sx={{ width: 30 }} />
                    <Box sx={{ flex: 3 }}>Tên file</Box>
                    <Box sx={{ flex: 1.2 }}>Loại</Box>
                    <Box sx={{ flex: 1 }}>Kích thước</Box>
                    <Box sx={{ flex: 1.2 }}>Ngày tạo</Box>
                    <Box sx={{ flex: 1.6 }}>Người tạo</Box>
                    <Box sx={{ width: 120, textAlign: "right" }}>Thao tác</Box>
                  </Box>
                  {fileItems.map((item) => {
                    const isSelected = Array.from(selectedItems).some(
                      (selected) =>
                        selected.type === "file" && selected.id === item.id,
                    );
                    const isOwner = isFolderOwner(item);

                    return (
                      <Box
                        key={item.id}
                        onClick={() => handleView(item)}
                        onContextMenu={(e) => handleFileContextMenu(e, item)}
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          px: 2,
                          py: 1,
                          fontSize: 13,
                          borderTop: "1px solid",
                          borderColor: "divider",
                          bgcolor: isSelected
                            ? "action.selected"
                            : "background.paper",
                          "&:hover": {
                            bgcolor: "action.hover",
                            cursor: "pointer",
                          },
                        }}
                      >
                        {isOwner ? (
                          <Checkbox
                            checked={isSelected}
                            onChange={(e) => {
                              e.stopPropagation();
                              handleSelectItem(
                                item.id,
                                "file",
                                e.target.checked,
                              );
                            }}
                            onClick={(e) => e.stopPropagation()}
                            sx={{
                              width: 30,
                              "& .MuiSvgIcon-root": { fontSize: 20 },
                            }}
                          />
                        ) : <Box sx={{ width: 30, height: 38}} />}

                        <Box sx={{ flex: 3, pr: 2, overflow: "hidden" }}>
                          <Typography
                            variant="body2"
                            sx={{ fontWeight: 600 }}
                          >
                            {item.originalName}
                          </Typography>
                        </Box>
                        <Box sx={{ flex: 1.2 }}>
                          <Typography
                            variant="caption"
                            color="text.secondary"
                          >
                            {item.fileType}
                          </Typography>
                        </Box>
                        <Box sx={{ flex: 1 }}>
                          <Typography
                            variant="caption"
                            color="text.secondary"
                          >
                            {item.fileSize
                              ? `${(item.fileSize / 1024).toFixed(2)} KB`
                              : "--"}
                          </Typography>
                        </Box>
                        <Box sx={{ flex: 1.2 }}>
                          <Typography
                            variant="caption"
                            color="text.secondary"
                          >
                            {item.createdAt
                              ? new Date(
                                  item.createdAt,
                                ).toLocaleString("vi-VN")
                              : "--"}
                          </Typography>
                        </Box>
                        <Box
                          sx={{
                            flex: 1.6,
                          }}
                        >
                          <Typography
                            variant="caption"
                            color="text.secondary"
                            noWrap
                          >
                            {getCreatorName(item)}
                          </Typography>
                        </Box>
                        <Box
                          sx={{
                            width: 120,
                            display: "flex",
                            justifyContent: "flex-end",
                            gap: 1,
                          }}
                        >
                          <IconButton
                            size="small"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleView(item);
                            }}
                          >
                            <VisibilityIcon fontSize="small" />
                          </IconButton>
                          {isOwner && (
                            <IconButton
                              size="small"
                              color="error"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDelete(item.id);
                              }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          )}
                        </Box>
                      </Box>
                    );
                  })}
                </Box>
              )}
            </Box>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <Box sx={{ mt: 4 }}>
              <Box sx={{ display: "flex", justifyContent: "center", mb: 2 }}>
                <Pagination
                  count={totalPages}
                  page={page + 1}
                  onChange={handlePageChange}
                  color="primary"
                  size="large"
                  showFirstButton
                  showLastButton
                />
              </Box>
              <Box
                sx={{
                  textAlign: "center",
                  color: "text.secondary",
                  fontSize: "14px",
                }}
              >
                Hiển thị {page * pageSize + 1} -{" "}
                {Math.min((page + 1) * pageSize, total)} của {total} file
              </Box>
            </Box>
          )}
        </>
      )}

      {/* Hidden input for folder upload */}
      <input
        ref={folderUploadInputRef}
        type="file"
        hidden
        onChange={handleFolderUpload}
      />

      {/* Detail Modal */}
      <MediaDetailModal
        open={detailModal.open}
        media={detailModal.data}
        onClose={handleCloseModal}
      />

      {/* Create Folder Modal */}
      <CreateEditFolderModal
        open={createFolderModalOpen}
        folder={activeFolder}
        onClose={() => {
          closeFolderModal();
          setActiveFolder(null);
        }}
        onSubmit={handleCreateFolder}
        loading={uploading}
      />

      {/* Context Menu */}
      <ContextMenu
        open={contextMenuState?.open || false}
        anchorPosition={
          contextMenuState?.open
            ? { x: contextMenuState.x, y: contextMenuState.y }
            : null
        }
        type={contextMenuState?.type}
        item={contextMenuState?.item}
        onClose={hideContextMenu}
        isOwner={
          contextMenuState?.type === 'folder' && contextMenuState?.item
            ? isFolderOwner(contextMenuState.item)
            : true
        }
        onDelete={
          contextMenuState?.type === "folder"
            ? handleDeleteFolder
            : (item) => handleDelete(item.id)
        }
        onOpenFolder={handleOpenFolder}
        onUploadHere={handleUploadToFolder}
        onDownload={handleDownload}
        onCopyUrl={handleCopyUrl}
        onRename={handleRename}
        onShare={(_f) => {
          setActiveFolder(_f);
          setIsModalShareFolder(true)
        } }
        onMove={(_f) => {
          setActiveFolder(_f);
          setIsModalMoveFolder(true);
        }}
      />

      <ModalMove
        folder={activeFolder}
        open={isModalMoveFolder}
        options={folderItems?.filter((f) => f.id !== activeFolder?.id)}
        fetchFolderContent={() => fetchFolderContents(currentFolder?.id)}
        onClose={() => setIsModalMoveFolder(false)}
      />
      <ModalShareFolder
        open={isModalShareFolder}
        handleShare={activeFolder ? handleShareSingleFolder : handleShare}
        title={
          activeFolder?.name
            ? `Gửi đường liên kết cho "${activeFolder.name}"`
            : "Gửi đường liên kết"
        }
        folder={activeFolder}
        onClose={() => {
          setIsModalShareFolder(false);
          setActiveFolder(null);
        }}
      />
    </Box>
  );
};

export default MediaManagementMain;
