import {
  getAllExamTemplatesAction,
  getAllQuestionsAction,
  getAllTopicAction,
} from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import styled from "styled-components";
import { useDispatchRedux } from "utils/hooks/useRedux";

import ExamGenerateForm from "./components/Form";
import { convertDataSubmissionToManualSelections } from "./components/Form/helpers";
import ModalNotification from "./components/Form/ModalNotification";
import {
  createExamGenerateAction,
  detailExamGenerateAction,
  editExamGenerateAction,
  queryExamGenerateAction,
} from "./store/actions";
import { MODE_GENERATE } from "./store/constants";

const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

const ExamGenerateFormTeacher = () => {
  const { id } = useParams();

  const fetchAllExamTemplate = useDispatchRedux(getAllExamTemplatesAction);
  const fetchAllQuestions = useDispatchRedux(getAllQuestionsAction);
  const fetchAllTopics = useDispatchRedux(getAllTopicAction);
  const rqCreateExamGenerate = useDispatchRedux(createExamGenerateAction);
  const rqDetailExamGenerate = useDispatchRedux(detailExamGenerateAction);
  const rqEditExamGenerate = useDispatchRedux(editExamGenerateAction);
  const fetchAllExamGenerate = useDispatchRedux(queryExamGenerateAction);

  useEffect(() => {
    fetchAllTopics();
    fetchAllExamTemplate();
    fetchAllExamGenerate();

    setTimeout(() => {
      fetchAllQuestions();

      if (id) rqDetailExamGenerate(id);
    }, 500);
  }, []);

  const handleSubmit = (values) => {
    if (
      values?.manualSelections?.length &&
      values?.mode === MODE_GENERATE.EXAM_TEMPLATE
    ) {
      values.manualSelections = convertDataSubmissionToManualSelections(
        values.manualSelections
      );
    }

    if (id) return rqEditExamGenerate(values);

    rqCreateExamGenerate(values);
  };

  return (
    <PageWrapper>
      <AppHeader
        isHiddenBtn
        componentName={
          id ? "EditExamGenerateTeacher" : "AddExamGenerateTeacher"
        }
      />

      <ExamGenerateForm onSubmit={handleSubmit} />

      <ModalNotification />
    </PageWrapper>
  );
};

export default ExamGenerateFormTeacher;
