import {
  getAllSubjectAction,
  getAllExamTemplatesAction,
} from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import PropTypes from "prop-types";
import { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import { ListExamGenerateWrapper } from "./components/List/Styled";
import Table from "./components/List/Table";
import PreviewModal from "./components/Preview/PreviewModal";
import {
  queryExamGenerateAction,
  resetStoreExamGenerateAction,
} from "./store/actions";

const ListExamGenerate = () => {
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const resetStoreExamGenerate = useDispatchRedux(resetStoreExamGenerateAction);
  const fetchAllExamTemplate = useDispatchRedux(getAllExamTemplatesAction);
  const fetchAllExamGenerate = useDispatchRedux(queryExamGenerateAction);

  useEffect(() => {
    fetchAllSubject();
    fetchAllExamTemplate();

    setTimeout(() => {
      fetchAllExamGenerate();
    }, 500);

    return () => resetStoreExamGenerate();
  }, []);

  return (
    <ListExamGenerateWrapper>
      <AppHeader
        btnName="Tạo đề thi mới"
        componentName="ExamGenerateTeacher"
        componentNameAdd="AddExamGenerateTeacher"
      />

      <Table />
      <PreviewModal />
    </ListExamGenerateWrapper>
  );
};

ListExamGenerate.propTypes = {
  historyPathCreate: PropTypes.string,
  historyPathEdit: PropTypes.string,
};

export default ListExamGenerate;
