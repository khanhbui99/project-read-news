import { getAllTopicAction, getAllSubjectAction, setModalNotificationAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import ModalNotification from "components/common/Modal/ModalNotification";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import styled from "styled-components";
import { useDispatchRedux } from "utils/hooks/useRedux";

import FormExamTemplate from "./components/Form";
import { totalPoints } from "./components/Form/validation";
import {
  editExamTemplateAction,
  createExamTemplateAction,
  resetStoreExamTemplateAction,
  detailExamTemplateAction,
} from "./store/actions";

const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

const FormExamTemplateTeacher = () => {
  const { id } = useParams();

  const fetchAllTopic = useDispatchRedux(getAllTopicAction);
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const rqEditExamTemplate = useDispatchRedux(editExamTemplateAction);
  const rqDetailExamTemplate = useDispatchRedux(detailExamTemplateAction);
  const rqCreateExamTemplate = useDispatchRedux(createExamTemplateAction);
  const resetStoreExamTemplate = useDispatchRedux(resetStoreExamTemplateAction);
  const setModalNotification = useDispatchRedux(setModalNotificationAction);

  useEffect(() => {
    setTimeout(() => {
      fetchAllTopic();
      fetchAllSubject();

      if (id) {
        rqDetailExamTemplate(id);
      }
    }, 100);

    return () => {
      resetStoreExamTemplate();
    };
  }, []);

  const handleSubmit = (values) => {
    const totalPoint = totalPoints(values);
    if (totalPoint > values.totalScore) {
      setModalNotification({
        isError: true,
        title: "Lỗi",
        message: "Tổng điểm cấu trúc đề thi VƯỢT quá tổng điểm",
      });
      return;
    }

    if (totalPoint < values.totalScore) {
      setModalNotification({
        isError: true,
        title: "Lỗi",
        message: "Tổng điểm cấu trúc đề thi NHỎ hơn tổng điểm",
      });
      return;
    }

    if (id) return rqEditExamTemplate(values);
    return rqCreateExamTemplate(values);
  };

  return (
    <PageWrapper>
      <AppHeader
        isHiddenBtn
        componentName={
          id ? "EditExamTemplateTeacher" : "AddExamTemplateTeacher"
        }
      />

      <FormExamTemplate onSubmit={handleSubmit} />

      <ModalNotification componentName="ExamTemplateTeacher" />
    </PageWrapper>
  );
};

export default FormExamTemplateTeacher;
