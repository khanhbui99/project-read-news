import { getAllSubjectAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import PropTypes from "prop-types";
import { useEffect } from "react";
import React from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import TableExamTemplate from "./components/List/Table";
import {
  queryExamTemplateAction,
  resetStoreExamTemplateAction,
} from "./store/actions";

const ListExamTemplate = () => {
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const fetchAllExamTemplate = useDispatchRedux(queryExamTemplateAction);
  const resetStoreExamTemplate = useDispatchRedux(resetStoreExamTemplateAction);

  useEffect(() => {
    fetchAllSubject();
    // fetchAllExamTemplate();

    setTimeout(() => {
      fetchAllExamTemplate();
    }, 500);

    return () => {
      resetStoreExamTemplate();
    };
  }, []);

  return (
    <React.Fragment>
      <AppHeader
        btnName="Tạo cấu trúc đề"
        componentName="ExamTemplateTeacher"
        componentNameAdd="AddExamTemplateTeacher"
      />

      <TableExamTemplate />
    </React.Fragment>
  );
};

ListExamTemplate.propTypes = {
  historyPathCreate: PropTypes.string,
  historyPathEdit: PropTypes.string,
};

export default ListExamTemplate;
