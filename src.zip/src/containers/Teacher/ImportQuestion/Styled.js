import { Box, Alert, ListItem, ListItemText, Chip, Paper } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled(Box)`
  padding: 2rem;
  min-height: 100vh;
  border-radius: 24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.gray[100]} 0%,
    #e8eef3 100%
  );

  @media (max-width: 768px) {
    padding: 0;
    border-radius: 16px;
    background: none;

    .btn {
      width: 100%;
    }

    .partWrapper {
      padding: 16px;
    }
  }
`;

export const ContentWrapper = styled(Box)`
  max-width: 1000px;
  margin: 0 auto;

  @media (max-width: 1200px) {
    max-width: 100%;
    padding: 0 1rem;
  }

  @media (max-width: 768px) {
    padding: 0;
  }
`;

export const SectionTitleStyled = styled(Box)`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;

  svg {
    color: ${VPB_THEMES.colors.green};
    font-size: 2rem;
  }

  .step-number {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(
      135deg,
      ${VPB_THEMES.colors.green} 0%,
      ${VPB_THEMES.colors.blue} 100%
    );
    color: white;
    font-weight: 700;
    font-size: 0.9rem;
  }

  @media (max-width: 768px) {
    gap: 0.75rem;
    margin-bottom: 1.5rem;

    .step-number {
      width: 28px;
      height: 28px;
      font-size: 0.8rem;
    }

    svg {
      font-size: 1.5rem;
    }
  }

  @media (max-width: 480px) {
    gap: 0.5rem;
    margin-bottom: 1rem;

    .step-number {
      width: 24px;
      height: 24px;
      font-size: 0.75rem;
    }
  }
`;

export const DownloadSectionStyled = styled(Paper)`
  display: flex;
  align-items: center;
  gap: 2rem;
  padding: 2rem;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  border-radius: 12px !important;
  margin-bottom: 2rem;
  border: 2px solid #c8f0d4;
  transition: all 0.3s ease;

  &:hover {
    border-color: ${VPB_THEMES.colors.green};
    box-shadow: 0 12px 32px rgba(0, 173, 83, 0.15);
  }

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 1.5rem;
    padding: 1.5rem;
    text-align: center;
  }

  @media (max-width: 480px) {
    padding: 1rem;
    gap: 1rem;
    margin-bottom: 1.5rem;
  }
`;

export const DownloadIconBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 80px;
  border-radius: 12px;
  background: white;
  box-shadow: 0 4px 16px rgba(0, 173, 83, 0.2);
  flex-shrink: 0;

  svg {
    font-size: 2.5rem;
    color: ${VPB_THEMES.colors.green};
  }

  @media (max-width: 768px) {
    width: 70px;
    height: 70px;

    svg {
      font-size: 2rem;
    }
  }

  @media (max-width: 480px) {
    width: 60px;
    height: 60px;

    svg {
      font-size: 1.75rem;
    }
  }
`;

export const FileTypeListStyled = styled(Box)`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  margin-top: 1.5rem;

  @media (max-width: 600px) {
    gap: 0.75rem;
  }
`;

export const FileTypeChipStyled = styled(Chip)`
  background: linear-gradient(
    135deg,
    rgba(0, 173, 83, 0.1) 0%,
    rgba(29, 66, 137, 0.1) 100%
  ) !important;
  border: 1.5px solid ${VPB_THEMES.colors.green} !important;
  color: ${VPB_THEMES.colors.green} !important;
  font-weight: 600 !important;
  font-size: 0.9rem !important;

  svg {
    color: ${VPB_THEMES.colors.green} !important;
  }
`;

export const AlertStyled = styled(Alert)`
  background: linear-gradient(135deg, #f0faf5 0%, #e8f5f0 100%) !important;
  border: 2px solid ${VPB_THEMES.colors.green}30 !important;
  border-radius: 12px !important;
  margin-bottom: 2rem !important;

  .MuiAlert-icon {
    color: ${VPB_THEMES.colors.green} !important;
  }
`;

export const DropZoneStyled = styled(Paper)`
  border: 3px dashed ${VPB_THEMES.colors.green};
  border-radius: 16px;
  padding: 4rem 2rem;
  text-align: center;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(
      circle at 30% 70%,
      rgba(0, 173, 83, 0.05) 0%,
      transparent 50%
    );
    pointer-events: none;
  }

  &:hover {
    background: linear-gradient(135deg, #f0f9f5 0%, #e8f5f0 100%);
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 16px 48px rgba(0, 173, 83, 0.2);
  }

  &.dragover {
    background: linear-gradient(135deg, #e8f5f0 0%, #e0f2eb 100%);
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 20px 60px rgba(0, 173, 83, 0.3);
    transform: scale(1.01);
  }

  input[type="file"] {
    display: none;
  }

  @media (max-width: 768px) {
    padding: 3rem 1.5rem;
    border-width: 2px;
  }

  @media (max-width: 480px) {
    padding: 2rem 1rem;
    border-radius: 12px;
  }
`;

export const DropZoneContentStyled = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  position: relative;
  z-index: 1;

  svg {
    font-size: 5rem;
    color: ${VPB_THEMES.colors.green};
    opacity: 0.8;
    animation: float 3s ease-in-out infinite;
  }

  @keyframes float {
    0%,
    100% {
      transform: translateY(0px);
    }
    50% {
      transform: translateY(-10px);
    }
  }

  h3 {
    color: #1a1a1a;
    margin: 0;
    font-size: 1.3rem;
    font-weight: 700;
  }

  p {
    color: #666;
    margin: 0;
    font-size: 1rem;

    &:last-child {
      font-size: 0.9rem;
      color: #999;
    }
  }

  @media (max-width: 768px) {
    gap: 1rem;

    svg {
      font-size: 4rem;
    }

    h3 {
      font-size: 1.1rem;
    }

    p {
      font-size: 0.9rem;

      &:last-child {
        font-size: 0.85rem;
      }
    }
  }

  @media (max-width: 480px) {
    gap: 0.75rem;

    svg {
      font-size: 3rem;
    }

    h3 {
      font-size: 1rem;
    }

    p {
      font-size: 0.85rem;

      &:last-child {
        font-size: 0.8rem;
      }
    }
  }
`;

export const FileItemStyled = styled(ListItem)`
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%) !important;
  border-radius: 12px !important;
  margin-bottom: 1rem !important;
  padding: 1.25rem !important;
  border-left: 5px solid ${VPB_THEMES.colors.green} !important;
  transition: all 0.3s ease !important;

  &:hover {
    box-shadow: 0 8px 24px rgba(0, 173, 83, 0.15) !important;
    transform: translateX(8px);
  }

  @media (max-width: 768px) {
    padding: 1rem !important;
    border-left-width: 4px !important;
  }

  @media (max-width: 480px) {
    padding: 0.75rem !important;
    border-left-width: 3px !important;
    margin-bottom: 0.75rem !important;
  }
`;

export const FileInfoStyled = styled(ListItemText)`
  margin: 0 !important;

  .MuiListItemText-primary {
    font-weight: 600 !important;
    color: #1a1a1a !important;
    font-size: 1rem !important;
  }

  .MuiListItemText-secondary {
    color: #999 !important;
    font-size: 0.9rem !important;
    margin-top: 0.25rem !important;
  }
`;
