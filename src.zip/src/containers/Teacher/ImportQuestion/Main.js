import {
  getAllSubjectAction,
  getAllBankQuestionsAction,
} from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import DownloadTemplate from "./components/DownloadTemplate";
import ImportSection from "./components/ImportSection";
import { ContainerStyled, ContentWrapper } from "./Styled";

const Main = () => {
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const fetchAllBankQuestions = useDispatchRedux(getAllBankQuestionsAction);

  useEffect(() => {
    fetchAllSubject();
    fetchAllBankQuestions();
  }, []);

  return (
    <React.Fragment>
      <AppHeader isHiddenBtn componentName="ImportQuestionTeacher" />
      <ContainerStyled>
        <ContentWrapper>
          <DownloadTemplate />

          <ImportSection />
        </ContentWrapper>
      </ContainerStyled>
    </React.Fragment>
  );
};

export default Main;
