export const SUPPORTED_FORMATS = [
  { type: "PDF", ext: ".pdf" },
  { type: "Excel", ext: ".xlsx, .xls" },
  { type: "Word", ext: ".docx, .doc" },
];

export const ACCEPTED_FILE_TYPES = ".xlsx,.xls,.docx,.doc";

export const VALID_EXTENSIONS = SUPPORTED_FORMATS.map((fmt) => fmt.ext)
  .join(",")
  .split(",")
  .map((ext) => ext.trim());

