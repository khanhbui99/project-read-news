import PropTypes from "prop-types";
import ListSkeleton from "skeletons/ListSkeleton";
import loadable from "utils/loadable";

const Provider = ({ children }) => {
  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const ImportQuestionTeacher = loadable(() => import("./Main"), {
  fallback: <ListSkeleton />,
  provider: Provider,
});

export default ImportQuestionTeacher;
