import { getAllSubjectAction, getAllTopicAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useLayoutEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import TableQuestionBank from "./components/List/Table";
import { queryBankAction, resetStoreQuestionBankAction } from "./store/actions";

// import FilterQuestionBank from "./components/List/Filter";

const ListQuestionBank = () => {
  const fetchAllTopic = useDispatchRedux(getAllTopicAction);
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const fetchAllQuestionBank = useDispatchRedux(queryBankAction);
  const resetStoreQuestionBank = useDispatchRedux(resetStoreQuestionBankAction);

  useLayoutEffect(() => {
    fetchAllTopic();
    fetchAllSubject();
    // fetchAllQuestionBank();

    setTimeout(() => {
      fetchAllQuestionBank();
    }, 500);

    return () => {
      resetStoreQuestionBank();
    };
  }, []);

  return (
    <React.Fragment>
      <AppHeader
        componentName="QuestionBankTeacher"
        componentNameAdd="AddQuestionBankTeacher"
        btnName="Tạo ngân hàng câu hỏi"
      />

      {/* <FilterQuestionBank /> */}
      <TableQuestionBank />
    </React.Fragment>
  );
};

export default ListQuestionBank;
