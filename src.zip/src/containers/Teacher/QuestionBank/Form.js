import { getAllSubjectAction, getAllTopicAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import ModalActionNextStep from "containers/Teacher/QuestionBank/components/Form/ModalActionNextStep";
import React, { useEffect, useMemo } from "react";
import { useParams } from "react-router-dom";
import { useDispatchRedux } from "utils/hooks/useRedux";

import FormQuestionBank from "./components/Form";
import {
  detailBankAction,
  resetStoreQuestionBankAction,
} from "./store/actions";
import { MODE_FORM_BANK_QUESTION } from "./store/constants";

const FormQuestionBankTeacher = () => {
  const { id, questionid } = useParams();

  const fetchAllTopic = useDispatchRedux(getAllTopicAction);
  const fetchAllSubject = useDispatchRedux(getAllSubjectAction);
  const resetStoreQuestionBank = useDispatchRedux(resetStoreQuestionBankAction);
  const fetchDetailQuestionBank = useDispatchRedux(detailBankAction);
  // const fetchDetailQuestion = useDispatchRedux(detailQuestionAction);

  /**
   * Xác định mode của form:
   * - CREATE_BANK: tạo mới ngân hàng câu hỏi
   * - EDIT_BANK: chỉnh sửa ngân hàng câu hỏi
   * - EDIT_QUESTION: chỉnh sửa câu hỏi trong ngân hàng
   * - CREATE_QUESTION: tạo mới câu hỏi trong ngân hàng
   */
  const mode = useMemo(() => {
    if (!id && !questionid) {
      return {
        name: MODE_FORM_BANK_QUESTION.CREATE_BANK,
        title: "Tạo ngân hàng câu hỏi",
      };
    }
    console.log(id, questionid);
    if (id && !questionid) {
      return {
        name: MODE_FORM_BANK_QUESTION.EDIT_BANK,
        title: "Chỉnh sửa thông tin ngân hàng câu hỏi",
      };
    }

    if (questionid && String(questionid).toLowerCase() !== "new") {
      return {
        name: MODE_FORM_BANK_QUESTION.EDIT_QUESTION,
        title: "Chỉnh sửa câu hỏi",
      };
    }

    return {
      title: "Tạo câu hỏi",
      name: MODE_FORM_BANK_QUESTION.CREATE_QUESTION,
    };
  }, [id, questionid]);

  useEffect(() => {
    fetchAllTopic();
    fetchAllSubject();

    if (id) {
      fetchDetailQuestionBank({ bankId: id, questionId: questionid });
    }

    return () => {
      resetStoreQuestionBank();
    };
  }, []);

  return (
    <React.Fragment>
      <AppHeader isHiddenBtn pageTitle={mode.title} />

      <FormQuestionBank id={id} mode={mode.name} />

      <ModalActionNextStep mode={mode.name} />
    </React.Fragment>
  );
};

export default FormQuestionBankTeacher;
