//
//  Nơi khởi tạo page và component trong menu
//
import AuthLogin from "containers/Auth.Login";
import ClassroomManagement from "containers/ClassroomManagement";
import * as PagesClassRooms from "containers/ClassRooms";
import MyProfile from "containers/Common/MyProfile";
import * as PagesConfig from "containers/Config";
import Dashboard from "containers/Dashboard";
import ImportReport from "containers/ImportReport";
import * as PagesOrgchart from "containers/Orgchart";
import * as PagesReportMgmt from "containers/ReportMgmt";
import * as PagesTeacher from "containers/Teacher";
import WordEditor from "containers/WordEditor";
import NewFeature from "modules/500";
import * as BGHModule from "modules/BGH";
import ChangePasswordPage from "modules/ChangePassword";
import * as ChatModule from "modules/Chat";
import * as ConfigModule from "modules/Config";
import * as DashbroadModule from "modules/Dashbroad";
import * as EmulationModule from "modules/Emulation";
import * as FacilityModule from "modules/Facility";
import * as GiamThiModule from "modules/GiamThi";
import * as HomeWorkModule from "modules/HomeWork";
import * as ParentsModule from "modules/Parents";
import * as ReportModule from "modules/Report";
import * as StudentModule from "modules/Student";
import * as TeacherModule from "modules/Teacher";
import * as TimeableModule from "modules/Timeable";
import * as TaskModule from "modules/Task";
import ViewFile from "modules/ViewFile";

const NonComponent = () => null;

export const UnAuthPages = {
  AuthLogin,
};

export default {
  MyProfile,
  NonComponent,
  ClassroomManagement,
  Dashboard,
  ImportReport,
  WordEditor,
  NewFeature,
  ViewFile,
  ChangePasswordPage,

  ...PagesConfig,
  ...PagesOrgchart,
  ...PagesTeacher,
  ...PagesClassRooms,
  ...PagesReportMgmt,
  ...StudentModule,
  ...TeacherModule,
  ...GiamThiModule,
  ...ChatModule,
  ...ReportModule,
  ...ParentsModule,
  ...ConfigModule,
  ...BGHModule,
  ...DashbroadModule,
  ...EmulationModule,
  ...FacilityModule,
  ...HomeWorkModule,
  ...TimeableModule,
  ...TaskModule,
};
