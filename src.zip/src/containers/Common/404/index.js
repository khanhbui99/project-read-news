import NotFoundIcons from 'assets/icons/404';
import React from 'react';
import { pxToRem } from 'utils/helpers';

const NotFound = () => (
  <div className="text-center">
    <img
      style={{
        height: `calc(100vh - ${pxToRem(80)})`,
        margin: '0 auto',
      }}
      src={NotFoundIcons[404]}
      alt="404"
    />
  </div>
);

export default NotFound;
