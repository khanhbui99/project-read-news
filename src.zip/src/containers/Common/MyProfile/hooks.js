import get from 'lodash/get';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import NotistackApp from 'utils/NotistackApp';

import * as myProfileAction from './store/actions';
import { key } from './store/constants';

const useLogicMyProfile = () => {
  const dispatch = useDispatch();

  const {
    profile = {},
    authorized = [],
    concurrent = [],
    isLoading = false,
  } = useSelector(state => get(state, key, {}));

  const [selectedItem, setSelectedItem] = useState();
  const [openConfirmModal, setOpenConfirmModal] = useState(false);

  const onChangeAvatar = (event, refInput) => {
    const file = get(event, 'target.files[0]', null);

    if (!file) {
      NotistackApp.error('Không tìm thầy file ảnh từ máy tính!');
      return;
    }

    const formData = new FormData();

    formData.append('file', file);
    formData.append('accountCode', get(profile, 'accountCode'));

    dispatch(myProfileAction.changeAvatarAction(formData));
     
    refInput.current.value = null;
  };

  const onConfirmAuthorized = item => {
    setSelectedItem({ ...item });
    setOpenConfirmModal(true);
  };

  const onActiveAuthorized = id => {
    setOpenConfirmModal(false);
    dispatch(myProfileAction.activeAthorizedAction({ id }));
  };

  const onDetailConcurrent = id => {
    // setOpenConfirmModal(false);
    dispatch(myProfileAction.detailConcurrentAction({ id }));
  };
  
  useEffect(() => {
    setTimeout(() => {
      dispatch(myProfileAction.getMyProfileAction());
      dispatch(myProfileAction.getListConcurrentAction());
      dispatch(myProfileAction.getListConfirmAuthorizedAction());
    }, 100);
  }, []);

  return {
    profile,
    isLoading,
    authorized,
    concurrent,
    selectedItem,
    openConfirmModal,

    onChangeAvatar,
    onDetailConcurrent,
    onActiveAuthorized,
    onConfirmAuthorized,
    setOpenConfirmModal,
  };
};

export default useLogicMyProfile;
