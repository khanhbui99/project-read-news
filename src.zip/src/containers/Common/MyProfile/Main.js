import ConfirmModal from 'components/common/ConfirmModal';
import LoadingPage from 'components/common/LoadingPage';
import dayjs from 'dayjs';
import get from 'lodash/get';
import React from 'react';
import { VPB_THEMES } from 'utils/configs';
import { DateFormat2 } from 'utils/constants';

import BoxProfile from './components/BoxProfile';
import ModalFormConcurrent from './components/ModalFormConcurrent';
import TabList from './components/TabList';
import useLogicMyProfile from './hooks';

const Main = () => {
  const {
    profile,
    isLoading,
    authorized,
    concurrent,
    selectedItem,
    openConfirmModal,
    // FUNC
    onChangeAvatar,
    onDetailConcurrent,
    onActiveAuthorized,
    onConfirmAuthorized,
    setOpenConfirmModal,
  } = useLogicMyProfile();

  return (
    <React.Fragment>
      <LoadingPage loading={isLoading} />

      <BoxProfile profile={profile} onChangeAvatar={onChangeAvatar} />

      {/* <TabList
        authorized={authorized}
        concurrent={concurrent}
        onDetailConcurrent={onDetailConcurrent}
        onConfirmAuthorized={onConfirmAuthorized}
      /> */}

      <ConfirmModal
        id={get(selectedItem, 'id')}
        open={openConfirmModal}
        messageWarning="Hành động này sẽ không thể thu hồi lại được nếu nhấn xác nhận!"
        mesage={
          <>
            <span style={{ color: VPB_THEMES.colors.red }}>
              {`Bạn muốn ỦY QUYỀN cho tài khoản ${get(
                selectedItem,
                'username',
                '',
              )}`}
            </span>
            <br />
            <span style={{ color: VPB_THEMES.colors.red }}>
              {`Đến ngày ${get(selectedItem, 'expireTime') &&
                dayjs(selectedItem.expireTime).format(DateFormat2)}`}
            </span>
          </>
        }
        onClose={setOpenConfirmModal}
        onSubmit={onActiveAuthorized}
      />

      <ModalFormConcurrent/>
    </React.Fragment>
  );
};

export default Main;
