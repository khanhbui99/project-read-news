//
// Quản lý component
// FORMAT: {name}{Name product}
// example: name: Component; product:CCPA => ComponentPACC
//
// export {
//   UserAccount2,
//   UserAddAccount,
//   UserEditAccount,
// } from "containers/Common/User/Account2";
// export { default as ProductBranch } from "containers/Common/Product/Branch";
// export { default as UserAccount } from "containers/Common/User/Account";
// export { default as UserGroup } from "containers/Common/User/GroupPermission";
// export { default as UserProduct } from "containers/Common/User/Product";
// export { default as MergeTeam } from "containers/Common/OrgChart/MergeTeam";
// export { default as Concurrent } from "containers/Common/OrgChart/Concurrent";
// export { default as AssignProduct } from "containers/Common/OrgChart/AssignProduct";
// export { default as AddGroupPermission } from "containers/Common/User/GroupPermission/components/AddGroupPermission";