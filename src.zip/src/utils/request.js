import axios from "axios";

import {
  API_TIMEOUT,
  ROOT_URI,
  TOKEN_NAME,
} from "./constants";
import { logout } from "./helpers";


const instance = axios.create({
  baseURL: ROOT_URI,
  timeout: API_TIMEOUT,
});

const sendRequest = ({
  url,
  data,
  method,
  params,
  notAuth = false,
  multipart = false,
  responseType,
  timeout,
  headers,
  xAPIKey,
}) =>
  instance({
    url,
    method,
    params,
    data,
    responseType,
    headers: {
      "content-type": multipart ? "multipart/form-data" : "application/json",
      Authorization: notAuth ? "" : localStorage.getItem(TOKEN_NAME) || "",
      ...headers,
      ...xAPIKey,
    },
    timeout,
  })
    .then((response) => {
      if (!response.data.error || response.data.error === 0) {
        return handleSuccess(response);
      }
      return handleError(response);
    })
    .catch(({ response, message = "Request failed" }) => {
      if (response?.status === 401 && !notAuth) {
        // refeshToken();
        logout();
      }

      throw (response && response?.data?.meta) || { message };
    });

export const get = (props) => sendRequest({ method: "GET", ...props });

export const post = (props) =>
  sendRequest({
    method: "POST",
    ...props,
  });

export const put = (props) => sendRequest({ method: "PUT", ...props });

export const del = (props) => sendRequest({ method: "DELETE", ...props });
export const patch = (props) => sendRequest({ method: "PATCH", ...props });

export const getFile = ({ url, params, notAuth, responseType }) =>
  sendRequest({ url, params, method: "GET", notAuth, responseType });

const handleSuccess = (respond) => Promise.resolve(respond);

const handleError = (error) => {
  if (error.response) {
    return Promise.reject(error && error.response && error.response.data.meta);
  }

  return Promise.reject(error);
};

// const refeshToken = () => {
//   retryToken -= 1;

//   post({
//     url: API.auth.refreshToken,
//     data: {
//       refresh_token: localStorage.getItem(REFRESH_TOKEN_NAME),
//     },
//   })
//     .then(({ data, status }) => {
//       if (retryToken <= 0 || status !== 200) {
//         logout();
//         return;
//       }

//       const token = getLd(data, "data.access_token");
//       if (token) {
//         const val = `Bearer ${token}`;
//         const cookies = new Cookies();

//         cookies.set(TOKEN_NAME, val, { path: "/" });

//         localStorage.setItem(TOKEN_NAME, val);

//         history.push(window.location.pathname);
//       }
//     })
//     .catch(logout);
// };

const sendDownloadRequest = ({
  url,
  method,
  params,
  data,
  folderName,
  notAuth = false,
  multipart = false,
}) =>
  instance({
    url,
    method,
    params,
    data,
    responseType: "blob",
    headers: {
      "content-type": multipart ? "multipart/form-data" : "application/json",
      Authorization: notAuth ? "" : localStorage.getItem(TOKEN_NAME) || "",
    },
    // mode: 'no-cors',
  })
    .then((response) => {
      const url1 = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url1;
      const fileName = folderName || `Document.zip`;
      link.setAttribute("download", fileName);
      document.body.appendChild(link);
      link.click();
    })
    .catch((error) => handleError(error));

export const download = ({
  url,
  params = {},
  data,
  method = "POST",
  folderName,
}) =>
  sendDownloadRequest({
    url,
    params,
    method,
    data,
    folderName,
  });
