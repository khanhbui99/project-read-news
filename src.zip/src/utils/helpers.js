/* eslint-disable no-useless-escape */
import CryptoJS from "crypto-js";
import isNumber from "lodash/isNumber";
import queryString from "query-string";
import { useMemo } from "react";
import { useLocation } from "react-router-dom";
import { PUBLIC_PATH, rem, TOKEN_NAME, adminPrefix, USER_INFO_NAME } from "utils/constants";
import history from "utils/history";
import localStorageService from "utils/services/service.localStorage";

export const useSearchQuery = () => {
  const { search } = useLocation();
  const params = useMemo(() => queryString.parse(search), [search]);

  return params;
};

export const isAuthenticated = () => localStorage.getItem(TOKEN_NAME);

export const logout = () => {
  localStorage.clear();
  window.location.replace(PUBLIC_PATH);
  window.location.reload(true);
};

export const getQueryParams = () => {
  const search = window.location.search.substring(1);
  return search ? queryString.parse(search) : {};
};

export const pxToRem = (px) => `${(px / rem.fhd).toFixed(5)}rem`;

export const isSvgUrl = (url) => (url || "").includes(".svg");

export const numberWithCommas = (number) => {
  if (!number && !isNumber(number)) return "";
  const numberToString = number.toString().replace(/\,/g, "");
  return numberToString
    .toString()
    .replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
};

export const toAccentVietnamese = (str) => {
  let st = `${str}`;
  st = st.toLowerCase();
  st = st.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
  st = st.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
  st = st.replace(/ì|í|ị|ỉ|ĩ/g, "i");
  st = st.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
  st = st.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
  st = st.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
  st = st.replace(/đ/g, "d");
  // Some system encode vietnamese combining accent as individual utf-8 characters
  st = st.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // Huyền sắc hỏi ngã nặng
  st = st.replace(/\u02C6|\u0306|\u031B/g, ""); // Â, Ê, Ă, Ơ, Ư
  //
  st = st
    .replaceAll("(", "")
    .replaceAll(")", "")
    .replaceAll("[", "")
    .replaceAll("]", "");
  return st;
};

export const compareVietnamese = (text, keySearch) => {
  if (!text || !keySearch) return false;
  const normalizedText = toAccentVietnamese(text);
  const normalizedKey = toAccentVietnamese(keySearch);
  return normalizedText.includes(normalizedKey);
};

export const downloadFile = async (url, fileName) => {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Không thể tải tệp từ ${url}`);
  }

  const blob = await response.blob();
  let fileType = ".jpg";

  if (String(url).includes(".mp4?")) fileType = "";

  const now = new Date().getTime();
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}_${now}${fileType}`;
  link.click();
  URL.revokeObjectURL(link.href);
};

export function getLinkConcurrentDetail(url) {
  const urlParams = new URLSearchParams(new URL(url).search);
  const fileName = urlParams.get("fileName");

  // If 'fileName' exists, match the filename and extension
  if (fileName) {
    const regex = /[^/]+\.[a-zA-Z0-9]+/;
    const match = fileName.match(regex);
    return match ? String(match[0] || "").replaceAll("_", " ") : null;
  }
  return null;
}

export const parseNumber = (formattedValue) => {
  if (!formattedValue) return "";
  return Number(String(formattedValue).replace(/\D/g, "")); // Loại bỏ ký tự không phải số
};

export function findMenuByComponentName(componentName) {
  try {
    const menus = localStorageService.menu.get();
    const menuActive = menus[localStorageService.menu.type()];

    if (!Array.isArray(menuActive)) return null;

    for (const item of menuActive) {
      if (item.component === componentName) {
        item.url = `${adminPrefix()}${item.url}`;
        return item;
      }

      if (Array.isArray(item.child)) {
        const found = findComponentInTree(item.child, componentName);
        if (found) {
          found.url = `${adminPrefix()}${found.url}`;
          return found;
        }
      }
    }

    return null;
  } catch {
    return null;
  }
}

export function findComponentInTree(dataArray, targetComponent) {
  if (!Array.isArray(dataArray)) return null;

  for (const item of dataArray) {
    if (item.component === targetComponent) return item;

    if (Array.isArray(item.child)) {
      const found = findComponentInTree(item.child, targetComponent);
      if (found) return found;
    }
  }

  return null;
}

export const handleScrollToBottom = () => {
  setTimeout(() => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  }, 300);
};

export const handleScrollToPosition = (position) => {
  setTimeout(() => {
    window.scrollTo({ top: position, behavior: "smooth" });
  }, 300);
};

/**
 * Convert relative URL to absolute URL using VITE_ROOT_URI
 * @param {string} url - Relative or absolute URL
 * @returns {string} - Absolute URL
 */
export const getAbsoluteUrl = (url) => {
  if (!url) return "";

  // If already absolute URL, return as is
  if (url.startsWith("http://") || url.startsWith("https://")) {
    return url;
  }

  // Get root URI from environment
  const rootUri = import.meta.env.VITE_ROOT_URI || "";

  // Remove leading slash from url if exists
  const cleanUrl = url.startsWith("/") ? url : `/${url}`;

  return `${rootUri}${cleanUrl}`;
};

export const filterTopicBySubjectId = (topics, subjectId) => {
  return topics.filter((topic) => topic.subjectId === subjectId);
};

/**
 * Kiểm tra xem tài khoản có phải là quản trị hệ thống hay không
 * Logic: Nếu orgCharts (hoặc org_charts) trong USER_INFO bằng rỗng hoặc không tồn tại thì là quản trị hệ thống
 * @returns {boolean} - true nếu là quản trị hệ thống, false nếu không
 */
export const isSystemAdmin = () => {
  const orgChartId = localStorageService.auth.orgChartId();
  return isNaN(Number(orgChartId));
};

/**
 * Tạo danh sách năm học theo format YYYY-YYYY+1
 * Bao gồm: 1 năm tương lai, năm hiện tại, 10 năm quá khứ
 * Sắp xếp từ cao đến thấp (tương lai -> hiện tại -> quá khứ)
 */
export const createYearOpt = (isFuture = true) => {
  const currentYear = new Date().getFullYear();
  const options = [];

  // 1 năm tương lai
  if (isFuture) {
    options.push({
      value: `${currentYear + 1}-${currentYear + 2}`,
      label: `${currentYear + 1}-${currentYear + 2}`,
    });
  }

  // Năm hiện tại
  options.push({
    value: `${currentYear}-${currentYear + 1}`,
    label: `${currentYear}-${currentYear + 1}`,
  });

  // 10 năm quá khứ (từ gần nhất đến xa nhất)
  for (let i = 1; i <= 10; i++) {
    const year = currentYear - i;
    options.push({
      value: `${year}-${year + 1}`,
      label: `${year}-${year + 1}`,
    });
  }

  return options;
};

/**
 * Binary search để tìm index của item trong mảng đã được sort giảm dần theo id
 * Time complexity: O(log n) thay vì O(n) của findIndex
 * @param {Array} sortedArray - Mảng đã được sort giảm dần theo id (id lớn nhất ở đầu)
 * @param {number|string} targetId - ID cần tìm
 * @returns {number} - Index của item nếu tìm thấy, -1 nếu không tìm thấy
 */
export const binarySearchById = (sortedArray, targetId) => {
  if (!Array.isArray(sortedArray) || sortedArray.length === 0) {
    return -1;
  }

  // Xử lý trường hợp mảng nhỏ (1-2 phần tử) bằng linear search để tránh lỗi
  if (sortedArray.length <= 10) {
    for (let i = 0; i < sortedArray.length; i++) {
      if (sortedArray[i]?.id === targetId) {
        return i;
      }
    }
    return -1;
  }

  let left = 0;
  let right = sortedArray.length - 1;

  // Convert targetId to number for comparison, nhưng giữ nguyên nếu không phải số hợp lệ
  const target =
    typeof targetId === "string" && !isNaN(Number(targetId))
      ? Number(targetId)
      : targetId;

  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    const midItem = sortedArray[mid];

    if (!midItem || midItem.id === undefined) {
      return -1;
    }

    const midId =
      typeof midItem.id === "string" && !isNaN(Number(midItem.id))
        ? Number(midItem.id)
        : midItem.id;

    // So sánh trực tiếp trước (hỗ trợ cả string và number)
    if (midId === target || midItem.id === targetId) {
      return mid;
    }

    // Mảng sort giảm dần (id lớn nhất ở đầu)
    // Nếu midId > target, item cần tìm ở bên phải
    // Nếu midId < target, item cần tìm ở bên trái
    if (midId > target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }

  return -1;
};

export const shortcutName = (str = "", size = 32) => {
  let name = "";

  const words = str.split(" ").filter((word) => word.length > 0);
  if (words.length === 0) name = "NA";
  if (words.length === 1) name = words[0][0].toUpperCase();
  if (words.length === 2) name = (words[0][0] + words[1][0]).toUpperCase();
  if (words.length > 2)
    name = (words[0][0] + words[words.length - 1][0]).toUpperCase();

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        backgroundColor: "#007bff",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "14px",
        fontWeight: "bold",
        color: "#fff",
        marginRight: "8px",
        textTransform: "uppercase",
      }}
    >
      {name}
    </div>
  );
};

const secretKey = "my-secret-key-123";

export const encrypted = (value) => {
  return CryptoJS.AES.encrypt(JSON.stringify(value), secretKey).toString();
};

export const decrypted = (encrypted) => {
  const bytes = CryptoJS.AES.decrypt(encrypted, secretKey);
  return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
};

export const generateUDID = () => Date.now().toString(36) + Math.random().toString(36).substring(2, 10);

export const getInfoUser = (teachers, name) =>{
  try {
    const stored = localStorage.getItem(USER_INFO_NAME);
    const parse = stored ? JSON.parse(stored) : null;
    const condition = name || parse?.name;
    return teachers.find((teacher) => teacher.fullName == condition || teacher.full_name === condition);
  }
  catch {
    return null;
  }
}

export const getCodeLeaderByTeacherCode = (configApproved) => {
  const teacherCode = localStorageService.auth.teacherCode();
  
  if (!configApproved) return null;

  for (const config of configApproved) {
    if (config?.child?.includes(teacherCode)) {
      return [`${config.leader}`];
    }
  }
  return ["0102229940","0102229964","0102153153"];
}

const quanLy = localStorageService.auth.info();
export const isBGH = () => ['Hiệu Trưởng', 'Phó Hiệu Trưởng'].some(role => String(quanLy?.listRole)?.toUpperCase()?.split(';')?.includes(String(role).toUpperCase()));

export const isToTruong = () => {
  const orgChartId = localStorageService.auth.orgChartId();
  const info = localStorageService.auth.info();

  if(orgChartId && info?.orgCharts) {
    const orgChart = info.orgCharts.find(item => item.orgChartId == orgChartId);
    return !orgChart?.lowestLevel;
  }
  return false;
}

export function getSemesterId() {
  const date = new Date();
  const month = date.getMonth();
  const day = date.getDate();

  if (month < 6 || (month === 0 && day >= 20)) {
    return 2;// Học kỳ 2
  }

  return 1;// Học kỳ 1
}

export const getInitials = (name) => {
  if (!name) return "HS";
  const parts = name.trim().split(" ");
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return name.substring(0, 2).toUpperCase();
};

export const handleRedirect = (comp) => {
  const pathList = findMenuByComponentName(comp)?.url || "";
  history.push(pathList);
}
