import { enqueueSnackbar } from 'notistack';

const NotistackApp = {
  success: (successMessage = '') => {
    enqueueSnackbar(successMessage, {
      variant: 'success',
    });
  },
  error: (errorMessage = '') => {
    enqueueSnackbar(errorMessage, {
      variant: 'error',
    });
  },
};

export default NotistackApp;
