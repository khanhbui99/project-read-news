/**
 * Generate fake user data for testing performance
 * @param {number} count - Number of users to generate
 * @returns {Array} Array of user objects with id and name
 */
export const generateFakeUsers = (count = 10000000) => {
  const users = [];
  for (let i = 0; i < count; i++) {
    users.push({
      id: i + 1,
      name: `User ${i + 1} - ${Math.random().toString(36).substring(7)}`,
    });
  }
  return users;
};

