import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import weekOfYear from "dayjs/plugin/weekOfYear";
import "dayjs/locale/vi";

dayjs.locale("vi");
dayjs.extend(weekOfYear);
dayjs.extend(relativeTime);

export default dayjs;
