import { createTheme } from '@mui/material/styles';
export const MINI_SIDEBAR_WITH = 72;
export const SIDEBAR_WITH = 300;
export const LOGO_HEIGHT = 36;
export const MENU_ITEM_HEIGHT = 32;
export const MINI_MENU_ITEM_HEIGHT = 48;
export const PROFILE_HEIGHT = 32;
export const PROFILE_PADDING_TOP = 16;

export const green = '#00AD53';
const blue = '#0077be'; // Màu xanh dương chuẩn từ landing page
const primaryBlue = '#0077be'; // Màu xanh dương chủ đạo (--primary-blue)
const secondaryBlue = '#00a8e8'; // Màu xanh dương phụ (--secondary-blue)
const lightBlue = '#48cae4'; // Màu xanh dương nhạt (--light-blue)
const darkBlue = '#023e8a'; // Màu xanh dương đậm (--dark-blue)
// Màu text và background chuẩn từ landing page
const textDark = '#1e293b'; // --text-dark
const textLight = '#64748b'; // --text-light
const lightBg = '#f8fafc'; // --light-bg

export const VPB_THEMES = {
  colors: {
    green,
    blue,
    primaryBlue,
    secondaryBlue,
    lightBlue,
    darkBlue,
    // Giữ lại các màu cam để tương thích ngược
    primaryOrange: '#f97316',
    lightOrange: '#fb923c',
    brightOrange: '#ff6b35',
    vibrantOrange: '#ff8c42',
    sunnyOrange: '#ffa94d',
    red: '#E10600',
    yellow: '#CF8B1E',
    purple: '#9C27B0',
    pink: '#E91E63',
    orange: '#FF5722',
    teal: '#00897B', // Xanh ngọc - dùng cho Công lập
    gray: {
      '500': '#181B1D',
      '400': '#5B5B61',
      '300': '#ACACAC',
      '200': '#E9EAEC',
      '100': '#F5F5F5',
      profileHeader: '#5d7080',
      fieldset: '#cad3da'
    },
    table: {
      border:'rgba(242, 244, 248, 1)',
      headerBg: '#F2F4F8',
      borderLight: '#d0d7de', // Màu border nhẹ cho table
      borderMedium: '#e8eef3', // Màu border trung bình
    },
    neutral: '#5d7080',
    white: '#fff',
    null: '#adadad',
    xml: '#f7bc26',
    string: '#5d7080',
    object: '#3c976d',
    boolean: 'cornflowerblue',
    pending: '#DA8600',
    cancel: '#670AC5',
    "94a3b8": "#94a3b8",
    f0fdf4: "#f0fdf4",
    statusActiveBg: "#ECFDF3",
    statusActiveText: "#027A48",
    statusActiveDot: "#12B76A",
    statusHiddenBg: "#F2F4F7",
    statusHiddenText: "#475569",
    statusMaintenanceBg: "#FFF7ED",
    statusMaintenanceText: "#C2410C",
    statusMaintenanceDot: "#F97316",
    statusInactiveBg: "#FEF2F2",
    statusInactiveText: "#B91C1C",
    statusInactiveDot: "#EF4444",
    "475569": "#475569",
    fffbeb: "#fffbeb",
    f0f9ff: "#f0f9ff",
    // Màu text chuẩn từ landing page
    textDark, // --text-dark: #1e293b
    textLight, // --text-light: #64748b
    secondaryText: textLight, // Cập nhật để dùng màu chuẩn
    textColor: textDark, // Cập nhật để dùng màu chuẩn
    btnColor: '#526779',
    // Background chuẩn từ landing page
    lightBg, // --light-bg: #f8fafc
    pageBg: '#F7F9FC', // Background page enterprise dashboard (Facility...)
    neutral001: '#8497AA',
    shade: '#F2F4F8',
    F9F9F9: '#F9F9F9',
    DEE2E8: '#DEE2E8',
    eff6ff: "#eff6ff",
    cardShadow: '0 2px 12px rgba(15, 23, 42, 0.06)',
    cardRadius: '12px',
    // Màu cho lesson items - tông màu nhẹ nhàng, tinh tế
    lessonDefault: {
      start: '#e3f2fd',
      end: '#bbdefb',
    },
    lessonSport: {
      start: '#e8f5e9',
      end: '#c8e6c9',
    },
    lessonArt: {
      start: '#fff3e0',
      end: '#ffe0b2',
    },
    lessonSpecial: {
      start: '#f3e5f5',
      end: '#e1bee7',
    },
    lessonEmpty: {
      start: '#f5f5f5',
      end: '#e0e0e0',
    },
    // Màu cho InfoCard icons
    iconClass: '#4facfe',
    iconPerson: '#f093fb',
    iconCalendar: '#fa709a',
    iconSchool: '#667eea',
    // Màu cho button inactive/disabled
    buttonInactive: '#ACACAC', // Màu xám nhẹ
    buttonDisabled: '#DEE2E8',
    // Màu cho modal và exam schedule
    modal: {
      sectionTitle: '#7f8c8d', // Màu xám cho section title
      subjectTitle: '#2c3e50', // Màu xám đậm cho tiêu đề
      infoLabel: '#7f8c8d', // Màu xám cho label
      infoValue: '#2c3e50', // Màu xám đậm cho giá trị
      roomCardBg: '#f8f9fa', // Background cho room card
      roomCardHover: '#f0f7ff', // Background hover cho room card
      summaryBg: '#e3f2fd', // Background cho summary box
      summaryBgEnd: '#f0f7ff', // Background gradient end
      summaryBorder: '#b3d9ff', // Border cho summary box
    },
    // Màu trạng thái bài tập học sinh
    assignmentStatus: {
      CHUA_XEM: { color: '#2563eb', bg: '#eff6ff', border: '#bfdbfe' },
      DA_XEM: { color: '#0891b2', bg: '#ecfeff', border: '#a5f3fc' },
      DA_NOP: { color: '#059669', bg: '#ecfdf5', border: '#a7f3d0' },
      NOP_TRE: { color: '#ea580c', bg: '#fff7ed', border: '#fed7aa' },
      DA_CHAM: { color: '#7c3aed', bg: '#f5f3ff', border: '#ddd6fe' },
      DA_KHOA: { color: '#64748b', bg: '#f1f5f9', border: '#cbd5e1' },
    },
    deadlineWarning: '#f59e0b',
    deadlineDanger: '#ef4444',
    alertWarningBg: '#fff7ed',
    alertWarningColor: '#c2410c',
    alertWarningBorder: '#fed7aa',
    // Màu cho icon và accent
    iconBlue: '#0084ff', // Màu xanh cho icon
    iconBgBlue: '#e3f2fd', // Background xanh nhạt cho icon
    iconBgOrange: '#fff3e0', // Background cam nhạt cho icon
    iconOrange: '#ff9800', // Màu cam cho icon
  },
  gradient: {
    '1': `#006494`,
    '2': `linear-gradient(81.17deg, ${primaryBlue} 0%, ${secondaryBlue} 50%, ${lightBlue} 100%)`,
    '3': `linear-gradient(135deg, ${primaryBlue} 0%, ${secondaryBlue} 50%, ${lightBlue} 100%)`, // Ocean gradient chuẩn (--ocean-gradient)
    '4': `linear-gradient(180deg, ${primaryBlue} 0%, #ffffff 100%)`,
    '5': `linear-gradient(135deg, ${secondaryBlue} 0%, ${lightBlue} 50%, #ffffff 100%)`,
    ocean: `linear-gradient(135deg, ${primaryBlue} 0%, ${secondaryBlue} 50%, ${lightBlue} 100%)`, // Ocean gradient chuẩn
  },
  bosShadow: '0px 12px 20px rgba(0, 0, 0, 0.15)',
};

export const MuiTheme = createTheme({
  typography: {
    fontFamily: "'SVN_Gilroy', sans-serif",
  },
  palette: {
    primary: {
      main: VPB_THEMES.colors.primaryBlue,
      light: VPB_THEMES.colors.lightBlue,
      dark: VPB_THEMES.colors.darkBlue,
      contrastText: '#fff',
    },
    secondary: {
      main: VPB_THEMES.colors.secondaryBlue,
      contrastText: '#fff',
    },
    background: {
      default: '#ffffff',
      paper: '#ffffff',
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: '8px',
          textTransform: 'unset',
        },
      },
    },
    MuiCheckbox: {
      styleOverrides: {
        root: {
          color: VPB_THEMES.colors.gray[300],
        },
      },
    },
    //table
    MuiTable: {
      styleOverrides: {
        root: {
          border: `1px solid ${VPB_THEMES.colors.table.border}`,
        },
      },
    },
    MuiTableHead: {
      styleOverrides: {
        root: {
          backgroundColor: VPB_THEMES.colors.table.headerBg,
          height: '49px',
        },
      },
    },
    MuiTableRow: {
      styleOverrides: {
        root: {
          borderBottom: '1px solid',
          borderColor: VPB_THEMES.colors.table.border,
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        stickyHeader: {
          backgroundColor: VPB_THEMES.colors.table.headerBg,
        },
      },
    },
    //end table
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
      },
    },
    MuiAutocomplete: {
      styleOverrides: {
        popper: {
          minWidth: 'fit-content',
        },
      },
    },
  },
});
