const apiUrls = {
  card: {
    cardsOffer: "/card/v2/public/cards-offers",
    cardsOfferDetail: (payload) => `/card/v2/public/cards-offers/${payload}`,
    editCardsOffer: (payload) => `/card/v2/public/cards-offers/${payload}`,
    deleteCardsOffer: (payload) => `/card/v2/public/cards-offers/${payload}`,

    cardConfig: "/card/v2/public/card-config",
    cardConfigPriority: "card/v2/public/card-config/priority",
    cardConfigDetail: (payload) => `/card/v2/public/card-config/${payload}`,
    editCardConfig: (payload) => `/card/v2/public/card-config/${payload}`,
    deleteCardConfig: (payload) => `/card/v2/public/card-config/${payload}`,

    updateKYC: "/card/v2/public/applications/change-kyc",
    allocation: "/card/v2/public/allotment",
    allocationCancel: (payload) =>
      `/card/v2/public/allotment/action/${payload}`,
    allocationAuto: "/card/v2/public/assign/all",
    allocationAutoCancel: (payload) =>
      `card/v2/public/assign/cancel/${payload}`,
    allocationAutoCreate: "/card/v2/public/assign/add-new",
    allocationAutoUpdate: "/card/v2/public/assign/update",
    allocationAutoDetail: (payload) =>
      `/card/v2/public/assign/detail/${payload}`,
    export: `/card/v2/public/export`,
    allocationManual: "/card/v2/public/assign/sale/view/list",
    viewListApplication: "/card/v2/public/applications/view-list",

    benefit: "card/v2/public/benefits",
    benefitAction: (payload) => `card/v2/public/benefits/${payload}`,

    saleViewList: "/card/v2/public/assign/sale/view/list",
    statusOption: "card/v2/public/assign/all/utm",

    profileRetry: `/card/v2/public/admin/retry/search`,

    viewSummary: `/card/v2/public/applications/view-over`,
    getStatusDisb: `/card/v2/public/applications/get-status-disbursement`,
    retryDetail: (payload) => `/card/v2/public/admin/retry/${payload}`,
    retryDelete: (payload) => `/card/v2/public/admin/retry/${payload}`,
    doRetryRa: (payload) =>
      `/card/v2/public/admin/retry/do-retry-ra/${payload}`,
    doRetry: (payload) => `/card/v2/public/admin/retry/do-retry/${payload}`,
    doRetryT24: (payload) =>
      `/card/v2/public/admin/retry/push-doc-to-t24/${payload}`,
    doRetryDocNFCBio: (payload) =>
      `/card/v2/public/admin/retry/do-retry-get-doc-nfc-bio/${payload}`,
    doRetryForce: (payload) =>
      `/card/v2/public/admin/retry/do-retry-force/${payload}`,
    doRetryBIO: (payload) =>
      `/card/v2/public/admin/retry/retry-submit-disb/${payload}`,
    closeAppManual: (payload) =>
      `/card/v2/public/applications/close-app-manual/${payload}`,
    viewAppInfo: (payload) =>
      `/card/v2/public/applications/view-app-info/${payload}`,
    csrTracking: (payload) => `/card/v2/public/csr_tracking/${payload}`,
    getAllocateDetail: (payload) =>
      `/card/v2/public/assign/sale/view/detail/${payload}`,
    submitAssignSale: `/card/v2/public/assign/sale`,
    virtualCCLimit: "/card/v2/public/virtual-cc-limit/filter",
    virtualCCLimitGetChannel: `/card/v2/public/virtual-cc-limit/channel`,
    virtualCCLimitAction: "/card/v2/public/virtual-cc-limit",
    virtualCCLimitDetail: (payload) =>
      `/card/v2/public/virtual-cc-limit/${payload}`,
    closeApp: (id) => `/card/v2/public/admin/close-app-cms/${id}`,
    getListCloseApp: (id) => `/card/v2/public/admin/find-app-by-id/${id}`,
    // ma tran the
    matrixCard: "/card/v2/public/api/matrix-card-ekyc",
    editMatrixCard: (payload) =>
      `/card/v2/public/api/matrix-card-ekyc/${payload}`,
    matrixCardDetail: (payload) =>
      `/card/v2/public/api/matrix-card-ekyc/${payload}`,
    scoreColor: `/card/v2/public/api/matrix-card-ekyc/list-score-color`,
    deleteMatrixCard: (payload) =>
      `/card/v2/public/api/matrix-card-ekyc/${payload}`,
    checkExitedMatrixCard: "/card/v2/public/api/matrix-card-ekyc/check-existed",
    updateSalesCode: "card/v2/public/assign/sale/update-sale-manual",
    doRetryFaceAuth: (payload) =>
      `/card/v2/public/admin/retry/retry-register-face-auth/${payload}`,
    doResetCountOtp: "card/v2/public/admin/reset-otp",
    resetOtpByAppId: "card/v2/public/admin/reset-otp/find-by-id",
    tpcData: "card/v2/public/tpc-data",
    tpcDataByLosId: (losId) => `card/v2/public/tpc-data/${losId}`,
    getMappingDocFolder: `/card/v2/public/api/document-type`,
    createMappingDocFolder: `/card/v2/public/api/document-type`,
    updateMappingDocFolder: (payload) =>
      `/card/v2/public/api/document-type/${payload}`,
    getCardManagementConfig: `/card/v2/public/sale/cards-new/view-list`,
    createCardManagementConfig: `/card/v2/public/sale/cards-new`,
    editCardManagementConfig: `/card/v2/public/sale/cards-new`,
    detailCardManagementConfig: (payload) =>
      `/card/v2/public/sale/cards-new/${payload}`,
    getListMatrixCardSale: "/card/v2/public/card-sale/get-all",
    getMatrixCardDetailSale: (payload) =>
      `/card/v2/public/card-sale/get-all?id=${payload}`,
    deleteMatrixCardSale: (payload) =>
      `/card/v2/public/card-sale/delete-matrix/${payload}`,
    createMatrixCardSale: "/card/v2/public/card-sale/add-matrix",
    updateMatrixCardSale: "/card/v2/public/card-sale/update-matrix",
    //sales
    getListCardSale: (payload) =>
      `/card/v2/public/card-sale/get-match-card?appId=${payload.appId}&newLimit=${payload.newLimit}`,
    submitWF3C1: "/card/v2/public/card-sale/selected-card",

    viewConfigReport: `card/v2/public/report/config-report/view-all`,
    detailConfigReport: (id) =>
      `card/v2/public/report/config-report/details/${id}`,
    addNewConfigReport: `card/v2/public/report/config-report/create`,
    updateConfigReport: (id) =>
      `card/v2/public/report/config-report/update/${id}`,
    deActiveConfigReport: (id) =>
      `card/v2/public/report/config-report/delete/${id}`,
  },
  common: {
    utmConfig: "card/v2/public/utm-config",
    deleteUtmConfig: (id) => `/card/v2/public/utm-config/deleted/${id}`,
    pendingStep: "/card/v2/public/pending-step",
    deletePendingStep: (id) => `/card/v2/public/pending-step/${id}`,
    getAllStep: "card/v2/public/pending-step/get-all-step",
    utmDaoConfig: "/card/v2/public/utm-dao-config",
    deleteUtmDaoConfig: (id) => `/card/v2/public/utm-dao-config/${id}`,
    updateBioCode: "/card/v2/public/admin/update-bio-code",
  },
  log: {
    fraudHistory: "/log/v2/public/fraud",
    getTransactionHistory: "/log/v2/public/action_log/find-all",
  },
  auth: {
    getMenuitem: `/auth/v2/public/menu-item`,
    login: `auth/v2/public/accounts/login`,
    getListMenu: `auth/v2/public/menu-item/list-menu`,
    switchRole: `auth/v2/public/accounts/concurrent-login`,
    getListOrgChart: `/auth/v2/public/products/get-by-user`,
    myProfile: "auth/v2/public/accounts/profile",
    refreshToken: `auth/v2/public/accounts/refresh_token`,
    permissions: `auth/v2/public/permissions`,
    permissionsAction: `auth/v2/public/permissions`,
    configPermission: "auth/v2/public/permission-config",
    confirmAuthorized: "auth/v2/public/accounts/profile/authorized",
    activeAuthorized: (payload) =>
      `auth/v2/public/accounts/account-concurrent/active/${payload}`,
    getListConcurrent: "auth/v2/public/accounts/profile/concurrent",
    getOrgChartListByAccountCode: `auth/v2/public/org-chart/filter-by-account`,
    getRoleByChartId: `auth/v2/public/org-chart/authorities-by-account?`,
    getProductList: `auth/v2/public/org-chart/products-by-account`,
    getAssignMember: `/auth/v2/public/accounts/members-by-manager`,
    account: "/auth/v2/public/accounts",
    getListAllBranch: "auth/v2/public/branch",
    branchAction: (payload) => `auth/v2/public/branch/${payload}`,
    getAllProduct: "auth/v2/public/products/find-all",
    getListUserByRole: `/auth/v2/public/accounts/all-child-by-role`,
    getAllRole: "auth/v2/public/authorities",
    roleAction: (payload) => `/auth/v2/public/authorities/${payload}`,
    createOrgChart: "auth/v2/public/org-chart",
    getDetailOrgChart: (payload) => `auth/v2/public/org-chart/${payload}`,
    editOrgChart: (payload) => `auth/v2/public/org-chart/${payload}`,
    deleteOrgChart: (payload) => `auth/v2/public/org-chart/${payload}`,
    getAllOrgChartList: "auth/v2/public/org-chart/search",
    getAuthRoleByChart: (payload) =>
      `auth/v2/public/org-chart/${payload}/authorities`,
    getAccountManager: `auth/v2/public/org-chart/account-manager`,
    getProductsChannelsOps: `auth/v2/public/org-chart/addition-info`,
    getOrgChartAuthorities: (payload) =>
      `auth/v2/public/org-chart/authorities/${payload}`,
    getAllUserByRole: "auth/v2/public/accounts/account-tree",
    getAccountConcurrent: `auth/v2/public/accounts/account-concurrent`,
    getAuthoritySelectList: `auth/v2/public/accounts/authorized`,
    getConcurrentList: `auth/v2/public/accounts/concurrent`,
    accountConcurrentAction: (payload) =>
      `/auth/v2/public/accounts/account-concurrent/${payload}`,
    activeUser: (activePath, payload) =>
      `/auth/v2/public/accounts/account-concurrent/${activePath.toLowerCase()}/${payload}`,
    getTeamCanMerge: `/auth/v2/public/accounts/teams-merge-able`,
    mergeTeam: (payload) => `/auth/v2/public/accounts/merge-team/${payload}`,
    activeAccount: (accountId) =>
      `auth/v2/public/accounts/${accountId}/active-account`,
    unlockAccount: (accountId) =>
      `/auth/v2/public/accounts/${accountId}/un-block`,
    lockAccount: (accountId) => `/auth/v2/public/accounts/${accountId}/block`,
    accountManager: "auth/v2/public/accounts/manager",
    createAccount: "auth/v2/public/accounts/v2/create",
    updateAccount: (payload) => `auth/v2/public/accounts/${payload}/v2/update`,
    getGroup: `auth/v2/public/groups`,
    groupAction: (payload) => `auth/v2/public/groups/${payload}`,
    getDefaultGroup: "auth/v2/public/groups/default",
    getMenuOption: "auth/v2/public/menu-item/presents",
    createProduct: "auth/v2/public/products",
    productAction: (payload) => `auth/v2/public/products/${payload}`,
    getMenuTab: "auth/v2/public/menu-tabs",
    createMenuTab: "auth/v2/public/menu-tabs",
    getDetailMenuTab: (payload) => `auth/v2/public/menu-tabs/${payload}`,
    updateMenuTab: (payload) => `auth/v2/public/menu-tabs/${payload}`,
    deleteMenuTab: (payload) => `auth/v2/public/menu-tabs/${payload}`,
    getMenuTypeForCreateMenu: "auth/v2/public/menu-tabs/types/available",
    getChildTabCode: "auth/v2/public/menu-tabs/child-tab-code/available",
    getApprovalLimit: "auth/v2/public/approve-config/filter",
    getChartByProductId: `auth/v2/public/org-chart/product`,
    getRoleLimit: `auth/v2/public/org-chart/roles`,
    createRoleLimit: `auth/v2/public/approve-config`,
    getApprovalLimitDetail: "auth/v2/public/approve-config/detail",
    rqGetListChart: "auth/v2/public/org-chart/admin-filter",
    detailAccountConcurrent: (id) =>
      `auth/v2/public/accounts/view-detail/account-concurrent/${id}`,
    branchFilter: `auth/v2/public/branch/filter`,
    chartByBranchIds: "auth/v2/public/org-chart/get-by-branch-ids",
    checkDuplicateBranch: "auth/v2/public/org-chart/check-duplicate-branch",
    getChannel: "auth/v2/public/channel",
    getAccountChild: `/auth/v2/public/org-chart/account-child`,
    checkPermissionApi: "auth/v2/public/accounts/check-permission",
  },
  core: {
    getChannelType: "core/v2/public/channel-types",
    getProvince: "core/v2/public/province",
    getAllProvince: "core/v2/public/province/find-all",
    getDistrict: `core/v2/public/district`,
    districtUpdate: (payload) =>
      `core/v2/public/district/district-update?code=${payload}`,
    getDistrictList: `core/v2/public/district/find-all`,
    getHolidays: "/core/v2/public/holidays",
    holidayAction: (payload) => `/core/v2/public/holidays/${payload}`,
    workingTime: "/core/v2/public/working-time",
    workingTimeAction: (payload) => `/core/v2/public/working-time/${payload}`,
    mappingCodeEKYC: "/core/v2/public/mapping-code-ekyc",
    mappingCodeEKYCAction: (payload) =>
      `/core/v2/public/mapping-code-ekyc/${payload}`,
    getGroupAction: "/core/v2/public/group-action",
    groupAction: (payload) => `/core/v2/public/group-action/${payload}`,
    configFraud: "/core/v2/public/fraud-config",
    fraudUTM: "core/v2/public/fraud-utm",
    fraudDeviceApp: "/core/v2/public/fraud-devices/application/",
    fraudDevice: "/core/v2/public/fraud-devices",
    fraudDistrictBan: "core/v2/public/fraud-address",
    getDistrictListByProvinceCode: `core/v2/public/district/find-all-by-province-code`,
    fraudGetNation: "core/v2/public/fraud-national-id",
    fraudPhone: "core/v2/public/fraud-phone",
    fraudEmail: "core/v2/public/fraud-email",
    fraudProvince: "core/v2/public/fraud-province",
    fraudIpDetail: "/core/v2/public/fraud-ips/application",
    fraudIp: "/core/v2/public/fraud-ips",
    fraudBlacklistVKYC: "/core/v2/public/fraud-vkyc",
    fraudBlacklistVKYCDetail: (fraudVkycId) =>
      `core/v2/public/fraud-vkyc-application/${fraudVkycId}`,
    fraudBlacklistCode: `core/v2/public/fraud-vkyc/code`,
    getAllDeliveryBrand: "core/v2/public/delivery-branch/find-all",
    getSelections: "core/v2/public/selections",
    getSelectionsFindByCategories: (payload) =>
      `/core/v2/public/selections/find-by-categories?nameCategory=${payload}`,
    deliveryBranch: "core/v2/public/delivery-branch",
    riskCheckPCB: "/core/v2/public/pcb",
    provinceSellingArea: "/core/v2/public/province/selling-area",
    wardSellingArea: "/core/v2/public/wards/selling-area",
    getWards: "/core/v2/public/wards",
    getAllWards: `core/v2/public/wards/get-all`,
    assignProduct: `/core/v2/public/distribute-controller/all-app`,
    profileDistribute: "/core/v2/public/distribute-controller",
    getCompany: "/core/v2/public/company",
    systemConfig: "/core/v2/public/config",
    systemConfigAll: "/core/v2/public/config/all",
    mappingPromotionCodeProductSubProductFindAll: `core/v2/public/mapping-promotion-code-product-sub-product/find-all`,
    mappingPromotionCodeProductSubProduct:
      "core/v2/public/mapping-promotion-code-product-sub-product",
    mappingPromotionCodeProductSubProductGroup:
      "/core/v2/public/mapping-promotion-code-product-sub-product/product-group",
    mappingPromotionCodeProductSubProductSubProduct:
      "core/v2/public/mapping-promotion-code-product-sub-product/sub-product",
    createCategory: "/core/v2/public/property",
    getCategoryOption:
      "core/v2/public/property/category?property-type=CATEGORY",
    saleAreaConfig: "/core/v2/public/sale-area-config",
    getProvinceSellingArea: "/core/v2/public/province/selling-area",

    // form
    getFormList: "/core/v2/public/api/component-config/view-list",
    createForm: "/core/v2/public/api/component-config",
    formAction: (id) => `/core/v2/public/api/component-config/${id}`,
    getSelectionList: "core/v2/public/selections/category",
    getSelectionByCategory: "core/v2/public/selections/find-value-with-name",
    getDistributionList: "core/v2/public/distribution/view-list-distribution",
    createDistribution: "core/v2/public/distribution/create-distribution",
    updateDistribution: (id) =>
      `core/v2/public/distribution/update-distribution/${id}`,
    viewDistributionDetail: (id) =>
      `core/v2/public/distribution/view-distribution-detail/${id}`,
    getListConfigField: "core/v2/public/api/component-config/flat",
    getBasicInfoConfig: "core/v2/public/api/screen-config/get-form-basic-info",
    getListConfigForm: "core/v2/public/api/screen-config",
    getDetailConfigForm: (id) => `core/v2/public/api/screen-config/${id}`,
    getCountries: `core/v2/public/countries`,
    deleteConfigForm: (id) => `core/v2/public/api/screen-config/${id}`,
    // default value mapping
    getDefaultValues: "/core/v2/public/api/default-value/view-list",
    getFormBasicInfo: "/core/v2/public/api/screen-config/get-form-basic-info",
    getDetailDefaultValue: (payload) =>
      `/core/v2/public/api/default-value/${payload}`,
    createConfigDefaultValue: "/core/v2/public/api/default-value",
    getDefaultValuesMapping:
      "/core/v2/public/api/default-values-mapping/view-list",
    getDetailDefaultValuesMapping: (payload) =>
      `/core/v2/public/api/default-values-mapping/${payload}`,
    createConfigDefaultValuesMapping:
      "/core/v2/public/api/default-values-mapping",
    getAllPartnerConfig: `core/v2/public/partner-config/view-all`,
    createPartnerConfig: `core/v2/public/partner-config/create`,
    updatePartnerConfig: (id) => `core/v2/public/partner-config/update/${id}`,
    deletePartnerConfig: (id) => `core/v2/public/partner-config/delete/${id}`,
    getConfigSubProduct: "/core/v2/public/api/sub-product-config-new/view-list",
    detailConfigSubProduct: (payload) =>
      `/core/v2/public/api/sub-product-config-new/detail?keyNum=${payload}`,
    createConfigSubProduct: "/core/v2/public/api/sub-product-config-new",
    editConfigSubProduct: (payload) =>
      `/core/v2/public/api/sub-product-config-new?keyNum=${payload}`,
    deleteConfigSubProduct: (payload) =>
      `/core/v2/public/api/sub-product-config-new?keyNum=${payload}`,
    getCustomerConfirmType: "/core/v2/public/customer-confirm-type/get-all",
    createCustomerConfirmType: "/core/v2/public/customer-confirm-type/create",
    updateCustomerConfirmType: (payload) =>
      `/core/v2/public/customer-confirm-type/update/${payload}`,
    detailCustomerConfirmType: (payload) =>
      `/core/v2/public/customer-confirm-type/get-by-id/${payload}`,
    deleteCustomerConfirmType: (payload) =>
      `/core/v2/public/customer-confirm-type/delete/${payload}`,
    disburseVKYC: "core/v2/public/config-video-call",
    getProductGroup: `/core/v2/public/api/api/product-group`,
    createProductGroup: `/core/v2/public/api/product-group`,
    deleteProductGroup: (payload) =>
      `/core/v2/public/api/product-group?code=${payload}`,
    detailProductGroup: (payload) =>
      `/core/v2/public/api/product-group/details?code=${payload}`,
    getSubProductGroup: `/core/v2/public/api/sub-product-group`,
    createSubProductGroup: `/core/v2/public/api/sub-product-group`,
    deleteSubProductGroup: (payload) =>
      `/core/v2/public/api/sub-product-group?code=${payload}`,
    detailSubProductGroup: (payload) =>
      `/core/v2/public/api/sub-product-group/details?code=${payload}`,
    getConfigPromotionCodeFilter:
      "/core/v2/public/config-filter-promotion-code",
    detailConfigPromotionCodeFilter: (payload) =>
      `/core/v2/public/config-filter-promotion-code/${payload}`,
    createConfigPromotionCodeFilter:
      "/core/v2/public/config-filter-promotion-code",
    getConfigDeactiveCard: "/core/v2/public/api/deactive-card/list",
    createConfigDeactiveCard: "/core/v2/public/api/deactive-card/create-update",
    getDetailDeactiveCard: (payload) =>
      `/core/v2/public/api/deactive-card/detail?id=${payload}`,
    deleteDeactiveCard: (payload) =>
      `/core/v2/public/api/deactive-card/delete?id=${payload}`,
    getConfigBankRepresentativeSignatureBank:
      "/core/v2/public/api/bank-representative-signature",
    getDetailConfigBankRepresentativeSignatureBank: (payload) =>
      `/core/v2/public/api/bank-representative-signature/${payload}`,
    creteConfigBankRepresentativeSignatureBank:
      "/core/v2/public/api/bank-representative-signature",
    getDetailConfigBySubID: (subId) => {
      if (subId) {
        return `core/v2/public/api/sub-product-config-new/get-all-component?subId=${subId}`;
      }
      return `core/v2/public/api/sub-product-config-new/get-all-component`;
    },
  },
  gateway: {
    uploadAvatar: "gateway/v2/public/storage-file/upload-avatar",
    downloadSingleFile: `/gateway/v2/public/storage-file/download`,
    downloadFile: `/gateway/v2/public/storage-file/download-all`,
    uploadFile: "/gateway/v2/public/storage-file/upload-file",
    getAllServiceType: "gateway/v2/public/log/get-all-service",
    downloadFileTpc: "/gateway/v2/public/storage-file/download-all-tpc",
    upLoadListFile: "/gateway/v2/public/storage-file/upload-list-file",
    deleteListFile: "/gateway/v2/public/storage-file/delete-document",
    checkVPOUser: (appId, username) =>
      `gateway/v2/public/check-username-vpo?appId=${appId}&username=${username}`,
    uploadFileCommon: `gateway/v2/public/storage-file/upload-common`,
    getFile: `gateway/v2/public/storage-file/get-file`,
  },
  upl: {
    reSubmitDisb: (payload) =>
      `/upl/v2/public/applications/re-submit-disb/${payload}`,
    doRetryBIO: (payload) =>
      `/upl/v2/public/applications/re-submit-disb-bio/${payload}`,
  },
  hhb: {
    downloadFile: "hhb/v2/public/partner-lead-upload/download-template",
    uploadFile: "hhb/v2/public/partner-lead-upload/upload-lead",
    getUploadHistory: "hhb/v2/public/partner-lead-upload/history",
    getUploadFail: "hhb/v2/public/partner-lead-upload/fail",
    getUploadSuccess: "hhb/v2/public/partner-lead-upload/success",
    getPartnerAvailable: "/hhb/v2/public/partner-configs/partner-available",
    closeLeadList: "hhb/v2/public/partner-lead-store",
    closeLead: "hhb/v2/public/partner-lead-store/close-leads",
  },
  ccPartner: {
    viewOver: "partner/v2/public/admin/applications/view-over",
    viewList: "partner/v2/public/admin/applications/view-list",
    viewDetail: (id) => `partner/v2/public/application/detail/${id}`,
    partnerCodeList: `partner/v2/public/admin/partner-code/list`,
    partnerCodeAction: (id) => `partner/v2/public/admin/partner-code/${id}`,
    addPartnerCode: `partner/v2/public/admin/partner-code`,
    addCardMatrix: `partner/v2/public/admin/cards-matrix`,
    cardMatrixAction: (id) => `partner/v2/public/admin/cards-matrix/${id}`,
    cardMatrixList: "partner/v2/public/admin/cards-matrix/list",
    getSelectionList: "partner/v2/public/lov/get-info",
    getPartnerCodeList: "partner/v2/public/admin/constants/partner-code",
    export: `partner/v2/public/admin/export`,
    retrySearch: `partner/v2/public/admin/retry/search`,
    retryDelete: (id) => `partner/v2/public/admin/retry/${id}`,
    doRetryRa: (payload) =>
      `partner/v2/public/admin/retry/do-retry-ra/${payload}`,
    doRetryOA: (payload) =>
      `partner/v2/public/admin/retry/do-retry-oa/${payload}`,
    doRetry: (payload) => `partner/v2/public/admin/retry/do-retry/${payload}`,
    doRetryForce: (payload) =>
      `partner/v2/public/admin/retry/do-retry-force/${payload}`,
    downloadFileDocument: "partner/v2/public/download-file",
    closeAppCms: "partner/v2/public/admin/application/close-app-cms",
    closeAppManual: "partner/v2/public/admin/application/close-app-manual",
    getListCloseApp: (id) =>
      `partner/v2/public/admin/applications/view-app-info/${id}`,
    csrTracking: (id) => `partner/v2/public/admin/csr-tracking/${id}`,
    saleLocation: `partner/v2/public/admin/sale-location`,
    getListCompany: `partner/v2/public/admin/find-company`,
    companyInformation: `partner/v2/public/admin/company`,
    getStatusDisb: `partner/v2/public/admin/get-status-disbursement`,
  },
  bnpl: {
    viewListApplication: "/bnpl/v2/public/admin/view-list",
    viewAppInfo: (payload) => `/bnpl/v2/public/admin/details?id=${payload}`,
    doRetry: (payload) =>
      `/bnpl/v2/public/bnpl-retry-onboarding?appId=${payload}`,
    retryCloseLos: (payload) =>
      `/bnpl/v2/public/bnpl-retry-close-app?appId=${payload}`,
  },
  sales: {
    login: "/auth/v2/public/accounts/sale/login",
    saleGetView: "unsecure/v2/public/sale-application/sale-filter",
    viewAllApplication: "/unsecure/v2/public/sale-admin/get-apps",
    getChartByAccountCode: "unsecure/v2/public/org-chart/account-code",
    createApplication: "unsecure/v2/public/sale-application/create-app",
    ConfigCustType: "/unsecure/v2/public/customer-type/all",
    updateApplication: (id) =>
      `/unsecure/v2/public/sale-application/update-app/${id}`,
    getIdSearchAction: "auth/v2/public/org-chart/id-search",
    getApplicationDetail: (id) =>
      `unsecure/v2/public/sale-application/detail/${id}`,
    approvalApplication: (id) =>
      `/unsecure/v2/public/sale-application/approve/${id}`,
    submitApplication: (id) =>
      `/unsecure/v2/public/sale-application/submit-app/${id}`,
    getConfigForm: (subName, workForm) =>
      `core/v2/public/api/screen-config/get-by-sub-and-work-form?subName=${subName}&workForm=${workForm}`,
    createForm: `/unsecure/v2/public/customer-universal/init-cus`,
    configCustTypeDetail: (payload) =>
      `/unsecure/v2/public/customer-type/${payload}`,
    editConfigCustType: "/unsecure/v2/public/customer-type",
    getLeadDetailApplication: (id) =>
      `/unsecure/v2/public/customer-universal/detail/${id}`,
    getConfigCodeMSALOS: "/unsecure/v2/public/action-config/filter",
    createConfigCodeMSALOS: "/unsecure/v2/public/action-config",
    editConfigCodeMSALOS: (id) => `/unsecure/v2/public/action-config/${id}`,
    csrTracking: (id) => `card/v2/public/csr_tracking?cusId=${id}`,
    showListOfferWF1: (id) =>
      `unsecure/v2/public/customer-universal/get-info?cusId=${id}`,
    checkDCBan: (id) => `core/v2/public/district/${id}`,
    getConfigCopyCustomer: "/unsecure/v2/public/sale-admin/view-all",
    getConfigAllFieldCopyCustomer: "/unsecure/v2/public/sale-admin/view-field",
    updateConfigCopyCustomer: (payload) =>
      `/unsecure/v2/public/sale-admin/update?configType=${payload}`,
    createForm1C2: "unsecure/v2/public/customer-universal/save-wf1c2",
    copyKH: (leadId, appId) =>
      `unsecure/v2/public/customer-universal/copy/${leadId}?appId=${appId}`,
    getDocsForCus: (id) =>
      `unsecure/v2/public/customer-universal/get-document-for-cus/${id}`,
    getListDocsForCus: "unsecure/v2/public/customer-universal/list-document",
    deleteDocs: `unsecure/v2/public/customer-universal/delete-document`,
    uploadDocs: `unsecure/v2/public/customer-universal/upload-document`,
    getListConfigRankShopee: "/unsecure/v2/public/shopee-config/filter",
    createConfigRankShopee: "/unsecure/v2/public/shopee-config",
    detailConfigRankShopee: (payload) =>
      `/unsecure/v2/public/shopee-config/${payload}`,
    checkAppPA: (id) =>
      `unsecure/v2/public/application-cc-sale/get-info-pa/${id}`,
    submitWF2C1: `unsecure/v2/public/application-cc-sale/submit-wf2c1`,
    getDetailApplication: (id) =>
      `unsecure/v2/public/application-cc-sale/details/${id}`,
    putPAChoice: ({
      id,
      limit,
      promotionCode,
      amountValidation,
      subCode,
      isPicked,
    }) =>
      `unsecure/v2/public/application-cc-sale/save-pa-program/${id}?limit=${limit}&promotionCode=${promotionCode}&amountValidation=${amountValidation}&subCode=${subCode}&isPicked=${isPicked}`,
    getOfferSub: (id) => `unsecure/v2/public/get-sub-for-app/${id}`,
    getOfferSubProduct: (id) => `unsecure/v2/public/get-sub-for-app/${id}`,
    pickSubProduct: (id, subCode, subId) =>
      `unsecure/v2/public/application-cc-sale/save-sub-at-work-form-2c1/${id}?subCode=${subCode}&program=${subId}`,
    getInfo2c2: (id) => `unsecure/v2/public/get-info-at-2c2/${id}`,
    submitData2c2: `unsecure/v2/public/application-cc-sale/submit-wf2c2`,
    checkCASA: (id, kycMethod) =>
      `unsecure/v2/public/check-casa/${id}?kycMethod=${kycMethod}`,
    submitData3c2: `unsecure/v2/public/submit-wf-3c2`,
    cancelApp: (id) =>
      `unsecure/v2/public/application-cc-sale/cancel-app?appId=${id}`,
    smSubmitR3: (id) => `unsecure/v2/public/sm-confirm-r3/${id}`,
    smSubmitToLos: (id) => `unsecure/v2/public/sm-submit-doc/${id}`,
    smCancelApp: (id, reason) =>
      `unsecure/v2/public/application-cc-sale/cancel-app-by-sale-manager?appId=${id}&reason=${reason}`,
    smReqUpdateDocsApp: (id, reason) =>
      `unsecure/v2/public/application-cc-sale/request-update-document?appId=${id}&reason=${reason}&note=${reason}`,
    smConfirmApp: (id) => `unsecure/v2/public/sm-confirm-app/${id}`,
    saleNeedUpdateCif: (id) => `unsecure/v2/public/need-update-cif/${id}`,
    getAppFromLead: (leadId) =>
      `unsecure/v2/public/view-app-from-lead?leadId=${leadId}`,
    saleSubmitDocApp: (id) => `unsecure/v2/public/sale-resubmit-to-sm/${id}`,
    getCardIssuance: `unsecure/v2/public/dash-board/card-issuance/info`,
    getKycHistory: (id, isLead) =>
      `unsecure/v2/public/kyc-history?id=${id}&isLead=${isLead}`,
    checkStatusLOS: `unsecure/v2/public/los/check-status`,
    cancelLead: (id) =>
      `unsecure/v2/public/customer-universal/cancel-lead/${id}`,
    saleDraft: (id) => {
      if (!id) {
        return `unsecure/v2/public/application-sale-draft/create`;
      }
      return `unsecure/v2/public/application-sale-draft/create?customerUniversal=${id}`;
    },
  },
  unsecure: {
    dashboardCardInfo: "unsecure/v2/public/dash-board/card-info",
    getCardIssuance: `unsecure/v2/public/dash-board/card-info/filter`,
    getSystemResult: "/unsecure/v2/public/application-cc-sale/details-popup",
    getFunnelChart: "unsecure/v2/public/dash-board/card-profile/funnel",
    getListNotify: "unsecure/v2/public/notify/posts/user",
    saveBookmarkNotify: (id) =>
      `unsecure/v2/public/notify/posts/save-post/${id}`,

    // notify config
    getNotifyConfig: "unsecure/v2/public/notify/posts/filter",
    saveDraft: "unsecure/v2/public/notify/posts",
    updateNotify: (id) => `unsecure/v2/public/notify/posts/${id}`,
    getDetailNotify: (id) => `unsecure/v2/public/notify/posts/detail/${id}`,
    getDetailNotifyConfig: (id) =>
      `unsecure/v2/public/notify/admin/posts/detail/${id}`,
    registerFcmToken: "unsecure/v2/public/api/user-fcm-token",
    getUnreadNotify: "unsecure/v2/public/notify/posts/user/count-post",
    deActiveNotify: (id) => `unsecure/v2/public/notify/posts/inactive/${id}`,
    approveNotify: (id) => `unsecure/v2/public/notify/posts/approve/${id}`,
    reSendNotify: (id) => `unsecure/v2/public/notify/posts/resend/${id}`,
    getAppNotify: "/unsecure/v2/public/view-notify-app",
    retrySale: `unsecure/v2/public/admin/retry/search`,
    retryDetail: (payload) => `/unsecure/v2/public/admin/retry/${payload}`,
    retryDelete: (payload) => `/unsecure/v2/public/admin/retry/${payload}`,
    doRetry: (payload) => `/unsecure/v2/public/admin/retry/do-retry/${payload}`,
    doRetryForce: (payload) =>
      `/unsecure/v2/public/admin/retry/do-retry-force/${payload}`,
    homePageForSale: "/unsecure/v2/public/dash-board/home-page-for-sale",
    insertConfigKpiTarget:
      "unsecure/v2/public/sale-admin/insert-config-kpi-target",
    updateConfigKpiTarget: (id) =>
      `unsecure/v2/public/sale-admin/update-config-kpi-target/${id}`,
    viewAppSm: `unsecure/v2/public/view-app-sm`,
    overviewSm: `unsecure/v2/public/app-overview`,
    trendBusiness: `unsecure/v2/public/trend-business`,
    effectiveBusiness: `unsecure/v2/public/effective-business`,
    getStatusDisb: `unsecure/v2/public/applications/get-status-disbursement`,
    // banner
    getListBanner: "/unsecure/v2/public/banner-config/list",
    bannerAction: "/unsecure/v2/public/banner-config",
    bannerConfig: `unsecure/v2/public/banner-config/list-home-page`,
    checkButtonFilterApprove:
      "unsecure/v2/public/sale-admin/check-permission-for-filter",
  },
  cardLead: {
    TS: {
      filterCardLead:
        "/card-lead-service/public/v1/trusting-social/filter-card-lead",
      filterFeedbackCardLead:
        "/card-lead-service/public/v1/trusting-social/filter-feedback-card-lead",
      detailCardLead:
        "/card-lead-service/public/v1/trusting-social/card-lead-details",
      exportFile: "/card-lead-service/public/v1/export-excel/card-lead-ts",
    },
  },
};

export default apiUrls;
