import {
  USER_INFO_NAME,
  IL_USER_SELECTED_ORGCHART,
  IL_LIST_ROLE,
  IL_MENU_USER,
  IL_MENU_TYPE
} from "utils/constants";

export default {
  auth: {
    id: () => {
      try {
        return JSON.parse(localStorage.getItem(USER_INFO_NAME))?.id || "";
      } catch {
        return "";
      }
    },
    name: () => {
      try {
        const userInfo = JSON.parse(localStorage.getItem(USER_INFO_NAME)) || {};
        return userInfo?.name || "";
      } catch {
        return "";
      }
    },
    email: () => {
      try {
        const userInfo = JSON.parse(localStorage.getItem(USER_INFO_NAME)) || {};
        return userInfo?.email || "";
      } catch {
        return "";
      }
    },
    role: () => {
      return (
        localStorage.getItem(IL_LIST_ROLE) ||
        sessionStorage.getItem(IL_LIST_ROLE)
      );
    },

    info: () => {
      try {
        return JSON.parse(
          localStorage.getItem(USER_INFO_NAME) ||
            sessionStorage.getItem(USER_INFO_NAME)
        );
      } catch {
        return {};
      }
    },
    orgChartId: () => {
      return (
        localStorage.getItem(IL_USER_SELECTED_ORGCHART) ||
        sessionStorage.getItem(IL_USER_SELECTED_ORGCHART)
      );
    },
    teacherCode: () => {
      try {
        return JSON.parse(localStorage.getItem(USER_INFO_NAME))?.teacherCode || "";
      } catch {
        return "";
      }
    },
  },
  menu: {
    set: val =>{
      const valStringIfy = JSON.stringify(val);
      localStorage.setItem(IL_MENU_USER, valStringIfy)
      return;
    },
    get: () => {
      try {
        const menuByUser = localStorage.getItem(IL_MENU_USER);
        return menuByUser ? JSON.parse(menuByUser) : [];
      } catch {
        return [];
      }
    },
    type: () => localStorage.getItem(IL_MENU_TYPE),
  }
}