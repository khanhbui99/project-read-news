import Fuse from "fuse.js";
import debounce from 'lodash/debounce';  // Import debounce
import size from 'lodash/size'
import { useRef, useEffect } from "react";

const options = {
  keys: ['name'],
  includeScore: true,
  threshold: 0.2,
  useExtendedSearch: true
};

const useDistributedFuseSearch = (data = [], option, shardSize = 50000) => {
  const fuseShardRef = useRef([]);

  /**
   * useEffect hook initializes Fuse.js instances for each data shard when the data array changes.
   * It also splits the data into smaller shards to improve search performance for large datasets.
   */
  useEffect(() => {
    if(size(data)) {
      const shards = []; // Split the data into "shards" (subsets) for more efficient search when data is large

      // Create shards of data based on the specified shard size
      for (let i = 0; i < size(data); i += shardSize){
        shards.push(data.slice(i, i + shardSize)); // Slice the data into chunks
      }
  
      // Initialize Fuse.js for each shard with the provided options
      fuseShardRef.current = shards.map(
        (shard) => new Fuse(shard, { ...options, ...option }) // Merge default options with any custom options passed in
      );
    }

    // Cleanup function to reset the fuseShardRef when the component unmounts or the data changes
    return () => {
      fuseShardRef.current = [];
    };
  }, [data]);

  /**
   * searchAcrossShards performs a search across all shards (Fuse.js instances).
   * It returns the combined results of searching each shard in parallel.
   * 
   * @param {string} query - The search query to search for across the shards.
   * @returns {Array} - The combined results from all the shards.
   */
  const searchAcrossShards = async (query) => {
    if (fuseShardRef.current.length > 0 && query) {
      // Run search on all shards in parallel
      const results = await Promise.all(fuseShardRef.current.map(fuse => {
        return fuse.search(query) // Search each shard for the query
      }));

      // Flatten the results (because each shard search returns an array of results)
      const combinedResults = results.flat().map((result) => result.item);

      // Return the combined results from all shards
      return combinedResults;
    }

    return []; // Return an empty array if no shards or query is provided
  };

  /**
   * debouncedSearch is a debounced version of the search function.
   * It delays the execution of the search until the user stops typing for a certain period.
   * 
   * @param {string} query - The search query to search for.
   * @param {function} cb - The callback to return the results of the search.
   */
  const debouncedSearch = useRef(debounce(async (query, cb) => {
    // Perform the search and then call the provided callback with the results
    const results = await searchAcrossShards(query);

    return cb(results); // Callback with the search results
  }, 300)).current;


  /**
   * onSearchQuery is the function exposed to the component that performs the debounced search.
   * It waits for the debounced search results and returns the results once the debounced search is completed.
   * 
   * @param {string} query - The search query to perform the search.
   * @returns {Promise} - A promise that resolves with the search results.
   */
  const onSearchQuery = async (query) => {
    return new Promise((resolve) => {
      return debouncedSearch(query, res =>  resolve(res))  
    });
  };

  return {
    onSearchQuery,
  };
};

export default useDistributedFuseSearch;
