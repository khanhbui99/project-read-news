import { useMemo } from 'react';
import { findComponentInTree } from 'utils/helpers';
import { useOneState } from 'utils/hooks/useRedux';

const useMenuByComponent = (componentName) => {
  const menuRouter = useOneState('global', 'menuRouter');
  const menuType = useOneState('global', 'menuType');

  const menu = useMemo(() => {
    if (!menuType || !menuRouter) return null;
    const menu = menuRouter[menuType] || [];
    return findComponentInTree(menu, componentName) || {};
  }, [menuRouter, menuType]);

  return menu
}

export default useMenuByComponent;