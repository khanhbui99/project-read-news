import { useState, useRef } from "react";

export const useFileUpload = ({ multiple = false, validExtensions = [] }) => {
  const refFileInput = useRef(null);
  const [files, setFiles] = useState([]);
  const [dragOver, setDragOver] = useState(false);

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    addFiles(droppedFiles);
  };

  const handleFileInput = (e) => {
    const selectedFiles = Array.from(e.target.files);
    addFiles(selectedFiles);
    refFileInput.current.value = null; // reset input
  };

  const addFiles = (newFiles) => {
    const validFiles = newFiles.filter((file) => {
      const extension = "." + file.name.split(".").pop().toLowerCase();
      return validExtensions.includes(extension);
    });

    // loại bỏ file trùng (theo tên + size)
    const uniqueFiles = validFiles.filter(
      (file) => !files.some((f) => f.name === file.name && f.size === file.size)
    );

    if (multiple) {
      setFiles((prev) => [...prev, ...uniqueFiles]);
    } else {
      setFiles(uniqueFiles.length > 0 ? [uniqueFiles[0]] : []);
    }
  };

  const removeFile = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  return {
    refFileInput,
    files,
    dragOver,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    handleFileInput,
    addFiles,
    removeFile,
    multiple,
  };
};
