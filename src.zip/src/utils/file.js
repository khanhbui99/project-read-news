import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { TOKEN_NAME } from "utils/constants";

const VIEWABLE_EXTENSIONS = ["pdf", "png", "jpg", "jpeg", "gif", "webp", "bmp"];

export const getFileNameFromPath = (path = "") => {
  const parts = String(path).split("/");
  return decodeURIComponent(parts[parts.length - 1] || "file");
};

export const mapListPathToFiles = (listPath = []) => {
  if (!Array.isArray(listPath)) return [];

  return listPath
    .map((item) => {
      if (typeof item === "string") {
        return { name: getFileNameFromPath(item), path: item };
      }

      const path = item?.path || item?.fileUrl || item?.url || "";
      return {
        name: item?.fileName || item?.name || getFileNameFromPath(path),
        path,
      };
    })
    .filter((file) => file.path);
};

const getFileExtension = (fileName = "") => {
  const parts = String(fileName).split(".");
  return parts.length > 1 ? parts.pop().toLowerCase() : "";
};

const triggerBlobDownload = (blob, fileName) => {
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = blobUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(blobUrl);
};

export const fetchFileByPath = async (path) => {
  if (!path) {
    throw new Error("Không tìm thấy file");
  }

  const fileName = getFileNameFromPath(path);

  if (/^https?:\/\//i.test(path)) {
    const response = await fetch(path, {
      headers: {
        Authorization: localStorage.getItem(TOKEN_NAME) || "",
      },
      method: "POST"
    });

    if (!response.ok) {
      throw new Error("Không thể tải file");
    }

    return { blob: await response.blob(), fileName };
  }

  const blob = await ApiReq.fetchBlob({
    url: urlApi.managementService.s3.download,
    method: "POST",
    params: { path },
  });

  return { blob, fileName };
};

export const downloadFileByPath = async (path, fileName) => {
  const { blob, fileName: defaultName } = await fetchFileByPath(path);
  triggerBlobDownload(blob, fileName || defaultName);
};

export const viewFileByPath = async (path, fileName) => {
  const { blob, fileName: defaultName } = await fetchFileByPath(path);
  const name = fileName || defaultName;
  const extension = getFileExtension(name);
  const blobUrl = URL.createObjectURL(blob);

  if (VIEWABLE_EXTENSIONS.includes(extension)) {
    window.open(blobUrl, "_blank", "noopener,noreferrer");
    return;
  }

  triggerBlobDownload(blob, name);
  URL.revokeObjectURL(blobUrl);
};
