import { createBrowserHistory } from 'history';

import { PUBLIC_PATH } from './constants';
const history = createBrowserHistory({ basename: PUBLIC_PATH });
export default history;
