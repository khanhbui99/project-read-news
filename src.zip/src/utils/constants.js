import { VPB_THEMES } from "./configs";

export const VERSION = import.meta.env.VERSION;
export const NODE_ENV = import.meta.env.VITE_NODE_ENV;
export const ROOT_URI = import.meta.env.VITE_ROOT_URI;
export const PUBLIC_PATH = import.meta.env.VITE_PUBLIC_PATH;
export const FIREBASE_API_KEY = import.meta.env.VITE_FIREBASE_API_KEY;
export const FIREBASE_AUTH_DOMAIN = import.meta.env.VITE_FIREBASE_AUTH_DOMAIN;
export const FIREBASE_PROJECT_ID = import.meta.env.VITE_FIREBASE_PROJECT_ID;
export const FIREBASE_STORAGE_BUCKET = import.meta.env
  .VITE_FIREBASE_STORAGE_BUCKET;
export const FIREBASE_MESSAGING_SENDER_ID = import.meta.env
  .VITE_FIREBASE_MESSAGING_SENDER_ID;
export const FIREBASE_APP_ID = import.meta.env.VITE_FIREBASE_APP_ID;
export const FIREBASE_MEASUREMENT_ID = import.meta.env
  .VITE_FIREBASE_MEASUREMENT_ID;
export const FIREBASE_KEY_PAIR = import.meta.env.VITE_FIREBASE_KEY_PAIR;
export const LINK_VIEW_DOC = import.meta.env.VITE_LINK_VIEW_DOC;

export const API_TIMEOUT = String(1 * 60 * 60 * 1000); // 1 hour
export const API_TIMEOUT_PCB = "3600000";
export const RESTART_ON_REMOUNT = "@@saga-injector/restart-on-remount";
export const DAEMON = "@@saga-injector/daemon";
export const ONCE_TILL_UNMOUNT = "@@saga-injector/once-till-unmount";

export const responseCode = {
  "IL-200": "LMS-200",
  "IL-4003": "LMS-4003",
};

export const TOKEN_NAME = "LMS_ADMIN_TOKEN";
export const REFRESH_TOKEN_NAME = "LMS_REFRESH_ADMIN_TOKEN";
export const ACCOUNT_CODE = "LMS_ACCOUNT_CODE";
export const IL_LIST_ROLE = "LMS_LIST_ROLE";
export const IL_MENU_TYPE = "LMS_MENU_TYPE";
export const IL_MENU_USER = "LMS_MENU_USER";
export const IL_MENU_TYPE_PARENT = "LMS_MENU_TYPE_PARENT";
export const USER_INFO_NAME = "USER_INFO";
export const IL_USER_SELECTED_ORGCHART = "LMS_USER_SELECTED_ORGCHART";
export const SALES = "SALES";
export const COMMON_ROUTE = "COMMON";
export const CC_SALE_ROUTE = "CC_SALE";
export const IL_SALES_PRODUCT_TYPE = "LMS_SALES_PRODUCT_TYPE";
export const MAX_STUDENTS = 99999999;

export const allOp = {
  id: "all",
  code: "all",
  value: "all",
  text: "-- Tất cả --",
  term: "-- Tất cả --",
  name: "-- Tất cả --",
  label: "-- Tất cả --",
  status: "-- Tất cả --",
  source: "-- Tất cả --",
  category: "-- Tất cả --",
  campaign: "-- Tất cả --",
  group_name: "-- Tất cả --",
};

export const adminPrefix = () => `/portal`;
// `/portal/${localStorage.getItem(IL_MENU_TYPE) || menu}`;
export const sysPrefix = "/sys";
export const authPrefix = "/auth";

export const colAction = { name: "Action", width: 1, align: "right" };

export const DateFormat = "YYYY-MM-DD";
export const DateFormat2 = "DD-MM-YYYY";
export const DateFormat3 = "YYYY-MM-DDTHH:mm:00";
export const HourFormat = "HH:mm:00";
export const DateFormat4 = "DD/MM/YYYY";

export const maxWidth = 980;

export const rem = {
  hd: 13,
  fhd: 14,
  tablet: 12,
};

export const addPath = "/add";
export const editPath = "/edit";
export const detailPath = "/detail";
export const thirty = 30 * 60 * 60 * 24 * 1000; // 1 month
export const flowFilterDropdown = [
  {
    value: "VPBANK",
    label: "VPBANK",
  },
  {
    value: "PARTNER",
    label: "PARTNER",
  },
];
export const partnerListSearch = [
  { value: "ALL", label: "Tất cả" },
  { value: "FTEL", label: "FTEL" },
];

export const PROFILE_DETAIL_URL = {
  ccPartner: "ProfileDetailCCPartner",
  ccBundle: "ProfileDetailCCBundle",
  uplBundle: "ProfileDetailUPLBundle",
};

export const MODE_FILTER = {
  CUSTOM: "CUSTOM",
  INPUT: "INPUT_FIELD",
  DATE_PICKER: "DATE_PICKER",
  SELECT_SEARCH: "SELECT_SEARCH",
  DYNAMIC_SEARCH_TEXT: "DYNAMIC_SEARCH_TEXT",
};

export const STATUS = {
  ACTIVE: "ACTIVE",
  INACTIVE: "INACTIVE",
};
export const FORM_MODE = {
  CREATE: "create",
  EDIT: "edit",
  VIEW: "view",
};

export const GENERATION_MODE = [
  {
    label: "Tạo tự động",
    value: "AUTO",
    backgroundColor: VPB_THEMES.colors.blue,
    textColor: VPB_THEMES.colors.white,
  },
  {
    label: "Tạo thủ công",
    value: "MANUAL",
    backgroundColor: VPB_THEMES.colors.gray[300],
    textColor: VPB_THEMES.colors.white,
  },
];

export const TYPE_QUESTION_FORM = {
  ESSAY: {
    name: "Tự luận",
    value: "ESSAY",
  },
  CHOICE: {
    name: "Trắc nghiệm",
    value: "CHOICE",
  },
};


export const STATUS_EXCELLENT = {
  REGISTERING: {
    value: "REGISTERING",
    label: "Đang đăng ký",
    bgColor: "#c8e7d7",
    color: "#13adcb",
    transitions: [
      {
        label: "Kết thúc kỳ thi",
        value: "CONTEST_CLOSED",
        dot: "#8b5cf6",
      },
      {
        label: "Huỷ kỳ thi",
        value: "CANCELLED",
        dot: "red",
      },
    ],
  },
  EXAM_FINISHED: {
    value: "EXAM_FINISHED",
    label: "Hoàn thành thi",
    bgColor: "#b9f1b9",
    color: "#48c532",
    transitions: [
      {
        label: "Kết thúc kỳ thi",
        value: "CONTEST_CLOSED",
        dot: "green",
      },
    ],
  },
  CONTEST_CLOSED: {
    value: "CONTEST_CLOSED",
    label: "Kết thúc kỳ thi",
    bgColor: "#8b5cf6",
    color: "#fff",
    transitions: [],
  },
  REGISTRATION_EXPIRED: {
    value: "REGISTRATION_EXPIRED",
    label: "Hết hạn đăng ký",
    bgColor: "#fef3c7",
    color: "#92400e",
    transitions: [
      {
        label: "Hoàn thành thi",
        value: "EXAM_FINISHED",
        dot: "green",
      },
      {
        label: "Huỷ kỳ thi",
        value: "CANCELLED",
        dot: "red",
      },
    ],
  },
  DRAFT: {
    value: "DRAFT",
    label: "Chưa đến ngày",
    bgColor: "#f1f5f9",
    color: "#475569",
    transitions: [
      {
        label: "Kết thúc kỳ thi",
        value: "CONTEST_CLOSED",
        dot: "#8b5cf6",
      },
      {
        label: "Huỷ kỳ thi",
        value: "CANCELLED",
        dot: "red",
      },
    ],
  },
  CANCELLED: {
    value: "CANCELLED",
    label: "Kỳ thi bị huỷ",
    bgColor: VPB_THEMES.colors.red,
    color: "#fff",
    transitions: [],
  },
};


export const TYPE_QUESTION = {
  MULTI_CHOICE: {
    name: "Câu hỏi lựa chọn nhiều",
    value: "MULTI_CHOICE",
  },
  SINGLE_CHOICE: {
    name: "Câu hỏi lựa chọn đơn",
    value: "SINGLE_CHOICE",
  },
  ESSAY: {
    name: "Câu hỏi tự luận",
    value: "ESSAY",
  },
  // MATCHING: {
  //   name: "Câu hỏi ghép đôi",
  //   value: "MATCHING",
  // },
  // GROUP: {
  //   name: "Câu hỏi nhóm",
  //   value: "GROUP",
  // },
  // FILL_BLANK: {
  //   name: "Câu hỏi điền vào chỗ trống",
  //   value: "FILL_BLANK",
  // },
};

export const DIFFICULTY = {
  EASY: {
    name: "Dễ",
    value: "EASY",
    color: VPB_THEMES.colors.green,
    bgColor: "#e8f5e9",
  },
  MEDIUM: {
    name: "Trung bình",
    value: "MEDIUM",
    color: "#ff9800",
    bgColor: "#fff3e0",
  },
  HARD: {
    name: "Khó",
    value: "HARD",
    color: VPB_THEMES.colors.red,
    bgColor: "#ffebee",
  },
};

export const RESOURCE_TYPE = {
  EXAM: "EXAM",
  QUESTION: "QUESTION",
  QUESTION_BANK_CONTAINER: "QUESTION_BANK_CONTAINER",
};

// Leave Request Status Map
export const LEAVE_REQUEST_STATUS_MAP = {
  PENDING: "Chờ duyệt",
  APPROVED: "Đã duyệt",
  REJECTED: "Từ chối",
};



// Leave Type Map
export const LEAVE_TYPE_MAP = {
  FULL_DAY: "Nghỉ cả ngày",
  BY_PERIOD: "Nghỉ theo ca",
  LESSON: "Nghỉ theo tiết",
};

// Semester Options
export const SEMESTER_OPTIONS = [
  { value: "", label: "Tất cả", id: null },
  { value: "Học kỳ 1", label: "Học kỳ 1", id: 1 },
  { value: "Học kỳ 2", label: "Học kỳ 2", id: 2 },
];

export const EMULATION_TYPE_OPTIONS = [
  { id: "REWARD", name: "Khen thưởng" },
  { id: "PENALTY", name: "Kỷ luật" },
];

export const KEY = {
  AUTH: "AUTH",
  TEACHER: "TEACHER",
  LEAVE_REQUEST: "LEAVE_REQUEST",
  CONFIG_APPROVED: "CONFIG_APPROVED",
  CLASS_TEACHER_SUBJECT: 'CLASS_TEACHER_SUBJECT',

  // THI ĐUA GIÁO VIÊN
  COMPETITION_TEACHER_CATEGORY: "COMPETITION_TEACHER_CATEGORY",
  COMPETITION_TEACHER_REASON: "COMPETITION_TEACHER_REASON",
  COMPETITION_TEACHER_SCORE: "COMPETITION_TEACHER_SCORE",

  // THI ĐUA LỚP
  COMPETITION_CLASS_CATEGORY: "COMPETITION_CLASS_CATEGORY",
  COMPETITION_CLASS_REASON: "COMPETITION_CLASS_REASON",
  COMPETITION_CLASS_SCORE: "COMPETITION_CLASS_SCORE",

  MAP_LOAI_MON: "MAP_LOAI_MON",
  SCORE_STUDENT: "SCORE_STUDENT",
  SCORE_STUDENT_HK_2: "SCORE_STUDENT_HK_2",
}


// leave request
export const NEXT_STEP_LEAVE_APPROVED = {
  HEAD: {
    label: "Tổ trưởng",
    value: "HEAD",
  },
  BOARD: {
    label: "BGH",
    value: "BOARD",
  },
  DONE: {
    label: "Đã duyệt",
    value: "DONE",
  },
  APPROVED: {
    label: 'Đã duyệt',
    value: 'APPROVED',
  }
}

export const STATUS_LEAVE = {
  WAIT_HEAD_APPROVAL: {
    value: 'WAIT_HEAD_APPROVAL',
    // label: 'Tổ trưởng phê duyệt',
    label: 'Chờ duyệt Tổ trưởng'
  },
  WAIT_BOARD_APPROVAL: {
    value: 'WAIT_BOARD_APPROVAL',
    label: 'Chờ duyệt BGH'
  },
  REJECTED: {
    value: 'WAIT_BOARD_APPROVAL',
    label: 'Từ chối'
  },
  APPROVED: {
    value: 'APPROVED_BOARD',
    label: 'Đã duyệt'
  }
}

export const LEAVE_REQUEST_STATUS_COLOR_MAP = {
  WAIT_HEAD_APPROVAL: "#ff9800",
  WAIT_BOARD_APPROVAL: "#ff9800",
  APPROVED: "#4caf50",
  REJECTED: "#f44336",
  default: "#757575",
};

export const TYPE_LEAVE_REQUEST = [
  {
    value: 'PAID_LEAVE',
    label: 'Nghỉ do điều động'
  },
  {
    value: 'UNPAID_LEAVE',
    label: 'Nghỉ việc riêng'
  },
  // {
  //   value: 'CHANGE_PERIOD',
  //   label: 'Đổi ca với giáo viên khác'
  // },
]

export const SUBJECT_TYPE_MAPPING = {
  LOAI_1: {
    type: "LOAI_1",
    schema: "SCHEMA_A",
  },
  LOAI_2: {
    type: "LOAI_2",
    schema: "SCHEMA_B",
  },
  LOAI_3: {
    type: "LOAI_3",
    schema: "SCHEMA_B",
  },
}

export const awardLevelOpt = [
  {
    label: "🥇 Giải Nhất",
    value: "FIRST",
  },
  {
    label: "🥈 Giải Nhì",
    value: "SECOND",
  },
  {
    label: "🥉 Giải Ba",
    value: "THIRD",
  },
  {
    label: "🎖 Khuyến Khích",
    value: "CONSOLATION",
  },
];

// Appeal Excellent Score Status
export const APPEAL_EXCELLENT_SCORE_STATUS_MAP = {
  PENDING: "Đang đợi phúc khảo",
  SCORE_UPDATED: "Đã phúc khảo",
};

// CHANGE_PERIOD, NO_CHANGE_PERIOD, PAID_LEAVE, UNPAID_LEAVE