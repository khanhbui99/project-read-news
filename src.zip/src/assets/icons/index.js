export {default as IcAdd} from './common/add.svg';
export {default as IcLoadingPage} from './common/loadingPage.svg';
export {default as IcEmpty} from './common/empty.svg';
export {default as IcStructure} from './template/structure.png';