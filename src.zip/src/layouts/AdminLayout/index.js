import { MENU_TYPE } from "App/store/constants";
import HeaderBar from "components/HeaderBar";
import MenuSelect from "components/MenuSelect";
import Sidebar from "components/Sidebar";
import React from "react";
import { IL_MENU_TYPE_PARENT, SALES } from "utils/constants";

import AdminLayoutStyle, { AdminContentStyle } from "./AdminLayoutStyle";

const AdminLayout = ({ children }) => {
  const isShowMenuSelect = ![SALES, MENU_TYPE.common].includes(
    String(localStorage.getItem(IL_MENU_TYPE_PARENT))
  );

  return (
    <AdminLayoutStyle>
      <Sidebar />
      <AdminContentStyle>
        <HeaderBar />
        <div className="body-content mt-3">
          {/* {isShowMenuSelect && <MenuSelect />} */}
          {children}
        </div>
      </AdminContentStyle>
    </AdminLayoutStyle>
  );
};

export default AdminLayout;
