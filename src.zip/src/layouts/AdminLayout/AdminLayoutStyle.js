import styled from 'styled-components';
import { MINI_SIDEBAR_WITH, SIDEBAR_WITH } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

const AdminLayoutStyle = styled.div`
  width: 100%;
  height: 100vh;
`;

export default AdminLayoutStyle;

const AdminContentStyle = styled.div`
  min-height: 100vh;
  padding-top: 0;
  margin-left: ${SIDEBAR_WITH}px;
  transition: margin-left 0.3s ease-in-out;
  
  .body-content {
    padding: 24px 24px ${pxToRem(40)};
  }
  
  :has(.riskCheckPCB) {
    background-color: #f5f5f5;
  }

  /* Tablet: 768px - 1024px */
  @media (max-width: 1024px) {
    margin-left: ${SIDEBAR_WITH}px;
    
    .body-content {
      padding: 20px 20px ${pxToRem(32)};
    }
  }

  /* Mobile: < 768px */
  @media (max-width: 768px) {
    margin-left: 0;
    
    .body-content {
      padding: 16px 16px ${pxToRem(24)};
    }
  }
`;
export {
  AdminContentStyle
}