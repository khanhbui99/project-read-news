# DashboardLayout

Layout component cho dashboard LMS với cấu trúc Header, Sidebar và Content.

## Cấu trúc

```
DashboardLayout/
├── index.js                    # Layout chính
├── DashboardLayoutStyle.js     # Styles cho layout
├── components/
│   ├── DashboardHeader/       # Header component
│   ├── DashboardSidebar/      # Sidebar component
│   ├── DashboardContent/      # Content wrapper
│   └── widgets/               # Các widget components
│       ├── StatCard/          # Card hiển thị thống kê
│       ├── AlertCard/         # Card cảnh báo
│       └── ChartCard/         # Card biểu đồ
└── README.md
```

## Cách sử dụng

### Basic Usage

```jsx
import DashboardLayout from 'layouts/DashboardLayout';

function DashboardPage() {
  return (
    <DashboardLayout>
      <div>Nội dung trang dashboard</div>
    </DashboardLayout>
  );
}
```

### Sử dụng các Widget Components

```jsx
import DashboardLayout from 'layouts/DashboardLayout';
import { StatCard, AlertCard, ChartCard } from 'layouts/DashboardLayout/components/widgets';
import { TrendingUp } from '@mui/icons-material';

function DashboardPage() {
  return (
    <DashboardLayout>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
        <StatCard
          value="7.8"
          label="Điểm TB Toàn Trường"
          change="+0.3"
          changeType="positive"
          icon={TrendingUp}
        />
        <StatCard
          value="65%"
          label="HS Điểm ≥8.0"
          change="+5%"
          changeType="positive"
        />
        <StatCard
          value="450"
          label="Tổng Học Sinh"
        />
      </div>

      <div style={{ marginTop: '24px' }}>
        <AlertCard
          title="38 HS Cần Can Thiệp Gấp"
          description="Điểm TB <5.0 ở các môn thi tốt nghiệp. Cần hỗ trợ kịp thời."
          type="error"
          actionText="Xem chi tiết"
          onAction={() => console.log('Xem chi tiết')}
        />
      </div>

      <div style={{ marginTop: '24px' }}>
        <ChartCard
          title="Xu Hướng Điểm TB 3 Năm"
          actionText="Chi tiết"
          onAction={() => console.log('Chi tiết')}
        >
          {/* Nội dung biểu đồ */}
          <div>Biểu đồ ở đây</div>
        </ChartCard>
      </div>
    </DashboardLayout>
  );
}
```

## Responsive

Layout tự động responsive cho mobile:
- Sidebar sẽ ẩn/hiện khi click menu trên mobile
- Header và các component tự động điều chỉnh kích thước
- Grid layout tự động chuyển sang 1 cột trên mobile

## Components

### StatCard

Card hiển thị thống kê với icon, giá trị, label và thay đổi.

**Props:**
- `value` (string|number): Giá trị hiển thị
- `label` (string): Nhãn mô tả
- `change` (string): Thay đổi (ví dụ: "+0.3", "+5%")
- `changeType` ('positive'|'negative'|'neutral'): Loại thay đổi
- `icon` (elementType): Icon component từ MUI
- `color` (string): Màu theme ('primary'|'secondary'|'warning'|'error')

### AlertCard

Card hiển thị cảnh báo hoặc thông báo quan trọng.

**Props:**
- `title` (string): Tiêu đề
- `description` (string): Mô tả
- `type` ('warning'|'error'|'info'): Loại cảnh báo
- `actionText` (string): Text nút action
- `onAction` (function): Callback khi click action

### ChartCard

Card wrapper cho biểu đồ hoặc nội dung phức tạp.

**Props:**
- `title` (string): Tiêu đề
- `children` (node): Nội dung
- `actionText` (string): Text nút action
- `onAction` (function): Callback khi click action

## Customization

Các component sử dụng styled-components và có thể customize thông qua:
- Theme từ `utils/configs` (VPB_THEMES)
- CSS-in-JS với styled-components
- Props để điều chỉnh behavior

