import styled from 'styled-components';
import { SIDEBAR_WITH, MINI_SIDEBAR_WITH } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

const DashboardLayoutStyle = styled.div`
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f5f5f5;
  position: relative;
`;

const DashboardMainStyle = styled.main`
  flex: 1;
  margin-left: ${(p) => (p.isSidebarOpen ? SIDEBAR_WITH : MINI_SIDEBAR_WITH)}px;
  margin-top: 70px;
  transition: margin-left 0.3s ease;
  min-height: calc(100vh - 70px);

  @media (max-width: 768px) {
    margin-left: 0;
    margin-top: 60px;
  }
`;

DashboardMainStyle.shouldForwardProp = (prop) => !['isSidebarOpen'].includes(prop);

export default DashboardLayoutStyle;
export { DashboardMainStyle };

