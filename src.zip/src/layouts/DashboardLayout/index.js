import React, { useState } from 'react';
import { useSelector } from 'react-redux';

import DashboardContent from './components/DashboardContent';
import DashboardHeader from './components/DashboardHeader';
import DashboardSidebar from './components/DashboardSidebar';
import DashboardLayoutStyle, { DashboardMainStyle } from './DashboardLayoutStyle';

const DashboardLayout = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <DashboardLayoutStyle>
      <DashboardHeader 
        onToggleSidebar={toggleSidebar}
        onToggleMobileMenu={toggleMobileMenu}
        isSidebarOpen={isSidebarOpen}
      />
      <DashboardSidebar 
        isOpen={isSidebarOpen}
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={closeMobileMenu}
      />
      <DashboardMainStyle isSidebarOpen={isSidebarOpen}>
        <DashboardContent>
          {children}
        </DashboardContent>
      </DashboardMainStyle>
    </DashboardLayoutStyle>
  );
};

export default DashboardLayout;

