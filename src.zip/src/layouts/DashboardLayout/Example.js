/**
 * Example sử dụng DashboardLayout
 * File này chỉ để tham khảo, có thể xóa sau khi đã hiểu cách sử dụng
 */

import { 
  TrendingUp, 
  School, 
  People, 
  EmojiEvents,
  Assessment 
} from '@mui/icons-material';
import React from 'react';

import { StatCard, AlertCard, ChartCard, GridContainer } from './components/widgets';

import DashboardLayout from './index';

const DashboardExample = () => {
  return (
    <DashboardLayout>
      {/* Header Section */}
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 600, marginBottom: '8px' }}>
          Tổng Quan
        </h1>
        <p style={{ color: '#526779', fontSize: '14px' }}>
          Dashboard tổng hợp - Năm học 2024-2025
        </p>
      </div>

      {/* Stats Grid */}
      <GridContainer columns={{ xs: 1, sm: 2, md: 3, lg: 6 }} gap={16}>
        <StatCard
          value="7.8"
          label="Điểm TB Toàn Trường"
          change="+0.3"
          changeType="positive"
          icon={Assessment}
          color="primary"
        />
        <StatCard
          value="65%"
          label="HS Điểm ≥8.0"
          change="+5%"
          changeType="positive"
          icon={TrendingUp}
          color="primary"
        />
        <StatCard
          value="8.5%"
          label="HS Yếu (<5.0)"
          change="-1.2%"
          changeType="positive"
          icon={School}
          color="warning"
        />
        <StatCard
          value="450"
          label="Tổng Học Sinh"
          icon={People}
          color="secondary"
        />
        <StatCard
          value="30"
          label="Tổng Giáo Viên"
          change="+2"
          changeType="positive"
          icon={People}
          color="secondary"
        />
        <StatCard
          value="12"
          label="Giải Thưởng"
          change="+4"
          changeType="positive"
          icon={EmojiEvents}
          color="primary"
        />
      </GridContainer>

      {/* Alerts Section */}
      <div style={{ marginTop: '24px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '16px' }}>
        <AlertCard
          title="38 HS Cần Can Thiệp Gấp"
          description="Điểm TB <5.0 ở các môn thi tốt nghiệp. Cần hỗ trợ kịp thời."
          type="error"
          actionText="Xem chi tiết"
          onAction={() => console.log('Xem chi tiết HS cần can thiệp')}
        />
        <AlertCard
          title="Lớp 12A5: Vắng Mặt Cao"
          description="Tỷ lệ vắng mặt 15.2% - cao gấp 3 lần trung bình trường."
          type="warning"
          actionText="Xem chi tiết"
          onAction={() => console.log('Xem chi tiết lớp 12A5')}
        />
        <AlertCard
          title="5 GV Chưa Kiểm Tra Bài Cũ"
          description="Tháng này chưa thực hiện kiểm tra bài cũ theo quy định."
          type="info"
          actionText="Xem chi tiết"
          onAction={() => console.log('Xem chi tiết GV')}
        />
      </div>

      {/* Charts Section */}
      <GridContainer columns={{ xs: 1, md: 2 }} gap={16} style={{ marginTop: '24px' }}>
        <ChartCard
          title="Xu Hướng Điểm TB 3 Năm"
          actionText="Chi tiết"
          onAction={() => console.log('Xem chi tiết xu hướng')}
        >
          <div style={{ padding: '20px', textAlign: 'center', color: '#526779' }}>
            Biểu đồ xu hướng điểm TB 3 năm
            <br />
            (Có thể tích hợp Chart.js, Recharts, hoặc thư viện biểu đồ khác)
          </div>
        </ChartCard>

        <ChartCard
          title="Phân Bổ Học Lực"
          actionText="Chi tiết"
          onAction={() => console.log('Xem chi tiết phân bổ học lực')}
        >
          <div style={{ padding: '20px', textAlign: 'center', color: '#526779' }}>
            Biểu đồ phân bổ học lực
            <br />
            (Có thể tích hợp Chart.js, Recharts, hoặc thư viện biểu đồ khác)
          </div>
        </ChartCard>
      </GridContainer>
    </DashboardLayout>
  );
};

export default DashboardExample;

