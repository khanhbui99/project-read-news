import styled from 'styled-components';

const NormalLayoutStyle = styled.div`
  width: 100%;
`;

export default NormalLayoutStyle;
