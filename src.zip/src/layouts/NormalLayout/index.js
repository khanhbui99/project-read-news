import React from 'react';

import NormalLayoutStyle from './UnauthenticationLayoutStyle';

const NormalLayout = ({ children }) => (
  <NormalLayoutStyle>{children}</NormalLayoutStyle>
);

export default NormalLayout;
