const urlApi = {
  orgChart: {
    faculty: {
      listAll: "org-chart-service/v2/api/public/faculty/find-all",
      create: "org-chart-service/v2/api/public/faculty/create",
      edit: "org-chart-service/v2/api/public/faculty/put",
      delete: (id) => `org-chart-service/v2/api/public/faculty/delete/${id}`,
    },
    department: {
      listAll: "org-chart-service/v2/api/public/department/find-all",
      create: "org-chart-service/v2/api/public/department/create",
      edit: "org-chart-service/v2/api/public/department/put",
      delete: (id) => `org-chart-service/v2/api/public/department/delete/${id}`,
    },
    account: {
      accountManager:
        "org-chart-service/v2/api/public/org-chart/account-manager",
      login: "org-chart-service/v2/api/public/accounts/sale/login",
      accountTree: "org-chart-service/v2/api/public/accounts/account-tree",
      list: "org-chart-service/v2/api/public/accounts",
      detail: (id) => `org-chart-service/v2/api/public/accounts/${id}`,
      create: "org-chart-service/v2/api/public/accounts/v2/create",
      update: (id) =>
        `org-chart-service/v2/api/public/accounts/${id}/v2/update`,
      delete: (id) => `org-chart-service/v2/api/public/accounts/${id}`,
      active: (id) =>
        `org-chart-service/v2/api/public/accounts/${id}/active-account`,
      unlockAccount: (id) =>
        `org-chart-service/v2/api/public/accounts/${id}/un-block`,
      lockAccount: (id) =>
        `org-chart-service/v2/api/public/accounts/${id}/block`,
      password: `org-chart-service/v2/api/public/accounts/password`,
    },
    menuTab: {
      type: "org-chart-service/v2/api/public/menu-tabs/types/available",
      list: "org-chart-service/v2/api/public/menu-tabs",
      create: "org-chart-service/v2/api/public/menu-tabs",
      update: (id) => `org-chart-service/v2/api/public/menu-tabs/${id}`,
      delete: (id) => `org-chart-service/v2/api/public/menu-tabs/${id}`,
    },
    menuItem: {
      list: "org-chart-service/v2/api/public/menu-item",
      create: "org-chart-service/v2/api/public/menu-item",
      listMenu: "org-chart-service/v2/api/public/menu-item/list-menu",
      presents: "org-chart-service/v2/api/public/menu-item/presents",
      update: (id) => `org-chart-service/v2/api/public/menu-item/${id}`,
      detail: (id) => `org-chart-service/v2/api/public/menu-item/${id}`,
      delete: (id) => `org-chart-service/v2/api/public/menu-item/${id}`,
    },
    authorities: {
      listAll: "org-chart-service/v2/api/public/authorities",
      create: "org-chart-service/v2/api/public/authorities",
      detail: (id) => `org-chart-service/v2/api/public/authorities/${id}`,
      edit: (id) => `org-chart-service/v2/api/public/authorities/${id}`,
      delete: (id) => `org-chart-service/v2/api/public/authorities/${id}`,
    },
    groups: {
      listAll: "org-chart-service/v2/api/public/groups",
      listDefault: "org-chart-service/v2/api/public/groups/default",
    },
    permissions: {
      list: "org-chart-service/v2/api/public/permissions",
      delete: (id) => `org-chart-service/v2/api/public/permissions/${id}`,
    },
    chart: {
      search: "org-chart-service/v2/api/public/org-chart/search",
      create: "org-chart-service/v2/api/public/org-chart",
      listAll: "org-chart-service/v2/api/public/org-chart",
      update: (id) => `org-chart-service/v2/api/public/org-chart/${id}`,
      detail: (id) => `org-chart-service/v2/api/public/org-chart/${id}`,
      delete: (id) => `org-chart-service/v2/api/public/org-chart/${id}`,
    },
    onLeave: {
      createPersonal:
        "org-chart-service/v2/api/public/leave-requests/personal/teacher",
      createPolicy: "org-chart-service/v2/api/public/leave-requests/policy",
      viewAll: "org-chart-service/v2/api/public/leave-requests/view-all",
      listApprove: "org-chart-service/v2/api/public/on-leave/list-approve",
      needAssign: "org-chart-service/v2/api/public/leave-requests/need-assign",
      backupConfirm: (id) =>
        `org-chart-service/v2/api/public/leave-requests/${id}/backup/confirm`,
      backupReject: (id) =>
        `org-chart-service/v2/api/public/leave-requests/${id}/backup/reject`,
      updatePeriodBackup: (id, periodId) =>
        `org-chart-service/v2/api/public/leave-requests/${id}/periods/${periodId}/backup`,
      assignTeacher: (periodId) =>
        `org-chart-service/v2/api/public/leave-requests/periods/${periodId}/assign-teacher`,
      approvePolicy: (id) =>
        `org-chart-service/v2/api/public/leave-requests/${id}/approve/policy`,
      approvePersonalTeacher: (id) =>
        `org-chart-service/v2/api/public/leave-requests/${id}/approve/personal-teacher`,
      reject: (id) => `org-chart-service/v2/api/public/on-leave/${id}/reject`,
      // backup: `org-chart-service/v2/api/public/leave-requests/backup/my-requests`,

      create: `org-chart-service/v2/api/public/teacher-leave`,
      detail: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/details/${id}`,
      update: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/update/${id}`,
      delete: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/delete/${id}`,
      backup: `org-chart-service/v2/api/public/teacher-leave/backup`,
      approve: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/head/${id}`,
      rejectHead: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/head/${id}`,
      myRequest:
        "org-chart-service/v2/api/public/teacher-leave/head-and-teacher-view",
      mySummary:
        "org-chart-service/v2/api/public/teacher-leave/my-summary",
      boardSummary:
        "org-chart-service/v2/api/public/teacher-leave/board-summary",
      listBoard: "org-chart-service/v2/api/public/teacher-leave/board",
      approved: "org-chart-service/v2/api/public/teacher-leave/approved",
      approveBoard: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/board/${id}`,
      rejectBoard: (id) =>
        `org-chart-service/v2/api/public/teacher-leave/board/${id}`,
    },
    officeUtilityType: {
      list: "org-chart-service/v2/api/public/office-utility-types",
      create: "org-chart-service/v2/api/public/office-utility-types",
      update: (id) =>
        `org-chart-service/v2/api/public/office-utility-types/${id}`,
      delete: (id) =>
        `org-chart-service/v2/api/public/office-utility-types/${id}`,
    },
    officeUtilityRequest: {
      my: "org-chart-service/v2/api/public/office-utility-requests/my",
      approve:
        "org-chart-service/v2/api/public/office-utility-requests/approve",
      create: "org-chart-service/v2/api/public/office-utility-requests",
      update: (id) =>
        `org-chart-service/v2/api/public/office-utility-requests/${id}`,
      delete: (id) =>
        `org-chart-service/v2/api/public/office-utility-requests/${id}`,
      approveAction: (id) =>
        `org-chart-service/v2/api/public/office-utility-requests/${id}/approve`,
      rejectAction: (id) =>
        `org-chart-service/v2/api/public/office-utility-requests/${id}/reject`,
    },
    auth: {
      resetPassword: `org-chart-service/v2/api/public/accounts/default-password`
    }
  },
  managementService: {
    chat: {
      // Source of truth: .cursor/docs/emulation/class/chat/chat-tester.html
      contacts: "management-service/v2/api/public/chat/contacts",
      conversations: "management-service/v2/api/public/chat/conversations",
      createConversation: "management-service/v2/api/public/chat/conversations",
      messages: (conversationId) =>
        `management-service/v2/api/public/chat/conversations/${conversationId}/messages`,
      sendMessage: (conversationId) =>
        `management-service/v2/api/public/chat/conversations/${conversationId}/messages`,
      read: (conversationId) =>
        `management-service/v2/api/public/chat/conversations/${conversationId}/read`,
      ws: "management-service/v2/api/ws-chat",
    },
    classEmulationCriteria: {
      list: "management-service/v2/api/public/thi-dua/criteria",
      create: "management-service/v2/api/public/thi-dua/criteria",
      update: (id) =>
        `management-service/v2/api/public/thi-dua/criteria/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/thi-dua/criteria/${id}`,
    },
    classEmulationDailyScores: {
      list: "management-service/v2/api/public/thi-dua/daily-scores",
      create: "management-service/v2/api/public/thi-dua/daily-scores",
      update: (id) =>
        `management-service/v2/api/public/thi-dua/daily-scores/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/thi-dua/daily-scores/${id}`,
      impactPreview:
        "management-service/v2/api/public/thi-dua/daily-scores/impact-preview",
      violations:
        "management-service/v2/api/public/thi-dua/daily-scores/violations",
    },
    classEmulationComplaints: {
      mine: "management-service/v2/api/public/thi-dua/complaints/mine",
      list: "management-service/v2/api/public/thi-dua/complaints",
      create: "management-service/v2/api/public/thi-dua/complaints",
      update: (id) =>
        `management-service/v2/api/public/thi-dua/complaints/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/thi-dua/complaints/${id}`,
      resolve: (id) =>
        `management-service/v2/api/public/thi-dua/complaints/${id}/resolve`,
    },
    classEmulationMovements: {
      list: "management-service/v2/api/public/thi-dua/movements",
      create: "management-service/v2/api/public/thi-dua/movements",
      update: (id) =>
        `management-service/v2/api/public/thi-dua/movements/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/thi-dua/movements/${id}`,
      activities:
        "management-service/v2/api/public/thi-dua/movement-activities",
    },
    classEmulationReports: {
      classMonthly: (classId) =>
        `management-service/v2/api/public/thi-dua/reports/classes/${classId}/monthly`,
      classSemester: (classId) =>
        `management-service/v2/api/public/thi-dua/reports/classes/${classId}/semester`,
      monthlyRanking:
        "management-service/v2/api/public/thi-dua/reports/monthly-ranking",
      semesterRanking:
        "management-service/v2/api/public/thi-dua/reports/semester-ranking",
    },
    manualNotifications: {
      sent: "management-service/v2/api/public/manual-notifications/sent",
      sentDetail: (id) =>
        `management-service/v2/api/public/manual-notifications/sent/${id}`,
      targetOptions:
        "management-service/v2/api/public/manual-notifications/target-options",
      create: "management-service/v2/api/public/manual-notifications",
      downloadFile: (notificationId, fileId) =>
        `management-service/v2/api/public/manual-notifications/${notificationId}/files/${fileId}/download`,
    },
    topic: {
      list: "management-service/v2/api/public/topics",
      create: "management-service/v2/api/public/topics",
      edit: (id) => `management-service/v2/api/public/topics/${id}`,
      delete: (id) => `management-service/v2/api/public/topics/${id}`,
    },
    subject: {
      list: "management-service/v2/api/public/subject",
      create: "management-service/v2/api/public/subject",
      edit: (id) => `management-service/v2/api/public/subject/${id}`,
      delete: (id) => `management-service/v2/api/public/subject/${id}`,
    },
    examTemplate: {
      list: "management-service/v2/api/public/exam-template",
      create: "management-service/v2/api/public/exam-template",
      edit: (id) => `management-service/v2/api/public/exam-template/${id}`,
      delete: (id) => `management-service/v2/api/public/exam-template/${id}`,
      detail: (id) => `management-service/v2/api/public/exam-template/${id}`,
    },
    bankQuestion: {
      list: "management-service/v2/api/public/question-bank-containers",
      create: "management-service/v2/api/public/question-bank-containers",
      edit: (id) =>
        `management-service/v2/api/public/question-bank-containers/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/question-bank-containers/${id}`,
      detail: (id) =>
        `management-service/v2/api/public/question-bank-containers/${id}`,
    },
    question: {
      list: "management-service/v2/api/public/question",
      create: "management-service/v2/api/public/question",
      detail: (id) => `management-service/v2/api/public/question/${id}`,
      edit: (id) => `management-service/v2/api/public/question/${id}`,
      delete: (id) => `management-service/v2/api/public/question/${id}`,
      findByBankIdAndSubjectId:
        "management-service/v2/api/public/question/find-by-bank-id-subject-id",
    },
    examGenerate: {
      list: "management-service/v2/api/public/exams/get-all",
      create: "management-service/v2/api/public/exams",
      createVariants:
        "management-service/v2/api/public/exams/exams/variants-v2",
      edit: (id) => `management-service/v2/api/public/exams/update/${id}`,
      delete: (id) => `management-service/v2/api/public/exams/delete/${id}`,
      detail: (id) => `management-service/v2/api/public/exams/${id}/detail2`,
      pdf: (id) => `management-service/v2/api/public/exams/exams/${id}/pdf2`,
    },
    examPeriod: {
      categoryDependency:
        "management-service/v2/api/public/exams-period/category-dependency",
    },
    timetable: {
      byClass: (classId) =>
        `management-service/v2/api/timetables/class/${classId}`,
    },
    tkb: {
      byClass: (classId) =>
        `management-service/v2/api/public/tkb/class/${classId}`,
      me: "management-service/v2/api/public/tkb/me",
      school: "management-service/v2/api/public/tkb/school",
      import: {
        validate: "management-service/v2/api/public/tkb/import/validate",
        commit: "management-service/v2/api/public/tkb/import/commit",
      },
    },
    course: {
      list: "management-service/v2/api/public/courses",
      create: "management-service/v2/api/public/courses",
      detail: (id) => `management-service/v2/api/public/courses/${id}`,
      update: (id) => `management-service/v2/api/public/courses/${id}`,
      delete: (id) => `management-service/v2/api/public/courses/${id}`,
    },
    lesson: {
      create: (courseId) =>
        `management-service/v2/api/public/lessons/courses/${courseId}`,
      update: (id) => `management-service/v2/api/public/lessons/${id}`,
      delete: (id) => `management-service/v2/api/public/lessons/${id}`,
      reorder: (courseId) =>
        `management-service/v2/api/public/courses/${courseId}/lessons/order`,
    },
    material: {
      create: (lessonId) =>
        `management-service/v2/api/public/materials/lessons/${lessonId}`,
      update: (id) => `management-service/v2/api/public/materials/${id}`,
      delete: (id) => `management-service/v2/api/public/materials/${id}`,
      reorder: (lessonId) =>
        `management-service/v2/api/public/materials/lessons/${lessonId}/order`,
    },
    media: {
      list: "management-service/v2/api/public/media",
      upload: "management-service/v2/api/public/media/upload",
      detail: (id) => `management-service/v2/api/public/media/${id}`,
      delete: (id) => `management-service/v2/api/public/media/${id}`,
      move: (id) => `management-service/v2/api/public/media/${id}/move`,
    },
    folder: {
      list: "management-service/v2/api/public/folders",
      rootContents: "management-service/v2/api/public/folders/root/contents",
      detail: (id) => `management-service/v2/api/public/folders/${id}`,
      contents: (id) =>
        `management-service/v2/api/public/folders/${id}/contents`,
      create: "management-service/v2/api/public/folders",
      update: (id) => `management-service/v2/api/public/folders/${id}`,
      delete: (id) => `management-service/v2/api/public/folders/${id}`,
      move: (id) => `management-service/v2/api/public/folders/${id}/move`,
      search: "management-service/v2/api/public/folders/search",
    },
    excel: {
      downloadTemplate: (subjectId) =>
        `management-service/v2/api/public/excel/template?subjectId=${subjectId}`,
      importTemplate: (subjectId, bankQuestionId) =>
        `management-service/v2/api/public/excel/import-template?subjectId=${subjectId}&bankQuestionId=${bankQuestionId}`,
    },
    share: {
      share: "management-service/v2/api/public/share/share",
    },
    report: {
      downloadTemplate:
        "management-service/v2/api/api/report/download-template",
      import: "management-service/v2/api/api/report/import",
      downloadTemplateV2:
        "management-service/v2/api/api/report/download-template-v2",
      importV2: "management-service/v2/api/api/report/import-v2",
      studentCountBySchool:
        "management-service/v2/api/api/report/student-count-by-school",
      staffChangesBySchool:
        "management-service/v2/api/api/report/staff-changes-by-school",
      staffBySchool: "management-service/v2/api/api/report/staff-by-school",
      studentCountByEducationalOwnership:
        "management-service/v2/api/api/report/student-count-by-educational-ownership",
      staffChangesByEducationalOwnership:
        "management-service/v2/api/api/report/staff-changes-by-education-ownership",
      staffByEducationalOwnership:
        "management-service/v2/api/api/report/staff-by-educational-ownership",
      reportDefinition:
        "management-service/v2/api/api/report-definition/get-all",
      exportWordV2: "management-service/v2/api/api/report/export-word-v2",
    },
    school: {
      search: "management-service/v2/api/api/schools",
      create: "management-service/v2/api/api/schools",
      edit: (id) => `management-service/v2/api/api/schools/${id}`,
      delete: (id) => `management-service/v2/api/api/schools/${id}`,
    },
    templateManagement: {
      listAll: "management-service/v2/api/public/template-management/find-all",
      findSchools:
        "management-service/v2/api/public/template-management/find-schools",
      create: "management-service/v2/api/public/template-management/created",
      pushToSchool:
        "management-service/v2/api/public/template-management/push-to-school",
      download: "management-service/v2/api/public/template-management/download",
      delete: (id) =>
        `management-service/v2/api/public/template-management/delete/${id}`,
    },
    s3: {
      download: "management-service/v2/api/public/s3/download",
      uploadResource: "management-service/v2/api/public/s3/upload-resource",
    },
    academicYear: {
      findAll: "management-service/v2/api/public/academic-year/find-all",
    },
    reportDefinition: {
      getAll: "management-service/v2/api/api/report-definition/get-all",
    },
    reportForAll: {
      districtSummary:
        "management-service/v2/api/api/report-for-all/district-summary",
    },
    excellentStudentContest: {
      create: "management-service/v2/api/public/excellent-student-contest",
      list: "management-service/v2/api/public/excellent-student-contest",
      edit: (id) => `management-service/v2/api/public/excellent-student-contest/${id}`,
      delete: (id) => `management-service/v2/api/public/excellent-student-contest/${id}`,
      detail: (id) => `management-service/v2/api/public/excellent-student-contest/${id}`, 
      updateStatus: (id) => `management-service/v2/api/public/excellent-student-contest/update-status/${id}`,
      assignRooms: "management-service/v2/api/public/excellent-student-contest/assign-room",
      previewScore: id => `management-service/v2/api/public/excellent-student-contest/${id}/scores/preview`,
      importExternal: (id) => `management-service/v2/api/public/excellent-student-contest/${id}/import-external`,
      importScores: (id) => `management-service/v2/api/public/excellent-student-contest/${id}/import-scores`,
      awardScoreRanges: id => `management-service/v2/api/public/excellent-student-contest/${id}/award-score-ranges`,
      removeExternalCandidate: (contestId, candidateId) => `management-service/v2/api/public/excellent-student-contest/${contestId}/external-candidate/${candidateId}`,
      appeal: id => `management-service/v2/api/public/excellent-student-contest/${id}/appeal`,
      appeals: id => `management-service/v2/api/public/excellent-student-contest/${id}/appeals`,
      appealScoreHistory: id => `management-service/v2/api/public/excellent-student-contest/appeals/${id}/score-history`,
      myScoreAppeals:'/management-service/v2/api/public/excellent-student-contest/my-score-appeals',
      appealsImportScores:id => `management-service/v2/api/public/excellent-student-contest/${id}/appeals/import-scores`,
      contests: 'management-service/v2/api/public/excellent-student-contest/appeals/contests'
    },
    testSessions: 'management-service/v2/api/public/test-sessions',
    typeOfExams: 'management-service/v2/api/public/type-of-exams',
    teachingAssignment:"management-service/v2/api/public/teaching-assignment",
    teacher: {
      mySchedule: `management-service/v2/api/public/teaching-assignment/my-schedule`,
    },
    score: {
      pendingApproval:
        "management-service/v2/api/public/api/scores/push/pending-approvals",
      reject: (id) =>
        `management-service/v2/api/public/api/scores/push/${id}/reject`,
      approve: (id) =>
        `management-service/v2/api/public/api/scores/push/${id}/approve`,
      viewBgh: `management-service/v2/api/public/api/scores/bgh/view`,
      previewBgh: (id) =>
        `management-service/v2/api/public/api/scores/push/${id}/preview`,
      locks: "management-service/v2/api/public/api/score-column-locks",
      locksMulti: "management-service/v2/api/public/api/score-column-locks/multi",
      statusQI: "management-service/v2/api/public/api/scores/push/lock-status",
      toggleLock:"management-service/v2/api/public/api/scores/push/toggle-lock",
      scoreBulk: "management-service/v2/api/public/api/score-column-locks/bulk"
    },
    student: {
      detail: `management-service/v2/api/student/me/detail`,
      viewScore: `management-service/v2/api/public/api/scores/student/view`,
    },
    teacherEmulation: {
      criteria: {
        list: "management-service/v2/api/public/teacher-emulation-criteria",
        create: "management-service/v2/api/public/teacher-emulation-criteria",
        listGroup: "management-service/v2/api/public/teacher-emulation-criteria/get-group",
        update: (id) => `management-service/v2/api/public/teacher-emulation-criteria/${id}`,
        delete: (id) => `management-service/v2/api/public/teacher-emulation-criteria/${id}`,
      },
      score: {
        list: 'management-service/v2/api/public/teacher-emulation-scores/find-all',
        pending: "management-service/v2/api/public/teacher-emulation-scores/pending",
        reject: (id) =>
          `management-service/v2/api/public/teacher-emulation-scores/${id}/reject`,
        approve: (id, reason) =>
          `management-service/v2/api/public/teacher-emulation-scores/${id}/${reason}/approve`,
        create: 'management-service/v2/api/public/teacher-emulation-scores',
        report: id => `management-service/v2/api/public/teacher-emulation-scores/${id}/complaint`,
        detailTeacher: id => `management-service/v2/api/public/teacher-emulation-scores/teacher/${id}`,
        toggle: 'management-service/v2/api/public/teacher-emulation-scores/toggle',
        toggleStatus: 'management-service/v2/api/public/teacher-emulation-scores/toggle/status',
      }
    },
    assignments: {
      list: "management-service/v2/api/public/assignments",
      create: "management-service/v2/api/public/assignments",
      detail: (id) => `management-service/v2/api/public/assignments/${id}`,
      update: (id) => `management-service/v2/api/public/assignments/${id}`,
      updateDueDate: (id) =>
        `management-service/v2/api/public/assignments/${id}/due-date`,
      delete: (id) => `management-service/v2/api/public/assignments/${id}`,
      lock: (id) => `management-service/v2/api/public/assignments/${id}/lock`,
      unlock: (id) =>
        `management-service/v2/api/public/assignments/${id}/unlock`,
      gradeSubmission: (assignmentId, submissionId) =>
        `management-service/v2/api/public/assignments/${assignmentId}/submissions/${submissionId}/grade`,
      uploadAnnotatedFile: (assignmentId, submissionId) =>
        `management-service/v2/api/public/assignments/${assignmentId}/submissions/${submissionId}/annotated-file`,
      reopenSubmission: (assignmentId, submissionId) =>
        `management-service/v2/api/public/assignments/${assignmentId}/submissions/${submissionId}/reopen`,
      downloadSubmissionFile: (assignmentId, submissionId, fileId) =>
        `management-service/v2/api/public/assignments/${assignmentId}/submissions/${submissionId}/files/${fileId}/download`,
      downloadAssignmentFile: (assignmentId, fileId) =>
        `management-service/v2/api/public/assignments/${assignmentId}/files/${fileId}/download`,
    },
    facility: {
      subjects: {
        list: "management-service/v2/api/public/facility/subjects",
        create: "management-service/v2/api/public/facility/subjects",
        update: (id) =>
          `management-service/v2/api/public/facility/subjects/${id}`,
        delete: (id) =>
          `management-service/v2/api/public/facility/subjects/${id}`,
      },
      types: {
        list: "management-service/v2/api/public/facility/types",
        create: "management-service/v2/api/public/facility/types",
        update: (id) => `management-service/v2/api/public/facility/types/${id}`,
        delete: (id) => `management-service/v2/api/public/facility/types/${id}`,
      },
      standardDevices: {
        list: "management-service/v2/api/public/facility/standard-devices",
        create: "management-service/v2/api/public/facility/standard-devices",
        update: (id) =>
          `management-service/v2/api/public/facility/standard-devices/${id}`,
        delete: (id) =>
          `management-service/v2/api/public/facility/standard-devices/${id}`,
        hideCode: (id) =>
          `management-service/v2/api/public/facility/standard-devices/${id}/hide-code`,
        unhideCode: (id) =>
          `management-service/v2/api/public/facility/standard-devices/${id}/unhide-code`,
        codeChangeImpact: (id) =>
          `management-service/v2/api/public/facility/standard-devices/${id}/code-change-impact`,
      },
      roomTypes: {
        list: "management-service/v2/api/public/facility/room-types",
        create: "management-service/v2/api/public/facility/room-types",
        update: (id) =>
          `management-service/v2/api/public/facility/room-types/${id}`,
        delete: (id) =>
          `management-service/v2/api/public/facility/room-types/${id}`,
      },
      rooms: {
        list: "management-service/v2/api/public/facility/rooms",
        create: "management-service/v2/api/public/facility/rooms",
        detail: (id) =>
          `management-service/v2/api/public/facility/rooms/${id}`,
        update: (id) =>
          `management-service/v2/api/public/facility/rooms/${id}`,
        delete: (id) =>
          `management-service/v2/api/public/facility/rooms/${id}`,
        assignManager: (roomId, userId) =>
          `management-service/v2/api/public/facility/rooms/${roomId}/managers/${userId}`,
        removeManager: (roomId, userId) =>
          `management-service/v2/api/public/facility/rooms/${roomId}/managers/${userId}`,
      },
      assets: {
        list: "management-service/v2/api/public/facility/assets",
        myRooms:
          "management-service/v2/api/public/facility/assets/my-rooms",
        myRoomsDetail: (id) =>
          `management-service/v2/api/public/facility/assets/my-rooms/${id}`,
        myRoomsHistory: (id) =>
          `management-service/v2/api/public/facility/assets/my-rooms/${id}/history`,
        create: "management-service/v2/api/public/facility/assets",
        detail: (id) =>
          `management-service/v2/api/public/facility/assets/${id}`,
        update: (id) =>
          `management-service/v2/api/public/facility/assets/${id}`,
        delete: (id) =>
          `management-service/v2/api/public/facility/assets/${id}`,
        ids: "management-service/v2/api/public/facility/assets/ids",
        history: (id) =>
          `management-service/v2/api/public/facility/assets/${id}/history`,
        exportCodes:
          "management-service/v2/api/public/facility/assets/export-codes",
        export: "management-service/v2/api/public/facility/assets/export",
        transfer: "management-service/v2/api/public/facility/assets/transfer",
        proposeDispose:
          "management-service/v2/api/public/facility/disposal-proposals",
      },
      transfers: {
        create: "management-service/v2/api/public/facility/transfers",
      },
      disposalProposals: {
        list: "management-service/v2/api/public/facility/disposal-proposals",
        create:
          "management-service/v2/api/public/facility/disposal-proposals",
        detail: (id) =>
          `management-service/v2/api/public/facility/disposal-proposals/${id}`,
        submit: (id) =>
          `management-service/v2/api/public/facility/disposal-proposals/${id}/submit`,
        decide: (id) =>
          `management-service/v2/api/public/facility/disposal-proposals/${id}/decide`,
      },
      restoreProposals: {
        list: "management-service/v2/api/public/facility/restore-proposals",
        create: "management-service/v2/api/public/facility/restore-proposals",
        detail: (id) =>
          `management-service/v2/api/public/facility/restore-proposals/${id}`,
        submit: (id) =>
          `management-service/v2/api/public/facility/restore-proposals/${id}/submit`,
        decide: (id) =>
          `management-service/v2/api/public/facility/restore-proposals/${id}/decide`,
      },
      borrows: {
        available:
          "management-service/v2/api/public/facility/borrows/available",
        create: "management-service/v2/api/public/facility/borrows",
        mine: "management-service/v2/api/public/facility/borrows/mine",
        return: (id) =>
          `management-service/v2/api/public/facility/borrows/${id}/return`,
      },
      activityLogs: {
        list: "management-service/v2/api/public/facility/activity-logs",
      },
      repairTickets: {
        list: "management-service/v2/api/public/facility/repair-tickets",
        mine: "management-service/v2/api/public/facility/repair-tickets/mine",
        myRooms:
          "management-service/v2/api/public/facility/repair-tickets/my-rooms",
        create: "management-service/v2/api/public/facility/repair-tickets",
        detail: (id) =>
          `management-service/v2/api/public/facility/repair-tickets/${id}`,
        update: (id) =>
          `management-service/v2/api/public/facility/repair-tickets/${id}`,
        delete: (id) =>
          `management-service/v2/api/public/facility/repair-tickets/${id}`,
        decideItems: (ticketId) =>
          `management-service/v2/api/public/facility/repair-tickets/${ticketId}/items/decide`,
        resubmitItem: (ticketId, itemId) =>
          `management-service/v2/api/public/facility/repair-tickets/${ticketId}/items/${itemId}/resubmit`,
        expectedDate: (ticketId, itemId) =>
          `management-service/v2/api/public/facility/repair-tickets/${ticketId}/items/${itemId}/expected-date`,
        completeItem: (ticketId, itemId) =>
          `management-service/v2/api/public/facility/repair-tickets/${ticketId}/items/${itemId}/complete`,
        uploadFile: (ticketId, itemId) =>
          `management-service/v2/api/public/facility/repair-tickets/${ticketId}/items/${itemId}/files`,
        downloadFile: (ticketId, itemId, fileId) =>
          `management-service/v2/api/public/facility/repair-tickets/${ticketId}/items/${itemId}/files/${fileId}/download`,
      },
    },
  },
  classRooms: {
    attendance: {
      list: "management-service/v2/api/public/attendance",
      create: "management-service/v2/api/public/attendance",
      update: (id) => `management-service/v2/api/public/attendance/${id}`,
      delete: (id) => `management-service/v2/api/public/attendance/${id}`,
      statistics: "management-service/v2/api/public/attendance/statistics",
      history: "management-service/v2/api/public/attendance/history",
      generateQrCode:
        "management-service/v2/api/public/attendance/generate-qr-code",
    },
    list: "management-service/v2/api/public/classrooms",
    listByTeacher: (teacherId) =>
      `management-service/v2/api/public/classrooms/teacher/${teacherId}`,
    create: "management-service/v2/api/public/classrooms",
    update: (id) => `management-service/v2/api/public/classrooms/${id}`,
    detail: (id) => `management-service/v2/api/public/classrooms/${id}`,
    delete: (id) => `management-service/v2/api/public/classrooms/${id}`,
  },
  configImports: {
    partyMembers: {
      import: "management-service/v2/api/public/party-members/import",
      downloadTemplate:
        "management-service/v2/api/public/party-members/download-template",
    },
    timetable: {
      validate: "management-service/v2/api/public/tkb/import/validate",
      commit: "management-service/v2/api/public/tkb/import/commit",
    },
  },
  dashboard: {
    summary: "management-service/v2/api/public/dashboard",
    partyMemberReport:
      "management-service/v2/api/public/dashboard/party-member-report",
    partyMemberReportExportWord:
      "management-service/v2/api/public/dashboard/party-member-report/export-word",
    partyMemberReportExportExcel:
      "management-service/v2/api/public/dashboard/party-member-report/export-excel",
    teacherByDepartment:
      "management-service/v2/api/public/dashboard/teacher-by-department",
    teacherEduLevel:
      "management-service/v2/api/public/dashboard/teacher-edu-level",
    scoreReport: "management-service/v2/api/public/dashboard/score-report",
    scoreReportExportWord:
      "management-service/v2/api/public/dashboard/score-report/export-word",
    scoreReportExportExcel:
      "management-service/v2/api/public/dashboard/score-report/export-excel",
    personnelReport:
      "management-service/v2/api/public/dashboard/personnel-report",
    personnelReportExportWord:
      "management-service/v2/api/public/dashboard/personnel-report/export-word",
    personnelReportExportExcel:
      "management-service/v2/api/public/dashboard/personnel-report/export-excel",
    facilityReport:
      "management-service/v2/api/public/dashboard/facility-report",
    facilityReportExportWord:
      "management-service/v2/api/public/dashboard/facility-report/export-word",
    facilityReportExportExcel:
      "management-service/v2/api/public/dashboard/facility-report/export-excel",
    exportWord: "management-service/v2/api/public/dashboard/export-word",
    exportExcel: "management-service/v2/api/public/dashboard/export-excel",
    query: "management-service/v2/api/public/dashboard/query",
    schoolsByWard: "management-service/v2/api/api/report/schools",
    students: "management-service/v2/api/api/report/students",
    staff: "management-service/v2/api/api/report/staff",
    schoolType: "management-service/v2/api/public/dashboard/school-type",
    educationPlan: "management-service/v2/api/public/dashboard/education-plan",
    educationPlanSchools:
      "management-service/v2/api/public/dashboard/education-plan-schools",
    studentByLevel:
      "management-service/v2/api/public/dashboard/student-by-level",
    studentBySchoolType:
      "management-service/v2/api/public/dashboard/student-by-school-type",
  },
  core: {
    districts: {
      listAll: "management-service/v2/api/public/districts/find-all",
    },
    teachers: {
      listAll: "management-service/v2/api/public/teachers",
    },
  },
  studentService: {
    timetable: {
      getTimetable: `management-service/v2/api/student/me/tkb`,
    },
    examSchedule: {
      getExamSchedule: `management-service/v2/api/student/me/exam-schedules`,
    },
    score: {
      getScores: "management-service/v2/api/student/me/scores",
      getScoreTypes: "https://ticketkd.com/api/v1/scores/types",
    },
    excellentContest: {
      listContestForStudent:
        "management-service/v2/api/public/excellent-student-contest/list-contest-for-student",
      myRegistered:
        "management-service/v2/api/public/excellent-student-contest/my-registered-contests",
      infoStudent:
        "management-service/v2/api/public/excellent-student-contest/find-student-account-id",
      register: (id) =>
        `management-service/v2/api/public/excellent-student-contest/${id}/register`,
      cancelRegistration: (id) =>
        `management-service/v2/api/public/excellent-student-contest/${id}/cancel`,
    },
    assignments: {
      list: "management-service/v2/api/student/assignments",
      detail: (id) => `management-service/v2/api/student/assignments/${id}`,
      uploadFile: (id) =>
        `management-service/v2/api/student/assignments/${id}/files`,
      deleteFile: (assignmentId, fileId) =>
        `management-service/v2/api/student/assignments/${assignmentId}/files/${fileId}`,
    },
  },
  teacherService: {
    taskCategory: {
      list: "management-service/v2/api/public/teacher-task-categories",
      create: "management-service/v2/api/public/teacher-task-categories",
      update: (id) =>
        `management-service/v2/api/public/teacher-task-categories/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/teacher-task-categories/${id}`,
    },
    task: {
      list: "management-service/v2/api/public/teacher-tasks/assigned",
      create: "management-service/v2/api/public/teacher-tasks",
      update: (id) =>
        `management-service/v2/api/public/teacher-tasks/${id}/update`,
      delete: (id) => `management-service/v2/api/public/teacher-tasks/${id}`,
      detail: (id) =>
        `management-service/v2/api/public/teacher-tasks/${id}/details`,
      assigned: "management-service/v2/api/public/teacher-tasks/assigned",
      received: "management-service/v2/api/public/teacher-tasks/received",
      accept: (id) =>
        `management-service/v2/api/public/teacher-tasks/${id}/accept`,
      reject: (id) =>
        `management-service/v2/api/public/teacher-tasks/${id}/reject`,
      inProgress: (id) =>
        `management-service/v2/api/public/teacher-tasks/${id}/in-progress-task`,
      complete: (id) =>
        `management-service/v2/api/public/teacher-tasks/${id}/complete-task`,
    },
    emulationCriteria: {
      list: "management-service/v2/api/public/teacher-emulation-criteria",
      create: "management-service/v2/api/public/teacher-emulation-criteria",
      update: (id) =>
        `management-service/v2/api/public/teacher-emulation-criteria/${id}`,
      delete: (id) =>
        `management-service/v2/api/public/teacher-emulation-criteria/${id}`,
    },
    emulationScore: {
      summaryByCriteriaTop10:
        "management-service/v2/api/public/teacher-emulation-scores/summary/by-criteria-top-10",
      summaryByCriteria:
        "management-service/v2/api/public/teacher-emulation-scores/summary/by-criteria",
    },
    teacher: {
      list: "management-service/v2/api/public/teachers",
    },
    class: {
      list: "management-service/v2/api/classes",
      pushQI: "management-service/v2/api/public/api/scores/push",
      scoreFinal: "management-service/v2/api/public/api/scores/final",
      scoreDraft: "management-service/v2/api/public/api/scores/draft",
      detail: (id) => `management-service/v2/api/classes/${id}`,
      me: "management-service/v2/api/teacher/me/class",
    },
    timetable: {
      homeroomTkb: "management-service/v2/api/teacher/me/homeroom-tkb",
    },
    score: {
      save: "management-service/v2/api/teacher/scores",
    },
    notifications: {
      list: "management-service/v2/api/public/notifications",
      detail: (id) =>
        `management-service/v2/api/public/notifications/${id}`,
      unreadCount:
        "management-service/v2/api/public/notifications/unread-count",
      markAsRead: (id) =>
        `management-service/v2/api/public/notifications/${id}/read`,
      markAllAsRead:
        "management-service/v2/api/public/notifications/read-all",
    },
    /** @deprecated dùng notifications */
    announcement: {
      unreadCount:
        "management-service/v2/api/public/notifications/unread-count",
      list: "management-service/v2/api/public/notifications",
      detail: (id) =>
        `management-service/v2/api/public/notifications/${id}`,
      markAsRead: (id) =>
        `management-service/v2/api/public/notifications/${id}/read`,
    },
  },
};

export default urlApi;
