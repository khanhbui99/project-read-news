export { default as ApproveScoringBGH } from './ApproveScoring'
export { default as LockInputScoreBGH } from './LockInputScore'
