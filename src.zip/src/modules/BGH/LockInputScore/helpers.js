import uniq from "lodash/uniq";

export const LOCK_SCOPE = {
  CLASS: "CLASS",
  GRADE: "GRADE",
  SCHOOL: "SCHOOL",
};

export const ALL_GRADE_CHIP = { id: "", className: "Theo khối" };

export const LOCKED_COLUMNS_ALL = [
  "oral1",
  "oral2",
  "oral3",
  "oral4",
  "midterm",
  "finalTerm",
];

export const groupClassesByGrade = (classes = [], academicYearId) => {
  const gradeMap = {};

  classes
    .filter((cls) => cls?.schoolYearId === academicYearId)
    .forEach((cls) => {
      const gradeId = cls?.grade;
      if (!gradeId) return;

      if (!gradeMap[gradeId]) {
        gradeMap[gradeId] = [];
      }

      gradeMap[gradeId].push(cls.id);
    });

  return Object.entries(gradeMap).map(([gradeId, classIds]) => ({
    gradeId,
    classIds,
  }));
};

export const buildBulkGradeGroups = ({
  scope,
  academicYearId,
  gradeId,
  classId,
  classes = [],
  classByGradeId = [],
}) => {
  if (scope === LOCK_SCOPE.SCHOOL) {
    return groupClassesByGrade(classes, academicYearId);
  }

  if (scope === LOCK_SCOPE.GRADE) {
    return [
      {
        gradeId,
        classIds: classByGradeId.map((cls) => cls?.id).filter(Boolean),
      },
    ];
  }

  return [
    {
      gradeId,
      classIds: classId ? [classId] : [],
    },
  ];
};

export const initLockInputScoreSubj = (
  subjects = [],
  data = [],
  totalClass = 1,
) => {
  const mappingDataSubject = {};

  data.forEach((_scr) => {
    if (!mappingDataSubject[_scr?.subjectId]) {
      mappingDataSubject[_scr?.subjectId] = {
        oral1: [],
        oral2: [],
        oral3: [],
        oral4: [],
        midterm: [],
        finalTerm: [],
      };
    }

    if (_scr?.lockedColumns?.includes("oral1")) {
      mappingDataSubject[_scr?.subjectId].oral1.push(_scr?.id);
    }
    if (_scr?.lockedColumns?.includes("oral2")) {
      mappingDataSubject[_scr?.subjectId].oral2.push(_scr?.id);
    }
    if (_scr?.lockedColumns?.includes("oral3")) {
      mappingDataSubject[_scr?.subjectId].oral3.push(_scr?.id);
    }
    if (_scr?.lockedColumns?.includes("oral4")) {
      mappingDataSubject[_scr?.subjectId].oral4.push(_scr?.id);
    }
    if (_scr?.lockedColumns?.includes("midterm")) {
      mappingDataSubject[_scr?.subjectId].midterm.push(_scr?.id);
    }
    if (_scr?.lockedColumns?.includes("finalTerm")) {
      mappingDataSubject[_scr?.subjectId].finalTerm.push(_scr?.id);
    }
  });

  let dataInit = [];

  dataInit = subjects.map((_s) => {
    const item = mappingDataSubject[_s?.id];
    return {
      ..._s,
      oral1: item?.oral1?.length === totalClass,
      oral2: item?.oral2?.length === totalClass,
      oral3: item?.oral3?.length === totalClass,
      oral4: item?.oral4?.length === totalClass,
      midterm: item?.midterm?.length === totalClass,
      finalTerm: item?.finalTerm?.length === totalClass,
    };
  });

  return dataInit;
};

export const mappingLockedColumns = (item = {}, subjectId, columnName) => {
  const _i = { ...item };
  const val = [];

  if (item?.id === subjectId && columnName) {
    _i[columnName] = !item[columnName];
  }

  if (_i?.oral1) val.push("oral1");
  if (_i?.oral2) val.push("oral2");
  if (_i?.oral3) val.push("oral3");
  if (_i?.oral4) val.push("oral4");
  if (_i?.midterm) val.push("midterm");
  if (_i?.finalTerm) val.push("finalTerm");

  return uniq(val);
};
