import LockOpenOutlinedIcon from "@mui/icons-material/LockOpenOutlined";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { Button, Stack } from "@mui/material";
import {
  getAllClassesAction,
  getExamPeriodCategoryAction,
  lockStatusQIAction,
} from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import React, { useEffect, useState } from "react";
import { VPB_THEMES } from "utils/configs";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import Filtter from "./components/Filter";
import ModalLockAndUnLock from "./components/ModalLockAndUnLock";
import ScoreLock from "./components/ScoreLock";
import { LOCK_SCOPE } from "./helpers";
import {
  lockOrUnLockQIAction,
  resetStoreSubjectAction,
  scoreColumnLockBulkAction,
  unLockScoreBulkAction,
} from "./store/actions";
import { key } from "./store/constants";

const Main = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchAllClasses = useDispatchRedux(getAllClassesAction);
  const fetchLockStatusQI = useDispatchRedux(lockStatusQIAction);
  const rqLockOrUnLockQI = useDispatchRedux(lockOrUnLockQIAction);
  const rqScoreColumnLockBulk = useDispatchRedux(scoreColumnLockBulkAction);
  const rqUnLockScoreBulk = useDispatchRedux(unLockScoreBulkAction);

  const resetSubjectStore = useDispatchRedux(resetStoreSubjectAction);

  const lockedQI = useOneState(injectKey.GLOBAL, "lockedQI", true);
  const examPeriodCategory = useOneState(
    injectKey.GLOBAL,
    "examPeriodCategory",
    {},
  );
  const filter = useOneState(key, "filter", {});

  const [schoolConfirmOpen, setSchoolConfirmOpen] = useState(false);
  const [schoolConfirmMode, setSchoolConfirmMode] = useState("LOCK");

  const canSchoolBulk = Boolean(filter?.academicYearId && filter?.semesterId);

  useEffect(() => {
    fetchAllClasses();
    fetchLockStatusQI();
    fetchExamPeriodCategory();

    return () => {
      resetSubjectStore();
    };
  }, []);

  const handleSchoolBulkConfirm = (mode) => {
    setSchoolConfirmMode(mode);
    setSchoolConfirmOpen(true);
  };

  const handleConfirmSchoolBulk = () => {
    const payload = {
      data: examPeriodCategory?.subjects || [],
      scope: LOCK_SCOPE.SCHOOL,
      academicYearId: filter.academicYearId,
      semesterId: filter.semesterId,
    };

    if (schoolConfirmMode === "LOCK") {
      rqScoreColumnLockBulk(payload);
      return;
    }

    rqUnLockScoreBulk(payload);
  };

  return (
    <React.Fragment>
      <AppHeader
        componentName="LockInputScoreBGH"
        externalBtn={
          <Stack direction="row" spacing={1} alignItems="center">
            <Button
              variant="outlined"
              disabled={!canSchoolBulk}
              sx={{ height: 40, fontSize: 14 }}
              onClick={() => handleSchoolBulkConfirm("UN_LOCK")}
            >
              <LockOpenOutlinedIcon style={{ fontSize: 15, marginRight: 5 }} />
              Mở khoá toàn trường
            </Button>
            <Button
              variant="outlined"
              color="warning"
              disabled={!canSchoolBulk}
              sx={{ height: 40, fontSize: 14 }}
              onClick={() => handleSchoolBulkConfirm("LOCK")}
            >
              <LockOutlinedIcon style={{ fontSize: 15, marginRight: 5 }} />
              Khoá toàn trường
            </Button>
            <Button
              type="submit"
              variant="contained"
              sx={{
                height: 40,
                fontSize: 14,
                background: lockedQI
                  ? VPB_THEMES.colors.brightOrange
                  : VPB_THEMES.gradient[1],
              }}
              onClick={rqLockOrUnLockQI}
            >
              {lockedQI ? (
                <LockOpenOutlinedIcon style={{ fontSize: 15, marginRight: 5 }} />
              ) : (
                <LockOutlinedIcon style={{ fontSize: 15, marginRight: 5 }} />
              )}
              {lockedQI ? "Mở khoá nhập điểm QI" : "Khoá nhập điểm QI"}
            </Button>
          </Stack>
        }
      />

      <ModalLockAndUnLock
        open={schoolConfirmOpen}
        onClose={() => setSchoolConfirmOpen(false)}
        onConfirm={handleConfirmSchoolBulk}
        mode={schoolConfirmMode}
        bulkScope={LOCK_SCOPE.SCHOOL}
      />

      <Filtter
        gradeOpt={examPeriodCategory?.grades}
        semesters={examPeriodCategory?.semesters}
        academicYearOpt={examPeriodCategory?.academicYears}
      />

      <ScoreLock subjects={examPeriodCategory?.subjects} />
    </React.Fragment>
  );
};

export default Main;
