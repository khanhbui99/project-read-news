import {
  covertNumber,
  genScoreByType,
} from "modules/GiamThi/BaoCaoXemDiem/helpers";
import { SUBJECT_TYPE_MAPPING } from "utils/constants";

export const mappingTeachingForBGH = (
  item,
  classesOpt,
  teachersOpt,
  examPeriodCategory,
) => {
  if (!item) return null;

  const {
    subjects = [],
    semesters = [],
    academicYears = [],
  } = examPeriodCategory;

  const className =
    classesOpt.find((cls) => cls.id === item.classId)?.className || "";
  const teacherName =
    teachersOpt.find((_t) => _t.accountId === item.requestedBy)?.fullName || "";
  const subjectName =
    subjects.find((_s) => _s.id === item.subjectId)?.name || "";
  const semesterName =
    semesters.find((s) => s.id === item.semesterId)?.name || "";
  const schoolYearName =
    academicYears.find((year) => year.id === item.schoolYearId)?.name || "";

  return {
    ...item,
    className,
    teacherName,
    subjectName,
    schoolYearName,
    semesterName: semesterName ? `HK ${semesterName}` : "",
  };
};

export const initValueTable = (
  students = [],
  scoreFinal = [],
  typeSubject = "",
) => {
  if (!students || !students.length) return [];

  const result = [];
  const scoreFinalMap = {};

  // Create a map for quick lookup of scoreFinal by studentId
  if (Array.isArray(scoreFinal) && scoreFinal?.length > 0) {
    scoreFinal.forEach((final) => {
      scoreFinalMap[final.studentId] = {
        oral1: covertNumber(final.oral1),
        oral2: covertNumber(final.oral2),
        oral3: covertNumber(final.oral3),
        oral4: covertNumber(final.oral4),
        midterm: covertNumber(final.midterm),
        finalTerm: covertNumber(final.finalTerm),
        total: genScoreByType(typeSubject, final),
      };
    });
  }

  // mapping students to hocSinh structure, and merge scoreDraft data
  if (Array.isArray(students) && students?.length) {
    students.forEach((_s) => {
      const item = {
        ..._s,
        ...scoreFinalMap[_s?.id],
      };

      if (typeSubject === SUBJECT_TYPE_MAPPING.LOAI_3.type) {
        item.oral1 = item.oral1 == 0 ? "CĐ" : item.oral1 == 10 ? "Đ" : null;
        item.oral2 = item.oral2 == 0 ? "CĐ" : item.oral2 == 10 ? "Đ" : null;
        item.midterm =
          item.midterm == 0 ? "CĐ" : item.midterm == 10 ? "Đ" : null;
        item.finalTerm =
          item.finalTerm == 0 ? "CĐ" : item.finalTerm == 10 ? "Đ" : null;
      }

      result.push(item);
    });
  }

  return {
    students: result,
  };
};
