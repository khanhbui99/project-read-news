import AppHeader from "components/common/AppHeader";
import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import ModalApprove from "./components/ModalApprove";
import ModalReject from "./components/ModalReject";
import Table from "./components/Table";
import {
  queryLeaveRequestAction,
  resetStoreLeaveRequestAction,
} from "./store/actions";

const Main = () => {
  const fetchLeaveRequestList = useDispatchRedux(queryLeaveRequestAction);
  const resetLeaveRequestStore = useDispatchRedux(resetStoreLeaveRequestAction);

  useEffect(() => {
   fetchLeaveRequestList();

    // Cleanup function to reset the store when unmounting
    return () => {
      resetLeaveRequestStore();
    };
  }, []);

  return (
    <React.Fragment>
      <AppHeader
        componentName="ApproveScoringBGH"
        isHiddenBtn
      />

      <Table />

      <ModalApprove />
      <ModalReject />
    </React.Fragment>
  );
};

export default Main;
