import dayjs from "dayjs";
import { DateFormat4 } from "utils/constants";

import { TASK_STATUS_MAP } from "./saga/constants";

const normalizeText = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase();

export const stripHtml = (value) => {
  if (!value) return "";
  return String(value)
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
};

export const formatDueDate = (value) => {
  if (!value) return "";
  if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return value;
  }
  const date = dayjs(value);
  return date.isValid() ? date.format("YYYY-MM-DD") : "";
};

export const formatDueDateDisplay = (value) => {
  if (!value) return "—";
  const date = dayjs(value);
  return date.isValid() ? date.format(DateFormat4) : "—";
};

export const getTaskStatusLabel = (status) =>
  TASK_STATUS_MAP[status] || status || "—";

export const truncateText = (value, max = 100) => {
  const text = stripHtml(value);
  if (!text) return "—";
  return text.length > max ? `${text.substring(0, max)}...` : text;
};

export const uniqueNameOptions = (items = [], field) => {
  const seen = new Set();
  const options = [];

  items.forEach((item) => {
    const label = String(item?.[field] ?? "").trim();
    if (!label || seen.has(label)) return;
    seen.add(label);
    options.push({ value: label, label });
  });

  return options.sort((a, b) => a.label.localeCompare(b.label, "vi"));
};

export const uniqueCategoryOptions = (items = []) => {
  const seen = new Set();
  const options = [];

  items.forEach((item) => {
    const value = item?.taskCategoryId ?? item?.taskCategoryName;
    const label = item?.taskCategoryName || String(value ?? "");
    if (value == null || value === "" || seen.has(String(value))) return;
    seen.add(String(value));
    options.push({ value: String(value), label });
  });

  return options.sort((a, b) => a.label.localeCompare(b.label, "vi"));
};

export const filterTasksLocal = (items = [], filter = {}, personField) => {
  const categoryId = filter.categoryId;
  const person = filter.person;
  const status = filter.status;
  const dueDate = formatDueDate(filter.dueDate);
  const keyword = normalizeText(filter.keyword);

  return items.filter((item) => {
    if (categoryId) {
      const itemCategory = String(
        item.taskCategoryId ?? item.taskCategoryName ?? "",
      );
      if (itemCategory !== String(categoryId)) return false;
    }

    if (person && personField) {
      if (String(item[personField] ?? "") !== String(person)) return false;
    }

    if (status && item.status !== status) return false;

    if (dueDate && formatDueDate(item.dueDate) !== dueDate) return false;

    if (keyword) {
      const haystack = [
        item.taskCategoryName,
        item.userAssignee,
        item.userAssigner,
        stripHtml(item.content),
        getTaskStatusLabel(item.status),
      ]
        .map(normalizeText)
        .join(" ");
      if (!haystack.includes(keyword)) return false;
    }

    return true;
  });
};

export const filterCategoriesLocal = (items = [], filter = {}) => {
  const keyword = normalizeText(filter.keyword);
  if (!keyword) return items;

  return items.filter((item) => {
    const haystack = [item.code, item.name, item.description]
      .map(normalizeText)
      .join(" ");
    return haystack.includes(keyword);
  });
};
