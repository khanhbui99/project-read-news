import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

const STATUS_COLORS = {
  ASSIGNED: {
    color: VPB_THEMES.colors.primaryBlue,
    background: VPB_THEMES.colors.f0f9ff,
  },
  ACCEPTED: {
    color: VPB_THEMES.colors.statusActiveText,
    background: VPB_THEMES.colors.statusActiveBg,
  },
  IN_PROGRESS: {
    color: VPB_THEMES.colors.statusMaintenanceText,
    background: VPB_THEMES.colors.statusMaintenanceBg,
  },
  COMPLETED: {
    color: VPB_THEMES.colors.green,
    background: VPB_THEMES.colors.f0fdf4,
  },
  REJECTED: {
    color: VPB_THEMES.colors.statusInactiveText,
    background: VPB_THEMES.colors.statusInactiveBg,
  },
};

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  min-height: calc(100vh - 140px);
  margin-top: 16px;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  min-height: 0;
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: hidden;
`;

export const FilterGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 12px;

  > *:not(.filter-actions) {
    flex: 1 1 160px;
    min-width: 140px;
    max-width: 280px;
  }

  .filter-actions {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 0;
  }
`;

export const StatusChip = styled.span`
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
  color: ${({ $status }) =>
    STATUS_COLORS[$status]?.color || VPB_THEMES.colors.textLight};
  background: ${({ $status }) =>
    STATUS_COLORS[$status]?.background || VPB_THEMES.colors.lightBg};
`;

export const ModalWrap = styled.div`
  width: 680px;
  max-width: 100%;
  box-sizing: border-box;
  font-family: SVN_Gilroy, sans-serif;
`;

export const DetailGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
  margin-bottom: 12px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const DetailBlock = styled.div`
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.lightBg};
`;

export const DetailLabel = styled.div`
  margin-bottom: 6px;
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const DetailValue = styled.div`
  font-size: 14px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;
`;

export const ContentBox = styled.div`
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
  min-height: 120px;
  font-size: 14px;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;

  p {
    margin: 0 0 8px;

    &:last-child {
      margin-bottom: 0;
    }
  }
`;

export const RejectBlock = styled.div`
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.statusInactiveBg};
  background: ${VPB_THEMES.colors.statusInactiveBg};
  margin-top: 12px;
`;

export const RejectTitle = styled.div`
  margin-bottom: 6px;
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.statusInactiveText};
  font-family: SVN_Gilroy, sans-serif;
`;

export const RejectText = styled.div`
  font-size: 14px;
  color: ${VPB_THEMES.colors.statusInactiveText};
  font-family: SVN_Gilroy, sans-serif;
`;

export const HeaderStatusRow = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 8px;
`;
