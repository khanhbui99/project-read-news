import { useChat } from "./useChat";

export const useMessage = () => {
  const chat = useChat();
  return {
    messages: chat.messages || [],
    hasMore: chat.hasMoreOlder === true,
    loading: chat.loading?.messages === true,
    loadingOlder: chat.loading?.loadingOlder === true,
    sending: chat.loading?.sending === true,
    watermark: chat.readWatermark,
    currentConversation: chat.currentConversation,
    loadOlder: chat.loadOlderMessages,
    sendMessage: chat.sendMessage,
  };
};

export default useMessage;
