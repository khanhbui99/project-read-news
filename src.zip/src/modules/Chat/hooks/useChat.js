import { useCallback } from "react";
import { useDispatch, useSelector } from "react-redux";
import { createStructuredSelector } from "reselect";

import {
  CONTACT_FILTER_PAGE,
  CONVERSATION_FILTER_PAGE,
  SEARCH_DEBOUNCE_MS,
} from "../store/constants";
import {
  createPrivateConversationAction,
  disconnectSocketAction,
  initChatAction,
  loadOlderMessagesAction,
  queryMessagesAction,
  sendMessageAction,
  setFieldValueStoreChatAction,
} from "../store/actions";
import {
  makeSelectContactDialogOpen,
  makeSelectContactKeyword,
  makeSelectConversationKeyword,
  makeSelectConversationTab,
  makeSelectCurrentConversation,
  makeSelectHasMoreOlder,
  makeSelectLoading,
  makeSelectMessages,
  makeSelectPendingFile,
  makeSelectReadWatermark,
  makeSelectSocketState,
  makeSelectVisibleContacts,
  makeSelectVisibleConversations,
} from "../store/selectors";
import chatService from "../services/chatService";

const stateSelector = createStructuredSelector({
  visibleConversations: makeSelectVisibleConversations(),
  visibleContacts: makeSelectVisibleContacts(),
  messages: makeSelectMessages(),
  currentConversation: makeSelectCurrentConversation(),
  loading: makeSelectLoading(),
  socket: makeSelectSocketState(),
  contactDialogOpen: makeSelectContactDialogOpen(),
  conversationKeyword: makeSelectConversationKeyword(),
  contactKeyword: makeSelectContactKeyword(),
  conversationTab: makeSelectConversationTab(),
  pendingFile: makeSelectPendingFile(),
  readWatermark: makeSelectReadWatermark(),
  hasMoreOlder: makeSelectHasMoreOlder(),
});

export const useChat = () => {
  const dispatch = useDispatch();
  const state = useSelector(stateSelector);

  const initChat = useCallback(() => {
    dispatch(initChatAction());
  }, [dispatch]);

  const cleanupChat = useCallback(() => {
    dispatch(disconnectSocketAction());
  }, [dispatch]);

  const setConversationKeyword = useCallback(
    (keyword) => {
      dispatch(setFieldValueStoreChatAction("conversationKeyword", keyword));
      dispatch(
        setFieldValueStoreChatAction(
          "conversationVisibleCount",
          CONVERSATION_FILTER_PAGE,
        ),
      );
    },
    [dispatch],
  );

  const setContactKeyword = useCallback(
    (keyword) => {
      dispatch(setFieldValueStoreChatAction("contactKeyword", keyword));
      dispatch(
        setFieldValueStoreChatAction(
          "contactVisibleCount",
          CONTACT_FILTER_PAGE,
        ),
      );
    },
    [dispatch],
  );

  const setConversationTab = useCallback(
    (tab) => {
      dispatch(setFieldValueStoreChatAction("conversationTab", tab));
      dispatch(
        setFieldValueStoreChatAction(
          "conversationVisibleCount",
          CONVERSATION_FILTER_PAGE,
        ),
      );
    },
    [dispatch],
  );

  const loadMoreConversations = useCallback(() => {
    const next =
      (state.visibleConversations?.items?.length || 0) +
      CONVERSATION_FILTER_PAGE;
    dispatch(setFieldValueStoreChatAction("conversationVisibleCount", next));
  }, [dispatch, state.visibleConversations?.items?.length]);

  const loadMoreContacts = useCallback(() => {
    const next =
      (state.visibleContacts?.items?.length || 0) + CONTACT_FILTER_PAGE;
    dispatch(setFieldValueStoreChatAction("contactVisibleCount", next));
  }, [dispatch, state.visibleContacts?.items?.length]);

  const selectConversation = useCallback(
    (conversation) => {
      if (conversation?.id == null) return;
      dispatch(queryMessagesAction({ conversationId: conversation.id }));
    },
    [dispatch],
  );

  const loadOlderMessages = useCallback(() => {
    dispatch(loadOlderMessagesAction());
  }, [dispatch]);

  const openContactDialog = useCallback(() => {
    dispatch(setFieldValueStoreChatAction("contactDialogOpen", true));
  }, [dispatch]);

  const closeContactDialog = useCallback(() => {
    dispatch(setFieldValueStoreChatAction("contactDialogOpen", false));
  }, [dispatch]);

  const startConversationWithContact = useCallback(
    (contact) => {
      const contactId = contact?.accountId;
      if (!contactId) return;
      dispatch(
        createPrivateConversationAction({ otherAccountId: contactId }),
      );
    },
    [dispatch],
  );

  const setPendingFile = useCallback(
    (file) => {
      dispatch(setFieldValueStoreChatAction("pendingFile", file || null));
    },
    [dispatch],
  );

  const sendMessage = useCallback(
    (content) => {
      const conversationId = state.currentConversation?.id;
      if (conversationId == null) return;
      dispatch(
        sendMessageAction({
          conversationId,
          content,
          file: state.pendingFile,
        }),
      );
    },
    [dispatch, state.currentConversation, state.pendingFile],
  );

  const downloadAttachment = useCallback(async (fileUrl, fileName) => {
    await chatService.downloadAttachment(fileUrl, fileName);
  }, []);

  return {
    ...state,
    searchDebounceMs: SEARCH_DEBOUNCE_MS,
    initChat,
    cleanupChat,
    setConversationKeyword,
    setContactKeyword,
    setConversationTab,
    loadMoreConversations,
    loadMoreContacts,
    loadOlderMessages,
    selectConversation,
    openContactDialog,
    closeContactDialog,
    startConversationWithContact,
    setPendingFile,
    sendMessage,
    downloadAttachment,
  };
};

export default useChat;
