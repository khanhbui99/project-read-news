import { useChat } from "./useChat";

export const useSocket = () => {
  const chat = useChat();
  return {
    socket: chat.socket,
    connected: chat.socket?.connected === true,
    reconnecting: chat.socket?.reconnecting === true,
  };
};

export default useSocket;
