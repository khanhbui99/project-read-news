import { useChat } from "./useChat";

export const useConversation = () => {
  const chat = useChat();
  return {
    conversations: chat.visibleConversations?.items || [],
    total: chat.visibleConversations?.total || 0,
    hasMore: chat.visibleConversations?.hasMore === true,
    keyword: chat.conversationKeyword,
    loading: chat.loading?.conversations === true,
    currentConversation: chat.currentConversation,
    setKeyword: chat.setConversationKeyword,
    loadMore: chat.loadMoreConversations,
    selectConversation: chat.selectConversation,
  };
};

export default useConversation;
