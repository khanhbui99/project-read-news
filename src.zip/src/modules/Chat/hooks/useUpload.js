/** Upload chưa có API trong api.md — stub theo task, không call backend. */
export const useUpload = () => ({
  tasks: [],
  uploading: false,
  uploadFile: () => {},
  retryUpload: () => {},
  clearUpload: () => {},
});

export default useUpload;
