export const key = "Chat";

/** Page size messages — khớp chat-tester.html `size=30` */
export const MESSAGE_PAGE_SIZE = 30;

export const CONVERSATION_FILTER_PAGE = 40;
export const CONTACT_FILTER_PAGE = 40;

export const CHAT_WS_PATH = "management-service/v2/api/ws-chat";
export const CHAT_QUEUE_MESSAGES = "/user/queue/chat-messages";
export const CHAT_QUEUE_READ_STATUS = "/user/queue/chat-read-status";

export const SEARCH_DEBOUNCE_MS = 300;
export const CONNECT_LOAD_DELAY_MS = 600;

export const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024;

export const ALLOWED_ATTACHMENT_EXT = [
  "pdf",
  "png",
  "jpg",
  "jpeg",
  "gif",
  "webp",
  "bmp",
];

export const ALLOWED_ATTACHMENT_MIME = [
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/gif",
  "image/webp",
  "image/bmp",
];

export const CONVERSATION_TAB = {
  ALL: "all",
  UNREAD: "unread",
};
