import { createRoutine } from "redux-saga-routines";

import { key } from "./constants";

export const resetStoreChatAction = () => ({
  type: `${key}/RESET_STORE`,
});

export const setFieldValueStoreChatAction = (field, value) => ({
  type: `${key}/SET_FIELD`,
  payload: { field, value },
});

export const queryContactsAction = createRoutine(`${key}/QUERY_CONTACTS`);
export const queryConversationsAction = createRoutine(
  `${key}/QUERY_CONVERSATIONS`,
);
export const createPrivateConversationAction = createRoutine(
  `${key}/CREATE_PRIVATE_CONVERSATION`,
);
export const queryMessagesAction = createRoutine(`${key}/QUERY_MESSAGES`);
export const loadOlderMessagesAction = createRoutine(
  `${key}/LOAD_OLDER_MESSAGES`,
);
export const sendMessageAction = createRoutine(`${key}/SEND_MESSAGE`);

export const receiveSocketMessageAction = (message) => ({
  type: `${key}/RECEIVE_SOCKET_MESSAGE`,
  payload: { message },
});

export const receiveReadStatusAction = (event) => ({
  type: `${key}/RECEIVE_READ_STATUS`,
  payload: { event },
});

export const setSocketStateAction = (socketState) => ({
  type: `${key}/SET_SOCKET_STATE`,
  payload: { socketState },
});

export const markConversationReadLocalAction = (conversationId) => ({
  type: `${key}/MARK_CONVERSATION_READ_LOCAL`,
  payload: { conversationId },
});

export const connectSocketAction = () => ({
  type: `${key}/CONNECT_SOCKET`,
});

export const disconnectSocketAction = () => ({
  type: `${key}/DISCONNECT_SOCKET`,
});

export const initChatAction = () => ({
  type: `${key}/INIT_CHAT`,
});
