import { createSelector } from "reselect";

import {
  getContactVisible,
  getConversationVisible,
} from "../chatHelpers";
import { key } from "./constants";
import { initialState } from "./reducer";

const selectChatDomain = (state) => state[key] || initialState;

export const makeSelectContacts = () =>
  createSelector(selectChatDomain, (state) => state.contacts || []);

export const makeSelectConversations = () =>
  createSelector(selectChatDomain, (state) => state.conversations || []);

export const makeSelectCurrentConversationId = () =>
  createSelector(selectChatDomain, (state) => state.currentConversationId);

export const makeSelectCurrentConversation = () =>
  createSelector(selectChatDomain, (state) => {
    const id = state.currentConversationId;
    if (id == null) return null;
    return (
      (state.conversations || []).find((item) => item.id === id) || null
    );
  });

export const makeSelectMessages = () =>
  createSelector(selectChatDomain, (state) => {
    const id = state.currentConversationId;
    if (id == null) return [];
    return state.messagesByConversation?.[id] || [];
  });

export const makeSelectReadWatermark = () =>
  createSelector(selectChatDomain, (state) => {
    const id = state.currentConversationId;
    if (id == null) return 0;
    return state.readWatermark?.[id] || 0;
  });

export const makeSelectHasMoreOlder = () =>
  createSelector(selectChatDomain, (state) => {
    const id = state.currentConversationId;
    if (id == null) return false;
    return state.hasMoreOlder?.[id] === true;
  });

export const makeSelectConversationTab = () =>
  createSelector(
    selectChatDomain,
    (state) => state.conversationTab || "all",
  );

export const makeSelectVisibleConversations = () =>
  createSelector(selectChatDomain, (state) =>
    getConversationVisible(state.conversations || [], {
      keyword: state.conversationKeyword,
      visibleCount: state.conversationVisibleCount,
      tab: state.conversationTab,
    }),
  );

export const makeSelectVisibleContacts = () =>
  createSelector(selectChatDomain, (state) =>
    getContactVisible(state.contacts || [], {
      keyword: state.contactKeyword,
      visibleCount: state.contactVisibleCount,
    }),
  );

export const makeSelectLoading = () =>
  createSelector(selectChatDomain, (state) => state.loading || {});

export const makeSelectSocketState = () =>
  createSelector(selectChatDomain, (state) => state.socket || {});

export const makeSelectContactDialogOpen = () =>
  createSelector(selectChatDomain, (state) => state.contactDialogOpen === true);

export const makeSelectPendingFile = () =>
  createSelector(selectChatDomain, (state) => state.pendingFile);

export const makeSelectConversationKeyword = () =>
  createSelector(selectChatDomain, (state) => state.conversationKeyword || "");

export const makeSelectContactKeyword = () =>
  createSelector(selectChatDomain, (state) => state.contactKeyword || "");
