import { setMessageByFieldAction } from "App/store/actions";
import { eventChannel, END } from "redux-saga";
import {
  call,
  cancel,
  delay,
  fork,
  put as dispatch,
  select,
  take,
  takeLatest,
} from "redux-saga/effects";
import LocalStorage from "utils/services/service.localStorage";

import { mapMessage, validateAttachmentFile } from "../chatHelpers";
import chatService from "../services/chatService";
import { getSocketManager } from "../services/socketManager";
import * as actions from "./actions";
import { CONNECT_LOAD_DELAY_MS, key } from "./constants";

function* getChatState() {
  return yield select((state) => state[key] || {});
}

function* getCurrentUserId() {
  const store = yield getChatState();
  if (store.currentUserId) return String(store.currentUserId);
  return String(LocalStorage.auth.id() || "");
}

export function* queryContactsSaga() {
  try {
    yield dispatch(actions.queryContactsAction.request());
    const contacts = yield call(chatService.fetchContacts);
    yield dispatch(actions.queryContactsAction.success({ contacts }));
  } catch (err) {
    yield dispatch(actions.queryContactsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* queryConversationsSaga() {
  try {
    yield dispatch(actions.queryConversationsAction.request());
    const conversations = yield call(chatService.fetchConversations);
    yield dispatch(
      actions.queryConversationsAction.success({ conversations }),
    );
  } catch (err) {
    yield dispatch(actions.queryConversationsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* createPrivateConversationSaga({ payload = {} }) {
  try {
    const otherAccountId = payload.otherAccountId || payload.contactId;
    if (!otherAccountId) return;

    yield dispatch(actions.createPrivateConversationAction.request());
    const conversation = yield call(
      chatService.createConversation,
      otherAccountId,
    );
    yield dispatch(
      actions.createPrivateConversationAction.success({ conversation }),
    );
    yield dispatch(
      actions.queryMessagesAction({ conversationId: conversation.id }),
    );
  } catch (err) {
    yield dispatch(actions.createPrivateConversationAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* queryMessagesSaga({ payload = {} }) {
  try {
    const conversationId = payload.conversationId;
    if (conversationId == null) return;

    yield dispatch(actions.queryMessagesAction.request({ conversationId }));
    const messages = yield call(chatService.fetchMessages, conversationId);
    yield dispatch(
      actions.queryMessagesAction.success({ conversationId, messages }),
    );
    // HTML: unread local = 0 khi mở, KHÔNG gọi POST /read lúc open
    yield dispatch(actions.markConversationReadLocalAction(conversationId));
  } catch (err) {
    yield dispatch(actions.queryMessagesAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* loadOlderMessagesSaga({ payload = {} }) {
  try {
    const store = yield getChatState();
    const conversationId =
      payload.conversationId ?? store.currentConversationId;
    if (conversationId == null) return;
    const before = store.oldestLoaded?.[conversationId];
    if (!before) return;

    yield dispatch(actions.loadOlderMessagesAction.request());
    const messages = yield call(
      chatService.fetchOlderMessages,
      conversationId,
      before,
    );
    yield dispatch(
      actions.loadOlderMessagesAction.success({ conversationId, messages }),
    );
  } catch (err) {
    yield dispatch(actions.loadOlderMessagesAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* sendMessageSaga({ payload = {} }) {
  const store = yield getChatState();
  const conversationId =
    payload.conversationId ?? store.currentConversationId;
  const text = String(payload.content ?? payload.message ?? "").trim();
  const file = payload.file ?? store.pendingFile;

  if (conversationId == null) return;
  if (!text && !file) return;

  if (file) {
    const check = validateAttachmentFile(file);
    if (!check.ok) {
      yield dispatch(setMessageByFieldAction("error", check.error));
      return;
    }
  }

  try {
    yield dispatch(actions.sendMessageAction.request());
    const sent = yield call(chatService.sendMessage, conversationId, {
      message: text || null,
      file: file || null,
    });
    yield dispatch(
      actions.sendMessageAction.success({
        conversationId,
        message: sent,
      }),
    );
  } catch (err) {
    yield dispatch(actions.sendMessageAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

function createSocketChannel(socket) {
  return eventChannel((emit) => {
    socket.setHandlers({
      onMessage: (message) => emit({ kind: "message", message }),
      onReadStatus: (event) => emit({ kind: "read", event }),
      onStateChange: (socketState) => emit({ kind: "state", socketState }),
      onError: (error) => emit({ kind: "error", error }),
      onDisconnect: () =>
        emit({ kind: "state", socketState: { connected: false } }),
    });
    socket.connect();

    return () => {
      socket.disconnect();
      emit(END);
    };
  });
}

function* watchSocketChannel() {
  const socket = getSocketManager();
  const channel = yield call(createSocketChannel, socket);

  try {
    while (true) {
      const event = yield take(channel);
      if (!event) continue;

      if (event.kind === "state") {
        yield dispatch(actions.setSocketStateAction(event.socketState));
      }

      if (event.kind === "read" && event.event) {
        yield dispatch(actions.receiveReadStatusAction(event.event));
      }

      if (event.kind === "message" && event.message) {
        const mapped = mapMessage(event.message, { keepApiTime: true });
        const storeBefore = yield getChatState();
        const prevList =
          storeBefore.messagesByConversation?.[mapped.conversationId] || [];
        const isNew = !prevList.some((m) => m.id === mapped.id);
        const existedConv = (storeBefore.conversations || []).some(
          (c) => c.id === mapped.conversationId,
        );

        yield dispatch(actions.receiveSocketMessageAction(mapped));

        // HTML: active + !mine + isNew → POST /read
        if (
          isNew &&
          !mapped.mine &&
          mapped.conversationId === storeBefore.currentConversationId
        ) {
          try {
            yield call(
              chatService.markConversationRead,
              mapped.conversationId,
            );
          } catch (e) {
            // fire-and-forget như HTML .catch(() => {})
          }
        }

        if (!existedConv) {
          yield dispatch(actions.queryConversationsAction());
        }
      }
    }
  } finally {
    channel.close();
  }
}

let socketTask = null;

export function* connectSocketSaga() {
  const currentUserId = yield getCurrentUserId();
  yield dispatch(
    actions.setFieldValueStoreChatAction("currentUserId", currentUserId),
  );

  if (socketTask) return;
  socketTask = yield fork(watchSocketChannel);
}

export function* disconnectSocketSaga() {
  if (socketTask) {
    yield cancel(socketTask);
    socketTask = null;
  }
  getSocketManager().disconnect();
  yield dispatch(
    actions.setSocketStateAction({
      connected: false,
      reconnecting: false,
    }),
  );
}

/** Khớp HTML connect btn: connect WS → delay 600ms → load conversations + contacts */
export function* initChatSaga() {
  yield dispatch(actions.connectSocketAction());
  yield delay(CONNECT_LOAD_DELAY_MS);
  yield dispatch(actions.queryConversationsAction());
  yield dispatch(actions.queryContactsAction());
}

export default function* chatSaga() {
  yield takeLatest(actions.queryContactsAction, queryContactsSaga);
  yield takeLatest(actions.queryConversationsAction, queryConversationsSaga);
  yield takeLatest(
    actions.createPrivateConversationAction,
    createPrivateConversationSaga,
  );
  yield takeLatest(actions.queryMessagesAction, queryMessagesSaga);
  yield takeLatest(actions.loadOlderMessagesAction, loadOlderMessagesSaga);
  yield takeLatest(actions.sendMessageAction, sendMessageSaga);
  yield takeLatest(`${key}/CONNECT_SOCKET`, connectSocketSaga);
  yield takeLatest(`${key}/DISCONNECT_SOCKET`, disconnectSocketSaga);
  yield takeLatest(`${key}/INIT_CHAT`, initChatSaga);
}
