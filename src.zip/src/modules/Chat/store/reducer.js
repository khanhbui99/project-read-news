import { produce } from "immer";

import {
  addMessageIfNew,
  mapMessage,
  sortConversations,
} from "../chatHelpers";
import {
  CONTACT_FILTER_PAGE,
  CONVERSATION_FILTER_PAGE,
  CONVERSATION_TAB,
  MESSAGE_PAGE_SIZE,
  key,
} from "./constants";
import * as actions from "./actions";

export const initialState = {
  contacts: [],
  conversations: [],
  currentConversationId: null,
  messagesByConversation: {},
  oldestLoaded: {},
  hasMoreOlder: {},
  readWatermark: {},
  pendingFile: null,
  conversationKeyword: "",
  contactKeyword: "",
  conversationTab: CONVERSATION_TAB.ALL,
  conversationVisibleCount: CONVERSATION_FILTER_PAGE,
  contactVisibleCount: CONTACT_FILTER_PAGE,
  contactDialogOpen: false,
  currentUserId: "",
  loading: {
    contacts: false,
    conversations: false,
    messages: false,
    loadingOlder: false,
    sending: false,
    creating: false,
  },
  socket: {
    connected: false,
    reconnecting: false,
    reconnectCount: 0,
    heartbeat: null,
    sessionId: null,
  },
  error: null,
};

const chatReducer = (state = initialState, action = {}) => {
  const { payload = {}, type } = action;

  return produce(state, (draft) => {
    switch (type) {
      case `${key}/RESET_STORE`:
        return { ...initialState };

      case `${key}/SET_FIELD`:
        draft[payload.field] = payload.value;
        break;

      case `${key}/SET_SOCKET_STATE`:
        draft.socket = { ...draft.socket, ...(payload.socketState || {}) };
        break;

      case `${key}/MARK_CONVERSATION_READ_LOCAL`: {
        const conversationId = payload.conversationId;
        const idx = draft.conversations.findIndex(
          (item) => item.id === conversationId,
        );
        if (idx >= 0) draft.conversations[idx].unreadCount = 0;
        break;
      }

      case `${key}/RECEIVE_READ_STATUS`: {
        const evt = payload.event || {};
        const conversationId = evt.conversationId;
        if (conversationId == null) break;
        const prev = Number(draft.readWatermark[conversationId] || 0);
        const next = Number(evt.lastReadMessageId || 0);
        if (next > prev) {
          draft.readWatermark[conversationId] = next;
        }
        break;
      }

      case `${key}/RECEIVE_SOCKET_MESSAGE`: {
        const raw = payload.message || {};
        const msg = mapMessage(raw, { keepApiTime: true });
        const conversationId = msg.conversationId;
        if (conversationId == null || msg.id == null) break;

        const current = draft.messagesByConversation[conversationId] || [];
        const { list, isNew } = addMessageIfNew(current, msg);
        draft.messagesByConversation[conversationId] = list;

        const isActive = draft.currentConversationId === conversationId;
        const idx = draft.conversations.findIndex(
          (c) => c.id === conversationId,
        );

        if (idx >= 0) {
          draft.conversations[idx].lastMessage = msg.message || "[file]";
          if (isNew && !msg.mine && !isActive) {
            draft.conversations[idx].unreadCount =
              Number(draft.conversations[idx].unreadCount || 0) + 1;
          }
        }
        break;
      }

      case actions.queryContactsAction.REQUEST:
        draft.loading.contacts = true;
        break;
      case actions.queryContactsAction.SUCCESS:
        draft.loading.contacts = false;
        draft.contacts = payload.contacts || [];
        draft.contactVisibleCount = CONTACT_FILTER_PAGE;
        break;
      case actions.queryContactsAction.FAILURE:
        draft.loading.contacts = false;
        draft.error = payload;
        break;

      case actions.queryConversationsAction.REQUEST:
        draft.loading.conversations = true;
        break;
      case actions.queryConversationsAction.SUCCESS:
        draft.loading.conversations = false;
        draft.conversations = sortConversations(payload.conversations || []);
        draft.conversationVisibleCount = CONVERSATION_FILTER_PAGE;
        break;
      case actions.queryConversationsAction.FAILURE:
        draft.loading.conversations = false;
        draft.error = payload;
        break;

      case actions.createPrivateConversationAction.REQUEST:
        draft.loading.creating = true;
        break;
      case actions.createPrivateConversationAction.SUCCESS: {
        draft.loading.creating = false;
        const conversation = payload.conversation;
        if (!conversation) break;
        const idx = draft.conversations.findIndex(
          (c) => c.id === conversation.id,
        );
        if (idx >= 0) draft.conversations[idx] = conversation;
        else draft.conversations.unshift(conversation);
        draft.conversations = sortConversations(draft.conversations);
        draft.currentConversationId = conversation.id;
        draft.contactDialogOpen = false;
        break;
      }
      case actions.createPrivateConversationAction.FAILURE:
        draft.loading.creating = false;
        draft.error = payload;
        break;

      case actions.queryMessagesAction.REQUEST:
        draft.loading.messages = true;
        if (payload?.conversationId != null) {
          draft.currentConversationId = payload.conversationId;
        }
        break;
      case actions.queryMessagesAction.SUCCESS: {
        draft.loading.messages = false;
        const conversationId = payload.conversationId;
        const messages = payload.messages || [];
        draft.messagesByConversation[conversationId] = messages;
        draft.oldestLoaded[conversationId] = messages.length
          ? messages[0].id
          : null;
        draft.hasMoreOlder[conversationId] =
          messages.length >= MESSAGE_PAGE_SIZE;
        break;
      }
      case actions.queryMessagesAction.FAILURE:
        draft.loading.messages = false;
        draft.error = payload;
        break;

      case actions.loadOlderMessagesAction.REQUEST:
        draft.loading.loadingOlder = true;
        break;
      case actions.loadOlderMessagesAction.SUCCESS: {
        draft.loading.loadingOlder = false;
        const conversationId = payload.conversationId;
        const older = payload.messages || [];
        if (!older.length) {
          draft.hasMoreOlder[conversationId] = false;
          break;
        }
        const current = draft.messagesByConversation[conversationId] || [];
        const existingIds = new Set(current.map((m) => m.id));
        const uniqueOlder = older.filter((m) => !existingIds.has(m.id));
        draft.messagesByConversation[conversationId] = [
          ...uniqueOlder,
          ...current,
        ];
        draft.oldestLoaded[conversationId] = older[0].id;
        draft.hasMoreOlder[conversationId] =
          older.length >= MESSAGE_PAGE_SIZE;
        break;
      }
      case actions.loadOlderMessagesAction.FAILURE:
        draft.loading.loadingOlder = false;
        break;

      case actions.sendMessageAction.REQUEST:
        draft.loading.sending = true;
        break;
      case actions.sendMessageAction.SUCCESS: {
        draft.loading.sending = false;
        draft.pendingFile = null;
        const { conversationId, message } = payload || {};
        if (conversationId == null || !message) break;
        const current = draft.messagesByConversation[conversationId] || [];
        const { list } = addMessageIfNew(current, message);
        draft.messagesByConversation[conversationId] = list;
        const idx = draft.conversations.findIndex(
          (c) => c.id === conversationId,
        );
        if (idx >= 0) {
          draft.conversations[idx].lastMessage =
            message.message || "[file]";
        }
        break;
      }
      case actions.sendMessageAction.FAILURE:
        draft.loading.sending = false;
        draft.error = payload;
        break;

      default:
        break;
    }
  });
};

export default chatReducer;
