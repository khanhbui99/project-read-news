import loadable from "utils/loadable";

import ChatPageSkeleton from "./components/skeletons";

export const ChatPage = loadable(() => import("./Main"), {
  fallback: <ChatPageSkeleton />,
});
