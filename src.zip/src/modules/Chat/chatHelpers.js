import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";

import {
  ALLOWED_ATTACHMENT_EXT,
  ALLOWED_ATTACHMENT_MIME,
  CONTACT_FILTER_PAGE,
  CONVERSATION_FILTER_PAGE,
  CONVERSATION_TAB,
  MAX_ATTACHMENT_BYTES,
  MESSAGE_PAGE_SIZE,
} from "./store/constants";

dayjs.extend(utc);

/** Parse thời gian chat và hiển thị theo UTC+7 */
export const toChatDayjs = (value) => {
  if (value == null || value === "") return null;
  const raw = String(value).trim();
  // Có Z/offset → giữ absolute time rồi đưa về +7
  // Không có timezone → coi là UTC rồi convert +7
  const hasTz = /[zZ]$|[+-]\d{2}:?\d{2}$/.test(raw);
  const date = hasTz ? dayjs(raw).utcOffset(7) : dayjs.utc(raw).utcOffset(7);
  return date.isValid() ? date : null;
};

export const nowChatDayjs = () => dayjs().utcOffset(7);

const normalizeText = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase();

/** Map Conversation — field theo chat-tester.html */
export const mapConversation = (item = {}) => ({
  id: item.id,
  name: item.name || `Hội thoại ${item.id ?? ""}`,
  lastMessage: item.lastMessage || "",
  unreadCount: Number(item.unreadCount ?? 0) || 0,
  // giữ thêm nếu backend có
  updatedAt: item.updatedAt || item.lastMessageTime || null,
  lastMessageTime: item.lastMessageTime || item.updatedAt || null,
});

/**
 * Map Message — field theo chat-tester.html
 * keepApiTime: tin gửi/nhận realtime → hiển thị giờ như API, không convert +7
 */
export const mapMessage = (item = {}, { keepApiTime = false } = {}) => ({
  id: item.id,
  conversationId: item.conversationId,
  senderId: item.senderId,
  senderName: item.senderName || "",
  message: item.message ?? "",
  mine: item.mine === true,
  createdAt: item.createdAt || null,
  attachmentFileUrl: item.attachmentFileUrl || null,
  attachmentFileName: item.attachmentFileName || null,
  keepApiTime: keepApiTime === true,
});

/** Parse thời gian tin nhắn: lịch sử convert +7, realtime giữ API */
export const parseMessageDayjs = (value, keepApiTime = false) => {
  if (keepApiTime) {
    if (value == null || value === "") return null;
    const date = dayjs(value);
    return date.isValid() ? date : null;
  }
  return toChatDayjs(value);
};

/** Map Contact — field theo chat-tester.html */
export const mapContact = (item = {}) => ({
  accountId: item.accountId,
  fullName: item.fullName || "—",
  role: item.role || "",
  subject: item.subject || "",
  className: item.className || "",
  organization: item.subject || item.className || "",
});

export const getRoleTag = (role) => (role === "TEACHER" ? "GV" : "HS");

export const sortConversations = (items = []) =>
  [...(items || [])].sort((a, b) => {
    const ta = dayjs(a.lastMessageTime || a.updatedAt).valueOf() || 0;
    const tb = dayjs(b.lastMessageTime || b.updatedAt).valueOf() || 0;
    if (ta === tb) return Number(b.id) - Number(a.id);
    return tb - ta;
  });

export const addMessageIfNew = (list = [], msg) => {
  if (!msg?.id && msg?.id !== 0) return { list: list || [], isNew: false };
  if ((list || []).some((m) => m.id === msg.id)) {
    return { list: list || [], isNew: false };
  }
  return { list: [...(list || []), msg], isNew: true };
};

export const filterByKeyword = (items = [], keyword = "", fields = []) => {
  const key = normalizeText(keyword);
  if (!key) return items || [];
  return (items || []).filter((item) =>
    fields.some((field) => normalizeText(item?.[field]).includes(key)),
  );
};

export const getFileExtension = (fileName = "") => {
  const parts = String(fileName).split(".");
  if (parts.length < 2) return "";
  return parts[parts.length - 1].toLowerCase();
};

export const isImageFileName = (fileName = "") => {
  const ext = getFileExtension(fileName);
  return ["png", "jpg", "jpeg", "gif", "webp", "bmp"].includes(ext);
};

export const isPdfFileName = (fileName = "") =>
  getFileExtension(fileName) === "pdf";

/** Validate đính kèm: chỉ PDF/ảnh, ≤10MB — khớp BRD + chat-tester hint */
export const validateAttachmentFile = (file) => {
  if (!file) return { ok: false, error: "Chưa chọn file" };

  if (file.size > MAX_ATTACHMENT_BYTES) {
    return { ok: false, error: "Chỉ chấp nhận file tối đa 10MB" };
  }

  const ext = getFileExtension(file.name);
  const mime = String(file.type || "").toLowerCase();
  const mimeOk = mime && ALLOWED_ATTACHMENT_MIME.includes(mime);
  const extOk = ext && ALLOWED_ATTACHMENT_EXT.includes(ext);

  if (!mimeOk && !extOk) {
    return {
      ok: false,
      error: "Chỉ cho phép file PDF hoặc ảnh (PNG, JPG, GIF, WEBP)",
    };
  }

  // MIME nằm ngoài whitelist dù extension hợp lệ (vd. application/octet-stream) → vẫn cho nếu ext OK
  if (mime && !mimeOk && !extOk) {
    return {
      ok: false,
      error: "Chỉ cho phép file PDF hoặc ảnh (PNG, JPG, GIF, WEBP)",
    };
  }

  return { ok: true, error: null };
};

/** Local filter UI (Zalo search / tab) — không gọi API */
export const getConversationVisible = (
  all = [],
  {
    keyword = "",
    visibleCount = CONVERSATION_FILTER_PAGE,
    tab = CONVERSATION_TAB.ALL,
  } = {},
) => {
  let source = sortConversations(all);
  if (tab === CONVERSATION_TAB.UNREAD) {
    source = source.filter((item) => Number(item.unreadCount || 0) > 0);
  }
  const filtered = filterByKeyword(source, keyword, ["name", "lastMessage"]);
  const count = Math.max(CONVERSATION_FILTER_PAGE, Number(visibleCount) || 0);
  return {
    items: filtered.slice(0, count),
    total: filtered.length,
    hasMore: count < filtered.length,
  };
};

export const formatDateSeparator = (value, keepApiTime = false) => {
  const date = parseMessageDayjs(value, keepApiTime);
  if (!date) return "";
  const now = keepApiTime ? dayjs() : nowChatDayjs();
  const time = date.format("HH:mm");
  if (date.isSame(now, "day")) return `${time} Hôm nay`;
  if (date.isSame(now.subtract(1, "day"), "day")) return `${time} Hôm qua`;
  return date.format("HH:mm DD/MM/YYYY");
};

/** Nhóm tin theo ngày để hiển thị separator kiểu Zalo */
export const buildMessageRows = (messages = []) => {
  const rows = [];
  let lastDay = null;
  (messages || []).forEach((msg) => {
    const keepApiTime = msg.keepApiTime === true;
    const created = parseMessageDayjs(msg.createdAt, keepApiTime);
    const dayKey = created ? created.format("YYYY-MM-DD") : "unknown";
    if (dayKey !== lastDay) {
      rows.push({
        type: "separator",
        id: `sep-${dayKey}-${msg.id}`,
        label: formatDateSeparator(msg.createdAt, keepApiTime),
      });
      lastDay = dayKey;
    }
    rows.push({ type: "message", id: msg.id, message: msg });
  });
  return rows;
};

export const THREAD_FILTER = {
  ALL: "all",
  IMAGE: "image",
  FILE: "file",
};

export const SENDER_FILTER = {
  ALL: "all",
  MINE: "mine",
  THEIRS: "theirs",
};

export const DATE_FILTER = {
  ALL: "all",
  TODAY: "today",
  WEEK: "week",
  MONTH: "month",
};

/** Lọc / tìm trong messages đã load (local) — load thêm thì kết quả mở rộng */
export const filterLoadedMessages = (
  messages = [],
  {
    keyword = "",
    filter = THREAD_FILTER.ALL,
    sender = SENDER_FILTER.ALL,
    date = DATE_FILTER.ALL,
  } = {},
) => {
  const key = normalizeText(keyword);
  const now = dayjs();

  return (messages || []).filter((msg) => {
    const hasFile = Boolean(msg.attachmentFileUrl);
    const fileName = msg.attachmentFileName || "";

    if (filter === THREAD_FILTER.IMAGE) {
      if (!hasFile || !isImageFileName(fileName)) return false;
    }
    if (filter === THREAD_FILTER.FILE) {
      if (!hasFile) return false;
    }

    if (sender === SENDER_FILTER.MINE && !msg.mine) return false;
    if (sender === SENDER_FILTER.THEIRS && msg.mine) return false;

    if (date !== DATE_FILTER.ALL && msg.createdAt) {
      const created = parseMessageDayjs(
        msg.createdAt,
        msg.keepApiTime === true,
      );
      if (!created) return false;
      if (date === DATE_FILTER.TODAY && !created.isSame(now, "day")) return false;
      if (date === DATE_FILTER.WEEK && created.isBefore(now.subtract(7, "day"))) {
        return false;
      }
      if (
        date === DATE_FILTER.MONTH &&
        created.isBefore(now.subtract(30, "day"))
      ) {
        return false;
      }
    }

    if (!key) return true;
    return (
      normalizeText(msg.message).includes(key) ||
      normalizeText(fileName).includes(key)
    );
  });
};

/** Ảnh đính kèm từ messages đã load (mới nhất trước) */
export const getLoadedImages = (messages = []) =>
  [...(messages || [])]
    .reverse()
    .filter(
      (msg) =>
        msg.attachmentFileUrl && isImageFileName(msg.attachmentFileName || ""),
    );

/** File (PDF/khác) từ messages đã load */
export const getLoadedFiles = (messages = []) =>
  [...(messages || [])]
    .reverse()
    .filter(
      (msg) =>
        msg.attachmentFileUrl && !isImageFileName(msg.attachmentFileName || ""),
    );

export const getContactVisible = (
  all = [],
  { keyword = "", visibleCount = CONTACT_FILTER_PAGE } = {},
) => {
  const filtered = filterByKeyword(all, keyword, [
    "fullName",
    "role",
    "organization",
    "subject",
    "className",
  ]);
  const count = Math.max(CONTACT_FILTER_PAGE, Number(visibleCount) || 0);
  return {
    items: filtered.slice(0, count),
    total: filtered.length,
    hasMore: count < filtered.length,
  };
};

/** Thời gian trong bubble tin — lịch sử convert +7, gửi/nhận giữ API */
export const formatMessageTime = (value, keepApiTime = false) => {
  const date = parseMessageDayjs(value, keepApiTime);
  if (!date) return "";
  return date.format("HH:mm");
};

export const formatConversationTime = (value) => {
  if (!value) return "";
  const date = dayjs(value);
  if (!date.isValid()) return "";
  if (date.isSame(dayjs(), "day")) return date.format("HH:mm");
  if (date.isSame(dayjs().subtract(1, "day"), "day")) return "Hôm qua";
  return date.format("DD/MM");
};

/** Thời gian tương đối kiểu Zalo: "2 giờ", "5 phút", ... */
export const formatRelativeTime = (value) => {
  if (!value) return "";
  const date = dayjs(value);
  if (!date.isValid()) return "";
  const now = dayjs();
  const mins = now.diff(date, "minute");
  if (mins < 1) return "Vừa xong";
  if (mins < 60) return `${mins} phút`;
  const hours = now.diff(date, "hour");
  if (hours < 24) return `${hours} giờ`;
  const days = now.diff(date, "day");
  if (days < 7) return `${days} ngày`;
  return date.format("DD/MM/YYYY");
};

/** Tách text để highlight từ khóa (case-insensitive) */
export const splitHighlightParts = (text = "", keyword = "") => {
  const source = String(text ?? "");
  const key = String(keyword ?? "").trim();
  if (!key || !source) return [{ text: source, match: false }];

  const escaped = key.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`(${escaped})`, "gi");
  const parts = source.split(regex);
  return parts.filter(Boolean).map((part) => ({
    text: part,
    match: part.toLowerCase() === key.toLowerCase(),
  }));
};

export const getAvatarColorIndex = (name = "") => {
  const str = String(name);
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash) % 6;
};

export const isMessageSeen = (message, watermark) => {
  if (!message?.mine) return false;
  const wm = Number(watermark || 0);
  const id = Number(message.id);
  if (!wm || Number.isNaN(id)) return false;
  return wm >= id;
};

export { MESSAGE_PAGE_SIZE };
