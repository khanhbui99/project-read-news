import { Box, IconButton, Typography } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

const AVATAR_PALETTE = [
  VPB_THEMES.colors.primaryBlue,
  VPB_THEMES.colors.teal,
  VPB_THEMES.colors.purple,
  VPB_THEMES.colors.orange,
  VPB_THEMES.colors.darkBlue,
  VPB_THEMES.colors.secondaryBlue,
];

export const ChatLayout = styled(Box)`
  height: calc(100vh - 64px);
  // padding: 12px;
  // background: ${VPB_THEMES.colors.gray[100]};
  margin: -24px -24px -2.85714rem
`;

export const ChatPanel = styled(Box)`
  height: 100%;
  display: flex;
  overflow: hidden;
  // border-radius: 0 0 12px 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
`;

export const Sidebar = styled(Box)`
  width: 360px;
  min-width: 300px;
  max-width: 400px;
  height: 100%;
  display: flex;
  flex-direction: column;
  border-right: 1px solid ${VPB_THEMES.colors.gray[200]};
  background: ${VPB_THEMES.colors.white};
`;

export const SidebarHeader = styled(Box)`
  padding: 14px 16px 10px;
  display: flex;
  align-items: center;
  gap: 8px;
`;

export const SidebarTitle = styled(Typography)`
  && {
    flex: 1;
    font-size: 20px;
    font-weight: 700;
    color: ${VPB_THEMES.colors.gray[500]};
    letter-spacing: -0.02em;
  }
`;

export const SearchWrap = styled(Box)`
  padding: 0 12px 12px;
`;

export const SidebarList = styled(Box)`
  flex: 1;
  overflow-y: auto;

  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: ${VPB_THEMES.colors.gray[200]};
    border-radius: 4px;
  }
`;

export const ConversationRow = styled(Box)`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 14px;
  cursor: pointer;
  transition: background 0.12s ease;
  background: ${(p) =>
    p.$active ? VPB_THEMES.colors.f0f9ff : VPB_THEMES.colors.white};

  &:hover {
    background: ${(p) =>
      p.$active ? VPB_THEMES.colors.f0f9ff : VPB_THEMES.colors.gray[100]};
  }
`;

export const AvatarCircle = styled(Box)`
  width: 48px;
  height: 48px;
  min-width: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 18px;
  color: ${VPB_THEMES.colors.white};
  background: ${(p) => AVATAR_PALETTE[p.$tone % AVATAR_PALETTE.length]};
  text-transform: uppercase;
`;

export const ConversationMeta = styled(Box)`
  flex: 1;
  min-width: 0;
`;

export const ConversationTop = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
`;

export const ConversationName = styled(Typography)`
  && {
    font-weight: ${(p) => (p.$bold ? 700 : 600)};
    font-size: 15px;
    color: ${VPB_THEMES.colors.gray[500]};
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;

export const ConversationTime = styled(Typography)`
  && {
    font-size: 11px;
    color: ${VPB_THEMES.colors.gray[300]};
    white-space: nowrap;
  }
`;

export const ConversationPreview = styled(Typography)`
  && {
    margin-top: 2px;
    color: ${VPB_THEMES.colors.gray[400]};
    font-size: 13px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-weight: ${(p) => (p.$unread ? 600 : 400)};
  }
`;

export const UnreadBadge = styled(Box)`
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 9px;
  background: ${VPB_THEMES.colors.red};
  color: ${VPB_THEMES.colors.white};
  font-size: 11px;
  font-weight: 700;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-left: 6px;
`;

export const SidebarTabs = styled(Box)`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 0 12px 8px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
`;

export const SidebarTab = styled.button`
  border: none;
  background: transparent;
  cursor: pointer;
  font-family: inherit;
  font-size: 13px;
  font-weight: ${(p) => (p.$active ? 700 : 500)};
  color: ${(p) =>
    p.$active ? VPB_THEMES.colors.primaryBlue : VPB_THEMES.colors.gray[400]};
  padding: 8px 12px;
  border-bottom: 2px solid
    ${(p) => (p.$active ? VPB_THEMES.colors.primaryBlue : "transparent")};
`;

export const DateSeparator = styled(Box)`
  align-self: center;
  margin: 8px 0;
  padding: 4px 12px;
  border-radius: 999px;
  background: rgba(0, 0, 0, 0.06);
  color: ${VPB_THEMES.colors.gray[400]};
  font-size: 12px;
  font-weight: 500;
`;

export const MessageImage = styled.img`
  display: block;
  max-width: 260px;
  max-height: 280px;
  width: auto;
  height: auto;
  border-radius: 10px;
  margin-top: 4px;
  cursor: pointer;
  object-fit: cover;
`;

export const ChatMain = styled(Box)`
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 100%;
  background: ${VPB_THEMES.colors.gray[100]};
`;

export const ChatHeader = styled(Box)`
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  background: ${VPB_THEMES.colors.white};
  border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
  min-height: 64px;
`;

export const ChatHeaderActions = styled(Box)`
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 2px;
`;

export const RightPane = styled(Box)`
  width: 320px;
  min-width: 280px;
  max-width: 360px;
  height: 100%;
  display: flex;
  flex-direction: column;
  background: ${VPB_THEMES.colors.white};
  border-left: 1px solid ${VPB_THEMES.colors.gray[200]};
`;

export const RightPaneHeader = styled(Box)`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 52px;
  padding: 12px 40px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
`;

export const RightPaneTitle = styled(Typography)`
  && {
    font-size: 15px;
    font-weight: 700;
    color: ${VPB_THEMES.colors.darkBlue || VPB_THEMES.colors.gray[500]};
    text-align: center;
  }
`;

export const RightPaneClose = styled(Box)`
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
`;

export const RightPaneBody = styled(Box)`
  flex: 1;
  overflow-y: auto;
  padding: 16px;

  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: ${VPB_THEMES.colors.gray[200]};
    border-radius: 4px;
  }
`;

export const InfoProfile = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 8px 0 20px;
`;

export const InfoSection = styled(Box)`
  margin-top: 8px;
  padding-top: 12px;
  border-top: 1px solid ${VPB_THEMES.colors.gray[200]};
`;

export const InfoSectionTitle = styled(Typography)`
  && {
    font-size: 14px;
    font-weight: 700;
    color: ${VPB_THEMES.colors.darkBlue || VPB_THEMES.colors.gray[500]};
    margin-bottom: 10px;
  }
`;

export const MediaGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 6px;
`;

export const MediaCell = styled.button`
  aspect-ratio: 1;
  border: none;
  padding: 0;
  border-radius: 6px;
  overflow: hidden;
  cursor: pointer;
  background: ${VPB_THEMES.colors.gray[100]};
  display: flex;
  align-items: center;
  justify-content: center;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

export const ViewAllBtn = styled.button`
  width: 100%;
  margin-top: 10px;
  border: none;
  border-radius: 8px;
  padding: 10px 12px;
  font-family: inherit;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  background: ${VPB_THEMES.colors.gray[100]};
  color: ${VPB_THEMES.colors.darkBlue || VPB_THEMES.colors.gray[500]};

  &:hover {
    background: ${VPB_THEMES.colors.gray[200]};
  }
`;

export const SearchEmpty = styled(Box)`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 32px 20px;
  gap: 14px;
  color: ${VPB_THEMES.colors.gray[400]};
`;

export const SearchEmptyIcon = styled(Box)`
  width: 96px;
  height: 96px;
  border-radius: 50%;
  background: ${VPB_THEMES.colors.f0f9ff};
  display: flex;
  align-items: center;
  justify-content: center;
  color: ${VPB_THEMES.colors.primaryBlue};
`;

export const ThreadFilterRow = styled(Box)`
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
`;

export const FilterSelectBtn = styled.button`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: none;
  border-radius: 8px;
  padding: 7px 10px;
  font-family: inherit;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  background: ${VPB_THEMES.colors.gray[100]};
  color: ${VPB_THEMES.colors.gray[500]};
`;

export const EmojiGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 2px;
  max-width: 280px;
  max-height: 220px;
  overflow-y: auto;
  padding: 6px;
`;

export const EmojiBtn = styled.button`
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 20px;
  line-height: 1.4;
  border-radius: 6px;
  padding: 4px;

  &:hover {
    background: ${VPB_THEMES.colors.gray[100]};
  }
`;

export const MessageScroll = styled(Box)`
  flex: 1;
  overflow-y: auto;
  padding: 16px 18px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  background: ${VPB_THEMES.colors.gray[100]};

  &::-webkit-scrollbar {
    width: 6px;
  }
  &::-webkit-scrollbar-thumb {
    background: ${VPB_THEMES.colors.gray[200]};
    border-radius: 4px;
  }
`;

export const MessageRow = styled(Box)`
  display: flex;
  justify-content: ${(p) => (p.$mine ? "flex-end" : "flex-start")};
  margin-top: 2px;
`;

export const MessageBubble = styled(Box)`
  max-width: 68%;
  padding: ${(p) => (p.$mediaOnly ? "4px" : "8px 12px 6px")};
  border-radius: ${(p) =>
    p.$mine ? "14px 14px 4px 14px" : "14px 14px 14px 4px"};
  background: ${(p) =>
    p.$mine ? VPB_THEMES.colors.f0f9ff : VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.gray[500]};
  border: 1px solid
    ${(p) =>
      p.$mine ? `${VPB_THEMES.colors.primaryBlue}33` : VPB_THEMES.colors.gray[200]};
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.04);
  word-break: break-word;
`;

export const MessageSender = styled(Typography)`
  && {
    font-size: 11px;
    font-weight: 700;
    color: ${VPB_THEMES.colors.primaryBlue};
    margin-bottom: 2px;
  }
`;

export const MessageMeta = styled(Box)`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 6px;
  margin-top: 4px;
`;

export const MessageTime = styled(Typography)`
  && {
    font-size: 11px;
    opacity: 0.75;
    line-height: 1;
  }
`;

export const SeenTick = styled(Typography)`
  && {
    font-size: 11px;
    font-weight: 700;
    color: ${VPB_THEMES.colors.primaryBlue};
    opacity: 0.95;
  }
`;

export const AttachmentChip = styled.button`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-top: 6px;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  cursor: pointer;
  font-size: 12px;
  font-family: inherit;
  background: ${VPB_THEMES.colors.gray[100]};
  color: ${VPB_THEMES.colors.gray[500]};
  text-align: left;
`;

export const ComposerBar = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 0;
  background: ${VPB_THEMES.colors.white};
  border-top: 1px solid ${VPB_THEMES.colors.gray[200]};
`;

export const ComposerToolbar = styled(Box)`
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px 8px 0;
`;

export const ComposerRow = styled(Box)`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 10px 12px;
`;

export const ComposerActionBtn = styled(IconButton)`
  && {
    width: 40px;
    height: 40px;
    padding: 8px;
    flex-shrink: 0;
  }
`;

export const AttachActionBtn = styled(IconButton)`
  && {
    width: 40px;
    height: 40px;
    padding: 8px;
    flex-shrink: 0;
    color: ${VPB_THEMES.colors.primaryBlue};
    background: ${VPB_THEMES.colors.f0f9ff};

    &:hover {
      background: ${VPB_THEMES.colors.gray[200]};
    }

    &.Mui-disabled {
      color: ${VPB_THEMES.colors.gray[300]};
      background: ${VPB_THEMES.colors.gray[100]};
    }
  }
`;

export const SearchResultItem = styled(Box)`
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px 4px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
  cursor: pointer;

  &:hover {
    background: ${VPB_THEMES.colors.gray[100]};
  }
`;

export const SearchResultBody = styled(Box)`
  flex: 1;
  min-width: 0;
`;

export const SearchResultTop = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 2px;
`;

export const SearchHighlight = styled.span`
  color: ${VPB_THEMES.colors.primaryBlue};
  font-weight: 600;
`;

export const FileChip = styled(Box)`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: calc(100% - 24px);
  padding: 4px 10px;
  border-radius: 8px;
  background: ${VPB_THEMES.colors.f0f9ff};
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  font-size: 12px;
  color: ${VPB_THEMES.colors.gray[400]};
`;

export const EmptyWrap = styled(Box)`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 32px;
  color: ${VPB_THEMES.colors.gray[400]};
  text-align: center;
`;

export const LoadMoreBtn = styled.button`
  display: block;
  margin: 4px auto 12px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.primaryBlue};
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  padding: 6px 14px;
  border-radius: 999px;
  font-family: inherit;

  &:hover {
    background: ${VPB_THEMES.colors.f0f9ff};
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

export const RoleTag = styled.span`
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 4px;
  background: ${VPB_THEMES.colors.gray[100]};
  color: ${VPB_THEMES.colors.gray[400]};
`;

export const StatusDot = styled.span`
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
  background: ${(p) =>
    p.$on
      ? VPB_THEMES.colors.statusActiveDot
      : p.$warn
        ? VPB_THEMES.colors.pending
        : VPB_THEMES.colors.gray[300]};
`;
