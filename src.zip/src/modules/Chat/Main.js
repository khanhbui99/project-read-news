import ChatOutlinedIcon from "@mui/icons-material/ChatOutlined";
import FolderOutlinedIcon from "@mui/icons-material/FolderOutlined";
import SearchIcon from "@mui/icons-material/Search";
import { Box, IconButton, Typography } from "@mui/material";
import { setLoadingAction } from "App/store/actions";
import { useSnackbar } from "notistack";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { VPB_THEMES } from "utils/configs";
import { useInjectReducer } from "utils/injectReducer";
import { useInjectSaga } from "utils/injectSaga";

import { getAvatarColorIndex } from "./chatHelpers";
import Composer from "./components/Composer";
import ContactDialog from "./components/ContactDialog";
import ConversationInfoPane from "./components/ConversationInfoPane";
import ConversationList from "./components/ConversationList";
import EmptyState from "./components/EmptyState";
import MessageList from "./components/MessageList";
import ThreadSearchPanel from "./components/ThreadSearchPanel";
import { useChat } from "./hooks";
import { key } from "./store/constants";
import reducer from "./store/reducer";
import saga from "./store/saga";
import {
  AvatarCircle,
  ChatHeader,
  ChatHeaderActions,
  ChatLayout,
  ChatMain,
  ChatPanel,
  Sidebar,
  SidebarHeader,
  SidebarTitle,
} from "./Styled";

function ChatPage() {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });
  const { enqueueSnackbar } = useSnackbar();
  const dispatch = useDispatch();

  const {
    visibleConversations,
    visibleContacts,
    messages,
    currentConversation,
    loading,
    contactDialogOpen,
    conversationKeyword,
    contactKeyword,
    conversationTab,
    pendingFile,
    readWatermark,
    hasMoreOlder,
    initChat,
    cleanupChat,
    setConversationKeyword,
    setContactKeyword,
    setConversationTab,
    loadMoreConversations,
    loadMoreContacts,
    loadOlderMessages,
    selectConversation,
    openContactDialog,
    closeContactDialog,
    startConversationWithContact,
    setPendingFile,
    sendMessage,
    downloadAttachment,
  } = useChat();

  const [rightPane, setRightPane] = useState(null); // 'search' | 'info' | null
  const [showAllMedia, setShowAllMedia] = useState(false);
  const [highlightMessageId, setHighlightMessageId] = useState(null);

  useEffect(() => {
    initChat();
    return () => cleanupChat();
  }, [initChat, cleanupChat]);

  useEffect(() => {
    setRightPane(null);
    setShowAllMedia(false);
    setHighlightMessageId(null);
  }, [currentConversation?.id]);

  const peerName = currentConversation?.name || "";

  const handleDownload = async (fileUrl, fileName) => {
    dispatch(setLoadingAction(true));
    try {
      await downloadAttachment(fileUrl, fileName);
    } catch (err) {
      enqueueSnackbar(err?.message || "Tải file thất bại", {
        variant: "error",
      });
    } finally {
      dispatch(setLoadingAction(false));
    }
  };

  const togglePane = (pane) => {
    setRightPane((prev) => (prev === pane ? null : pane));
  };

  return (
    <ChatLayout>
      <ChatPanel>
        <Sidebar>
          <SidebarHeader>
            <SidebarTitle>Tin nhắn</SidebarTitle>
            <IconButton
              onClick={openContactDialog}
              sx={{ color: VPB_THEMES.colors.primaryBlue }}
              aria-label="Tin nhắn mới"
            >
              <ChatOutlinedIcon />
            </IconButton>
          </SidebarHeader>
          <ConversationList
            items={visibleConversations?.items || []}
            currentConversationId={currentConversation?.id}
            keyword={conversationKeyword}
            tab={conversationTab}
            loading={loading?.conversations}
            hasMore={visibleConversations?.hasMore}
            onSearch={setConversationKeyword}
            onTabChange={setConversationTab}
            onSelect={selectConversation}
            onLoadMore={loadMoreConversations}
          />
        </Sidebar>

        <ChatMain>
          {!currentConversation ? (
            <EmptyState
              message="Chào mừng đến Tin nhắn"
              hint="Chọn một hội thoại ở bên trái hoặc tạo tin nhắn mới"
            />
          ) : (
            <>
              <ChatHeader>
                <AvatarCircle $tone={getAvatarColorIndex(peerName)}>
                  {peerName.charAt(0) || "C"}
                </AvatarCircle>
                <Box sx={{ minWidth: 0, flex: 1 }}>
                  <Typography variant="subtitle1" fontWeight={700} noWrap>
                    {peerName}
                  </Typography>
                </Box>
                <ChatHeaderActions>
                  <IconButton
                    size="small"
                    onClick={() => togglePane("search")}
                    title="Tìm kiếm tin nhắn"
                    sx={{
                      color:
                        rightPane === "search"
                          ? VPB_THEMES.colors.primaryBlue
                          : VPB_THEMES.colors.gray[400],
                      background:
                        rightPane === "search"
                          ? VPB_THEMES.colors.f0f9ff
                          : "transparent",
                    }}
                  >
                    <SearchIcon />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => togglePane("info")}
                    title="Thông tin hội thoại / File"
                    sx={{
                      color:
                        rightPane === "info"
                          ? VPB_THEMES.colors.primaryBlue
                          : VPB_THEMES.colors.gray[400],
                      background:
                        rightPane === "info"
                          ? VPB_THEMES.colors.primaryBlue
                          : "transparent",
                      ...(rightPane === "info"
                        ? { color: VPB_THEMES.colors.white }
                        : {}),
                    }}
                  >
                    <FolderOutlinedIcon />
                  </IconButton>
                </ChatHeaderActions>
              </ChatHeader>

              <MessageList
                conversationId={currentConversation.id}
                items={messages || []}
                loading={loading?.messages}
                loadingOlder={loading?.loadingOlder}
                hasMore={hasMoreOlder}
                watermark={readWatermark}
                highlightMessageId={highlightMessageId}
                onLoadOlder={loadOlderMessages}
                onDownload={handleDownload}
              />
              <Composer
                sending={loading?.sending}
                pendingFile={pendingFile}
                peerName={peerName}
                onSend={sendMessage}
                onPickFile={setPendingFile}
                onClearFile={() => setPendingFile(null)}
              />
            </>
          )}
        </ChatMain>

        <ThreadSearchPanel
          open={Boolean(currentConversation) && rightPane === "search"}
          messages={messages || []}
          hasMoreLoadedHint={hasMoreOlder}
          onClose={() => setRightPane(null)}
          onSelectResult={(msg) => {
            setHighlightMessageId(msg.id);
            setRightPane(null);
          }}
        />

        <ConversationInfoPane
          open={Boolean(currentConversation) && rightPane === "info"}
          peerName={peerName}
          messages={messages || []}
          showAllMedia={showAllMedia}
          onToggleShowAll={() => setShowAllMedia((v) => !v)}
          onClose={() => setRightPane(null)}
          onDownload={handleDownload}
        />
      </ChatPanel>

      <ContactDialog
        open={contactDialogOpen}
        items={visibleContacts?.items || []}
        keyword={contactKeyword}
        loading={loading?.contacts || loading?.creating}
        hasMore={visibleContacts?.hasMore}
        onClose={closeContactDialog}
        onSearch={setContactKeyword}
        onSelect={startConversationWithContact}
        onLoadMore={loadMoreContacts}
      />
    </ChatLayout>
  );
}

export default ChatPage;
