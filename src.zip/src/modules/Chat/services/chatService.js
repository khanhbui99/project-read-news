import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { TOKEN_NAME } from "utils/constants";

import { mapContact, mapConversation, mapMessage } from "../chatHelpers";
import { MESSAGE_PAGE_SIZE } from "../store/constants";

const chatApi = urlApi.managementService.chat;

const asList = (data) => (Array.isArray(data) ? data : []);

export const fetchContacts = async () => {
  const { data: res = {} } = await ApiReq.get({ url: chatApi.contacts });
  return asList(res?.data).map(mapContact);
};

export const fetchConversations = async () => {
  const { data: res = {} } = await ApiReq.get({ url: chatApi.conversations });
  return asList(res?.data).map(mapConversation);
};

export const createConversation = async (otherAccountId) => {
  const { data: res = {} } = await ApiReq.post({
    url: chatApi.createConversation,
    params: { otherAccountId },
  });
  return mapConversation(res?.data ?? res);
};

export const fetchMessages = async (conversationId, { size = MESSAGE_PAGE_SIZE } = {}) => {
  const { data: res = {} } = await ApiReq.get({
    url: chatApi.messages(conversationId),
    params: { size },
  });
  return asList(res?.data).map(mapMessage);
};

export const fetchOlderMessages = async (
  conversationId,
  beforeMessageId,
  { size = MESSAGE_PAGE_SIZE } = {},
) => {
  const { data: res = {} } = await ApiReq.get({
    url: chatApi.messages(conversationId),
    params: { size, beforeMessageId },
  });
  return asList(res?.data).map(mapMessage);
};

/** Multipart: part `request` (JSON) + optional `file` — khớp chat-tester.html */
export const sendMessage = async (conversationId, { message, file } = {}) => {
  const form = new FormData();
  form.append(
    "request",
    new Blob([JSON.stringify({ message: message || null })], {
      type: "application/json",
    }),
  );
  if (file) form.append("file", file);

  const { data: res = {} } = await ApiReq.post({
    url: chatApi.sendMessage(conversationId),
    data: form,
    multipart: true,
  });
  return mapMessage(res?.data ?? res, { keepApiTime: true });
};

export const markConversationRead = async (conversationId) => {
  await ApiReq.post({ url: chatApi.read(conversationId) });
};

const fetchAttachmentBlob = async (fileUrl) => {
  const res = await fetch(fileUrl, {
    method: "POST",
    headers: {
      Authorization: localStorage.getItem(TOKEN_NAME) || "",
    },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.blob();
};

/** Download attachment: POST + Bearer + Blob — khớp chat-tester.html */
export const downloadAttachment = async (fileUrl, fileName) => {
  const blob = await fetchAttachmentBlob(fileUrl);
  const objectUrl = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = objectUrl;
  a.download = fileName || "file";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(objectUrl);
};

/** Preview ảnh: POST lấy blob URL (S3 download không dùng GET) */
export const fetchAttachmentObjectUrl = async (fileUrl) => {
  const blob = await fetchAttachmentBlob(fileUrl);
  return URL.createObjectURL(blob);
};

export default {
  fetchContacts,
  fetchConversations,
  createConversation,
  fetchMessages,
  fetchOlderMessages,
  sendMessage,
  markConversationRead,
  downloadAttachment,
  fetchAttachmentObjectUrl,
};
