import { Client } from "@stomp/stompjs";
import { ROOT_URI, TOKEN_NAME } from "utils/constants";

import {
  CHAT_QUEUE_MESSAGES,
  CHAT_QUEUE_READ_STATUS,
  CHAT_WS_PATH,
} from "../store/constants";

let instance = null;

class SocketManager {
  constructor() {
    this.client = null;
    this.subscriptions = [];
    this.connected = false;
    this.reconnecting = false;
    this.reconnectCount = 0;
    this.heartbeat = null;
    this.sessionId = null;
    this.handlers = {
      onMessage: null,
      onReadStatus: null,
      onConnect: null,
      onDisconnect: null,
      onError: null,
      onStateChange: null,
    };
  }

  static getInstance() {
    if (!instance) instance = new SocketManager();
    return instance;
  }

  setHandlers(handlers = {}) {
    this.handlers = { ...this.handlers, ...handlers };
  }

  emitState() {
    this.handlers.onStateChange?.({
      connected: this.connected,
      reconnecting: this.reconnecting,
      reconnectCount: this.reconnectCount,
      heartbeat: this.heartbeat,
      sessionId: this.sessionId,
    });
  }

  /** Khớp chat-tester: http(s)://host → ws(s)://host/.../ws-chat */
  getBrokerURL() {
    const root = String(ROOT_URI || "")
      .trim()
      .replace(/\/+$/, "");
    const wsRoot = root.replace(/^http/, "ws");
    return `${wsRoot}/${CHAT_WS_PATH}`;
  }

  getAuthHeader() {
    return localStorage.getItem(TOKEN_NAME) || "";
  }

  connect() {
    if (this.client?.active) return;

    const token = this.getAuthHeader();
    this.reconnecting = false;
    this.emitState();

    // Giống HTML: deactivate cũ nếu có
    if (this.client) {
      try {
        this.client.deactivate();
      } catch (e) {
        // ignore
      }
    }

    this.client = new Client({
      brokerURL: this.getBrokerURL(),
      connectHeaders: token ? { Authorization: token } : {},
      heartbeatIncoming: 10000,
      heartbeatOutgoing: 10000,
      reconnectDelay: 4000,
      debug: () => {},
      onConnect: (frame) => {
        this.connected = true;
        this.reconnecting = false;
        this.heartbeat = new Date().toISOString();
        this.sessionId = frame?.headers?.["user-name"] || null;
        this.emitState();
        this.subscribe();
        this.handlers.onConnect?.(frame);
      },
      onDisconnect: () => {
        this.connected = false;
        this.subscriptions = [];
        this.emitState();
        this.handlers.onDisconnect?.();
      },
      onStompError: (frame) => {
        this.handlers.onError?.(frame);
        this.emitState();
      },
      onWebSocketClose: () => {
        this.connected = false;
        this.reconnecting = true;
        this.reconnectCount += 1;
        this.emitState();
      },
    });

    this.client.activate();
  }

  subscribe() {
    if (!this.client?.connected) return;
    this.unsubscribe();

    const messageSub = this.client.subscribe(CHAT_QUEUE_MESSAGES, (frame) => {
      this.heartbeat = new Date().toISOString();
      this.emitState();
      try {
        const body = frame?.body ? JSON.parse(frame.body) : null;
        if (body) this.handlers.onMessage?.(body);
      } catch (err) {
        this.handlers.onError?.(err);
      }
    });

    const readSub = this.client.subscribe(CHAT_QUEUE_READ_STATUS, (frame) => {
      this.heartbeat = new Date().toISOString();
      this.emitState();
      try {
        const body = frame?.body ? JSON.parse(frame.body) : null;
        if (body) this.handlers.onReadStatus?.(body);
      } catch (err) {
        this.handlers.onError?.(err);
      }
    });

    this.subscriptions = [messageSub, readSub];
  }

  unsubscribe() {
    this.subscriptions.forEach((sub) => {
      try {
        sub.unsubscribe();
      } catch (e) {
        // ignore
      }
    });
    this.subscriptions = [];
  }

  disconnect() {
    this.unsubscribe();
    if (this.client) {
      try {
        this.client.deactivate();
      } catch (e) {
        // ignore
      }
    }
    this.client = null;
    this.connected = false;
    this.reconnecting = false;
    this.emitState();
  }
}

export const getSocketManager = () => SocketManager.getInstance();

export default SocketManager;
