const messageCache = new Map();

export const cacheService = {
  getMessages(conversationId) {
    return messageCache.get(String(conversationId)) || [];
  },

  setMessages(conversationId, messages = []) {
    messageCache.set(String(conversationId), messages || []);
  },

  mergeMessages(conversationId, incoming = []) {
    const current = this.getMessages(conversationId);
    const map = new Map();
    current.forEach((item) => map.set(String(item.id), item));
    (incoming || []).forEach((item) => {
      if (!item?.id) return;
      map.set(String(item.id), { ...map.get(String(item.id)), ...item });
    });
    const merged = Array.from(map.values());
    this.setMessages(conversationId, merged);
    return merged;
  },

  clear(conversationId) {
    if (conversationId == null) {
      messageCache.clear();
      return;
    }
    messageCache.delete(String(conversationId));
  },
};

export default cacheService;
