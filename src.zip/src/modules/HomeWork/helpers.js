import { TOKEN_NAME } from "utils/constants";

/** Loại file trên submission / attachment */
export const HOMEWORK_FILE_TYPE = {
  ORIGINAL: "ORIGINAL",
  ANNOTATED: "ANNOTATED",
};

export const getFileType = (file = {}) => {
  const candidates = [
    file?.fileType,
    file?.category,
    file?.fileCategory,
    file?.attachmentType,
    file?.kind,
    // `type` chỉ dùng khi không phải MIME (vd. application/pdf)
    typeof file?.type === "string" && file.type.includes("/")
      ? ""
      : file?.type,
  ];

  const raw = candidates.find((value) => value != null && value !== "");
  return String(raw || "").toUpperCase();
};

export const isAnnotatedFile = (file = {}) =>
  getFileType(file) === HOMEWORK_FILE_TYPE.ANNOTATED;

export const normalizeHomeworkFile = (file, index = 0) => {
  if (typeof file === "string") {
    return {
      id: `${index}`,
      name: String(file).split("/").pop() || `File ${index + 1}`,
      url: file,
      path: file,
      fileUrl: file,
      type: HOMEWORK_FILE_TYPE.ORIGINAL,
    };
  }

  const fileUrl =
    file.fileUrl || file.url || file.path || file.downloadUrl || "";

  return {
    ...file,
    id: file.id || file.fileId || file.path || index,
    name:
      file.name ||
      file.fileName ||
      file.originalName ||
      (fileUrl ? String(fileUrl).split("/").pop() : `File ${index + 1}`),
    url: file.url || fileUrl,
    path: file.path || file.url || "",
    fileUrl,
    size: file.size || file.fileSize,
    type: getFileType(file) || HOMEWORK_FILE_TYPE.ORIGINAL,
  };
};

export const filterOriginalFiles = (files = []) =>
  (Array.isArray(files) ? files : [])
    .map(normalizeHomeworkFile)
    .filter((file) => !isAnnotatedFile(file));

export const filterAnnotatedFiles = (files = []) =>
  (Array.isArray(files) ? files : [])
    .map(normalizeHomeworkFile)
    .filter((file) => isAnnotatedFile(file));

/**
 * Master data (môn, năm học, học kỳ, khối...) lấy từ
 * App API: exams-period/category-dependency → GLOBAL.examPeriodCategory
 * Lớp giáo viên: my-schedule → flatten unique class từ info[]
 */
export const getClassOptionsFromMySchedule = (mySchedule = []) => {
  const map = new Map();

  (mySchedule || []).forEach((period) => {
    (period?.info || []).forEach((item) => {
      const id = item?.classId ?? item?.id;
      if (id == null || map.has(String(id))) return;

      map.set(String(id), {
        ...item,
        id,
        classId: id,
        className: item?.className || item?.name || "",
        name: item?.className || item?.name || "",
      });
    });
  });

  return Array.from(map.values());
};

export const getSubjectOptionsFromMySchedule = (
  mySchedule = [],
  classIds = []
) => {
  const selectedIds = (Array.isArray(classIds) ? classIds : [classIds])
    .filter((id) => id != null && id !== "")
    .map(String);
  const map = new Map();

  (mySchedule || []).forEach((period) => {
    (period?.info || []).forEach((cls) => {
      const classId = String(cls?.classId ?? cls?.id ?? "");
      if (selectedIds.length && !selectedIds.includes(classId)) return;

      (cls?.subject || []).forEach((subject) => {
        const id = subject?.subjectId ?? subject?.id;
        if (id == null || map.has(String(id))) return;

        map.set(String(id), {
          ...subject,
          id,
          subjectId: id,
          name: subject?.name || subject?.subjectName || "",
        });
      });
    });
  });

  return Array.from(map.values());
};

export const getSubjectOptions = (examPeriodCategory = {}) =>
  examPeriodCategory?.subjects || [];

export const getAcademicYearOptions = (examPeriodCategory = {}) =>
  examPeriodCategory?.academicYears || [];

export const getSemesterOptions = (examPeriodCategory = {}) =>
  examPeriodCategory?.semesters || [];

export const getGradeOptions = (examPeriodCategory = {}) =>
  examPeriodCategory?.grades || [];

export const getFileUrl = (file = {}) =>
  file.fileUrl || file.url || file.path || file.downloadUrl || "";

export const getFileName = (file = {}) =>
  file.name ||
  file.fileName ||
  file.originalName ||
  (getFileUrl(file) ? String(getFileUrl(file)).split("/").pop() : "file.pdf");

export const getFileSizeLabel = (file = {}) => {
  const size = Number(file.size || file.fileSize || 0);
  if (!size) return "";
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(0)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
};

export const getFileCacheKey = (file = {}) => {
  const url = getFileUrl(file);
  const id = file.id || file.fileId || "";
  return id ? `id:${id}` : url ? `url:${url}` : "";
};

const fileBlobCache = new Map();
const fileBlobInflight = new Map();

const resolveFileAbsoluteUrl = (url = "") => {
  if (!url) return "";
  if (/^https?:\/\//i.test(url) || url.startsWith("blob:")) return url;
  const rootUri = import.meta.env.VITE_ROOT_URI || "";
  const cleanUrl = url.startsWith("/") ? url : `/${url}`;
  return `${rootUri}${cleanUrl}`;
};

const sniffPreviewKind = (fileName = "", mime = "") => {
  const name = String(fileName).toLowerCase();
  const type = String(mime).toLowerCase();
  if (type.includes("pdf") || /\.pdf($|\?)/i.test(name)) return "pdf";
  if (
    type.startsWith("image/") ||
    /\.(png|jpe?g|gif|webp|bmp)($|\?)/i.test(name)
  ) {
    return "image";
  }
  return "other";
};

export const getCachedFileBlob = (file = {}) => {
  const key = getFileCacheKey(file);
  if (!key) return null;
  return fileBlobCache.get(key) || null;
};

/** Lấy file bằng POST tới fileUrl (không dùng API download) */
export const fetchAndCacheFileBlob = async (file = {}) => {
  const key = getFileCacheKey(file);
  const fileUrl = getFileUrl(file);
  if (!key || !fileUrl) {
    throw new Error("File chưa có fileUrl.");
  }

  const cached = fileBlobCache.get(key);
  if (cached?.blobUrl) return cached;

  if (fileBlobInflight.has(key)) {
    return fileBlobInflight.get(key);
  }

  const task = (async () => {
    const absoluteUrl = resolveFileAbsoluteUrl(fileUrl);
    const token = localStorage.getItem(TOKEN_NAME) || "";
    const response = await fetch(absoluteUrl, {
      method: "POST",
      headers: token ? { Authorization: token } : {},
    });

    if (!response.ok) {
      throw new Error("Không thể tải file.");
    }

    const blob = await response.blob();
    const fileName = getFileName(file);
    const mime = blob.type || "application/octet-stream";
    const previewKind = sniffPreviewKind(fileName, mime);
    const previewBlob =
      previewKind === "pdf" && mime !== "application/pdf"
        ? new Blob([blob], { type: "application/pdf" })
        : blob;
    const blobUrl = URL.createObjectURL(previewBlob);
    const entry = {
      key,
      url: fileUrl,
      blobUrl,
      fileName,
      mime: previewBlob.type || mime,
      previewKind,
    };
    fileBlobCache.set(key, entry);
    return entry;
  })();

  fileBlobInflight.set(key, task);
  try {
    return await task;
  } finally {
    fileBlobInflight.delete(key);
  }
};

/** Tải: POST fileUrl (dùng cache nếu có) rồi mở tab mới */
export const downloadFile = async (file) => {
  const entry = await fetchAndCacheFileBlob(file);
  if (!entry?.blobUrl) return;

  const link = document.createElement("a");
  link.href = entry.blobUrl;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
