import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const FormCard = styled.div`
  background: ${VPB_THEMES.colors.white};
  border-radius: 16px;
  padding: 40px;
  // max-width: 480px;
  width: 100%;
  max-width: 800px;
  margin: auto;
  margin-top: 20px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 48px rgba(0,0,0,0.12);
  }
`;

export const Title = styled.h2`
  margin: 0 0 24px;
  font-size: 24px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  text-align: center;
`;

export const FieldWrapper = styled.div`
  margin: auto;
  margin-bottom: 30px;
  max-width: 600px;
`;

export const Header = styled.div`
  text-align: center;
  margin-bottom: 24px;
`;

export const HeaderIcon = styled.div`
  width: 64px;
  height: 64px;
  margin: 0 auto 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: ${VPB_THEMES.gradient["3"]};
  color: white;
  font-size: 32px;
`;

export const RequirementList = styled.div`
  margin-top: 8px;
  font-size: 13px;
  color: ${VPB_THEMES.colors.textLight};
`;

export const StrengthBarWrapper = styled.div`
  margin-top: 20px;
`;
export const Actions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  max-width: 600px;
  margin: auto;
  button {
    width: 100%;
    height: 40px;
    font-size: 16px;
  }
`;

export const SuccessContent = styled.div`
  padding: 24px;
  padding-bottom: 0;
  text-align: center;
`;

export const SuccessButton = styled.button`
  background: ${VPB_THEMES.colors.green};
  color: #fff;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  padding: 10px 24px;
  cursor: pointer;
  transition: background 0.2s ease;
  width: 80%;
  margin: auto;
  margin-bottom: 20px;
  &:hover {
    background: ${VPB_THEMES.colors.greenDark || VPB_THEMES.colors.green};
  }
`;

export const SuccessIconWrapper = styled.div`
  margin: 0 auto 16px;
  width: 96px;
  height: 96px;
  border-radius: 50%;
  background: ${VPB_THEMES.colors.green};
  display: flex;
  align-items: center;
  justify-content: center;

  svg {
    color: white;
    font-size: 48px;
  }
`;

export const SuccessText = styled.p`
  margin: 16px 0;
  font-size: 16px;
  color: ${VPB_THEMES.colors.textDark};
`;
