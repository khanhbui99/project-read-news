import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import LockIcon from "@mui/icons-material/Lock";
import { Box, Button, Dialog, DialogActions, DialogContent, LinearProgress, Typography } from "@mui/material";
import AppPasswordField from "components/common/AppPasswordField";
import { useFormik } from "formik";
import { useState } from "react";
import { VPB_THEMES } from "utils/configs";
import { logout } from "utils/helpers";
import { useDispatchRedux } from "utils/hooks/useRedux";
import * as Yup from "yup";

import { changePasswordAction } from "./store/actions";
import {
  FormCard,
  Header,
  HeaderIcon,
  Title,
  FieldWrapper,
  StrengthBarWrapper,
  RequirementList,
  Actions,
  SuccessContent,
  SuccessText,
  SuccessIconWrapper,
  SuccessButton,
} from "./Styled";


const validationSchema = Yup.object({
  currentPassword: Yup.string().required("Mật khẩu hiện tại không được để trống"),
  newPassword: Yup.string()
    .required("Mật khẩu mới không được để trống")
    .min(8, "Mật khẩu phải ít nhất 8 ký tự")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
      "Mật khẩu phải chứa chữ hoa, chữ thường và số"
    )
    .notOneOf(
      [Yup.ref("currentPassword"), null],
      "Mật khẩu mới không được trùng mật khẩu hiện tại"
    ),
  confirmPassword: Yup.string()
    .required("Xác nhận mật khẩu không được để trống")
    .oneOf([Yup.ref("newPassword"), null], "Mật khẩu xác nhận không khớp"),
});

const getPasswordStrength = (password) => {
  if (!password) return { strength: 0, label: "", color: "#e0e0e0" };
  let strength = 0;
  if (password.length >= 8) strength += 1;
  if (password.length >= 12) strength += 1;
  if (/[a-z]/.test(password)) strength += 1;
  if (/[A-Z]/.test(password)) strength += 1;
  if (/\d/.test(password)) strength += 1;
  if (/[^a-zA-Z\d]/.test(password)) strength += 1;
  if (strength <= 2) return { strength: 33, label: "Yếu", color: VPB_THEMES.colors.red };
  if (strength <= 4) return { strength: 66, label: "Trung bình", color: VPB_THEMES.colors.yellow };
  return { strength: 100, label: "Mạnh", color: VPB_THEMES.colors.green };
};

const ChangePasswordPage = () => {
  const rqChangePassword = useDispatchRedux(changePasswordAction)

  const [successOpen, setSuccessOpen] = useState(false);

  const formik = useFormik({
    initialValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
    validationSchema,
    onSubmit: (values) => {
      rqChangePassword({
        ...values,
        cb: () => setSuccessOpen(true),
      })
    },
  });

  const passwordStrength = getPasswordStrength(formik.values.newPassword);
  const handleCloseSuccess = () => {
    setSuccessOpen(false);
    logout()
  };

  return (
    <>
      {/* <AppHeader componentName="ChangePasswordPage" isHiddenBtn/> */}
        <FormCard>
        <Header>
          <HeaderIcon>
            <LockIcon fontSize="inherit" />
          </HeaderIcon>
          <Title>Đổi mật khẩu</Title>
        </Header>
        <form onSubmit={formik.handleSubmit}>
          <FieldWrapper>
            <AppPasswordField
              label="Mật khẩu hiện tại"
              name="currentPassword"
              placeholder="Nhập mật khẩu hiện tại"
              value={formik.values.currentPassword}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              errorMessage={
                formik.touched.currentPassword && formik.errors.currentPassword
              }
              fullWidth
              isLabelTop
              rq
            />
          </FieldWrapper>

          <FieldWrapper>
            <AppPasswordField
              label="Mật khẩu mới"
              name="newPassword"
              placeholder="Nhập mật khẩu mới"
              value={formik.values.newPassword}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              errorMessage={
                formik.touched.newPassword && formik.errors.newPassword
              }
              fullWidth
              isLabelTop
              rq
            />
            <StrengthBarWrapper>
              <Box display="flex" alignItems="center" gap={1} mb={1}>
                <LinearProgress
                  variant="determinate"
                  value={passwordStrength.strength}
                  sx={{ flex: 1, height: 8, borderRadius: 4, backgroundColor: '#e0e0e0', '& .MuiLinearProgress-bar': { backgroundColor: passwordStrength.color } }}
                />
                <Typography variant="caption" style={{ color: passwordStrength.color }}>
                  {passwordStrength.label}
                </Typography>
              </Box>
              <RequirementList>
                <Typography component="div">
                  {formik.values.newPassword.length >= 8 ? (
                    <CheckCircleIcon fontSize="small" style={{ color: VPB_THEMES.colors.green, verticalAlign: 'middle' }} />
                  ) : (
                    <Box component="span" style={{ width: 16, display: 'inline-block' }} />
                  )}{' '}
                  ≥ 8 ký tự
                </Typography>
                <Typography component="div">
                  {/[A-Z]/.test(formik.values.newPassword) ? (
                    <CheckCircleIcon fontSize="small" style={{ color: VPB_THEMES.colors.green, verticalAlign: 'middle' }} />
                  ) : (
                    <Box component="span" style={{ width: 16, display: 'inline-block' }} />
                  )}{' '}
                  Chữ hoa
                </Typography>
                <Typography component="div">
                  {/[a-z]/.test(formik.values.newPassword) ? (
                    <CheckCircleIcon fontSize="small" style={{ color: VPB_THEMES.colors.green, verticalAlign: 'middle' }} />
                  ) : (
                    <Box component="span" style={{ width: 16, display: 'inline-block' }} />
                  )}{' '}
                  Chữ thường
                </Typography>
                <Typography component="div">
                  {/\d/.test(formik.values.newPassword) ? (
                    <CheckCircleIcon fontSize="small" style={{ color: VPB_THEMES.colors.green, verticalAlign: 'middle' }} />
                  ) : (
                    <Box component="span" style={{ width: 16, display: 'inline-block' }} />
                  )}{' '}
                  Số
                </Typography>
              </RequirementList>
            </StrengthBarWrapper>
          </FieldWrapper>

          <FieldWrapper>
            <AppPasswordField
              label="Xác nhận mật khẩu"
              name="confirmPassword"
              placeholder="Nhập lại mật khẩu mới"
              value={formik.values.confirmPassword}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              errorMessage={
                formik.touched.confirmPassword && formik.errors.confirmPassword
              }
              fullWidth
              isLabelTop
              rq
            />
          </FieldWrapper>

          <Actions>
            <Button type="submit" variant="contained" color="primary">
              Xác nhận
            </Button>
          </Actions>
        </form>
        </FormCard>

      <Dialog open={successOpen} onClose={handleCloseSuccess} maxWidth="xs" fullWidth>
        <DialogContent>
          <SuccessContent>
            <SuccessIconWrapper>
              <CheckCircleIcon />
            </SuccessIconWrapper>
            <Typography variant="h5" style={{ fontWeight: 700, color: VPB_THEMES.colors.green }}>
              Thay đổi thành công!
            </Typography>
            <SuccessText>
              Mật khẩu của bạn đã được cập nhật. Vui lòng đăng nhập lại để tiếp tục.
            </SuccessText>
          </SuccessContent>
        </DialogContent>
        <DialogActions>
          <SuccessButton onClick={handleCloseSuccess} autoFocus>
            Đăng nhập
          </SuccessButton>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default ChangePasswordPage;
