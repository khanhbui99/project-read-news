import { getAllTeachersAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import EmptyIconText from "components/Emptys/EmptyIconText";
import dayjs from "dayjs";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import { ActivityDataTable, ActivityToolbar } from "../components";
import {
  buildActorNameByAccountId,
  canAccessHistory,
  filterActivityLogsLocal,
  mapActivityLogItem,
  mapActorOpt,
  paginateLocal,
  resolveHistoryRole,
} from "../historyHelpers";
import { CardPanel, ForbiddenWrap, PageWrap } from "./Styled";
import {
  queryActivityLogsAction,
  resetStoreActivityLogAction,
  setFieldValueStoreActivityLogAction,
} from "../store/actions";
import { key, PAGE_SIZE } from "../store/constants";

const HistoryMain = () => {
  const userInfo = useOneState(injectKey.GLOBAL, "userInfo") || {};
  const role = resolveHistoryRole(userInfo);
  const canAccess = canAccessHistory(role);

  const state = useOneState(key, "activityLog") || {};
  const {
    keyword = "",
    fromDate = null,
    toDate = null,
    actorAccountId = "ALL",
    actionType = "ALL",
    page = 0,
    size = PAGE_SIZE,
    items = [],
    loading = false,
  } = state;

  const teachersOpt = useOneState(injectKey.GLOBAL, "teachersOpt", []);
  const fetchTeachers = useDispatchRedux(getAllTeachersAction);
  const setField = useDispatchRedux(setFieldValueStoreActivityLogAction);
  const fetchLogs = useDispatchRedux(queryActivityLogsAction);
  const resetStore = useDispatchRedux(resetStoreActivityLogAction);

  const actorOpts = useMemo(
    () => (teachersOpt || []).map(mapActorOpt).filter((opt) => opt.value),
    [teachersOpt],
  );

  const actorNameByAccountId = useMemo(
    () => buildActorNameByAccountId(teachersOpt),
    [teachersOpt],
  );

  // Remap khi teachersOpt về sau API nhật ký (Người thực hiện theo actorAccountId)
  const mappedItems = useMemo(
    () =>
      (items || []).map((item) =>
        mapActivityLogItem(item, actorNameByAccountId),
      ),
    [items, actorNameByAccountId],
  );

  const filteredItems = useMemo(
    () =>
      filterActivityLogsLocal(mappedItems, {
        keyword,
        fromDate,
        toDate,
        actorAccountId,
        actionType,
      }),
    [mappedItems, keyword, fromDate, toDate, actorAccountId, actionType],
  );

  const pagedRows = useMemo(
    () => paginateLocal(filteredItems, page, size),
    [filteredItems, page, size],
  );

  useEffect(() => {
    if (!canAccess) return undefined;
    if (!teachersOpt?.length) fetchTeachers();
    setField("typeFilter", "ALL");
    fetchLogs({});
    return () => resetStore();
  }, [canAccess]);

  const handleSearch = (next) => {
    setField("keyword", next);
    setField("page", 0);
  };

  const handleFilterChange = (field, value) => {
    if (field === "fromDate") {
      setField("fromDate", value);
      if (
        value &&
        toDate &&
        dayjs(toDate).isValid() &&
        dayjs(value).isValid() &&
        dayjs(toDate).isBefore(dayjs(value), "day")
      ) {
        setField("toDate", value);
      }
      setField("page", 0);
      return;
    }
    setField(field, value);
    setField("page", 0);
  };

  const handlePageChange = (nextPage) => {
    setField("page", nextPage);
  };

  const handlePageSizeChange = (nextSize) => {
    setField("size", nextSize);
    setField("page", 0);
  };

  return (
    <>
      <AppHeader
        componentName="FacilityHistory"
        pageTitle="Nhật ký hệ thống"
        isHiddenBtn
      />

      <PageWrap>
        <CardPanel>
          {!canAccess ? (
            <ForbiddenWrap>
              <EmptyIconText text="Bạn không có quyền truy cập màn hình này." />
            </ForbiddenWrap>
          ) : (
            <>
              <ActivityToolbar
                keyword={keyword}
                fromDate={fromDate}
                toDate={toDate}
                actorAccountId={actorAccountId}
                actionType={actionType}
                actorOpts={actorOpts}
                loading={loading}
                onSearch={handleSearch}
                onFilterChange={handleFilterChange}
              />

              <ActivityDataTable
                rows={pagedRows}
                loading={loading}
                page={page}
                size={size}
                total={filteredItems.length}
                onPageChange={handlePageChange}
                onPageSizeChange={handlePageSizeChange}
              />
            </>
          )}
        </CardPanel>
      </PageWrap>
    </>
  );
};

export default HistoryMain;
