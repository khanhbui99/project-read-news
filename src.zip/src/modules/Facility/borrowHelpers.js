import dayjs from "dayjs";
import { DateFormat4 } from "utils/constants";
import { isBGH } from "utils/helpers";

import { mapAssetItem, mapOpt, LIST_FETCH_SIZE } from "./assetHelpers";
import {
  ASSET_TABS,
  BORROW_ROLE,
  BORROW_STATUS,
  BORROW_STATUS_MAP,
} from "./store/constants";

export { LIST_FETCH_SIZE, mapOpt };

const formatDate = (value) => {
  if (!value) return "--";
  const d = dayjs(value);
  return d.isValid() ? d.format(DateFormat4) : "--";
};

/** Mã đơn mượn: MT-{id}. id < 1000 → pad 3 số (001–999); id ≥ 1000 → giữ nguyên. */
export const formatBorrowCode = (id) => {
  if (id == null || id === "") return "--";
  const number = Number(id);
  if (!Number.isFinite(number) || number < 0) return `MT-${id}`;
  const value = Math.trunc(number);
  if (value < 1000) return `MT-${String(value).padStart(3, "0")}`;
  return `MT-${value}`;
};

const collectRoleTokens = (userInfo = {}) => {
  const tokens = [];
  const push = (value) => {
    if (value == null || value === "") return;
    if (Array.isArray(value)) {
      value.forEach(push);
      return;
    }
    if (typeof value === "object") {
      push(value.code);
      push(value.roleCode);
      push(value.name);
      push(value.roleName);
      push(value.role);
      return;
    }
    String(value)
      .split(/[;,|]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((part) => tokens.push(part.toUpperCase()));
  };

  push(userInfo.listRole);
  push(userInfo.list_role);
  push(userInfo.roleName);
  push(userInfo.roleCode);
  push(userInfo.role);
  push(userInfo.currentRole);
  push(userInfo.roles);

  (userInfo.orgCharts || userInfo.org_charts || []).forEach((org) => {
    push(org?.roleName);
    push(org?.roleCode);
    push(org?.role);
  });

  return tokens;
};

const roleTextIncludes = (tokens = [], keywords = []) =>
  tokens.some((token) =>
    keywords.some((keyword) => token.includes(String(keyword).toUpperCase())),
  );

/** Giáo viên / BGH — đúng BRD Module 10 */
export const resolveBorrowRole = (userInfo = {}) => {
  const tokens = collectRoleTokens(userInfo);
  const exactRoles = new Set(tokens);

  if (
    (typeof isBGH === "function" && isBGH()) ||
    userInfo?.isBGH ||
    exactRoles.has("HIỆU TRƯỞNG") ||
    exactRoles.has("PHÓ HIỆU TRƯỞNG") ||
    roleTextIncludes(tokens, [
      "BGH",
      "BAN GIAM HIEU",
      "BAN_GIAM",
      "HIỆU TRƯỞNG",
      "HIEU TRUONG",
      "PHÓ HIỆU TRƯỞNG",
      "PHO HIEU TRUONG",
      "SCHOOL_MANAGER",
      "SCHOOL MANAGER",
    ])
  ) {
    return BORROW_ROLE.SCHOOL_MANAGER;
  }

  if (
    roleTextIncludes(tokens, [
      "TEACHER",
      "GIAO_VIEN",
      "GIAO VIEN",
      "GIÁO VIÊN",
      "GIÁO VIEN",
      "GV",
    ])
  ) {
    return BORROW_ROLE.TEACHER;
  }

  return BORROW_ROLE.OTHER;
};

export const canAccessBorrow = (role) =>
  role === BORROW_ROLE.TEACHER || role === BORROW_ROLE.SCHOOL_MANAGER;

/** Giáo viên / BGH được tạo đơn mượn + trả theo BRD */
export const canCreateBorrow = (role) => canAccessBorrow(role);

export const mapBorrowAsset = (item = {}) => {
  const mapped = mapAssetItem(item);
  return {
    ...mapped,
    assetGroup: item.assetGroup || mapped.assetGroup || "",
  };
};

export const mapBorrowItem = (item = {}) => {
  const returnedAt = item.returnedAt || item.returnAt || item.returnedDate || null;
  const returned = !!(
    returnedAt ||
    item.returned ||
    item.isReturned ||
    item.returnStatus === "RETURNED"
  );
  return {
    id: item.id || item.itemId,
    assetId: item.assetId || item.asset?.id || item.id,
    code: item.code || item.assetCode || item.asset?.code || "--",
    name: item.name || item.assetName || item.asset?.name || "--",
    typeName:
      item.typeName || item.facilityTypeName || item.asset?.typeName || "--",
    roomName: item.roomName || item.asset?.roomName || "--",
    facilitySubjectId: item.facilitySubjectId ?? item.subjectId ?? "",
    facilityTypeId: item.facilityTypeId ?? item.typeId ?? "",
    roomId: item.roomId ?? item.asset?.roomId ?? "",
    assetGroup: item.assetGroup || item.asset?.assetGroup || "",
    returnedAt,
    returnedAtDisplay: formatDate(returnedAt),
    returned,
    conditionOnReturn:
      item.conditionOnReturn || item.returnCondition || item.condition || "",
    returnNote: item.returnNote || item.note || "",
    status: item.status || "",
  };
};

export const mapBorrowOrder = (item = {}) => {
  const items = (item.items || item.assets || []).map(mapBorrowItem);
  const unreturned = items.filter((x) => !x.returned);
  const returnedItems = items.filter((x) => x.returned);
  const dueDate = item.dueDate || item.expectedReturnDate || null;
  const latestReturnedAt =
    item.returnedAt ||
    returnedItems
      .map((x) => x.returnedAt)
      .filter(Boolean)
      .sort((a, b) => dayjs(b).valueOf() - dayjs(a).valueOf())[0] ||
    null;

  const isReturned =
    item.status === BORROW_STATUS.RETURNED ||
    item.returned === true ||
    (items.length > 0 && unreturned.length === 0);
  const isOverdue =
    !isReturned &&
    dueDate &&
    dayjs(dueDate).isValid() &&
    dayjs(dueDate).isBefore(dayjs(), "day");

  let status = item.status || BORROW_STATUS.BORROWING;
  if (isReturned) status = BORROW_STATUS.RETURNED;
  else if (isOverdue) status = BORROW_STATUS.OVERDUE;
  else status = BORROW_STATUS.BORROWING;

  return {
    ...item,
    id: item.id,
    code: formatBorrowCode(item.id),
    borrowerName:
      item.borrowerName ||
      item.createdByName ||
      item.userName ||
      item.borrower?.fullName ||
      "--",
    borrowerId:
      item.borrowerId ||
      item.createdBy ||
      item.userId ||
      item.borrower?.id ||
      "",
    borrowedAt: item.borrowedAt || item.borrowDate || item.createdAt || null,
    borrowedAtDisplay: formatDate(
      item.borrowedAt || item.borrowDate || item.createdAt,
    ),
    dueDate,
    dueDateDisplay: formatDate(dueDate),
    returnedAt: latestReturnedAt,
    returnedAtDisplay: formatDate(latestReturnedAt),
    assetCount: item.assetCount ?? item.itemCount ?? items.length,
    returnedCount: returnedItems.length,
    items,
    unreturnedCount: unreturned.length,
    status,
    statusName: BORROW_STATUS_MAP[status] || status || "--",
    note: item.note || "",
    conditionOnReturn:
      item.conditionOnReturn ||
      item.returnCondition ||
      returnedItems.find((x) => x.conditionOnReturn)?.conditionOnReturn ||
      "",
    returnNote:
      item.returnNote ||
      returnedItems.find((x) => x.returnNote)?.returnNote ||
      "",
    canReturn: !isReturned && unreturned.length > 0,
  };
};

/** Parse GET /borrows/mine — tách theo returnedAt của từng item */
export const mapMyBorrowsResponse = (data = {}) => {
  const toOrders = (list) =>
    (Array.isArray(list) ? list : []).map(mapBorrowOrder);

  let allOrders = [];
  if (Array.isArray(data)) {
    allOrders = toOrders(data);
  } else {
    const borrowingRaw =
      data.borrowing || data.borrowingOrders || data.active || data.open || [];
    const returnedRaw =
      data.returned || data.returnedOrders || data.closed || data.done || [];
    const merged = [
      ...toOrders(borrowingRaw),
      ...toOrders(returnedRaw),
    ];
    // dedupe by id
    const map = new Map();
    merged.forEach((order) => {
      if (order?.id == null) return;
      map.set(String(order.id), order);
    });
    allOrders = map.size ? Array.from(map.values()) : merged;
  }

  // Tab mượn: còn item chưa có returnedAt
  const borrowing = allOrders
    .map((order) => {
      const activeItems = (order.items || []).filter((item) => !item.returned);
      if (!activeItems.length) return null;
      return {
        ...order,
        items: activeItems,
        assetCount: activeItems.length,
        unreturnedCount: activeItems.length,
        returnedCount: 0,
        canReturn: true,
        status:
          order.status === BORROW_STATUS.OVERDUE
            ? BORROW_STATUS.OVERDUE
            : BORROW_STATUS.BORROWING,
        statusName:
          order.status === BORROW_STATUS.OVERDUE
            ? BORROW_STATUS_MAP[BORROW_STATUS.OVERDUE]
            : BORROW_STATUS_MAP[BORROW_STATUS.BORROWING],
      };
    })
    .filter(Boolean);

  // Tab trả: item đã có returnedAt
  const returned = allOrders
    .map((order) => {
      const doneItems = (order.items || []).filter((item) => item.returned);
      if (!doneItems.length) return null;
      const latestReturnedAt =
        doneItems
          .map((x) => x.returnedAt)
          .filter(Boolean)
          .sort((a, b) => dayjs(b).valueOf() - dayjs(a).valueOf())[0] || null;
      return {
        ...order,
        items: doneItems,
        assetCount: doneItems.length,
        unreturnedCount: 0,
        returnedCount: doneItems.length,
        canReturn: false,
        returnedAt: latestReturnedAt,
        returnedAtDisplay: formatDate(latestReturnedAt),
        status: BORROW_STATUS.RETURNED,
        statusName: BORROW_STATUS_MAP[BORROW_STATUS.RETURNED],
      };
    })
    .filter(Boolean);

  return { borrowing, returned };
};
export const filterBorrowOrdersLocal = (
  items = [],
  {
    keyword = "",
    subjectFilter = "ALL",
    typeFilter = "ALL",
    roomFilter = "ALL",
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((order) => {
    if (kw) {
      const hay = `${order.code || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (
      subjectFilter !== "ALL" ||
      typeFilter !== "ALL" ||
      roomFilter !== "ALL"
    ) {
      const assets = order.items || [];
      if (!assets.length) return true;
      const matchAsset = assets.some((a) => {
        if (
          subjectFilter !== "ALL" &&
          String(a.facilitySubjectId || a.subjectId || "") !==
            String(subjectFilter)
        ) {
          // fixed assets always pass subject filter per BRD — if no subject, pass
          if (a.assetGroup === ASSET_TABS.FIXED || a.facilitySubjectId == null) {
            /* allow */
          } else {
            return false;
          }
        }
        if (
          typeFilter !== "ALL" &&
          String(a.facilityTypeId || a.typeId || "") !== String(typeFilter)
        ) {
          return false;
        }
        if (
          roomFilter !== "ALL" &&
          String(a.roomId || "") !== String(roomFilter)
        ) {
          return false;
        }
        return true;
      });
      if (!matchAsset) return false;
    }
    return true;
  });
};

/** Filter môn chỉ áp dụng TB dạy học; TSCĐ luôn hiện */
export const filterAvailableAssetsLocal = (
  items = [],
  {
    keyword = "",
    subjectFilter = "ALL",
    typeFilter = "ALL",
    roomFilter = "ALL",
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((item) => {
    if (kw) {
      const hay = `${item.code || ""} ${item.name || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    const isFixed =
      item.assetGroup === ASSET_TABS.FIXED ||
      item.assetGroup === "FIXED" ||
      !item.facilitySubjectId;
    if (
      subjectFilter &&
      subjectFilter !== "ALL" &&
      !isFixed &&
      String(item.facilitySubjectId) !== String(subjectFilter)
    ) {
      return false;
    }
    if (
      typeFilter &&
      typeFilter !== "ALL" &&
      String(item.facilityTypeId) !== String(typeFilter)
    ) {
      return false;
    }
    if (
      roomFilter &&
      roomFilter !== "ALL" &&
      String(item.roomId) !== String(roomFilter)
    ) {
      return false;
    }
    return true;
  });
};

export const mapRoomOpt = (item = {}) => ({
  value: item.id,
  label: item.name || item.code || `--`,
  ...item,
});

export const isBrokenOrMissing = (condition) =>
  condition === "BROKEN" || condition === "MISSING";
