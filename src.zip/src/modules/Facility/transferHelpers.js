import { mapAssetItem, mapOpt, LIST_FETCH_SIZE, paginateLocal } from "./assetHelpers";
import { ROOM_STATUS } from "./RoomAssignment/store/constants";

export const getEmptyTransferForm = () => ({
  sourceRoomId: "",
  targetRoomId: "",
  note: "",
});

export const mapTransferAssetItem = (item = {}) => {
  const mapped = mapAssetItem(item);
  return {
    ...mapped,
    transferable: item.transferable !== false && item.canTransfer !== false,
  };
};

/** Lấy danh sách tài sản từ response rooms.detail */
export const extractAssetsFromRoomDetail = (data = {}) => {
  const room = data?.room || data || {};
  const list =
    room.assets ||
    data?.assets ||
    room.roomAssets ||
    data?.roomAssets ||
    [];
  return Array.isArray(list) ? list : [];
};

export const filterTransferAssetsLocal = (
  items = [],
  {
    keyword = "",
    standardDeviceFilter = "ALL",
    subjectFilter = "ALL",
    typeFilter = "ALL",
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();

  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.code || ""} ${item.name || ""} ${item.standardDeviceName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (
      standardDeviceFilter &&
      standardDeviceFilter !== "ALL" &&
      String(item.standardDeviceId) !== String(standardDeviceFilter)
    ) {
      return false;
    }
    if (
      subjectFilter &&
      subjectFilter !== "ALL" &&
      String(item.facilitySubjectId) !== String(subjectFilter)
    ) {
      return false;
    }
    if (
      typeFilter &&
      typeFilter !== "ALL" &&
      String(item.facilityTypeId) !== String(typeFilter)
    ) {
      return false;
    }
    return true;
  });
};

export const mapRoomOpt = (item = {}) => ({
  value: item.id,
  label: item.name || item.code || `--`,
  status: item.status || ROOM_STATUS.ACTIVE,
  ...item,
});

/** Phòng đích: chỉ ACTIVE / MAINTENANCE, loại trừ phòng nguồn */
export const getTargetRoomOpts = (roomOpts = [], sourceRoomId) =>
  (roomOpts || []).filter((room) => {
    if (room.status === ROOM_STATUS.INACTIVE) return false;
    if (sourceRoomId && String(room.value) === String(sourceRoomId)) {
      return false;
    }
    return true;
  });

export const buildTransferPayload = ({
  sourceRoomId,
  targetRoomId,
  assetIds = [],
  note = "",
} = {}) => ({
  sourceRoomId: Number(sourceRoomId),
  targetRoomId: Number(targetRoomId),
  assetIds: (assetIds || []).map(Number).filter(Boolean),
  note: (note || "").trim() || "",
});

export { mapOpt, LIST_FETCH_SIZE, paginateLocal };
