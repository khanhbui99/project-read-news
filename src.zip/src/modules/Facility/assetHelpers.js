import dayjs from "dayjs";
import { DateFormat4 } from "utils/constants";

import { mapCatalogItem } from "./helpers";
import {
  ACQUISITION_TYPE,
  ACQUISITION_TYPE_MAP,
  ASSET_CONDITION,
  ASSET_CONDITION_MAP,
  ASSET_ROLE,
  ASSET_TABS,
  OPERATIONAL_STATUS,
  OPERATIONAL_STATUS_MAP,
} from "./store/constants";

const collectRoleTokens = (userInfo = {}) => {
  const tokens = [];
  const push = (value) => {
    if (value == null || value === "") return;
    if (Array.isArray(value)) {
      value.forEach(push);
      return;
    }
    if (typeof value === "object") {
      push(value.code);
      push(value.roleCode);
      push(value.name);
      push(value.roleName);
      push(value.role);
      return;
    }
    String(value)
      .split(/[;,|]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((part) => tokens.push(part.toUpperCase()));
  };

  push(userInfo.listRole);
  push(userInfo.list_role);
  push(userInfo.roleName);
  push(userInfo.roleCode);
  push(userInfo.role);
  push(userInfo.currentRole);
  push(userInfo.roles);

  (userInfo.orgCharts || userInfo.org_charts || []).forEach((org) => {
    push(org?.roleName);
    push(org?.roleCode);
    push(org?.role);
  });

  return tokens;
};

const roleTextIncludes = (tokens = [], keywords = []) =>
  tokens.some((token) =>
    keywords.some((keyword) => token.includes(String(keyword).toUpperCase())),
  );

/** CSVC quản lý đầy đủ; role khác chỉ xem phòng mình (my-rooms) */
export const resolveAssetRole = (userInfo = {}) => {
  const tokens = collectRoleTokens(userInfo);

  if (
    roleTextIncludes(tokens, [
      "CSVC",
      "FACILITY",
      "QUAN_LY_CSVC",
      "QUẢN LÝ CSVC",
      "QUAN LY CSVC",
      "FACILITY_MANAGER",
    ])
  ) {
    return ASSET_ROLE.FACILITY_MANAGER;
  }

  return ASSET_ROLE.OTHER;
};

export const canManageAssets = (role) =>
  role === ASSET_ROLE.FACILITY_MANAGER;

export const getEmptyCreateForm = (assetGroup = ASSET_TABS.FIXED) => ({
  assetGroup,
  standardDeviceId: "",
  facilityTypeId: "",
  facilitySubjectId: "",
  roomId: "",
  quantity: 1,
  condition: ASSET_CONDITION.NORMAL,
  acquisitionType: ACQUISITION_TYPE.PURCHASE,
  purchaseDate: null,
  unitPrice: "",
  supplier: "",
  documentNo: "",
  usageYear: "",
  expiryDate: null,
  note: "",
});

export const formatMoney = (value) => {
  if (value == null || value === "") return "";
  const num = Number(value);
  if (Number.isNaN(num)) return String(value);
  return `${num.toLocaleString("vi-VN")}đ`;
};

export const mapAssetItem = (item = {}) => {
  const condition = item.assetCondition || item.condition || "";
  const status = item.status || item.operationalStatus || "";
  const acquisitionTypeRaw =
    item.receiptType || item.acquisitionType || item.receiveType || "";
  const acquisitionType =
    acquisitionTypeRaw === "ALLOCATED"
      ? ACQUISITION_TYPE.GRANTED
      : acquisitionTypeRaw;
  const purchaseDate = item.purchaseDate || item.buyDate || null;
  const unitPrice = item.unitPrice ?? item.price ?? null;

  // facilitySubjectId / facilityTypeId lấy theo id danh mục Facility
  const facilityTypeId = item.facilityTypeId ?? item.type?.id ?? "";
  const facilitySubjectId = item.facilitySubjectId ?? item.subject?.id ?? "";

  let acquisitionDisplay =
    ACQUISITION_TYPE_MAP[acquisitionType] || acquisitionType || "--";
  if (acquisitionType === ACQUISITION_TYPE.PURCHASE) {
    const parts = [ACQUISITION_TYPE_MAP[ACQUISITION_TYPE.PURCHASE]];
    if (purchaseDate) parts.push(dayjs(purchaseDate).format(DateFormat4));
    if (unitPrice != null && unitPrice !== "") {
      parts.push(formatMoney(unitPrice));
    }
    acquisitionDisplay = parts.filter(Boolean).join(" · ");
  }

  return {
    ...item,
    code: item.code || "",
    name: item.name || item.standardDeviceName || "--",
    roomId: item.roomId || item.room?.id || "",
    roomName: item.roomName || item.room?.name || "--",
    facilityTypeId,
    typeName:
      item.facilityTypeName || item.typeName || item.type?.name || "--",
    facilitySubjectId,
    subjectName:
      item.facilitySubjectName ||
      item.subjectName ||
      item.subject?.name ||
      "--",
    standardDeviceId: item.standardDeviceId || item.standardDevice?.id || "",
    standardDeviceName:
      item.standardDeviceName || item.standardDevice?.name || item.name || "--",
    condition,
    conditionName: ASSET_CONDITION_MAP[condition] || condition || "--",
    status,
    statusName: OPERATIONAL_STATUS_MAP[status] || status || "--",
    acquisitionType,
    acquisitionTypeName:
      ACQUISITION_TYPE_MAP[acquisitionType] || acquisitionType || "--",
    acquisitionDisplay,
    purchaseDate,
    unitPrice,
    supplier: item.supplier || "",
    documentNo: item.receiptNumber || item.documentNo || item.voucherNo || "",
    usageYear: item.usageYear ?? item.yearOfUse ?? "",
    expiryDate: item.expiryDate || item.expireDate || null,
    note: item.note || "",
    canDelete: item.canDelete !== false && !item.hasHistory,
    updatedAtFormat: item.updatedAt
      ? dayjs(item.updatedAt).format(DateFormat4)
      : "--",
  };
};

export const mapHistoryItem = (item = {}, actorNameByAccountId) => {
  const occurredAt =
    item.occurredAt || item.time || item.createdAt || item.actedAt || null;
  const accountId = item.actorAccountId ?? item.accountId ?? item.userId;
  const teacherName =
    accountId != null && accountId !== "" && actorNameByAccountId
      ? actorNameByAccountId.get(String(accountId))
      : "";
  const oldValue =
    item.oldValue !== undefined && item.oldValue !== null
      ? String(item.oldValue)
      : "";
  const newValue =
    item.newValue !== undefined && item.newValue !== null
      ? String(item.newValue)
      : "";
  const hasChange = oldValue !== "" || newValue !== "";

  return {
    ...item,
    id:
      item.id ||
      `${occurredAt || ""}-${item.actionType || ""}-${item.entityId || ""}-${item.fieldName || ""}`,
    occurredAt,
    timeFormat: occurredAt
      ? dayjs(occurredAt).format("DD/MM/YYYY HH:mm")
      : "--",
    actorAccountId: accountId ?? "",
    actorName:
      item.actorName || item.performedBy || item.userName || teacherName || "--",
    actionType: item.actionType || "",
    actionName:
      item.description ||
      item.actionName ||
      item.action ||
      item.eventType ||
      item.actionType ||
      "--",
    entityCode: item.entityCode || item.entityId || "--",
    // Đối tượng: map GV theo actorAccountId
    objectDisplay: teacherName || item.entityCode || item.entityId || "--",
    entityType: item.entityType || "",
    fieldName: item.fieldName || "",
    oldValue: item.oldValue,
    newValue: item.newValue,
    description: item.description || "",
    changeText: hasChange
      ? `${oldValue || "--"} → ${newValue || "--"}`
      : item.changeText || item.change || item.description || "--",
  };
};

/** Option danh mục Facility — value luôn là id */
export const mapOpt = (item = {}) => {
  const mapped = mapCatalogItem(item);
  return {
    ...mapped,
    value: mapped.id,
    label: mapped.name || mapped.code || `--`,
  };
};

export const mapStandardDeviceOpt = (item = {}) => {
  const mapped = mapCatalogItem(item);
  return {
    ...mapped,
    value: mapped.id,
    label: mapped.name || mapped.code || `--`,
  };
};

export const buildCreatePayload = (values = {}) => {
  const isTeaching =
    values.assetGroup === ASSET_TABS.TEACHING_DEVICE ||
    values.assetGroup === "TEACHING_DEVICE";
  const isPurchase = values.acquisitionType === ACQUISITION_TYPE.PURCHASE;

  const payload = {
    standardDeviceId: Number(values.standardDeviceId) || 0,
    facilityTypeId: Number(values.facilityTypeId) || 0,
    roomId: Number(values.roomId) || 0,
    quantity: Number(values.quantity) || 0,
    assetCondition: values.condition || ASSET_CONDITION.NORMAL,
    receiptType: values.acquisitionType || ACQUISITION_TYPE.PURCHASE,
    purchaseDate: null,
    unitPrice: 0,
    supplier: "",
    receiptNumber: "",
    usageYear:
      values.usageYear === "" || values.usageYear == null
        ? 0
        : Number(values.usageYear) || 0,
    expiryDate: values.expiryDate
      ? dayjs(values.expiryDate).format("YYYY-MM-DD")
      : null,
    note: (values.note || "").trim() || "",
  };

  // Thiết bị dạy học: truyền môn theo form
  if (isTeaching || values.facilitySubjectId) {
    payload.facilitySubjectId = Number(values.facilitySubjectId) || 0;
  }

  if (values.assetGroup) {
    payload.assetGroup = values.assetGroup;
  }

  if (isPurchase && !isTeaching) {
    payload.purchaseDate = values.purchaseDate
      ? dayjs(values.purchaseDate).format("YYYY-MM-DD")
      : null;
    payload.unitPrice =
      values.unitPrice === "" || values.unitPrice == null
        ? 0
        : Number(values.unitPrice) || 0;
    payload.supplier = (values.supplier || "").trim() || "";
    payload.receiptNumber = (values.documentNo || "").trim() || "";
  }

  return payload;
};

export const buildUpdatePayload = (values = {}) => {
  const isPurchase = values.acquisitionType === ACQUISITION_TYPE.PURCHASE;
  const payload = {
    facilityTypeId: Number(values.facilityTypeId) || 0,
    receiptType: values.acquisitionType,
    purchaseDate: null,
    unitPrice: 0,
    supplier: "",
    receiptNumber: "",
    usageYear:
      values.usageYear === "" || values.usageYear == null
        ? 0
        : Number(values.usageYear) || 0,
    expiryDate: values.expiryDate
      ? dayjs(values.expiryDate).format("YYYY-MM-DD")
      : null,
    note: (values.note || "").trim() || "",
  };

  if (values.facilitySubjectId != null && values.facilitySubjectId !== "") {
    payload.facilitySubjectId = Number(values.facilitySubjectId) || 0;
  }

  if (isPurchase) {
    payload.purchaseDate = values.purchaseDate
      ? dayjs(values.purchaseDate).format("YYYY-MM-DD")
      : null;
    payload.unitPrice =
      values.unitPrice === "" || values.unitPrice == null
        ? 0
        : Number(values.unitPrice) || 0;
    payload.supplier = (values.supplier || "").trim() || "";
    payload.receiptNumber = (values.documentNo || "").trim() || "";
  }

  return payload;
};

export const buildListParams = ({
  keyword,
  assetGroup,
  standardDeviceId,
  roomId,
  facilityTypeId,
  facilitySubjectId,
  typeId,
  subjectId,
  condition,
  status,
  acquisitionType,
  page,
  size,
} = {}) => {
  const params = {
    page,
    size,
    assetGroup,
    sort: "codeNumeric,asc",
  };

  const typeFilterId = facilityTypeId ?? typeId;
  const subjectFilterId = facilitySubjectId ?? subjectId;

  if (keyword && String(keyword).trim()) {
    params.keyword = String(keyword).trim();
  }
  if (standardDeviceId && standardDeviceId !== "ALL") {
    params.standardDeviceId = standardDeviceId;
  }
  if (roomId && roomId !== "ALL") params.roomId = roomId;
  if (typeFilterId && typeFilterId !== "ALL") {
    params.facilityTypeId = typeFilterId;
  }
  if (subjectFilterId && subjectFilterId !== "ALL") {
    params.facilitySubjectId = subjectFilterId;
  }
  if (condition && condition !== "ALL") params.assetCondition = condition;
  if (acquisitionType && acquisitionType !== "ALL") {
    params.receiptType = acquisitionType;
  }

  if (!status || status === "ALL") {
    params.excludeDisposed = true;
  } else {
    params.status = status;
  }

  return params;
};

export const LIST_FETCH_SIZE = 10000;

/** Params chỉ lấy full list theo nhóm — lọc ở client */
export const buildFetchAllAssetsParams = (assetGroup) => ({
  assetGroup,
  page: 0,
  size: LIST_FETCH_SIZE,
  sort: "codeNumeric,asc",
});

export const filterAssetsLocal = (
  items = [],
  {
    keyword = "",
    standardDeviceFilter = "ALL",
    roomFilter = "ALL",
    typeFilter = "ALL",
    subjectFilter = "ALL",
    conditionFilter = "ALL",
    statusFilter = "ALL",
    acquisitionFilter = "ALL",
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();

  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.code || ""} ${item.name || ""} ${item.standardDeviceName || ""} ${item.roomName || ""} ${item.typeName || ""} ${item.subjectName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (
      standardDeviceFilter &&
      standardDeviceFilter !== "ALL" &&
      String(item.standardDeviceId) !== String(standardDeviceFilter)
    ) {
      return false;
    }
    if (
      roomFilter &&
      roomFilter !== "ALL" &&
      String(item.roomId) !== String(roomFilter)
    ) {
      return false;
    }
    if (
      typeFilter &&
      typeFilter !== "ALL" &&
      String(item.facilityTypeId) !== String(typeFilter)
    ) {
      return false;
    }
    if (
      subjectFilter &&
      subjectFilter !== "ALL" &&
      String(item.facilitySubjectId) !== String(subjectFilter)
    ) {
      return false;
    }
    if (
      conditionFilter &&
      conditionFilter !== "ALL" &&
      item.condition !== conditionFilter
    ) {
      return false;
    }
    if (
      acquisitionFilter &&
      acquisitionFilter !== "ALL" &&
      item.acquisitionType !== acquisitionFilter
    ) {
      return false;
    }
    if (!statusFilter || statusFilter === "ALL") {
      if (item.status === OPERATIONAL_STATUS.DISPOSED) return false;
    } else if (item.status !== statusFilter) {
      return false;
    }
    return true;
  });
};

export const paginateLocal = (items = [], page = 0, size = 10) => {
  const start = Number(page) * Number(size);
  return items.slice(start, start + Number(size));
};

export const filterAssetHistoryLocal = (items = [], keyword = "") => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  if (!kw) return items || [];
  return (items || []).filter((item) => {
    const hay =
      `${item.timeFormat || ""} ${item.actorName || ""} ${item.actionName || ""} ${item.objectDisplay || ""} ${item.entityCode || ""} ${item.changeText || ""} ${item.description || ""}`.toLowerCase();
    return hay.includes(kw);
  });
};

/** Params xuất nhãn: lọc theo thiết bị chuẩn / phòng */
export const buildExportAssetParams = ({
  assetGroup,
  standardDeviceId,
  roomId,
} = {}) => {
  const params = {};
  if (assetGroup) params.assetGroup = assetGroup;
  if (standardDeviceId && standardDeviceId !== "ALL") {
    params.standardDeviceId = standardDeviceId;
  }
  if (roomId && roomId !== "ALL") params.roomId = roomId;
  return params;
};

export const mapExportAssetLabelRow = (item = {}) => ({
  code: item.code || item.assetCode || "",
  name: item.name || item.assetName || item.standardDeviceName || "",
  roomName:
    item.roomName ||
    item.room?.name ||
    item.roomLabel ||
    "",
});

/** Cột Excel = cột table (không gồm checkbox / thao tác). */
export const getAssetTableExportColumns = (isTeaching = false) => {
  const cols = [
    { name: "Mã", field: "code" },
    { name: "Tên", field: "name" },
    { name: "Phòng", field: "roomName" },
  ];
  if (isTeaching) {
    cols.push({ name: "Môn", field: "subjectName" });
  } else {
    cols.push({ name: "Loại", field: "typeName" });
  }
  cols.push(
    { name: "Tình trạng tài sản", field: "conditionName" },
    { name: "Trạng thái vận hành", field: "statusName" },
  );
  if (isTeaching) {
    cols.push({ name: "Năm sử dụng", field: "usageYear" });
  }
  cols.push({ name: "Hình thức tiếp nhận", field: "acquisitionDisplay" });
  return cols;
};
