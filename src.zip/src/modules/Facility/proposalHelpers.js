import dayjs from "dayjs";
import { DateFormat4 } from "utils/constants";
import { isBGH } from "utils/helpers";

import { mapAssetItem, mapOpt, LIST_FETCH_SIZE } from "./assetHelpers";
import { isInDateRange } from "./helpers";
import { ROOM_STATUS } from "./RoomAssignment/store/constants";
import {
  OPERATIONAL_STATUS,
  OPERATIONAL_STATUS_MAP,
  PROPOSAL_DECISION,
  PROPOSAL_DECISION_MAP,
  PROPOSAL_ROLE,
  PROPOSAL_STATUS,
  PROPOSAL_STATUS_MAP,
  PROPOSAL_TABS,
} from "./store/constants";

export { LIST_FETCH_SIZE, mapOpt };

const collectRoleTokens = (userInfo = {}) => {
  const tokens = [];
  const push = (value) => {
    if (value == null || value === "") return;
    if (Array.isArray(value)) {
      value.forEach(push);
      return;
    }
    if (typeof value === "object") {
      push(value.code);
      push(value.roleCode);
      push(value.name);
      push(value.roleName);
      push(value.role);
      return;
    }
    String(value)
      .split(/[;,|]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((part) => tokens.push(part.toUpperCase()));
  };

  push(userInfo.listRole);
  push(userInfo.list_role);
  push(userInfo.roleName);
  push(userInfo.roleCode);
  push(userInfo.role);
  push(userInfo.currentRole);
  push(userInfo.roles);

  (userInfo.orgCharts || userInfo.org_charts || []).forEach((org) => {
    push(org?.roleName);
    push(org?.roleCode);
    push(org?.role);
  });

  return tokens;
};

const roleTextIncludes = (tokens = [], keywords = []) =>
  tokens.some((token) =>
    keywords.some((keyword) => token.includes(String(keyword).toUpperCase())),
  );

export const resolveProposalRole = (userInfo = {}) => {
  const tokens = collectRoleTokens(userInfo);
  const exactRoles = new Set(tokens);

  // BGH: Hiệu trưởng / Phó hiệu trưởng — chỉ duyệt/từ chối (BRD 05-role-permission)
  if (
    (typeof isBGH === "function" && isBGH()) ||
    userInfo?.isBGH ||
    exactRoles.has("HIỆU TRƯỞNG") ||
    exactRoles.has("PHÓ HIỆU TRƯỞNG") ||
    roleTextIncludes(tokens, [
      "BGH",
      "BAN GIAM HIEU",
      "BAN_GIAM",
      "HIỆU TRƯỞNG",
      "HIEU TRUONG",
      "PHÓ HIỆU TRƯỞNG",
      "PHO HIEU TRUONG",
      "SCHOOL_MANAGER",
      "SCHOOL MANAGER",
    ])
  ) {
    return PROPOSAL_ROLE.SCHOOL_MANAGER;
  }

  if (
    roleTextIncludes(tokens, [
      "CSVC",
      "FACILITY",
      "QUAN_LY_CSVC",
      "QUẢN LÝ CSVC",
      "QUAN LY CSVC",
      "FACILITY_MANAGER",
    ])
  ) {
    return PROPOSAL_ROLE.FACILITY_MANAGER;
  }

  return PROPOSAL_ROLE.OTHER;
};

export const canCreateProposal = (role) =>
  role === PROPOSAL_ROLE.FACILITY_MANAGER;

/** BGH được duyệt / từ chối item khi proposal đang Chờ xử lý */
export const canDecideProposal = (role) =>
  role === PROPOSAL_ROLE.SCHOOL_MANAGER;

/** Item chưa có kết quả duyệt thì BGH được tick */
export const canDecideProposalItem = (item = {}) => {
  const decision = normalizeProposalDecision(
    item.decision || item.decisionStatus || item.approveResult || "",
  );
  return (
    !decision ||
    decision === PROPOSAL_DECISION.PENDING ||
    decision === "NONE"
  );
};

export const canSubmitDraft = (role, status) =>
  role === PROPOSAL_ROLE.FACILITY_MANAGER &&
  normalizeProposalStatus(status) === PROPOSAL_STATUS.DRAFT;

/** BGH: proposal đang chờ xử lý → hiện nút Thực hiện */
export const proposalNeedsBghAction = (proposal = {}, canDecide = false) =>
  !!canDecide &&
  normalizeProposalStatus(proposal?.status) === PROPOSAL_STATUS.PENDING;

const formatDate = (value) => {
  if (!value) return "--";
  const d = dayjs(value);
  return d.isValid() ? d.format(DateFormat4) : "--";
};

export const normalizeProposalStatus = (status) => {
  const key = String(status || "")
    .trim()
    .toUpperCase();
  const aliases = {
    DRAFT: PROPOSAL_STATUS.DRAFT,
    NHAP: PROPOSAL_STATUS.DRAFT,
    PENDING: PROPOSAL_STATUS.PENDING,
    WAITING: PROPOSAL_STATUS.PENDING,
    SUBMITTED: PROPOSAL_STATUS.PENDING,
    IN_REVIEW: PROPOSAL_STATUS.PENDING,
    CHO_XU_LY: PROPOSAL_STATUS.PENDING,
    COMPLETED: PROPOSAL_STATUS.COMPLETED,
    COMPLETE: PROPOSAL_STATUS.COMPLETED,
    DONE: PROPOSAL_STATUS.COMPLETED,
    HOAN_TAT: PROPOSAL_STATUS.COMPLETED,
  };
  return aliases[key] || key || PROPOSAL_STATUS.DRAFT;
};

export const getProposalStatusName = (status) => {
  const normalized = normalizeProposalStatus(status);
  return PROPOSAL_STATUS_MAP[normalized] || status || "--";
};

export const normalizeProposalDecision = (decision) => {
  const key = String(decision || "")
    .trim()
    .toUpperCase();
  const aliases = {
    APPROVED: PROPOSAL_DECISION.APPROVED,
    APPROVE: PROPOSAL_DECISION.APPROVED,
    ACCEPTED: PROPOSAL_DECISION.APPROVED,
    REJECTED: PROPOSAL_DECISION.REJECTED,
    REJECT: PROPOSAL_DECISION.REJECTED,
    PENDING: PROPOSAL_DECISION.PENDING,
    WAITING: PROPOSAL_DECISION.PENDING,
    NONE: PROPOSAL_DECISION.PENDING,
  };
  return aliases[key] || key || "";
};

export const getProposalDecisionName = (decision) => {
  const normalized = normalizeProposalDecision(decision);
  if (!normalized) return "--";
  return PROPOSAL_DECISION_MAP[normalized] || decision || "--";
};

export const getOperationalStatusName = (status) => {
  const key = String(status || "")
    .trim()
    .toUpperCase();
  return OPERATIONAL_STATUS_MAP[key] || status || "--";
};

export const mapProposalItem = (item = {}, tab = PROPOSAL_TABS.DISPOSAL) => {
  const status = normalizeProposalStatus(item.status);
  const id = item.id;
  return {
    ...item,
    id,
    code: item.code || item.proposalCode || "--",
    assetCount:
      item.assetCount ??
      item.itemCount ??
      item.totalItems ??
      (item.items || []).length ??
      0,
    creatorName:
      item.proposedByName ||
      item.creatorName ||
      item.createdByName ||
      item.proposerName ||
      item.createdBy ||
      "--",
    status,
    statusName: getProposalStatusName(status),
    label:
      tab === PROPOSAL_TABS.DISPOSAL && id != null && id !== ""
        ? `#${id}`
        : "",
    createdAt: item.createdAt || item.createDate || null,
    createdAtDisplay: formatDate(item.createdAt || item.createDate),
    approverName:
      item.lastDecidedByName ||
      item.approverName ||
      item.decidedByName ||
      item.approvedByName ||
      "--",
    approvedAtDisplay: formatDate(
      item.lastDecidedAt ||
        item.approvedAt ||
        item.decidedAt ||
        item.approveDate,
    ),
    reason: item.reason || "",
    tab,
  };
};

export const mapProposalDetail = (data = {}, tab = PROPOSAL_TABS.DISPOSAL) => {
  const base = mapProposalItem(data, tab);
  const items = (data.items || data.assets || []).map((item, index) => {
    const operationalStatus =
      item.assetStatus ||
      item.operationalStatus ||
      item.status ||
      item.itemStatus ||
      "";
    const decisionRaw =
      item.decision ||
      item.approveResult ||
      item.decisionStatus ||
      item.decisionResult ||
      (item.approved === true
        ? PROPOSAL_DECISION.APPROVED
        : item.approved === false
          ? PROPOSAL_DECISION.REJECTED
          : "");
    const decision = normalizeProposalDecision(decisionRaw);

    const isRestoreTab = tab === PROPOSAL_TABS.RESTORE;
    const originalRoomName =
      item.originalRoomName ||
      item.sourceRoomName ||
      (!isRestoreTab
        ? item.roomName || item.asset?.roomName || ""
        : "") ||
      "--";
    // Đề xuất khôi phục: phòng gốc = originalRoomName, phòng đích = roomName
    const roomName = isRestoreTab
      ? item.roomName ||
        item.targetRoomName ||
        item.targetRoom?.name ||
        item.restoreRoomName ||
        "--"
      : item.roomName ||
        item.sourceRoomName ||
        item.originalRoomName ||
        item.asset?.roomName ||
        "--";
    const targetRoomName = isRestoreTab
      ? item.roomName ||
        item.targetRoomName ||
        item.targetRoom?.name ||
        item.restoreRoomName ||
        "--"
      : item.targetRoomName ||
        item.targetRoom?.name ||
        item.restoreRoomName ||
        "";

    return {
      ...item,
      id: item.id || item.itemId || index,
      assetId: item.assetId || item.asset?.id || item.id,
      code: item.code || item.assetCode || item.asset?.code || "--",
      name: item.name || item.assetName || item.asset?.name || "--",
      originalRoomName,
      roomName,
      targetRoomId:
        item.targetRoomId || item.targetRoom?.id || item.restoreRoomId || "",
      targetRoomName,
      status: operationalStatus,
      statusName: getOperationalStatusName(operationalStatus),
      decision,
      decisionName: getProposalDecisionName(decision),
    };
  });

  return {
    ...base,
    items,
  };
};

export const mapProposalAsset = (item = {}, isRestore = false) => {
  const mapped = mapAssetItem(item);
  const originalRoomId =
    item.originalRoomId || item.sourceRoomId || mapped.roomId || "";
  const originalRoomName =
    item.originalRoomName ||
    item.sourceRoomName ||
    mapped.roomName ||
    "--";
  const roomActive =
    item.originalRoomStatus !== ROOM_STATUS.INACTIVE &&
    item.roomStatus !== ROOM_STATUS.INACTIVE;

  return {
    ...mapped,
    originalRoomId,
    originalRoomName,
    targetRoomId: isRestore && roomActive ? originalRoomId : "",
    selectable: isRestore
      ? mapped.status === OPERATIONAL_STATUS.DISPOSED ||
        item.status === OPERATIONAL_STATUS.DISPOSED
      : true,
  };
};

/** Nested assets từ đề xuất loại bỏ trên list (data ngoài list đã có) */
export const getProposalNestedAssets = (proposal = {}) => {
  const list =
    proposal.items ||
    proposal.assets ||
    proposal.assetList ||
    proposal.disposedAssets ||
    proposal.unitItems ||
    [];
  return Array.isArray(list) ? list : [];
};

/**
 * Từ các đề xuất loại bỏ đã tick → danh sách tài sản có thể khôi phục
 * Chỉ lấy item đã xác nhận loại bỏ (APPROVED).
 */
export const buildRestoreCandidatesFromDisposalProposals = (
  proposals = [],
) => {
  const byAssetId = new Map();

  (proposals || []).forEach((proposal) => {
    const nested = getProposalNestedAssets(proposal);

    nested.forEach((raw, index) => {
      const decision = normalizeProposalDecision(
        raw.decision ||
          raw.approveResult ||
          raw.decisionStatus ||
          raw.decisionResult ||
          (raw.approved === true
            ? PROPOSAL_DECISION.APPROVED
            : raw.approved === false
              ? PROPOSAL_DECISION.REJECTED
              : ""),
      );

      // Chỉ tài sản đã xác nhận loại bỏ mới được khôi phục
      if (decision !== PROPOSAL_DECISION.APPROVED) return;

      const assetId = raw.assetId || raw.asset?.id || raw.id;
      if (assetId == null || assetId === "") return;

      const roomId =
        raw.roomId ||
        raw.sourceRoomId ||
        raw.originalRoomId ||
        raw.room?.id ||
        proposal.roomId ||
        "";
      const roomName =
        raw.roomName ||
        raw.sourceRoomName ||
        raw.originalRoomName ||
        raw.room?.name ||
        proposal.roomName ||
        "--";

      const key = String(assetId);
      if (byAssetId.has(key)) return;

      byAssetId.set(key, {
        id: assetId,
        assetId,
        code: raw.code || raw.assetCode || raw.asset?.code || "--",
        name:
          raw.name ||
          raw.assetName ||
          raw.standardDeviceName ||
          raw.asset?.name ||
          "--",
        roomId,
        roomName,
        originalRoomId: roomId,
        originalRoomName: roomName,
        targetRoomId: roomId || "",
        status: OPERATIONAL_STATUS.DISPOSED,
        statusName:
          OPERATIONAL_STATUS_MAP[OPERATIONAL_STATUS.DISPOSED] || "Đã loại bỏ",
        standardDeviceName: raw.standardDeviceName || "--",
        subjectName: raw.subjectName || raw.facilitySubjectName || "--",
        typeName: raw.typeName || raw.facilityTypeName || "--",
        selectable: true,
        decision,
        decisionName: getProposalDecisionName(decision),
        fromProposalId: proposal.id,
        fromProposalCode: proposal.code || proposal.proposalCode || "",
        rowKey: `${proposal.id || "p"}-${assetId}-${index}`,
      });
    });
  });

  return Array.from(byAssetId.values());
};

/**
 * Gom theo phòng để user tick chọn phòng cần khôi phục.
 * Chỉ phòng có tài sản đã xác nhận loại bỏ mới được chọn (selectable).
 */
export const buildRestoreRoomsFromCandidates = (candidates = []) => {
  const roomMap = new Map();

  (candidates || []).forEach((asset) => {
    const roomId = asset.originalRoomId || asset.roomId;
    const hasRoom = roomId != null && roomId !== "";
    const key = hasRoom ? String(roomId) : "__NONE__";
    const approved = asset.decision === PROPOSAL_DECISION.APPROVED;
    if (!roomMap.has(key)) {
      roomMap.set(key, {
        id: hasRoom ? roomId : key,
        roomId: hasRoom ? roomId : "",
        roomName: hasRoom
          ? asset.originalRoomName || asset.roomName || "--"
          : "Chưa xác định phòng gốc",
        assetIds: [],
        assetCount: 0,
        selectable: false,
      });
    }
    const room = roomMap.get(key);
    if (!room.assetIds.map(String).includes(String(asset.id))) {
      room.assetIds.push(asset.id);
      room.assetCount = room.assetIds.length;
    }
    if (approved) room.selectable = true;
  });

  return Array.from(roomMap.values());
};

export const filterProposalsLocal = (
  items = [],
  { keyword = "", statusFilter = "ALL", fromDate = null, toDate = null } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((item) => {
    if (kw) {
      const hay = `${item.code || ""} ${item.creatorName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (statusFilter && statusFilter !== "ALL" && item.status !== statusFilter) {
      return false;
    }
    if (!isInDateRange(item.createdAt, fromDate, toDate)) {
      return false;
    }
    return true;
  });
};

export const filterProposalAssetsLocal = (
  items = [],
  {
    keyword = "",
    roomFilter = "ALL",
    subjectFilter = "ALL",
    typeFilter = "ALL",
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((item) => {
    if (kw) {
      const hay = `${item.code || ""} ${item.name || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    const roomId = item.originalRoomId || item.roomId;
    if (roomFilter && roomFilter !== "ALL" && String(roomId) !== String(roomFilter)) {
      return false;
    }
    if (
      subjectFilter &&
      subjectFilter !== "ALL" &&
      String(item.facilitySubjectId) !== String(subjectFilter)
    ) {
      return false;
    }
    if (
      typeFilter &&
      typeFilter !== "ALL" &&
      String(item.facilityTypeId) !== String(typeFilter)
    ) {
      return false;
    }
    return true;
  });
};

export const filterProposalDetailItemsLocal = (
  items = [],
  { keyword = "", decisionFilter = "ALL" } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.code || ""} ${item.roomName || ""} ${item.targetRoomName || ""} ${item.decisionName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (decisionFilter === "SELECTABLE") {
      return canDecideProposalItem(item);
    }
    if (decisionFilter && decisionFilter !== "ALL") {
      const decision = normalizeProposalDecision(item.decision);
      return decision === decisionFilter;
    }
    return true;
  });
};

export const PROPOSAL_ITEM_DECISION_FILTER_OPTIONS = [
  { value: "ALL", label: "Tất cả đơn vị" },
  { value: "SELECTABLE", label: "Có thể chọn" },
  { value: "APPROVED", label: "Đã duyệt" },
  { value: "REJECTED", label: "Từ chối" },
  { value: "PENDING", label: "Chờ xử lý" },
];

export const paginateLocal = (items = [], page = 0, size = 10) => {
  const start = Number(page) * Number(size);
  return items.slice(start, start + Number(size));
};

export const mapRoomOpt = (item = {}) => ({
  value: item.id,
  label: item.name || item.code || `--`,
  status: item.status || ROOM_STATUS.ACTIVE,
  ...item,
});

export const getActiveRoomOpts = (roomOpts = []) =>
  (roomOpts || []).filter((r) => r.status !== ROOM_STATUS.INACTIVE);
