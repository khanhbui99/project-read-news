import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import AppButton from "components/common/AppButton";
import AppHeader from "components/common/AppHeader";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  DetailPage,
  DrawerComplete,
  ModalReject,
} from "./components";
import {
  canApproveItem,
  canCreateTicket,
  canDecideItems,
  handleRedirectRepairList,
  resolveRepairRole,
} from "./helpers";
import {
  completeRepairItemAction,
  decideRepairItemsAction,
  downloadRepairFileAction,
  getRepairTicketDetailAction,
  resubmitRepairItemAction,
  setFieldValueStoreRepairTicketAction,
  updateExpectedDateAction,
} from "../store/actions";
import { DECISION, REPAIR_ROLE, key } from "../store/constants";
import { CardPanel, PageWrap } from "./Styled";

const headerBackBtnStyle = {
  height: 40,
  borderRadius: 8,
  textTransform: "none",
  fontWeight: 600,
};

const RepairTicketDetail = () => {
  const { id } = useParams();
  const userInfo = useOneState(injectKey.GLOBAL, "userInfo", {});
  const role = resolveRepairRole(userInfo);
  const canCreate = canCreateTicket(role);

  const repairState = useOneState(key, "repairTicket") || {};
  const {
    detail = null,
    detailLoading = false,
    selectedItemIds = [],
    isRejectOpen = false,
    isCompleteOpen = false,
    completeItem = null,
  } = repairState;

  const isLoading = useOneState(injectKey.GLOBAL, "isLoading", false);

  const [expectedDates, setExpectedDates] = useState({});

  const setField = useDispatchRedux(setFieldValueStoreRepairTicketAction);
  const getDetail = useDispatchRedux(getRepairTicketDetailAction);
  const decideItems = useDispatchRedux(decideRepairItemsAction);
  const resubmitItemAction = useDispatchRedux(resubmitRepairItemAction);
  const updateExpectedDate = useDispatchRedux(updateExpectedDateAction);
  const completeRepairItem = useDispatchRedux(completeRepairItemAction);
  const downloadFile = useDispatchRedux(downloadRepairFileAction);

  useEffect(() => {
    if (!id) return undefined;
    const timer = setTimeout(() => {
      getDetail({ id });
    }, 100);
    return () => {
      clearTimeout(timer);
      setField("detail", null);
      setField("selectedItemIds", []);
      setField("isRejectOpen", false);
      setField("isCompleteOpen", false);
      setField("completeItem", null);
    };
  }, [id]);

  const handleToggleItem = (item) => {
    if (!canDecideItems(role) || !canApproveItem(role, item)) return;
    const exists = selectedItemIds.includes(item.id);
    const next = exists
      ? selectedItemIds.filter((itemId) => itemId !== item.id)
      : [...selectedItemIds, item.id];
    setField("selectedItemIds", next);
  };

  const handleDecision = (decision) => {
    if (!canDecideItems(role) || !selectedItemIds.length) return;

    const approvableIds = (detail?.items || [])
      .filter((item) => canApproveItem(role, item))
      .map((item) => item.id)
      .filter((itemId) => selectedItemIds.includes(itemId));

    if (!approvableIds.length) return;

    if (decision === DECISION.REJECT) {
      setField("isRejectOpen", true);
      return;
    }

    decideItems({
      ticketId: detail?.id,
      itemIds: approvableIds,
      decision,
    });
  };

  const handleRejectSubmit = (rejectReason) => {
    if (!canDecideItems(role)) return;
    const approvableIds = (detail?.items || [])
      .filter((item) => canApproveItem(role, item))
      .map((item) => item.id)
      .filter((itemId) => selectedItemIds.includes(itemId));
    if (!approvableIds.length) return;

    decideItems({
      ticketId: detail?.id,
      itemIds: approvableIds,
      decision: DECISION.REJECT,
      rejectReason,
    });
  };

  const handleResubmitSubmit = (values) => {
    if (!canCreate) return;
    resubmitItemAction({
      ticketId: detail?.id,
      itemId: values.itemId,
      description: values.description,
      priority: values.priority,
      files: values.files,
    });
  };

  const handleCompleteOpen = (item) => {
    if (role !== REPAIR_ROLE.FACILITY_MANAGER) return;
    setField("completeItem", item);
    setField("isCompleteOpen", true);
  };

  const handleCompleteSubmit = (values) => {
    if (role !== REPAIR_ROLE.FACILITY_MANAGER) return;
    completeRepairItem({
      ticketId: detail?.id,
      itemId: values.itemId,
      repaired: values.repaired,
      note: values.note,
    });
  };

  const handleExpectedDateChange = (item, value) => {
    if (role !== REPAIR_ROLE.FACILITY_MANAGER) return;
    setExpectedDates((prev) => ({ ...prev, [item.id]: value }));
  };

  const handleSaveExpectedDate = (item, value) => {
    if (role !== REPAIR_ROLE.FACILITY_MANAGER || !value) return;
    setExpectedDates((prev) => ({ ...prev, [item.id]: value }));
    updateExpectedDate({
      ticketId: detail?.id,
      itemId: item.id,
      expectedRepairDate: value,
    });
  };

  const handleDownloadFile = (item, file) => {
    downloadFile({
      ticketId: detail?.id,
      itemId: item.id,
      fileId: file.id || file.fileId,
      fileName: file.name || file.fileName,
    });
  };

  return (
    <>
      <AppHeader
        componentName="DetailRepairTicketFacility"
        pageTitle="Chi tiết phiếu báo hỏng"
        isHiddenBtn
        externalBtn={
          <AppButton
            outline
            type="button"
            startIcon={<ArrowBackIcon />}
            onClick={handleRedirectRepairList}
            style={headerBackBtnStyle}
            aria-label="Quay lại danh sách"
          >
            Quay lại
          </AppButton>
        }
      />

      <PageWrap>
        <CardPanel>
          <DetailPage
            detail={detail}
            loading={detailLoading}
            role={role}
            userInfo={userInfo}
            saving={isLoading}
            selectedItemIds={selectedItemIds}
            expectedDates={expectedDates}
            onBack={handleRedirectRepairList}
            onToggleItem={handleToggleItem}
            onApproveRepair={() => handleDecision(DECISION.APPROVE_REPAIR)}
            onApproveReplace={() => handleDecision(DECISION.APPROVE_REPLACE)}
            onReject={() => handleDecision(DECISION.REJECT)}
            onResubmit={handleResubmitSubmit}
            onComplete={handleCompleteOpen}
            onExpectedDateChange={handleExpectedDateChange}
            onSaveExpectedDate={handleSaveExpectedDate}
            onDownloadFile={handleDownloadFile}
          />
        </CardPanel>
      </PageWrap>

      <DrawerComplete
        open={isCompleteOpen && role === REPAIR_ROLE.FACILITY_MANAGER}
        item={completeItem}
        saving={isLoading}
        onClose={() => {
          setField("isCompleteOpen", false);
          setField("completeItem", null);
        }}
        onSubmit={handleCompleteSubmit}
      />

      <ModalReject
        open={isRejectOpen && canDecideItems(role)}
        saving={isLoading}
        onClose={() => setField("isRejectOpen", false)}
        onSubmit={handleRejectSubmit}
      />
    </>
  );
};

export default RepairTicketDetail;
