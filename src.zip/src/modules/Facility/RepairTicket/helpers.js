import dayjs from "dayjs";
import { DateFormat4 } from "utils/constants";
import { findMenuByComponentName, isBGH } from "utils/helpers";
import history from "utils/history";

import { isInDateRange } from "../helpers";
import {
  ITEM_STATUS,
  ITEM_STATUS_MAP,
  PRIORITY,
  PRIORITY_MAP,
  REPAIR_ROLE,
  TICKET_STATUS,
  TICKET_STATUS_MAP,
} from "../store/constants";

export const getEmptyCreateForm = () => ({
  roomId: "",
  selectedAssets: [],
  items: {},
});

// Định danh dòng tài sản: dùng rowKey khi API chưa trả id
export const assetKeyOf = (asset = {}) =>
  String(asset?.rowKey ?? asset?.id ?? "");

export const getEmptyItemForm = (asset = {}) => ({
  assetId: asset.id || "",
  assetCode: asset.code || "",
  assetName: asset.name || "",
  assetStatus: asset.status || asset.statusName || "",
  subjectName: asset.subjectName || "",
  typeName: asset.typeName || "",
  description: "",
  priority: PRIORITY.LOW,
  files: [],
});

export const getEditCreateForm = (detail = {}) => {
  const selectedAssets = (detail.items || []).map((item) => ({
    ...(item.asset || {}),
    id: item.assetId || item.asset?.id || "",
    code: item.assetCode || item.asset?.code || "",
    name: item.assetName || item.asset?.name || "--",
    subjectName:
      item.subjectName ||
      item.facilitySubjectName ||
      item.asset?.subjectName ||
      item.asset?.facilitySubjectName ||
      "--",
    typeName:
      item.typeName ||
      item.facilityTypeName ||
      item.asset?.typeName ||
      item.asset?.facilityTypeName ||
      "--",
    operationalStatus:
      item.operationalStatus || item.asset?.operationalStatus || "",
    rowKey: item.assetId || item.asset?.id || item.id,
  }));

  const items = {};
  (detail.items || []).forEach((item, index) => {
    const asset = selectedAssets[index];
    const key = assetKeyOf(asset);
    items[key] = {
      itemId: item.id,
      assetId: asset.id,
      assetCode: asset.code,
      assetName: asset.name,
      assetStatus: asset.operationalStatus,
      subjectName: asset.subjectName,
      typeName: asset.typeName,
      description: item.description || "",
      priority: item.priority || PRIORITY.LOW,
      files: item.files || [],
    };
  });

  return {
    roomId: detail.roomId || detail.room?.id || "",
    selectedAssets,
    items,
  };
};

export const formatDate = (value) => {
  if (!value) return "--";
  const d = dayjs(value);
  return d.isValid() ? d.format(DateFormat4) : "--";
};

/** Chuẩn hóa status item theo BRD (Waiting Approval → WAITING_APPROVAL) */
export const normalizeItemStatus = (raw = "") => {
  const value = String(raw || "").trim();
  if (!value) return "";
  const key = value
    .toUpperCase()
    .replace(/[\s-]+/g, "_");

  const aliases = {
    WAITING: ITEM_STATUS.WAITING,
    WAITING_APPROVAL: ITEM_STATUS.WAITING_APPROVAL,
    WAIT_APPROVAL: ITEM_STATUS.WAITING_APPROVAL,
    PENDING_APPROVAL: ITEM_STATUS.WAITING_APPROVAL,
    PENDING: ITEM_STATUS.PENDING,
    DRAFT: ITEM_STATUS.DRAFT,
    REJECTED: ITEM_STATUS.REJECTED,
    REJECT: ITEM_STATUS.REJECTED,
    REPAIRING: ITEM_STATUS.REPAIRING,
    APPROVED_REPAIR: ITEM_STATUS.APPROVED_REPAIR,
    APPROVE_REPAIR: ITEM_STATUS.APPROVED_REPAIR,
    IN_PROGRESS: ITEM_STATUS.IN_PROGRESS,
    COMPLETED: ITEM_STATUS.COMPLETED,
    COMPLETE: ITEM_STATUS.COMPLETED,
    REPAIRED: ITEM_STATUS.REPAIRED,
    WAITING_REPLACE: ITEM_STATUS.WAITING_REPLACE,
    REPLACE: ITEM_STATUS.REPLACE,
    REPLACE_NEW: ITEM_STATUS.REPLACE_NEW,
    CANNOT_REPAIR: ITEM_STATUS.CANNOT_REPAIR,
    CAN_NOT_REPAIR: ITEM_STATUS.CANNOT_REPAIR,
  };

  return aliases[key] || key;
};

export const isWaitingApprovalStatus = (status) => {
  const normalized = normalizeItemStatus(status);
  return (
    normalized === ITEM_STATUS.WAITING ||
    normalized === ITEM_STATUS.WAITING_APPROVAL ||
    normalized === ITEM_STATUS.PENDING
  );
};

export const normalizeTicketStatus = (raw = "") => {
  const value = String(raw || "").trim();
  if (!value) return "";
  const key = value.toUpperCase().replace(/[\s-]+/g, "_");
  const aliases = {
    DRAFT: TICKET_STATUS.DRAFT,
    WAITING: TICKET_STATUS.WAITING,
    PENDING: TICKET_STATUS.PENDING,
    PROCESSING: TICKET_STATUS.PROCESSING,
    IN_PROGRESS: TICKET_STATUS.IN_PROGRESS,
    COMPLETED: TICKET_STATUS.COMPLETED,
    REJECTED: TICKET_STATUS.REJECTED,
  };
  return aliases[key] || key;
};

export const mapTicketItem = (item = {}) => {
  const status = normalizeTicketStatus(item.status || item.ticketStatus || "");
  const nestedItems = item.items || item.ticketItems || [];
  const waitingApprovalCount = (() => {
    const raw =
      item.waitingApprovalCount ??
      item.pendingItemCount ??
      item.waitingItemCount ??
      item.itemWaitingCount;
    if (raw != null && raw !== "") return Number(raw) || 0;
    if (!nestedItems.length) return 0;
    return nestedItems.filter((it) =>
      isWaitingApprovalStatus(it.status || it.itemStatus),
    ).length;
  })();
  const waitingCompleteCount = (() => {
    const raw =
      item.waitingCompleteCount ??
      item.repairingItemCount ??
      item.itemRepairingCount;
    if (raw != null && raw !== "") return Number(raw) || 0;
    if (!nestedItems.length) return 0;
    return nestedItems.filter((it) => {
      const s = normalizeItemStatus(it.status || it.itemStatus);
      return (
        s === ITEM_STATUS.REPAIRING ||
        s === ITEM_STATUS.APPROVED_REPAIR ||
        s === ITEM_STATUS.IN_PROGRESS
      );
    }).length;
  })();

  return {
    ...item,
    id: item.id,
    code: item.code || item.ticketCode || "",
    roomId: item.roomId || item.room?.id || "",
    roomName: item.roomName || item.room?.name || "--",
    creatorName:
      item.creatorName ||
      item.createdByName ||
      item.createdBy?.fullName ||
      item.createdBy?.name ||
      "--",
    creatorAccountId:
      item.creatorAccountId ??
      item.createdByAccountId ??
      item.createdById ??
      item.creatorId ??
      item.createdBy?.accountId ??
      item.createdBy?.userId ??
      item.createdBy?.id ??
      "",
    itemCount: item.itemCount ?? nestedItems.length ?? item.totalItems ?? 0,
    status,
    statusName: TICKET_STATUS_MAP[status] || status || "--",
    createdAt: item.createdAt || item.createDate || null,
    createdAtDisplay: formatDate(item.createdAt || item.createDate),
    lastDecidedByName: item.lastDecidedByName || "",
    lastDecidedAt: item.lastDecidedAt || null,
    lastDecidedAtDisplay: formatDate(item.lastDecidedAt),
    approverName:
      item.lastDecidedByName ||
      item.approverName ||
      item.approvedByName ||
      item.approvedBy?.fullName ||
      "",
    approvedAt:
      item.lastDecidedAt || item.approvedAt || item.approveDate || null,
    approvedDisplay: (() => {
      const name =
        item.lastDecidedByName ||
        item.approverName ||
        item.approvedByName ||
        item.approvedBy?.fullName ||
        "";
      const date = formatDate(
        item.lastDecidedAt || item.approvedAt || item.approveDate,
      );
      if (!name && date === "--") return "--";
      if (!name) return date;
      if (date === "--") return name;
      return `${name} / ${date}`;
    })(),
    waitingApprovalCount,
    waitingCompleteCount,
    needActionText: item.needActionText || item.myAction || item.todoText || "",
  };
};

export const mapTicketDetail = (data = {}) => {
  const base = mapTicketItem(data);
  const items = (data.items || data.ticketItems || []).map(mapRepairItem);
  return {
    ...base,
    items,
    note: data.note || "",
  };
};

export const mapRepairItem = (item = {}) => {
  const status = normalizeItemStatus(item.status || item.itemStatus || "");
  const priority = item.priority || PRIORITY.LOW;
  return {
    ...item,
    id: item.id,
    assetId: item.assetId || item.asset?.id || "",
    assetCode: item.assetCode || item.asset?.code || "",
    assetName: item.assetName || item.asset?.name || "--",
    description: item.description || "",
    priority,
    priorityName: PRIORITY_MAP[priority] || priority,
    status,
    statusName: ITEM_STATUS_MAP[status] || status || "--",
    expectedRepairDate: item.expectedRepairDate || item.expectedDate || null,
    expectedRepairDateDisplay: formatDate(
      item.expectedRepairDate || item.expectedDate,
    ),
    note: item.note || item.repairNote || "",
    rejectReason: item.rejectReason || "",
    files: item.files || item.attachments || [],
    canResubmit: item.canResubmit === true || item.canResubmit === 1,
  };
};

export const mapRoomOpt = (item = {}) => ({
  value: item.id,
  label: item.name || item.roomName || "--",
});

export const extractAssetsFromRoomDetail = (data = {}) => {
  const room = data?.room || data || {};
  const list = room.assets || data?.assets || [];
  return Array.isArray(list) ? list : [];
};

export const mapAssetRow = (item = {}, roomMeta = {}, index = 0) => {
  const status = item.status || item.operationalStatus || "";
  const id = item.id ?? item.assetId ?? null;
  const selectable = isAssetSelectable(item);
  return {
    ...item,
    id,
    rowKey: id ?? `${item.subjectName || ""}|${item.typeName || ""}|${index}`,
    code: item.code || item.assetCode || "",
    name: item.name || item.standardDeviceName || "--",
    facilitySubjectId:
      item.facilitySubjectId ?? item.subjectId ?? item.subject?.id ?? "",
    facilityTypeId: item.facilityTypeId ?? item.typeId ?? item.type?.id ?? "",
    subjectName:
      item.facilitySubjectName ||
      item.subjectName ||
      item.subject?.name ||
      "--",
    typeName:
      item.facilityTypeName || item.typeName || item.type?.name || "--",
    roomName: item.roomName || item.room?.name || roomMeta.roomName || "--",
    count: item.count ?? null,
    status,
    statusName: item.statusName || status || "--",
    selectable,
  };
};

export const buildAssetFilterOpts = (items = []) => {
  const subjectMap = new Map();
  const typeMap = new Map();

  (items || []).forEach((item) => {
    const subjectName = item?.subjectName;
    const typeName = item?.typeName;
    const subjectKey = String(
      item?.facilitySubjectId || item?.subjectId || subjectName || "",
    );
    const typeKey = String(
      item?.facilityTypeId || item?.typeId || typeName || "",
    );

    if (subjectKey && subjectName && subjectName !== "--") {
      if (!subjectMap.has(subjectKey)) {
        subjectMap.set(subjectKey, { value: subjectKey, label: subjectName });
      }
    }
    if (typeKey && typeName && typeName !== "--") {
      if (!typeMap.has(typeKey)) {
        typeMap.set(typeKey, { value: typeKey, label: typeName });
      }
    }
  });

  return {
    subjectOpts: Array.from(subjectMap.values()),
    typeOpts: Array.from(typeMap.values()),
  };
};

/** Status yêu cầu đã kết thúc → được chọn lại */
export const isTerminalRepairStatus = (status) => {
  const item = normalizeItemStatus(status);
  const ticket = normalizeTicketStatus(status);
  return (
    item === ITEM_STATUS.REJECTED ||
    item === ITEM_STATUS.COMPLETED ||
    item === ITEM_STATUS.REPAIRED ||
    ticket === TICKET_STATUS.REJECTED ||
    ticket === TICKET_STATUS.COMPLETED
  );
};

export const isAssetSelectable = (asset = {}, options = {}) => {
  const {
    blockedAssetIds = null,
    allowAssetKeys = null,
  } = options;

  const assetKey = String(asset.id ?? asset.assetId ?? asset.rowKey ?? "");
  if (allowAssetKeys?.has?.(assetKey) || allowAssetKeys?.includes?.(assetKey)) {
    return true;
  }
  if (blockedAssetIds?.has?.(assetKey)) return false;

  const activeRepairStatus =
    asset.activeRepairItemStatus ??
    asset.repairItemStatus ??
    asset.currentRepairItemStatus ??
    asset.openRepairItemStatus ??
    asset.openItemStatus ??
    null;

  if (activeRepairStatus != null && String(activeRepairStatus).trim() !== "") {
    // Đã có yêu cầu đang mở (khác Từ chối / Hoàn tất) → không chọn
    if (!isTerminalRepairStatus(activeRepairStatus)) return false;
  } else if (
    asset.selectable === false ||
    asset.canSelect === false ||
    asset.disabled === true ||
    asset.locked === true
  ) {
    return false;
  }

  const status = String(
    asset.status || asset.operationalStatus || "",
  )
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");
  if (["LOCKED", "DISPOSED", "BORROWED"].includes(status)) return false;
  return true;
};

export const getAssetUnavailableText = (asset = {}) => {
  if (
    asset.blockedByActiveRepair ||
    asset.locked === true ||
    asset.selectable === false ||
    asset.canSelect === false
  ) {
    return "Tài sản đã có yêu cầu xử lý";
  }
  return "Tài sản không thể chọn";
};

/** Mọi role báo hỏng đều được tạo phiếu (GV / phụ trách phòng / BGH / CSVC) */
export const canCreateTicket = (role) =>
  role === REPAIR_ROLE.CREATOR ||
  role === REPAIR_ROLE.ROOM_MANAGER ||
  role === REPAIR_ROLE.SCHOOL_MANAGER ||
  role === REPAIR_ROLE.FACILITY_MANAGER;

export const canDeleteDraft = (role, ticket, userInfo) => {
  if (normalizeTicketStatus(ticket?.status) !== TICKET_STATUS.DRAFT) return false;
  if (isProcessorRole(role)) return isOwnTicket(ticket, userInfo);
  return canCreateTicket(role);
};

const collectUserIdentityIds = (userInfo = {}) => {
  const ids = [
    userInfo.accountId,
    userInfo.userId,
    userInfo.id,
    userInfo.teacherId,
    userInfo.teacherCode,
    userInfo.username,
    userInfo.userName,
    userInfo.loginName,
    userInfo.user?.accountId,
    userInfo.user?.id,
    userInfo.user?.teacherId,
    userInfo.user?.teacherCode,
    userInfo.user?.username,
  ];
  return new Set(
    ids
      .filter((v) => v != null && v !== "")
      .map((v) => String(v).trim()),
  );
};

const collectTicketCreatorIds = (ticket = {}) => {
  const createdBy = ticket.createdBy;
  const ids = [
    ticket.creatorAccountId,
    ticket.createdByAccountId,
    ticket.createdById,
    ticket.creatorId,
    ticket.createdByUserId,
    ticket.accountId,
    typeof createdBy === "object"
      ? createdBy?.accountId ??
        createdBy?.userId ??
        createdBy?.id ??
        createdBy?.teacherId ??
        createdBy?.teacherCode ??
        createdBy?.username
      : createdBy,
  ];
  return ids
    .filter((v) => v != null && v !== "")
    .map((v) => String(v).trim());
};

/** Phiếu do chính user tạo */
export const isOwnTicket = (ticket = {}, userInfo = {}) => {
  const mine = collectUserIdentityIds(userInfo);
  if (!mine.size) return false;
  return collectTicketCreatorIds(ticket).some((id) => mine.has(id));
};

export const isTicketCompleted = (ticket) =>
  normalizeTicketStatus(ticket?.status) === TICKET_STATUS.COMPLETED;

export const isTicketRejected = (ticket) =>
  normalizeTicketStatus(ticket?.status) === TICKET_STATUS.REJECTED;

export const isTicketDraft = (ticket) =>
  normalizeTicketStatus(ticket?.status) === TICKET_STATUS.DRAFT;

/** Phiếu đã kết thúc (hoàn tất / từ chối) — không sửa/xóa trên list */
export const isTicketClosed = (ticket) =>
  isTicketCompleted(ticket) || isTicketRejected(ticket);

/**
 * Asset đang có yêu cầu mở trên phiếu cùng phòng (khác phiếu đang sửa).
 * Chỉ khóa khi status item/ticket khác Từ chối & Hoàn tất.
 */
export const buildBlockedAssetIdSet = (
  tickets = [],
  { roomId, excludeTicketId } = {},
) => {
  const blocked = new Set();
  (tickets || []).forEach((ticket) => {
    if (
      excludeTicketId != null &&
      String(ticket.id) === String(excludeTicketId)
    ) {
      return;
    }
    if (roomId != null && String(ticket.roomId) !== String(roomId)) return;
    if (isTicketClosed(ticket)) return;

    const nested = ticket.items || ticket.ticketItems || [];
    if (nested.length) {
      nested.forEach((it) => {
        if (isTerminalRepairStatus(it.status || it.itemStatus)) return;
        const id = it.assetId ?? it.asset?.id;
        if (id != null && id !== "") blocked.add(String(id));
      });
      return;
    }

    (ticket.assetIds || ticket.selectedAssetIds || []).forEach((id) => {
      if (id != null && id !== "") blocked.add(String(id));
    });
  });
  return blocked;
};

/**
 * Action giống giáo viên (Sửa/Xóa) trên phiếu chưa đóng:
 * - GV / phụ trách phòng: mọi phiếu chưa đóng
 * - BGH / CSVC: chỉ phiếu mình tạo
 */
export const canShowEditDeleteActions = (role, ticket, userInfo) => {
  if (!ticket || isTicketClosed(ticket)) return false;
  if (!isProcessorRole(role)) return true;
  return isOwnTicket(ticket, userInfo);
};

/** BGH/CSVC: phiếu mình còn action như GV → hiện Chi tiết + Xóa */
export const canShowOwnerDetailDelete = (role, ticket, userInfo) =>
  isProcessorRole(role) && canShowEditDeleteActions(role, ticket, userInfo);

export const canShowDeleteAction = (role, ticket, userInfo) =>
  canShowEditDeleteActions(role, ticket, userInfo);

/** Cho phép mở editor / sửa phiếu chưa đóng (BGH/CSVC: phiếu mình) */
export const canManageIncompleteTicket = (role, ticket, userInfo) => {
  if (ticket && isTicketClosed(ticket)) return false;
  if (!isProcessorRole(role)) return true;
  if (ticket && userInfo) return isOwnTicket(ticket, userInfo);
  return true;
};

/** Mọi role đều xem được chi tiết */
export const canShowViewAction = () => true;

/**
 * Cho phép sửa mô tả / field item khi API trả canResubmit.
 * Fallback: món REJECTED với role được tạo phiếu (kể cả BGH/CSVC đã tạo).
 */
export const canResubmitItem = (role, item) => {
  if (!canCreateTicket(role)) return false;
  if (item?.canResubmit === true || item?.canResubmit === 1) return true;
  if (item?.canResubmit === false || item?.canResubmit === 0) return false;
  return normalizeItemStatus(item?.status) === ITEM_STATUS.REJECTED;
};

export const getItemStatusLabel = (status) => {
  const normalized = normalizeItemStatus(status);
  return ITEM_STATUS_MAP[normalized] || status || "--";
};

/** BGH: chỉ duyệt item đang Waiting / Waiting Approval */
export const canApproveItem = (role, item) => {
  if (role !== REPAIR_ROLE.SCHOOL_MANAGER) return false;
  return isWaitingApprovalStatus(item?.status);
};

export const canDecideItems = (role) => role === REPAIR_ROLE.SCHOOL_MANAGER;

/** Cột "Cần tôi làm": chỉ BGH và QL CSVC */
export const shouldShowNeedActionColumn = (role) =>
  role === REPAIR_ROLE.SCHOOL_MANAGER ||
  role === REPAIR_ROLE.FACILITY_MANAGER;

export const buildNeedActionTextByRole = (ticket = {}, role) => {
  if (role === REPAIR_ROLE.SCHOOL_MANAGER) {
    const count = Number(ticket.waitingApprovalCount) || 0;
    return count > 0 ? `${count} món chờ duyệt` : "--";
  }
  if (role === REPAIR_ROLE.FACILITY_MANAGER) {
    const count = Number(ticket.waitingCompleteCount) || 0;
    return count > 0 ? `${count} món chờ hoàn tất sửa` : "--";
  }
  return "";
};

export const canCompleteItem = (role, item) => {
  if (role !== REPAIR_ROLE.FACILITY_MANAGER) return false;
  const status = normalizeItemStatus(item?.status);
  return (
    status === ITEM_STATUS.REPAIRING ||
    status === ITEM_STATUS.APPROVED_REPAIR ||
    status === ITEM_STATUS.IN_PROGRESS
  );
};

const collectRoleTokens = (userInfo = {}) => {
  const tokens = [];
  const push = (value) => {
    if (value == null || value === "") return;
    if (Array.isArray(value)) {
      value.forEach(push);
      return;
    }
    if (typeof value === "object") {
      push(value.code);
      push(value.roleCode);
      push(value.name);
      push(value.roleName);
      push(value.role);
      return;
    }
    String(value)
      .split(/[;,|]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((part) => tokens.push(part.toUpperCase()));
  };

  push(userInfo.listRole);
  push(userInfo.list_role);
  push(userInfo.roleName);
  push(userInfo.roleCode);
  push(userInfo.role);
  push(userInfo.currentRole);
  push(userInfo.roles);

  (userInfo.orgCharts || userInfo.org_charts || []).forEach((org) => {
    push(org?.roleName);
    push(org?.roleCode);
    push(org?.role);
  });

  return tokens;
};

const roleTextIncludes = (tokens = [], keywords = []) =>
  tokens.some((token) =>
    keywords.some((keyword) => token.includes(String(keyword).toUpperCase())),
  );

export const resolveRepairRole = (userInfo = {}) => {
  const tokens = collectRoleTokens(userInfo);
  const exactRoles = new Set(tokens);

  // BGH: Hiệu Trưởng / Phó Hiệu Trưởng — chỉ phê duyệt, không tạo phiếu
  if (
    (typeof isBGH === "function" && isBGH()) ||
    userInfo?.isBGH ||
    exactRoles.has("HIỆU TRƯỞNG") ||
    exactRoles.has("PHÓ HIỆU TRƯỞNG") ||
    roleTextIncludes(tokens, [
      "BGH",
      "BAN GIAM HIEU",
      "BAN GIÁM HIỆU",
      "BAN_GIAM",
      "HIỆU TRƯỞNG",
      "HIEU TRUONG",
      "PHÓ HIỆU TRƯỞNG",
      "PHO HIEU TRUONG",
      "SCHOOL_MANAGER",
      "SCHOOL MANAGER",
    ])
  ) {
    return REPAIR_ROLE.SCHOOL_MANAGER;
  }

  if (
    roleTextIncludes(tokens, [
      "CSVC",
      "FACILITY",
      "QUAN_LY_CSVC",
      "QUẢN LÝ CSVC",
      "QUAN LY CSVC",
      "CAN BO CSVC",
      "CÁN BỘ CSVC",
      "CO SO VAT CHAT",
      "CƠ SỞ VẬT CHẤT",
      "FACILITY_MANAGER",
    ])
  ) {
    return REPAIR_ROLE.FACILITY_MANAGER;
  }

  if (
    roleTextIncludes(tokens, [
      "ROOM_MANAGER",
      "ROOM MANAGER",
      "PHỤ TRÁCH PHÒNG",
      "PHU TRACH PHONG",
      "PHU_TRACH",
    ])
  ) {
    return REPAIR_ROLE.ROOM_MANAGER;
  }

  return REPAIR_ROLE.CREATOR;
};

export const getListUrlByRole = (role, urls) => {
  if (role === REPAIR_ROLE.CREATOR) return urls.mine;
  if (role === REPAIR_ROLE.ROOM_MANAGER) return urls.myRooms;
  return urls.list;
};

/** BGH / QL CSVC — role xử lý duyệt/hoàn tất (vẫn được tạo phiếu) */
export const isProcessorRole = (role) =>
  role === REPAIR_ROLE.SCHOOL_MANAGER ||
  role === REPAIR_ROLE.FACILITY_MANAGER;

/** Cùng logic cột "Cần tôi làm" — có số món cần xử lý thì hiện nút Thực hiện */
export const ticketNeedsActionByRole = (ticket = {}, role) => {
  if (role === REPAIR_ROLE.SCHOOL_MANAGER) {
    return (Number(ticket.waitingApprovalCount) || 0) > 0;
  }
  if (role === REPAIR_ROLE.FACILITY_MANAGER) {
    return (Number(ticket.waitingCompleteCount) || 0) > 0;
  }
  return false;
};

/** Ưu tiên sort: cần xử lý → đang xử lý → hoàn tất/từ chối xuống cuối */
export const getTicketSortPriority = (ticket = {}, role) => {
  if (isTicketClosed(ticket)) return 100;
  if (ticketNeedsActionByRole(ticket, role)) return 0;
  const status = normalizeTicketStatus(ticket?.status);
  if (status === TICKET_STATUS.DRAFT) return 80;
  return 10;
};

export const sortTicketsForRole = (items = [], role) =>
  [...(items || [])].sort((a, b) => {
    const diff =
      getTicketSortPriority(a, role) - getTicketSortPriority(b, role);
    if (diff !== 0) return diff;
    const aTime = a?.createdAt ? dayjs(a.createdAt).valueOf() : 0;
    const bTime = b?.createdAt ? dayjs(b.createdAt).valueOf() : 0;
    return bTime - aTime;
  });

export const LIST_FETCH_SIZE = 10000;

export const filterTicketsLocal = (
  items = [],
  {
    keyword = "",
    roomFilter = "ALL",
    statusFilter = "ALL",
    fromDate = null,
    toDate = null,
    role,
    userInfo = {},
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  const processor = isProcessorRole(role);

  return (items || []).filter((item) => {
    // BGH/CSVC: ẩn nháp của người khác; giữ nháp của mình để Sửa/Xóa
    if (processor && isTicketDraft(item) && !isOwnTicket(item, userInfo)) {
      return false;
    }
    if (kw) {
      const hay =
        `${item.code || ""} ${item.roomName || ""} ${item.creatorName || ""} ${item.statusName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (
      roomFilter &&
      roomFilter !== "ALL" &&
      String(item.roomId) !== String(roomFilter)
    ) {
      return false;
    }
    if (statusFilter && statusFilter !== "ALL" && item.status !== statusFilter) {
      return false;
    }
    if (!isInDateRange(item.createdAt, fromDate, toDate)) {
      return false;
    }
    return true;
  });
};

export const filterRoomAssetsLocal = (
  items = [],
  { keyword = "", subjectFilter = [], typeFilter = [] } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  const subjectIds = (Array.isArray(subjectFilter) ? subjectFilter : [])
    .filter((v) => v != null && v !== "" && v !== "ALL")
    .map(String);
  const typeIds = (Array.isArray(typeFilter) ? typeFilter : [])
    .filter((v) => v != null && v !== "" && v !== "ALL")
    .map(String);

  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.code || ""} ${item.name || ""} ${item.subjectName || ""} ${item.typeName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (subjectIds.length) {
      const subjectId = String(
        item.facilitySubjectId || item.subjectId || "",
      );
      const subjectName = String(item.subjectName || "");
      const matched = subjectIds.some(
        (id) => id === subjectId || id === subjectName,
      );
      if (!matched) return false;
    }
    if (typeIds.length) {
      const typeId = String(item.facilityTypeId || item.typeId || "");
      const typeName = String(item.typeName || "");
      const matched = typeIds.some((id) => id === typeId || id === typeName);
      if (!matched) return false;
    }
    return true;
  });
};

export const paginateLocal = (items = [], page = 0, size = 10) => {
  const start = Number(page) * Number(size);
  return items.slice(start, start + Number(size));
};

export const handleRedirectRepairList = (options = {}) => {
  const path = findMenuByComponentName("RepairTicketFacility")?.url || "";
  if (!path) return;
  if (options.openCreate) {
    history.push({ pathname: path, state: { openCreate: true } });
    return;
  }
  history.push(path);
};

export const handleRedirectRepairDetail = (id) => {
  const path =
    findMenuByComponentName("DetailRepairTicketFacility")?.url || "";
  if (!path || !id) return;
  history.push({ pathname: path.replace(":id", String(id)) });
};
