import AppHeader from "components/common/AppHeader";
import dayjs from "dayjs";
import { useEffect, useMemo } from "react";
import { useLocation } from "react-router-dom";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import history from "utils/history";
import injectKey from "utils/injectKey";

import { ModalConfirm, ModalDelete } from "../components";
import {
  DrawerCreate,
  RepairDataTable,
  RepairToolbar,
} from "./components";
import {
  buildAssetFilterOpts,
  buildBlockedAssetIdSet,
  canCreateTicket,
  canManageIncompleteTicket,
  canShowDeleteAction,
  filterRoomAssetsLocal,
  filterTicketsLocal,
  getEmptyCreateForm,
  handleRedirectRepairDetail,
  isAssetSelectable,
  isTicketDraft,
  paginateLocal,
  resolveRepairRole,
  sortTicketsForRole,
} from "./helpers";
import {
  createRepairTicketAction,
  deleteRepairTicketAction,
  getRepairTicketDetailAction,
  queryRepairFilterOptsAction,
  queryRepairTicketsAction,
  queryRoomAssetsAction,
  resetStoreRepairTicketAction,
  setFieldValueStoreRepairTicketAction,
  updateRepairTicketAction,
} from "../store/actions";
import { CREATE_STEPS, key } from "../store/constants";
import { CardPanel, PageWrap } from "./Styled";

const RepairTicketList = () => {
  const location = useLocation();
  const userInfo = useOneState(injectKey.GLOBAL, "userInfo", {});
  const role = resolveRepairRole(userInfo);
  const canCreate = canCreateTicket(role);

  const repairState = useOneState(key, "repairTicket") || {};
  const {
    keyword = "",
    roomFilter = "ALL",
    statusFilter = "ALL",
    fromDate = null,
    toDate = null,
    page = 0,
    size = 10,
    items = [],
    loading = false,
    roomOpts = [],
    isCreateOpen = false,
    isEditMode = false,
    editingTicketId = null,
    originalSelectedAssetKeys = [],
    createStep = CREATE_STEPS.ROOM,
    createForm = getEmptyCreateForm(),
    createDirty = false,
    roomAssets = [],
    roomAssetsLoading = false,
    assetKeyword = "",
    assetSubjectFilter = [],
    assetTypeFilter = [],
    isDeleteOpen = false,
    deleteId = null,
    isDiscardOpen = false,
  } = repairState;

  const isLoading = useOneState(injectKey.GLOBAL, "isLoading", false);

  const setField = useDispatchRedux(setFieldValueStoreRepairTicketAction);
  const fetchList = useDispatchRedux(queryRepairTicketsAction);
  const fetchFilterOpts = useDispatchRedux(queryRepairFilterOptsAction);
  const fetchRoomAssets = useDispatchRedux(queryRoomAssetsAction);
  const createTicket = useDispatchRedux(createRepairTicketAction);
  const updateTicket = useDispatchRedux(updateRepairTicketAction);
  const getDetail = useDispatchRedux(getRepairTicketDetailAction);
  const deleteTicket = useDispatchRedux(deleteRepairTicketAction);
  const resetStore = useDispatchRedux(resetStoreRepairTicketAction);

  useEffect(() => {
    fetchFilterOpts();
    fetchList();

    if (location.state?.openCreate && canCreate) {
      setField("createForm", getEmptyCreateForm());
      setField("isEditMode", false);
      setField("editingTicketId", null);
      setField("originalSelectedAssetKeys", []);
      setField("createStep", CREATE_STEPS.ROOM);
      setField("createDirty", false);
      setField("assetKeyword", "");
      setField("assetSubjectFilter", []);
      setField("assetTypeFilter", []);
      setField("roomAssets", []);
      setField("isCreateOpen", true);
      history.replace({
        pathname: location.pathname,
        search: location.search,
        state: {},
      });
    }

    return () => resetStore();
  }, []);

  const filteredItems = useMemo(() => {
    const filtered = filterTicketsLocal(items, {
      keyword,
      roomFilter,
      statusFilter,
      fromDate,
      toDate,
      role,
      userInfo,
    });
    return sortTicketsForRole(filtered, role);
  }, [items, keyword, roomFilter, statusFilter, fromDate, toDate, role, userInfo]);

  const pagedRows = useMemo(
    () => paginateLocal(filteredItems, page, size),
    [filteredItems, page, size],
  );

  const roomAssetsWithSelected = useMemo(() => {
    if (!isEditMode) return roomAssets;
    const merged = [...roomAssets];
    const keys = new Set(
      merged.map((asset) => String(asset.rowKey ?? asset.id ?? "")),
    );
    (createForm.selectedAssets || []).forEach((asset) => {
      const assetKey = String(asset.rowKey ?? asset.id ?? "");
      if (assetKey && !keys.has(assetKey)) {
        merged.push(asset);
        keys.add(assetKey);
      }
    });
    return merged;
  }, [roomAssets, createForm.selectedAssets, isEditMode]);

  const filteredRoomAssets = useMemo(
    () =>
      filterRoomAssetsLocal(roomAssetsWithSelected, {
        keyword: assetKeyword,
        subjectFilter: assetSubjectFilter,
        typeFilter: assetTypeFilter,
      }),
    [
      roomAssetsWithSelected,
      assetKeyword,
      assetSubjectFilter,
      assetTypeFilter,
    ],
  );

  const roomAssetsForPicker = useMemo(() => {
    const blockedAssetIds = buildBlockedAssetIdSet(items, {
      roomId: createForm.roomId,
      excludeTicketId: editingTicketId,
    });
    const allowAssetKeys = new Set(
      (originalSelectedAssetKeys || []).map(String),
    );

    return filteredRoomAssets.map((asset) => {
      const selectable = isAssetSelectable(asset, {
        blockedAssetIds,
        allowAssetKeys: isEditMode ? allowAssetKeys : null,
      });
      return {
        ...asset,
        selectable,
        blockedByActiveRepair:
          !selectable && !allowAssetKeys.has(String(asset.id ?? "")),
      };
    });
  }, [
    filteredRoomAssets,
    items,
    createForm.roomId,
    editingTicketId,
    originalSelectedAssetKeys,
    isEditMode,
  ]);

  const roomAssetFilterOpts = useMemo(
    () => buildAssetFilterOpts(roomAssetsWithSelected),
    [roomAssetsWithSelected],
  );

  const handleSearch = (nextKeyword) => {
    setField("keyword", nextKeyword);
    setField("page", 0);
  };

  const handleRoomFilter = (nextRoom) => {
    setField("roomFilter", nextRoom);
    setField("page", 0);
  };

  const handleStatusFilter = (nextStatus) => {
    setField("statusFilter", nextStatus);
    setField("page", 0);
  };

  const handleDateFilter = (field, value) => {
    setField(field, value);
    setField("page", 0);
    if (
      field === "fromDate" &&
      toDate &&
      value &&
      dayjs(toDate).isValid() &&
      dayjs(value).isValid() &&
      dayjs(toDate).isBefore(dayjs(value), "day")
    ) {
      setField("toDate", value);
    }
  };

  const handleOpenCreate = () => {
    if (!canCreate) return;
    setField("createForm", getEmptyCreateForm());
    setField("isEditMode", false);
    setField("editingTicketId", null);
    setField("originalSelectedAssetKeys", []);
    setField("createStep", CREATE_STEPS.ROOM);
    setField("createDirty", false);
    setField("assetKeyword", "");
    setField("assetSubjectFilter", []);
    setField("assetTypeFilter", []);
    setField("roomAssets", []);
    setField("isCreateOpen", true);
  };

  const handleCloseCreate = () => {
    if (createDirty) {
      setField("isDiscardOpen", true);
      return;
    }
    setField("isCreateOpen", false);
    setField("isEditMode", false);
    setField("editingTicketId", null);
    setField("originalSelectedAssetKeys", []);
  };

  const handleConfirmDiscard = () => {
    setField("isDiscardOpen", false);
    setField("isCreateOpen", false);
    setField("createForm", getEmptyCreateForm());
    setField("createStep", CREATE_STEPS.ROOM);
    setField("createDirty", false);
    setField("isEditMode", false);
    setField("editingTicketId", null);
    setField("originalSelectedAssetKeys", []);
  };

  const handleFormChange = (nextForm) => {
    setField("createForm", nextForm);
    setField("createDirty", true);
  };

  const handleAssetFilterChange = (overrides = {}) => {
    if (overrides.keyword !== undefined) setField("assetKeyword", overrides.keyword);
    if (overrides.subjectFilter !== undefined) {
      setField("assetSubjectFilter", overrides.subjectFilter);
    }
    if (overrides.typeFilter !== undefined) {
      setField("assetTypeFilter", overrides.typeFilter);
    }
  };

  const handleView = (row) => {
    handleRedirectRepairDetail(row?.id);
  };

  const handleEdit = (row) => {
    if (!row?.id || !canManageIncompleteTicket(role, row, userInfo)) return;

    if (isTicketDraft(row)) {
      setField("assetKeyword", "");
      setField("assetSubjectFilter", []);
      setField("assetTypeFilter", []);
      setField("roomAssets", []);
      getDetail({ id: row.id, openEditor: true });
      return;
    }

    handleRedirectRepairDetail(row.id);
  };

  const handleOpenDelete = (row) => {
    if (!canShowDeleteAction(role, row, userInfo)) return;
    setField("deleteId", row.id);
    setField("isDeleteOpen", true);
  };

  const handleConfirmDelete = () => {
    if (!deleteId) return;
    deleteTicket({ id: deleteId });
  };

  return (
    <>
      <AppHeader
        componentName="RepairTicketFacility"
        pageTitle="Báo hỏng / Sửa chữa"
        isHiddenBtn
      />

      <PageWrap>
        <CardPanel>
          <RepairToolbar
            keyword={keyword}
            roomFilter={roomFilter}
            statusFilter={statusFilter}
            fromDate={fromDate}
            toDate={toDate}
            roomOpts={roomOpts}
            loading={loading}
            canCreate={canCreate}
            onSearch={handleSearch}
            onRoomChange={handleRoomFilter}
            onStatusChange={handleStatusFilter}
            onDateChange={handleDateFilter}
            onAdd={handleOpenCreate}
          />

          <RepairDataTable
            rows={pagedRows}
            loading={loading}
            page={page}
            size={size}
            total={filteredItems.length}
            role={role}
            userInfo={userInfo}
            canCreate={canCreate}
            onPageChange={(nextPage) => {
              setField("page", nextPage);
            }}
            onPageSizeChange={(nextSize) => {
              setField("size", nextSize);
              setField("page", 0);
            }}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleOpenDelete}
            onAdd={handleOpenCreate}
          />
        </CardPanel>
      </PageWrap>

      <DrawerCreate
        open={isCreateOpen && (canCreate || isEditMode)}
        isEdit={isEditMode}
        originalSelectedAssetKeys={originalSelectedAssetKeys}
        step={createStep}
        form={createForm}
        roomOpts={roomOpts}
        subjectOpts={roomAssetFilterOpts.subjectOpts}
        typeOpts={roomAssetFilterOpts.typeOpts}
        roomAssets={roomAssetsForPicker}
        roomAssetsLoading={roomAssetsLoading}
        assetKeyword={assetKeyword}
        assetSubjectFilter={assetSubjectFilter}
        assetTypeFilter={assetTypeFilter}
        saving={isLoading}
        onClose={handleCloseCreate}
        onStepChange={(next) => setField("createStep", next)}
        onFormChange={handleFormChange}
        onAssetFilterChange={handleAssetFilterChange}
        onLoadAssets={(payload) => fetchRoomAssets(payload)}
        onSubmit={(payload) =>
          isEditMode
            ? updateTicket({ ...payload, id: editingTicketId })
            : createTicket(payload)
        }
      />

      <ModalDelete
        open={isDeleteOpen}
        title="Xóa phiếu"
        saving={isLoading}
        onClose={() => {
          setField("isDeleteOpen", false);
          setField("deleteId", null);
        }}
        onConfirm={handleConfirmDelete}
      />

      <ModalConfirm
        open={isDiscardOpen}
        title="Xác nhận đóng"
        message="Nội dung chưa được lưu. Bạn có chắc chắn muốn đóng?"
        confirmText="Đóng"
        cancelText="Tiếp tục chỉnh sửa"
        onClose={() => setField("isDiscardOpen", false)}
        onConfirm={handleConfirmDiscard}
      />
    </>
  );
};

export default RepairTicketList;
