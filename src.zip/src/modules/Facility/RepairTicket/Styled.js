import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-height: calc(100vh - 140px);
  margin-top: 16px;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  min-height: 0;
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: hidden;
`;

export const DrawerBox = styled.div`
  width: ${({ $width }) => $width || 720}px;
  max-width: 100vw;
  height: 100%;
  display: flex;
  flex-direction: column;
  font-family: SVN_Gilroy !important;

  .MuiDialogContent-root {
    padding: 24px;
    flex: 1;
    overflow: auto;
  }
`;

export const StatusBadge = styled.span`
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  white-space: nowrap;
  background: ${({ $tone }) => {
    if ($tone === "warning") return VPB_THEMES.colors.fffbeb;
    if ($tone === "primary") return VPB_THEMES.colors.f0f9ff;
    if ($tone === "success") return VPB_THEMES.colors.statusActiveBg;
    if ($tone === "error") return VPB_THEMES.colors.statusInactiveBg;
    if ($tone === "info") return VPB_THEMES.colors.f0f9ff;
    return VPB_THEMES.colors.statusHiddenBg;
  }};
  color: ${({ $tone }) => {
    if ($tone === "warning") return VPB_THEMES.colors.pending;
    if ($tone === "primary") return VPB_THEMES.colors.primaryBlue;
    if ($tone === "success") return VPB_THEMES.colors.statusActiveText;
    if ($tone === "error") return VPB_THEMES.colors.statusInactiveText;
    if ($tone === "info") return VPB_THEMES.colors.darkBlue;
    return VPB_THEMES.colors.statusHiddenText;
  }};
`;

export const getTicketStatusTone = (status) => {
  const key = String(status || "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");

  switch (key) {
    case "WAITING":
    case "WAITING_APPROVAL":
    case "PENDING":
    case "DRAFT":
      return "warning";
    case "PROCESSING":
    case "IN_PROGRESS":
    case "REPAIRING":
    case "APPROVED_REPAIR":
      return "primary";
    case "COMPLETED":
    case "REPAIRED":
      return "success";
    case "REJECTED":
    case "REJECT":
    case "CANNOT_REPAIR":
      return "error";
    case "REPLACE":
    case "REPLACE_NEW":
    case "WAITING_REPLACE":
      return "info";
    default:
      return "grey";
  }
};

/**
 * Nền card theo tiến trình xử lý (nhạt → đậm đến hoàn tất).
 * Reject / không sửa được giữ tông đỏ riêng.
 */
export const getItemStatusSurface = (status) => {
  const key = String(status || "")
    .trim()
    .toUpperCase()
    .replace(/[\s-]+/g, "_");

  if (key === "REJECTED" || key === "REJECT" || key === "CANNOT_REPAIR") {
    return {
      bg: VPB_THEMES.colors.statusInactiveBg,
      border: VPB_THEMES.colors.alertWarningBorder,
      accent: VPB_THEMES.colors.statusInactiveText,
    };
  }

  // Tiến dần tới hoàn tất
  if (key === "DRAFT") {
    return {
      bg: VPB_THEMES.colors.lightBg,
      border: VPB_THEMES.colors.table.borderLight,
      accent: VPB_THEMES.colors.textLight,
    };
  }
  if (
    key === "WAITING" ||
    key === "WAITING_APPROVAL" ||
    key === "PENDING"
  ) {
    return {
      bg: VPB_THEMES.colors.fffbeb,
      border: VPB_THEMES.colors.alertWarningBorder,
      accent: VPB_THEMES.colors.pending,
    };
  }
  if (key === "APPROVED_REPAIR") {
    return {
      bg: VPB_THEMES.colors.eff6ff,
      border: VPB_THEMES.colors.table.borderMedium,
      accent: VPB_THEMES.colors.primaryBlue,
    };
  }
  if (key === "REPAIRING" || key === "IN_PROGRESS" || key === "PROCESSING") {
    return {
      bg: VPB_THEMES.colors.f0f9ff,
      border: VPB_THEMES.colors.table.borderMedium,
      accent: VPB_THEMES.colors.secondaryBlue,
    };
  }
  if (
    key === "WAITING_REPLACE" ||
    key === "REPLACE" ||
    key === "REPLACE_NEW"
  ) {
    return {
      bg: VPB_THEMES.colors.eff6ff,
      border: VPB_THEMES.colors.table.borderMedium,
      accent: VPB_THEMES.colors.darkBlue,
    };
  }
  if (key === "REPAIRED" || key === "COMPLETED") {
    return {
      bg: VPB_THEMES.colors.statusActiveBg,
      border: VPB_THEMES.colors.f0fdf4,
      accent: VPB_THEMES.colors.statusActiveText,
    };
  }

  return {
    bg: VPB_THEMES.colors.white,
    border: VPB_THEMES.colors.table.borderMedium,
    accent: VPB_THEMES.colors.lightBlue,
  };
};
