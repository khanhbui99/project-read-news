import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import { all, put as dispatch, select, takeLatest } from "redux-saga/effects";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { responseCode } from "utils/constants";
import injectKey from "utils/injectKey";

import {
  buildCreatePayload,
  buildFetchAllAssetsParams,
  buildListParams,
  buildUpdatePayload,
  canManageAssets,
  filterAssetsLocal,
  mapAssetItem,
  mapHistoryItem,
  mapOpt,
  mapStandardDeviceOpt,
  resolveAssetRole,
} from "../assetHelpers";
import { exportAssetLabelsExcel } from "../AssetManagement/utils/exportAssetLabels";
import * as actions from "./actions";
import {
  ASSET_TABS,
  CATALOG_STATUS as FACILITY_CATALOG_STATUS,
  key,
} from "./constants";

function* getState() {
  return yield select((state) => state[key]?.asset || {});
}

function* getUserInfo() {
  return yield select((state) => state[injectKey.GLOBAL]?.userInfo || {});
}

const buildActorNameByAccountId = (teachers = []) => {
  const map = new Map();
  (teachers || []).forEach((teacher) => {
    const accountId =
      teacher.accountId ??
      teacher.userId ??
      teacher.id ??
      teacher.teacherId ??
      "";
    if (accountId == null || accountId === "") return;
    const name =
      teacher.fullName ||
      teacher.full_name ||
      teacher.name ||
      teacher.userFullName ||
      teacher.userName ||
      teacher.displayName ||
      "";
    if (!name) return;
    map.set(String(accountId), name);
  });
  return map;
};

function* refreshList() {
  yield dispatch(actions.queryAssetsAction());
}

function getListPayloadFromStore(store, overrides = {}) {
  return {
    keyword: store.keyword,
    assetGroup: store.activeTab,
    standardDeviceId: store.standardDeviceFilter,
    roomId: store.roomFilter,
    facilityTypeId: store.typeFilter,
    facilitySubjectId: store.subjectFilter,
    condition: store.conditionFilter,
    status: store.statusFilter,
    acquisitionType: store.acquisitionFilter,
    page: store.page,
    size: store.size,
    ...overrides,
  };
}

export function* queryAssetsSaga({ payload = {} } = {}) {
  try {
    const store = yield getState();
    const userInfo = yield getUserInfo();
    const role = resolveAssetRole(userInfo);
    const canManage = canManageAssets(role);
    const assetGroup = payload.assetGroup || store.activeTab;
    const params = buildFetchAllAssetsParams(assetGroup);

    yield dispatch(actions.queryAssetsAction.request());
    const { data: res = {} } = yield ApiReq.get({
      url: canManage
        ? urlApi.managementService.facility.assets.list
        : urlApi.managementService.facility.assets.myRooms,
      params,
    });
    const { data, meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Lấy danh sách tài sản thất bại");
    }

    let list = [];
    if (Array.isArray(data)) {
      list = data;
    } else {
      list = data?.items || data?.content || data?.assets || [];
    }

    const items = list.map(mapAssetItem);
    yield dispatch(
      actions.queryAssetsAction.success({
        items,
        total: items.length,
      }),
    );
  } catch (err) {
    yield dispatch(actions.queryAssetsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* queryAssetFilterOptsSaga({ payload = {} } = {}) {
  try {
    const store = yield getState();
    const assetGroup = payload.assetGroup || store.activeTab;
    const force = payload.force === true;

    const needDevices =
      force ||
      payload.assetGroup != null ||
      !(store.standardDeviceOpts || []).length;
    const needRooms = force || !(store.roomOpts || []).length;
    const needTypes = force || !(store.typeOpts || []).length;
    const needSubjects = force || !(store.subjectOpts || []).length;

    if (!needDevices && !needRooms && !needTypes && !needSubjects) {
      return;
    }

    yield dispatch(actions.queryAssetFilterOptsAction.request());

    const pickList = (res) => {
      if (!res) return null;
      const { data, meta = {} } = res?.data || {};
      if (meta?.code && meta.code !== responseCode["IL-200"]) return [];
      if (Array.isArray(data)) return data;
      return data?.items || data?.content || [];
    };
console.log(needTypes)
    const tasks = {};
    if (needDevices) {
      tasks.devices = ApiReq.get({
        url: urlApi.managementService.facility.standardDevices.list,
      });
    }
    if (needRooms) {
      tasks.rooms = ApiReq.get({
        url: urlApi.managementService.facility.rooms.list,
      });
    }
    if (needTypes) {
      tasks.types = ApiReq.get({
        url: urlApi.managementService.facility.types.list,
      });
    }
    if (needSubjects) {
      tasks.subjects = ApiReq.get({
        url: urlApi.managementService.facility.subjects.list,
      });
    }

    const results = yield all(tasks);

    const devices = needDevices
      ? (pickList(results.devices) || []).filter(
          (d) =>
            !d.codeHidden &&
            (!d.assetGroup || d.assetGroup === assetGroup),
        )
      : null;
    const rooms = needRooms ? pickList(results.rooms) || [] : null;
    const types = needTypes ? pickList(results.types) || [] : null;
    const subjects = needSubjects ? pickList(results.subjects) || [] : null;

    yield dispatch(
      actions.queryAssetFilterOptsAction.success({
        standardDeviceOpts: devices
          ? devices.map(mapStandardDeviceOpt)
          : store.standardDeviceOpts || [],
        roomOpts: rooms ? rooms.map(mapOpt) : store.roomOpts || [],
        typeOpts: types ? types.map(mapOpt) : store.typeOpts || [],
        subjectOpts: subjects ? subjects.map(mapOpt) : store.subjectOpts || [],
      }),
    );
  } catch (err) {
    yield dispatch(actions.queryAssetFilterOptsAction.failure(err));
  }
}

export function* getAssetDetailSaga({ payload }) {
  try {
    const id = typeof payload === "object" ? payload?.id : payload;
    if (!id) return;

    const userInfo = yield getUserInfo();
    const canManage = canManageAssets(resolveAssetRole(userInfo));

    yield dispatch(actions.getAssetDetailAction.request());
    const { data: res = {} } = yield ApiReq.get({
      url: canManage
        ? urlApi.managementService.facility.assets.detail(id)
        : urlApi.managementService.facility.assets.myRoomsDetail(id),
    });
    const { data, meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Lấy chi tiết tài sản thất bại");
    }

    const raw = data?.asset || data || {};
    yield dispatch(actions.getAssetDetailAction.success(mapAssetItem(raw)));
    yield dispatch(actions.queryAssetHistoryAction({ id }));
  } catch (err) {
    yield dispatch(actions.getAssetDetailAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* queryAssetHistorySaga({ payload }) {
  try {
    const id = typeof payload === "object" ? payload?.id : payload;
    if (!id) return;

    const userInfo = yield getUserInfo();
    const canManage = canManageAssets(resolveAssetRole(userInfo));

    yield dispatch(actions.queryAssetHistoryAction.request());
    const { data: res = {} } = yield ApiReq.get({
      url: canManage
        ? urlApi.managementService.facility.assets.history(id)
        : urlApi.managementService.facility.assets.myRoomsHistory(id),
    });
    const { data, meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Lấy lịch sử tài sản thất bại");
    }
    const list = Array.isArray(data) ? data : data?.items || [];
    const teachersOpt = yield select(
      (state) => state[injectKey.GLOBAL]?.teachersOpt || [],
    );
    const actorNameByAccountId = buildActorNameByAccountId(teachersOpt);
    yield dispatch(
      actions.queryAssetHistoryAction.success(
        list.map((item) => mapHistoryItem(item, actorNameByAccountId)),
      ),
    );
  } catch (err) {
    yield dispatch(actions.queryAssetHistoryAction.failure(err));
  }
}

export function* createAssetsSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(actions.createAssetsAction.request());

    const formValues =
      payload && typeof payload === "object" && !Array.isArray(payload)
        ? payload
        : {};
    const assetGroup = formValues.assetGroup || undefined;
    const body = buildCreatePayload(formValues);

    const { data: res = {} } = yield ApiReq.post({
      url: urlApi.managementService.facility.assets.create,
      params: assetGroup ? { assetGroup } : undefined,
      data: body,
    });
    const { data, meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Tạo tài sản thất bại");
    }

    const firstId =
      data?.firstId ||
      data?.id ||
      (Array.isArray(data?.ids) ? data.ids[0] : null) ||
      data;

    yield dispatch(actions.createAssetsAction.success({ firstId }));
    yield dispatch(
      setMessageByFieldAction("success", "Tạo tài sản thành công"),
    );
    yield refreshList();
  } catch (err) {
    yield dispatch(actions.createAssetsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* updateAssetSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(actions.updateAssetAction.request());

    const id = payload?.id;
    const { data: res = {} } = yield ApiReq.put({
      url: urlApi.managementService.facility.assets.update(id),
      data: buildUpdatePayload(payload),
    });
    const { meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Cập nhật tài sản thất bại");
    }

    yield dispatch(actions.updateAssetAction.success({ id }));
    yield dispatch(
      setMessageByFieldAction("success", "Cập nhật tài sản thành công"),
    );
    yield dispatch(actions.getAssetDetailAction({ id }));
    yield refreshList();
  } catch (err) {
    yield dispatch(actions.updateAssetAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* deleteAssetsSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(actions.deleteAssetsAction.request());

    const ids = (payload?.ids || []).filter(Boolean);
    if (!ids.length) {
      throw new Error("Không có tài sản để xóa");
    }

    // Xóa từng request riêng, chạy song song
    const results = yield all(
      ids.map((id) =>
        ApiReq.del({
          url: urlApi.managementService.facility.assets.delete(id),
        }),
      ),
    );

    const failed = results.find((res) => {
      const meta = res?.data?.meta || {};
      return meta?.code && meta.code !== responseCode["IL-200"];
    });
    if (failed) {
      throw new Error(
        failed?.data?.meta?.message || "Xóa tài sản thất bại",
      );
    }

    yield dispatch(actions.deleteAssetsAction.success());
    yield dispatch(setMessageByFieldAction("success", "Đã xóa tài sản"));
    yield refreshList();
  } catch (err) {
    yield dispatch(actions.deleteAssetsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* queryAssetIdsSaga({ payload = {} } = {}) {
  try {
    const store = yield getState();
    const params = buildListParams(
      getListPayloadFromStore(store, { ...payload, page: 0, size: 1 }),
    );
    delete params.page;
    delete params.size;

    yield dispatch(actions.queryAssetIdsAction.request());
    const { data: res = {} } = yield ApiReq.get({
      url: urlApi.managementService.facility.assets.ids,
      params,
    });
    const { data, meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Lấy danh sách chọn thất bại");
    }
    const ids = Array.isArray(data) ? data : data?.ids || [];
    yield dispatch(actions.queryAssetIdsAction.success({ ids }));
  } catch (err) {
    yield dispatch(actions.queryAssetIdsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  }
}

export function* exportAssetCodesSaga({ payload = {} } = {}) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(actions.exportAssetCodesAction.request());
    const store = yield getState();

    // Chỉ xuất đúng các bản ghi đang khớp bộ lọc trên table
    const rows = filterAssetsLocal(store.items || [], {
      keyword: payload.keyword ?? store.keyword,
      standardDeviceFilter:
        payload.standardDeviceFilter ?? store.standardDeviceFilter,
      roomFilter: payload.roomFilter ?? store.roomFilter,
      typeFilter: payload.typeFilter ?? store.typeFilter,
      subjectFilter: payload.subjectFilter ?? store.subjectFilter,
      conditionFilter: payload.conditionFilter ?? store.conditionFilter,
      statusFilter: payload.statusFilter ?? store.statusFilter,
      acquisitionFilter: payload.acquisitionFilter ?? store.acquisitionFilter,
    });

    if (!rows.length) {
      throw new Error("Không có dữ liệu để xuất Excel");
    }

    const isTeaching = store.activeTab === ASSET_TABS.TEACHING_DEVICE;
    exportAssetLabelsExcel(rows, isTeaching);
    yield dispatch(actions.exportAssetCodesAction.success());
    yield dispatch(
      setMessageByFieldAction("success", "Xuất file Excel thành công"),
    );
  } catch (err) {
    yield dispatch(actions.exportAssetCodesAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* transferAssetsSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(actions.transferAssetsAction.request());

    const { data: res = {} } = yield ApiReq.post({
      url: urlApi.managementService.facility.assets.transfer,
      data: {
        ids: payload.ids || [],
        roomId: Number(payload.roomId),
        note: (payload.note || "").trim() || null,
      },
    });
    const { meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Điều chuyển thất bại");
    }

    yield dispatch(actions.transferAssetsAction.success());
    yield dispatch(
      setMessageByFieldAction("success", "Điều chuyển thành công"),
    );
    yield refreshList();
  } catch (err) {
    yield dispatch(actions.transferAssetsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export function* proposeDisposeAssetsSaga({ payload }) {
  try {
    yield dispatch(setLoadingAction(true));
    yield dispatch(actions.proposeDisposeAssetsAction.request());

    const note = (payload.note || payload.reason || "").trim();
    const submit = payload.submit !== false;

    const { data: res = {} } = yield ApiReq.post({
      url: urlApi.managementService.facility.assets.proposeDispose,
      data: {
        assetIds: payload.ids || [],
        reason: note,
        submit,
      },
    });
    const { meta = {} } = res;
    if (meta?.code && meta.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message || "Đề xuất loại bỏ thất bại");
    }

    yield dispatch(actions.proposeDisposeAssetsAction.success());
    yield dispatch(
      setMessageByFieldAction(
        "success",
        submit ? "Đã gửi đề xuất loại bỏ" : "Lưu nháp thành công.",
      ),
    );
    yield refreshList();
  } catch (err) {
    yield dispatch(actions.proposeDisposeAssetsAction.failure(err));
    yield dispatch(setMessageByFieldAction("error", err));
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export default function* assetManagementSaga() {
  yield all([
    takeLatest(actions.queryAssetsAction.TRIGGER, queryAssetsSaga),
    takeLatest(
      actions.queryAssetFilterOptsAction.TRIGGER,
      queryAssetFilterOptsSaga,
    ),
    takeLatest(actions.getAssetDetailAction.TRIGGER, getAssetDetailSaga),
    takeLatest(actions.queryAssetHistoryAction.TRIGGER, queryAssetHistorySaga),
    takeLatest(actions.createAssetsAction.TRIGGER, createAssetsSaga),
    takeLatest(actions.updateAssetAction.TRIGGER, updateAssetSaga),
    takeLatest(actions.deleteAssetsAction.TRIGGER, deleteAssetsSaga),
    takeLatest(actions.queryAssetIdsAction.TRIGGER, queryAssetIdsSaga),
    takeLatest(actions.exportAssetCodesAction.TRIGGER, exportAssetCodesSaga),
    takeLatest(actions.transferAssetsAction.TRIGGER, transferAssetsSaga),
    takeLatest(
      actions.proposeDisposeAssetsAction.TRIGGER,
      proposeDisposeAssetsSaga,
    ),
  ]);
}
