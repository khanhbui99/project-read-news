import injectKey from "utils/injectKey";

export const key = injectKey.facility.standardCode;

export const FACILITY_TABS = {
  SUBJECTS: "subjects",
  TYPES: "types",
  STANDARD_DEVICES: "standardDevices",
  ROOM_TYPES: "roomTypes",
};

export const FACILITY_TAB_LIST = [
  {
    key: FACILITY_TABS.SUBJECTS,
    label: "Môn / Nhóm",
    icon: "book",
    searchPlaceholder: "Tìm kiếm môn hoặc nhóm...",
    createTitle: "Thêm môn / nhóm",
    editTitle: "Sửa môn / nhóm",
    deleteTitle: "Xóa môn / nhóm",
    nameLabel: "Tên môn / nhóm",
    namePlaceholder: "Nhập tên môn / nhóm",
    codeLabel: "Mã gốc",
    codePlaceholder: "Nhập mã gốc",
    emptyText: "Chưa có dữ liệu môn / nhóm.",
  },
  {
    key: FACILITY_TABS.TYPES,
    label: "Loại",
    icon: "category",
    searchPlaceholder: "Tìm kiếm loại...",
    createTitle: "Thêm loại",
    editTitle: "Sửa loại",
    deleteTitle: "Xóa loại",
    nameLabel: "Tên loại",
    namePlaceholder: "Nhập tên loại",
    codeLabel: "Mã gốc",
    codePlaceholder: "Nhập mã gốc",
    emptyText: "Chưa có dữ liệu loại.",
  },
  {
    key: FACILITY_TABS.STANDARD_DEVICES,
    label: "Tài sản phục vụ dạy học",
    icon: "device",
    searchPlaceholder: "Tìm kiếm tài sản phục vụ dạy học...",
    createTitle: "Thêm tài sản phục vụ dạy học",
    editTitle: "Sửa tài sản phục vụ dạy học",
    deleteTitle: "Xóa tài sản phục vụ dạy học",
    nameLabel: "Tên thiết bị",
    namePlaceholder: "Nhập tên tài sản phục vụ dạy học",
    codeLabel: "Mã gốc",
    codePlaceholder: "Nhập mã gốc",
    emptyText: "Chưa có dữ liệu tài sản phục vụ dạy học.",
  },
  {
    key: FACILITY_TABS.ROOM_TYPES,
    label: "Loại phòng",
    icon: "room",
    searchPlaceholder: "Tìm kiếm loại phòng...",
    createTitle: "Thêm loại phòng",
    editTitle: "Sửa loại phòng",
    deleteTitle: "Xóa loại phòng",
    nameLabel: "Tên loại phòng",
    namePlaceholder: "Nhập tên loại phòng",
    codeLabel: "Mã gốc",
    codePlaceholder: "Nhập mã gốc",
    emptyText: "Chưa có dữ liệu loại phòng.",
  },
];

export const ASSET_GROUP = {
  FIXED: "FIXED",
  TEACHING_DEVICE: "TEACHING_DEVICE",
};

export const ASSET_GROUP_OPTIONS = [
  { value: ASSET_GROUP.FIXED, label: "Cơ sở vật chất" },
  { value: ASSET_GROUP.TEACHING_DEVICE, label: "Thiết bị dạy học" },
];

export const ASSET_GROUP_MAP = ASSET_GROUP_OPTIONS.reduce((acc, item) => {
  acc[item.value] = item.label;
  return acc;
}, {});

export const CATALOG_STATUS = {
  ACTIVE: "ACTIVE",
  HIDDEN: "HIDDEN",
};

export const CATALOG_STATUS_MAP = {
  [CATALOG_STATUS.ACTIVE]: "Đang sử dụng",
  [CATALOG_STATUS.HIDDEN]: "Đã ẩn",
  IN_USE: "Đang sử dụng",
};

export const STATUS_FILTER_OPTIONS = [
  { value: "ALL", label: "Tất cả" },
  { value: CATALOG_STATUS.ACTIVE, label: "Đang sử dụng" },
  { value: CATALOG_STATUS.HIDDEN, label: "Đã ẩn" },
];

export const PAGE_SIZE_OPTIONS = [10, 20, 50];
export const PAGE_SIZE = 10;

// Normal actions
export const RESET_STORE_FACILITY_STANDARD_CODE_ACTION = `app/${key}/RESET_STORE_FACILITY_STANDARD_CODE_ACTION`;
export const SET_FIELD_VALUE_STORE_FACILITY_STANDARD_CODE_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_FACILITY_STANDARD_CODE_ACTION`;

// Saga actions
export const QUERY_FACILITY_CATALOG_ACTION = `app/${key}/QUERY_FACILITY_CATALOG_ACTION`;
export const CREATE_FACILITY_CATALOG_ACTION = `app/${key}/CREATE_FACILITY_CATALOG_ACTION`;
export const UPDATE_FACILITY_CATALOG_ACTION = `app/${key}/UPDATE_FACILITY_CATALOG_ACTION`;
export const DELETE_FACILITY_CATALOG_ACTION = `app/${key}/DELETE_FACILITY_CATALOG_ACTION`;
export const TOGGLE_FACILITY_CATALOG_STATUS_ACTION = `app/${key}/TOGGLE_FACILITY_CATALOG_STATUS_ACTION`;
export const CHECK_CODE_CHANGE_IMPACT_ACTION = `app/${key}/CHECK_CODE_CHANGE_IMPACT_ACTION`;

// Asset management
export const ASSET_TABS = {
  FIXED: ASSET_GROUP.FIXED,
  TEACHING_DEVICE: ASSET_GROUP.TEACHING_DEVICE,
};

export const ASSET_TAB_LIST = [
  { key: ASSET_TABS.FIXED, label: "Cơ sở vật chất", icon: "device" },
  {
    key: ASSET_TABS.TEACHING_DEVICE,
    label: "Thiết bị dạy học",
    icon: "book",
  },
];

export const ASSET_ROLE = {
  FACILITY_MANAGER: "FACILITY_MANAGER",
  OTHER: "OTHER",
};

export const ASSET_CONDITION = {
  NORMAL: "NORMAL",
  OLD: "OLD",
  BROKEN: "BROKEN",
  MISSING: "MISSING",
};

export const ASSET_CONDITION_MAP = {
  [ASSET_CONDITION.NORMAL]: "Bình thường",
  [ASSET_CONDITION.OLD]: "Cũ",
  [ASSET_CONDITION.BROKEN]: "Hỏng",
  [ASSET_CONDITION.MISSING]: "Thiếu",
};

export const ASSET_CONDITION_OPTIONS = Object.keys(ASSET_CONDITION_MAP).map(
  (value) => ({ value, label: ASSET_CONDITION_MAP[value] }),
);

export const OPERATIONAL_STATUS = {
  IN_USE: "IN_USE",
  BORROWED: "BORROWED",
  LOCKED: "LOCKED",
  DISPOSED: "DISPOSED",
  PENDING_RESTORE:"PENDING_RESTORE"
};

export const OPERATIONAL_STATUS_MAP = {
  [OPERATIONAL_STATUS.IN_USE]: "Đang sử dụng",
  [OPERATIONAL_STATUS.BORROWED]: "Đang mượn",
  [OPERATIONAL_STATUS.LOCKED]: "Đang khóa",
  [OPERATIONAL_STATUS.DISPOSED]: "Đã loại bỏ",
  [OPERATIONAL_STATUS.PENDING_RESTORE]: "Chờ khôi phục",
};

export const OPERATIONAL_STATUS_OPTIONS = Object.keys(
  OPERATIONAL_STATUS_MAP,
).map((value) => ({ value, label: OPERATIONAL_STATUS_MAP[value] }));

export const OPERATIONAL_STATUS_FILTER_OPTIONS = [
  { value: "ALL", label: "Tất cả (trừ đã loại bỏ)" },
  ...OPERATIONAL_STATUS_OPTIONS,
];

export const ACQUISITION_TYPE = {
  PURCHASE: "PURCHASE",
  GRANTED: "GRANTED",
  DONATED: "DONATED",
};

export const ACQUISITION_TYPE_MAP = {
  [ACQUISITION_TYPE.PURCHASE]: "Mua sắm",
  [ACQUISITION_TYPE.GRANTED]: "Được cấp",
  [ACQUISITION_TYPE.DONATED]: "Trao tặng",
};

export const ACQUISITION_TYPE_OPTIONS = Object.keys(ACQUISITION_TYPE_MAP).map(
  (value) => ({ value, label: ACQUISITION_TYPE_MAP[value] }),
);

export const DETAIL_DRAWER_WIDTH = 640;
export const CREATE_DRAWER_WIDTH = 640;
export const MAX_CREATE_QUANTITY = 200;
export const MAX_UNIT_PRICE = 10_000_000_000;

export const DETAIL_TABS = {
  INFO: "info",
  HISTORY: "history",
};

export const RESET_STORE_ASSET_MANAGEMENT_ACTION = `app/${key}/RESET_STORE_ASSET_MANAGEMENT_ACTION`;
export const SET_FIELD_VALUE_STORE_ASSET_MANAGEMENT_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_ASSET_MANAGEMENT_ACTION`;
export const QUERY_ASSETS_ACTION = `app/${key}/QUERY_ASSETS_ACTION`;
export const QUERY_ASSET_FILTER_OPTS_ACTION = `app/${key}/QUERY_ASSET_FILTER_OPTS_ACTION`;
export const GET_ASSET_DETAIL_ACTION = `app/${key}/GET_ASSET_DETAIL_ACTION`;
export const CREATE_ASSETS_ACTION = `app/${key}/CREATE_ASSETS_ACTION`;
export const UPDATE_ASSET_ACTION = `app/${key}/UPDATE_ASSET_ACTION`;
export const DELETE_ASSETS_ACTION = `app/${key}/DELETE_ASSETS_ACTION`;
export const QUERY_ASSET_IDS_ACTION = `app/${key}/QUERY_ASSET_IDS_ACTION`;
export const QUERY_ASSET_HISTORY_ACTION = `app/${key}/QUERY_ASSET_HISTORY_ACTION`;
export const EXPORT_ASSET_CODES_ACTION = `app/${key}/EXPORT_ASSET_CODES_ACTION`;
export const TRANSFER_ASSETS_ACTION = `app/${key}/TRANSFER_ASSETS_ACTION`;
export const PROPOSE_DISPOSE_ASSETS_ACTION = `app/${key}/PROPOSE_DISPOSE_ASSETS_ACTION`;

// Repair ticket
export const CREATE_STEPS = {
  ROOM: 1,
  ASSET: 2,
  ITEM: 3,
};

export const CREATE_STEP_LABELS = [
  { step: CREATE_STEPS.ROOM, label: "Chọn phòng" },
  { step: CREATE_STEPS.ASSET, label: "Chọn tài sản" },
  { step: CREATE_STEPS.ITEM, label: "Thông tin báo hỏng" },
];

export const REPAIR_ROLE = {
  CREATOR: "CREATOR",
  ROOM_MANAGER: "ROOM_MANAGER",
  FACILITY_MANAGER: "FACILITY_MANAGER",
  SCHOOL_MANAGER: "SCHOOL_MANAGER",
};

export const TICKET_STATUS = {
  DRAFT: "DRAFT",
  WAITING: "WAITING",
  PENDING: "PENDING",
  PROCESSING: "PROCESSING",
  IN_PROGRESS: "IN_PROGRESS",
  COMPLETED: "COMPLETED",
  REJECTED: "REJECTED",
};

export const TICKET_STATUS_MAP = {
  [TICKET_STATUS.DRAFT]: "Nháp",
  [TICKET_STATUS.WAITING]: "Chờ duyệt",
  [TICKET_STATUS.PENDING]: "Chờ duyệt",
  [TICKET_STATUS.PROCESSING]: "Đang xử lý",
  [TICKET_STATUS.IN_PROGRESS]: "Đang xử lý",
  [TICKET_STATUS.COMPLETED]: "Hoàn thành",
  [TICKET_STATUS.REJECTED]: "Từ chối",
};

export const TICKET_STATUS_OPTIONS = [
  { value: "ALL", label: "Tất cả trạng thái" },
  ...Object.keys(TICKET_STATUS_MAP)
    // PENDING / IN_PROGRESS trùng label với WAITING / PROCESSING — ẩn khỏi filter
    .filter(
      (value) =>
        value !== TICKET_STATUS.PENDING && value !== TICKET_STATUS.IN_PROGRESS,
    )
    .map((value) => ({
      value,
      label: TICKET_STATUS_MAP[value],
    })),
];

export const ITEM_STATUS = {
  DRAFT: "DRAFT",
  WAITING: "WAITING",
  WAITING_APPROVAL: "WAITING_APPROVAL",
  PENDING: "PENDING",
  REJECTED: "REJECTED",
  REPAIRING: "REPAIRING",
  APPROVED_REPAIR: "APPROVED_REPAIR",
  IN_PROGRESS: "IN_PROGRESS",
  COMPLETED: "COMPLETED",
  REPAIRED: "REPAIRED",
  WAITING_REPLACE: "WAITING_REPLACE",
  REPLACE: "REPLACE",
  REPLACE_NEW: "REPLACE_NEW",
  CANNOT_REPAIR: "CANNOT_REPAIR",
};

export const ITEM_STATUS_MAP = {
  [ITEM_STATUS.DRAFT]: "Nháp",
  [ITEM_STATUS.WAITING]: "Chờ duyệt",
  [ITEM_STATUS.WAITING_APPROVAL]: "Chờ duyệt",
  [ITEM_STATUS.PENDING]: "Chờ duyệt",
  [ITEM_STATUS.REJECTED]: "Bị từ chối",
  [ITEM_STATUS.REPAIRING]: "Đang sửa",
  [ITEM_STATUS.APPROVED_REPAIR]: "Duyệt sửa",
  [ITEM_STATUS.IN_PROGRESS]: "Đang sửa",
  [ITEM_STATUS.COMPLETED]: "Hoàn thành",
  [ITEM_STATUS.REPAIRED]: "Đã sửa",
  [ITEM_STATUS.WAITING_REPLACE]: "Chờ thay mới",
  [ITEM_STATUS.REPLACE]: "Thay mới",
  [ITEM_STATUS.REPLACE_NEW]: "Thay mới",
  [ITEM_STATUS.CANNOT_REPAIR]: "Không sửa được",
};

export const PRIORITY = {
  LOW: "LOW",
  MEDIUM: "MEDIUM",
  HIGH: "HIGH",
  URGENT: "URGENT",
};

export const PRIORITY_MAP = {
  [PRIORITY.LOW]: "Thấp",
  [PRIORITY.MEDIUM]: "Trung bình",
  [PRIORITY.HIGH]: "Cao",
  [PRIORITY.URGENT]: "Khẩn",
};

export const PRIORITY_OPTIONS = Object.keys(PRIORITY_MAP).map((value) => ({
  value,
  label: PRIORITY_MAP[value],
}));

export const DECISION = {
  APPROVE_REPAIR: "APPROVE_REPAIR",
  APPROVE_REPLACE: "APPROVE_REPLACE",
  REJECT: "REJECT",
};

export const REPAIR_RESULT = {
  SUCCESS: "SUCCESS",
  FAILED: "FAILED",
};

export const REPAIR_RESULT_OPTIONS = [
  { value: REPAIR_RESULT.SUCCESS, label: "Sửa được" },
  { value: REPAIR_RESULT.FAILED, label: "Không sửa được" },
];

export const REPAIR_PAGE_SIZE = 10;
export const REPAIR_PAGE_SIZE_OPTIONS = [10, 20, 50, 100];
export const REPAIR_CREATE_DRAWER_WIDTH = 720;
export const COMPLETE_DRAWER_WIDTH = 560;
export const SEARCH_DEBOUNCE_MS = 500;
export const MAX_DESCRIPTION = 500;
export const MAX_FILES = 5;
export const MAX_FILE_SIZE_MB = 10;
export const ALLOWED_FILE_TYPES = [
  "image/jpeg",
  "image/png",
  "application/pdf",
];
export const ALLOWED_FILE_EXT = [".jpg", ".jpeg", ".png", ".pdf"];

export const RESET_STORE_REPAIR_TICKET_ACTION = `app/${key}/RESET_STORE_REPAIR_TICKET_ACTION`;
export const SET_FIELD_VALUE_STORE_REPAIR_TICKET_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_REPAIR_TICKET_ACTION`;
export const QUERY_REPAIR_TICKETS_ACTION = `app/${key}/QUERY_REPAIR_TICKETS_ACTION`;
export const QUERY_REPAIR_FILTER_OPTS_ACTION = `app/${key}/QUERY_REPAIR_FILTER_OPTS_ACTION`;
export const QUERY_ROOM_ASSETS_ACTION = `app/${key}/QUERY_ROOM_ASSETS_ACTION`;
export const CREATE_REPAIR_TICKET_ACTION = `app/${key}/CREATE_REPAIR_TICKET_ACTION`;
export const UPDATE_REPAIR_TICKET_ACTION = `app/${key}/UPDATE_REPAIR_TICKET_ACTION`;
export const GET_REPAIR_TICKET_DETAIL_ACTION = `app/${key}/GET_REPAIR_TICKET_DETAIL_ACTION`;
export const DELETE_REPAIR_TICKET_ACTION = `app/${key}/DELETE_REPAIR_TICKET_ACTION`;
export const DECIDE_REPAIR_ITEMS_ACTION = `app/${key}/DECIDE_REPAIR_ITEMS_ACTION`;
export const RESUBMIT_REPAIR_ITEM_ACTION = `app/${key}/RESUBMIT_REPAIR_ITEM_ACTION`;
export const UPDATE_EXPECTED_DATE_ACTION = `app/${key}/UPDATE_EXPECTED_DATE_ACTION`;
export const COMPLETE_REPAIR_ITEM_ACTION = `app/${key}/COMPLETE_REPAIR_ITEM_ACTION`;
export const UPLOAD_REPAIR_FILE_ACTION = `app/${key}/UPLOAD_REPAIR_FILE_ACTION`;
export const DOWNLOAD_REPAIR_FILE_ACTION = `app/${key}/DOWNLOAD_REPAIR_FILE_ACTION`;

// Transfer asset
export const TRANSFER_NOTE_MAX = 500;

export const RESET_STORE_TRANSFER_ACTION = `app/${key}/RESET_STORE_TRANSFER_ACTION`;
export const SET_FIELD_VALUE_STORE_TRANSFER_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_TRANSFER_ACTION`;
export const QUERY_TRANSFER_OPTS_ACTION = `app/${key}/QUERY_TRANSFER_OPTS_ACTION`;
export const QUERY_TRANSFER_ROOM_ASSETS_ACTION = `app/${key}/QUERY_TRANSFER_ROOM_ASSETS_ACTION`;
export const CREATE_TRANSFER_ACTION = `app/${key}/CREATE_TRANSFER_ACTION`;

// Disposal & Restore proposals
export const PROPOSAL_TABS = {
  DISPOSAL: "disposal",
  RESTORE: "restore",
};

export const PROPOSAL_TAB_LIST = [
  {
    key: PROPOSAL_TABS.DISPOSAL,
    label: "Đề xuất loại bỏ",
    icon: "device",
  },
  {
    key: PROPOSAL_TABS.RESTORE,
    label: "Đề xuất khôi phục",
    icon: "category",
  },
];

export const PROPOSAL_STATUS = {
  DRAFT: "DRAFT",
  PENDING: "PENDING",
  COMPLETED: "COMPLETED",
};

export const PROPOSAL_STATUS_MAP = {
  [PROPOSAL_STATUS.DRAFT]: "Nháp",
  [PROPOSAL_STATUS.PENDING]: "Chờ xử lý",
  [PROPOSAL_STATUS.COMPLETED]: "Hoàn tất",
};

export const PROPOSAL_DECISION = {
  APPROVED: "APPROVED",
  REJECTED: "REJECTED",
  PENDING: "PENDING",
};

export const PROPOSAL_DECISION_MAP = {
  [PROPOSAL_DECISION.APPROVED]: "Đã duyệt",
  [PROPOSAL_DECISION.REJECTED]: "Từ chối",
  [PROPOSAL_DECISION.PENDING]: "Chờ xử lý",
};

export const PROPOSAL_STATUS_OPTIONS = [
  { value: "ALL", label: "Tất cả trạng thái" },
  ...Object.keys(PROPOSAL_STATUS_MAP).map((value) => ({
    value,
    label: PROPOSAL_STATUS_MAP[value],
  })),
];

export const PROPOSAL_ROLE = {
  FACILITY_MANAGER: "FACILITY_MANAGER",
  SCHOOL_MANAGER: "SCHOOL_MANAGER",
  OTHER: "OTHER",
};

export const PROPOSAL_DRAWER_WIDTH = 900;
export const PROPOSAL_REASON_MAX = 500;

export const RESET_STORE_DISPOSAL_RESTORE_ACTION = `app/${key}/RESET_STORE_DISPOSAL_RESTORE_ACTION`;
export const SET_FIELD_VALUE_STORE_DISPOSAL_RESTORE_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_DISPOSAL_RESTORE_ACTION`;
export const QUERY_PROPOSALS_ACTION = `app/${key}/QUERY_PROPOSALS_ACTION`;
export const QUERY_PROPOSAL_OPTS_ACTION = `app/${key}/QUERY_PROPOSAL_OPTS_ACTION`;
export const QUERY_PROPOSAL_ASSETS_ACTION = `app/${key}/QUERY_PROPOSAL_ASSETS_ACTION`;
export const GET_PROPOSAL_DETAIL_ACTION = `app/${key}/GET_PROPOSAL_DETAIL_ACTION`;
export const CREATE_PROPOSAL_ACTION = `app/${key}/CREATE_PROPOSAL_ACTION`;
export const SUBMIT_PROPOSAL_ACTION = `app/${key}/SUBMIT_PROPOSAL_ACTION`;
export const DECIDE_PROPOSAL_ACTION = `app/${key}/DECIDE_PROPOSAL_ACTION`;
export const PREFILL_RESTORE_FROM_DISPOSAL_ACTION = `app/${key}/PREFILL_RESTORE_FROM_DISPOSAL_ACTION`;

// Borrow / Return
export const BORROW_TABS = {
  BORROWING: "BORROWING",
  RETURNED: "RETURNED",
};

export const BORROW_TAB_LIST = [
  { key: BORROW_TABS.BORROWING, label: "Đang mượn", icon: "device" },
  { key: BORROW_TABS.RETURNED, label: "Trả thiết bị", icon: "room" },
];

export const BORROW_HISTORY_TABS = {
  BORROW: "BORROW",
  RETURN: "RETURN",
};

export const BORROW_HISTORY_TAB_LIST = [
  { key: BORROW_HISTORY_TABS.BORROW, label: "Mượn", icon: "device" },
  { key: BORROW_HISTORY_TABS.RETURN, label: "Trả", icon: "room" },
];

export const BORROW_STATUS = {
  BORROWING: "BORROWING",
  RETURNED: "RETURNED",
  OVERDUE: "OVERDUE",
};

export const BORROW_STATUS_MAP = {
  [BORROW_STATUS.BORROWING]: "Đang mượn",
  [BORROW_STATUS.RETURNED]: "Đã trả",
  [BORROW_STATUS.OVERDUE]: "Quá hạn",
};

export const RETURN_CONDITION = {
  NORMAL: "NORMAL",
  OLD: "OLD",
  BROKEN: "BROKEN",
  MISSING: "MISSING",
};

export const RETURN_CONDITION_MAP = {
  [RETURN_CONDITION.NORMAL]: "Bình thường",
  [RETURN_CONDITION.OLD]: "Cũ",
  [RETURN_CONDITION.BROKEN]: "Hỏng",
  [RETURN_CONDITION.MISSING]: "Thiếu",
};

export const RETURN_CONDITION_OPTIONS = Object.keys(RETURN_CONDITION_MAP).map(
  (value) => ({ value, label: RETURN_CONDITION_MAP[value] }),
);

export const BORROW_ROLE = {
  TEACHER: "TEACHER",
  SCHOOL_MANAGER: "SCHOOL_MANAGER",
  OTHER: "OTHER",
};

export const BORROW_DRAWER_WIDTH = 700;
export const BORROW_NOTE_MAX = 500;

export const RESET_STORE_BORROW_ACTION = `app/${key}/RESET_STORE_BORROW_ACTION`;
export const SET_FIELD_VALUE_STORE_BORROW_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_BORROW_ACTION`;
export const QUERY_MY_BORROWS_ACTION = `app/${key}/QUERY_MY_BORROWS_ACTION`;
export const QUERY_BORROW_OPTS_ACTION = `app/${key}/QUERY_BORROW_OPTS_ACTION`;
export const QUERY_BORROW_AVAILABLE_ACTION = `app/${key}/QUERY_BORROW_AVAILABLE_ACTION`;
export const CREATE_BORROW_ACTION = `app/${key}/CREATE_BORROW_ACTION`;
export const RETURN_BORROW_ACTION = `app/${key}/RETURN_BORROW_ACTION`;

// Activity logs (Nhật ký hệ thống)
export const ACTIVITY_ACTION_TYPE = {
  CREATE: "CREATE",
  UPDATE: "UPDATE",
  DELETE: "DELETE",
  TRANSFER: "TRANSFER",
  REPORT_BROKEN: "REPORT_BROKEN",
  DISPOSAL: "DISPOSAL",
  RESTORE: "RESTORE",
  BORROW: "BORROW",
  RETURN: "RETURN",
  BORROW_RETURN: "BORROW_RETURN",
  ASSIGN_MANAGER: "ASSIGN_MANAGER",
};

export const ACTIVITY_ACTION_TYPE_MAP = {
  [ACTIVITY_ACTION_TYPE.CREATE]: "Tạo",
  [ACTIVITY_ACTION_TYPE.UPDATE]: "Sửa",
  [ACTIVITY_ACTION_TYPE.DELETE]: "Xóa",
  [ACTIVITY_ACTION_TYPE.TRANSFER]: "Điều chuyển",
  [ACTIVITY_ACTION_TYPE.REPORT_BROKEN]: "Báo hỏng",
  [ACTIVITY_ACTION_TYPE.DISPOSAL]: "Loại bỏ",
  [ACTIVITY_ACTION_TYPE.RESTORE]: "Khôi phục",
  [ACTIVITY_ACTION_TYPE.BORROW]: "Mượn",
  [ACTIVITY_ACTION_TYPE.RETURN]: "Trả",
  [ACTIVITY_ACTION_TYPE.BORROW_RETURN]: "Mượn / Trả",
  [ACTIVITY_ACTION_TYPE.ASSIGN_MANAGER]: "Gán phụ trách",
};

export const ACTIVITY_ACTION_TYPE_OPTIONS = [
  { value: "ALL", label: "Tất cả" },
  ...Object.keys(ACTIVITY_ACTION_TYPE_MAP).map((value) => ({
    value,
    label: ACTIVITY_ACTION_TYPE_MAP[value],
  })),
];

export const ACTIVITY_ROLE = {
  FACILITY_MANAGER: "FACILITY_MANAGER",
  SCHOOL_MANAGER: "SCHOOL_MANAGER",
  OTHER: "OTHER",
};

export const RESET_STORE_ACTIVITY_LOG_ACTION = `app/${key}/RESET_STORE_ACTIVITY_LOG_ACTION`;
export const SET_FIELD_VALUE_STORE_ACTIVITY_LOG_ACTION = `app/${key}/SET_FIELD_VALUE_STORE_ACTIVITY_LOG_ACTION`;
export const QUERY_ACTIVITY_LOGS_ACTION = `app/${key}/QUERY_ACTIVITY_LOGS_ACTION`;
