import { createRoutine } from "redux-saga-routines";

import * as Const from "./constants";

export const resetStoreFacilityStandardCodeAction = () => ({
  type: Const.RESET_STORE_FACILITY_STANDARD_CODE_ACTION,
});

export const setFieldValueStoreFacilityStandardCodeAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_FACILITY_STANDARD_CODE_ACTION,
  payload: { field, value },
});

export const queryFacilityCatalogAction = createRoutine(
  Const.QUERY_FACILITY_CATALOG_ACTION,
);
export const createFacilityCatalogAction = createRoutine(
  Const.CREATE_FACILITY_CATALOG_ACTION,
);
export const updateFacilityCatalogAction = createRoutine(
  Const.UPDATE_FACILITY_CATALOG_ACTION,
);
export const deleteFacilityCatalogAction = createRoutine(
  Const.DELETE_FACILITY_CATALOG_ACTION,
);
export const toggleFacilityCatalogStatusAction = createRoutine(
  Const.TOGGLE_FACILITY_CATALOG_STATUS_ACTION,
);
export const checkCodeChangeImpactAction = createRoutine(
  Const.CHECK_CODE_CHANGE_IMPACT_ACTION,
);

export const resetStoreAssetManagementAction = () => ({
  type: Const.RESET_STORE_ASSET_MANAGEMENT_ACTION,
});

export const setFieldValueStoreAssetManagementAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_ASSET_MANAGEMENT_ACTION,
  payload: { field, value },
});

export const queryAssetsAction = createRoutine(Const.QUERY_ASSETS_ACTION);
export const queryAssetFilterOptsAction = createRoutine(
  Const.QUERY_ASSET_FILTER_OPTS_ACTION,
);
export const getAssetDetailAction = createRoutine(Const.GET_ASSET_DETAIL_ACTION);
export const createAssetsAction = createRoutine(Const.CREATE_ASSETS_ACTION);
export const updateAssetAction = createRoutine(Const.UPDATE_ASSET_ACTION);
export const deleteAssetsAction = createRoutine(Const.DELETE_ASSETS_ACTION);
export const queryAssetIdsAction = createRoutine(Const.QUERY_ASSET_IDS_ACTION);
export const queryAssetHistoryAction = createRoutine(
  Const.QUERY_ASSET_HISTORY_ACTION,
);
export const exportAssetCodesAction = createRoutine(
  Const.EXPORT_ASSET_CODES_ACTION,
);
export const transferAssetsAction = createRoutine(Const.TRANSFER_ASSETS_ACTION);
export const proposeDisposeAssetsAction = createRoutine(
  Const.PROPOSE_DISPOSE_ASSETS_ACTION,
);

export const resetStoreRepairTicketAction = () => ({
  type: Const.RESET_STORE_REPAIR_TICKET_ACTION,
});

export const setFieldValueStoreRepairTicketAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_REPAIR_TICKET_ACTION,
  payload: { field, value },
});

export const queryRepairTicketsAction = createRoutine(
  Const.QUERY_REPAIR_TICKETS_ACTION,
);
export const queryRepairFilterOptsAction = createRoutine(
  Const.QUERY_REPAIR_FILTER_OPTS_ACTION,
);
export const queryRoomAssetsAction = createRoutine(
  Const.QUERY_ROOM_ASSETS_ACTION,
);
export const createRepairTicketAction = createRoutine(
  Const.CREATE_REPAIR_TICKET_ACTION,
);
export const updateRepairTicketAction = createRoutine(
  Const.UPDATE_REPAIR_TICKET_ACTION,
);
export const getRepairTicketDetailAction = createRoutine(
  Const.GET_REPAIR_TICKET_DETAIL_ACTION,
);
export const deleteRepairTicketAction = createRoutine(
  Const.DELETE_REPAIR_TICKET_ACTION,
);
export const decideRepairItemsAction = createRoutine(
  Const.DECIDE_REPAIR_ITEMS_ACTION,
);
export const resubmitRepairItemAction = createRoutine(
  Const.RESUBMIT_REPAIR_ITEM_ACTION,
);
export const updateExpectedDateAction = createRoutine(
  Const.UPDATE_EXPECTED_DATE_ACTION,
);
export const completeRepairItemAction = createRoutine(
  Const.COMPLETE_REPAIR_ITEM_ACTION,
);
export const uploadRepairFileAction = createRoutine(
  Const.UPLOAD_REPAIR_FILE_ACTION,
);
export const downloadRepairFileAction = createRoutine(
  Const.DOWNLOAD_REPAIR_FILE_ACTION,
);

export const resetStoreTransferAction = () => ({
  type: Const.RESET_STORE_TRANSFER_ACTION,
});

export const setFieldValueStoreTransferAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_TRANSFER_ACTION,
  payload: { field, value },
});

export const queryTransferOptsAction = createRoutine(
  Const.QUERY_TRANSFER_OPTS_ACTION,
);
export const queryTransferRoomAssetsAction = createRoutine(
  Const.QUERY_TRANSFER_ROOM_ASSETS_ACTION,
);
export const createTransferAction = createRoutine(Const.CREATE_TRANSFER_ACTION);

export const resetStoreDisposalRestoreAction = () => ({
  type: Const.RESET_STORE_DISPOSAL_RESTORE_ACTION,
});

export const setFieldValueStoreDisposalRestoreAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_DISPOSAL_RESTORE_ACTION,
  payload: { field, value },
});

export const queryProposalsAction = createRoutine(Const.QUERY_PROPOSALS_ACTION);
export const queryProposalOptsAction = createRoutine(
  Const.QUERY_PROPOSAL_OPTS_ACTION,
);
export const queryProposalAssetsAction = createRoutine(
  Const.QUERY_PROPOSAL_ASSETS_ACTION,
);
export const getProposalDetailAction = createRoutine(
  Const.GET_PROPOSAL_DETAIL_ACTION,
);
export const createProposalAction = createRoutine(Const.CREATE_PROPOSAL_ACTION);
export const submitProposalAction = createRoutine(Const.SUBMIT_PROPOSAL_ACTION);
export const decideProposalAction = createRoutine(Const.DECIDE_PROPOSAL_ACTION);
export const prefillRestoreFromDisposalAction = createRoutine(
  Const.PREFILL_RESTORE_FROM_DISPOSAL_ACTION,
);

export const resetStoreBorrowAction = () => ({
  type: Const.RESET_STORE_BORROW_ACTION,
});

export const setFieldValueStoreBorrowAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_BORROW_ACTION,
  payload: { field, value },
});

export const queryMyBorrowsAction = createRoutine(Const.QUERY_MY_BORROWS_ACTION);
export const queryBorrowOptsAction = createRoutine(
  Const.QUERY_BORROW_OPTS_ACTION,
);
export const queryBorrowAvailableAction = createRoutine(
  Const.QUERY_BORROW_AVAILABLE_ACTION,
);
export const createBorrowAction = createRoutine(Const.CREATE_BORROW_ACTION);
export const returnBorrowAction = createRoutine(Const.RETURN_BORROW_ACTION);

export const resetStoreActivityLogAction = () => ({
  type: Const.RESET_STORE_ACTIVITY_LOG_ACTION,
});

export const setFieldValueStoreActivityLogAction = (field, value) => ({
  type: Const.SET_FIELD_VALUE_STORE_ACTIVITY_LOG_ACTION,
  payload: { field, value },
});

export const queryActivityLogsAction = createRoutine(
  Const.QUERY_ACTIVITY_LOGS_ACTION,
);
