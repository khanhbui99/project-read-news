import { produce } from "immer";

import { getEmptyDetail } from "../helpers";
import * as actions from "./actions";
import activityLogReducer, {
  initialActivityLogState,
} from "./activityLogReducer";
import assetReducer, { initialAssetState } from "./assetReducer";
import borrowReducer, { initialBorrowState } from "./borrowReducer";
import {
  FACILITY_TABS,
  PAGE_SIZE,
  RESET_STORE_FACILITY_STANDARD_CODE_ACTION,
  SET_FIELD_VALUE_STORE_FACILITY_STANDARD_CODE_ACTION,
} from "./constants";
import disposalRestoreReducer, {
  initialDisposalRestoreState,
} from "./disposalRestoreReducer";
import repairReducer, {
  initialState as initialRepairState,
} from "./repairReducer";
import transferReducer, { initialTransferState } from "./transferReducer";

export const initialState = {
  activeTab: FACILITY_TABS.SUBJECTS,
  keyword: "",
  statusFilter: "ALL",
  assetGroupFilter: "ALL",
  page: 0,
  size: PAGE_SIZE,
  items: [],
  total: 0,
  loading: false,
  saving: false,

  isModalOpen: false,
  detail: getEmptyDetail(FACILITY_TABS.SUBJECTS),

  isDeleteOpen: false,
  deleteId: null,

  isCodeChangeConfirmOpen: false,
  codeChangeImpactCount: 0,
  pendingUpdate: null,

  // Dùng chung reducer Facility, namespace namespace để không xung đột field trang.
  asset: initialAssetState,
  repairTicket: initialRepairState,
  transfer: initialTransferState,
  disposalRestore: initialDisposalRestoreState,
  borrow: initialBorrowState,
  activityLog: initialActivityLogState,
};

const reducer = (state = initialState, action = {}) => {
  const { payload = {}, type } = action;

  return produce(state, (draft) => {
    draft.asset = assetReducer(state.asset, action);
    draft.repairTicket = repairReducer(state.repairTicket, action);
    draft.transfer = transferReducer(state.transfer, action);
    draft.disposalRestore = disposalRestoreReducer(
      state.disposalRestore,
      action,
    );
    draft.borrow = borrowReducer(state.borrow, action);
    draft.activityLog = activityLogReducer(state.activityLog, action);

    switch (type) {
      case RESET_STORE_FACILITY_STANDARD_CODE_ACTION: {
        return { ...initialState };
      }
      case SET_FIELD_VALUE_STORE_FACILITY_STANDARD_CODE_ACTION: {
        draft[payload.field] = payload.value;
        break;
      }

      case actions.queryFacilityCatalogAction.REQUEST: {
        draft.loading = true;
        break;
      }
      case actions.queryFacilityCatalogAction.SUCCESS: {
        draft.loading = false;
        draft.items = payload.items || [];
        draft.total = payload.total || 0;
        break;
      }
      case actions.queryFacilityCatalogAction.FAILURE: {
        draft.loading = false;
        draft.items = [];
        draft.total = 0;
        break;
      }

      case actions.createFacilityCatalogAction.REQUEST:
      case actions.updateFacilityCatalogAction.REQUEST:
      case actions.deleteFacilityCatalogAction.REQUEST:
      case actions.toggleFacilityCatalogStatusAction.REQUEST:
      case actions.checkCodeChangeImpactAction.REQUEST: {
        draft.saving = true;
        break;
      }
      case actions.createFacilityCatalogAction.SUCCESS:
      case actions.updateFacilityCatalogAction.SUCCESS: {
        draft.saving = false;
        draft.isModalOpen = false;
        draft.detail = getEmptyDetail(state.activeTab);
        draft.isCodeChangeConfirmOpen = false;
        draft.codeChangeImpactCount = 0;
        draft.pendingUpdate = null;
        break;
      }
      case actions.deleteFacilityCatalogAction.SUCCESS: {
        draft.saving = false;
        draft.isDeleteOpen = false;
        draft.deleteId = null;
        break;
      }
      case actions.toggleFacilityCatalogStatusAction.SUCCESS: {
        draft.saving = false;
        break;
      }
      case actions.checkCodeChangeImpactAction.SUCCESS: {
        if (payload?.pendingUpdate) {
          draft.saving = false;
          draft.isCodeChangeConfirmOpen = true;
          draft.codeChangeImpactCount = payload.count || 0;
          draft.pendingUpdate = payload.pendingUpdate;
        }
        break;
      }
      case actions.createFacilityCatalogAction.FAILURE:
      case actions.updateFacilityCatalogAction.FAILURE:
      case actions.deleteFacilityCatalogAction.FAILURE:
      case actions.toggleFacilityCatalogStatusAction.FAILURE:
      case actions.checkCodeChangeImpactAction.FAILURE: {
        draft.saving = false;
        break;
      }

      default:
        break;
    }
  });
};

export default reducer;
