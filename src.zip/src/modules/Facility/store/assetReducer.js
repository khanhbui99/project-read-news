import { produce } from "immer";

import { getEmptyCreateForm } from "../assetHelpers";
import * as actions from "./actions";
import {
  ASSET_TABS,
  DETAIL_TABS,
  PAGE_SIZE,
  RESET_STORE_ASSET_MANAGEMENT_ACTION,
  SET_FIELD_VALUE_STORE_ASSET_MANAGEMENT_ACTION,
} from "./constants";

export const initialAssetState = {
  activeTab: ASSET_TABS.FIXED,
  keyword: "",
  standardDeviceFilter: "ALL",
  roomFilter: "ALL",
  typeFilter: "ALL",
  subjectFilter: "ALL",
  conditionFilter: "ALL",
  statusFilter: "ALL",
  acquisitionFilter: "ALL",
  page: 0,
  size: PAGE_SIZE,
  items: [],
  total: 0,
  loading: false,
  saving: false,

  selectedIds: [],
  selectAllMatching: false,

  standardDeviceOpts: [],
  roomOpts: [],
  typeOpts: [],
  subjectOpts: [],

  isCreateOpen: false,
  createForm: getEmptyCreateForm(ASSET_TABS.FIXED),

  isDetailOpen: false,
  detailTab: DETAIL_TABS.INFO,
  detail: null,
  detailLoading: false,
  history: [],
  historyLoading: false,

  isDeleteOpen: false,
  isTransferOpen: false,
  isDisposeOpen: false,
  transferRoomId: "",
  transferNote: "",
  disposeReason: "",
  disposeNote: "",

  highlightId: null,
};

const assetReducer = (state = initialAssetState, action = {}) => {
  const { payload = {}, type } = action;

  return produce(state, (draft) => {
    switch (type) {
      case RESET_STORE_ASSET_MANAGEMENT_ACTION:
        return { ...initialAssetState };

      case SET_FIELD_VALUE_STORE_ASSET_MANAGEMENT_ACTION:
        draft[payload.field] = payload.value;
        break;

      case actions.queryAssetsAction.REQUEST:
        draft.loading = true;
        break;
      case actions.queryAssetsAction.SUCCESS:
        draft.loading = false;
        draft.items = payload.items || [];
        draft.total = payload.total || 0;
        break;
      case actions.queryAssetsAction.FAILURE:
        draft.loading = false;
        draft.items = [];
        draft.total = 0;
        break;

      case actions.queryAssetFilterOptsAction.SUCCESS:
        draft.standardDeviceOpts = payload.standardDeviceOpts || [];
        draft.roomOpts = payload.roomOpts || [];
        draft.typeOpts = payload.typeOpts || [];
        draft.subjectOpts = payload.subjectOpts || [];
        break;

      case actions.getAssetDetailAction.REQUEST:
        draft.detailLoading = true;
        break;
      case actions.getAssetDetailAction.SUCCESS:
        draft.detailLoading = false;
        draft.detail = payload;
        draft.isDetailOpen = true;
        break;
      case actions.getAssetDetailAction.FAILURE:
        draft.detailLoading = false;
        break;

      case actions.queryAssetHistoryAction.REQUEST:
        draft.historyLoading = true;
        break;
      case actions.queryAssetHistoryAction.SUCCESS:
        draft.historyLoading = false;
        draft.history = payload || [];
        break;
      case actions.queryAssetHistoryAction.FAILURE:
        draft.historyLoading = false;
        draft.history = [];
        break;

      case actions.createAssetsAction.REQUEST:
      case actions.updateAssetAction.REQUEST:
      case actions.deleteAssetsAction.REQUEST:
      case actions.transferAssetsAction.REQUEST:
      case actions.proposeDisposeAssetsAction.REQUEST:
      case actions.exportAssetCodesAction.REQUEST:
        draft.saving = true;
        break;

      case actions.createAssetsAction.SUCCESS: {
        draft.saving = false;
        draft.isCreateOpen = false;
        draft.createForm = getEmptyCreateForm(state.activeTab);
        draft.highlightId = payload?.firstId || null;
        draft.selectedIds = [];
        draft.selectAllMatching = false;
        break;
      }
      case actions.updateAssetAction.SUCCESS: {
        draft.saving = false;
        draft.highlightId = payload?.id || state.detail?.id || null;
        break;
      }
      case actions.deleteAssetsAction.SUCCESS:
      case actions.transferAssetsAction.SUCCESS:
      case actions.proposeDisposeAssetsAction.SUCCESS:
        draft.saving = false;
        draft.isDeleteOpen = false;
        draft.isTransferOpen = false;
        draft.isDisposeOpen = false;
        draft.selectedIds = [];
        draft.selectAllMatching = false;
        draft.transferRoomId = "";
        draft.transferNote = "";
        draft.disposeReason = "";
        draft.disposeNote = "";
        if (state.isDetailOpen) {
          draft.isDetailOpen = false;
          draft.detail = null;
        }
        break;

      case actions.exportAssetCodesAction.SUCCESS:
      case actions.exportAssetCodesAction.FAILURE:
        draft.saving = false;
        break;

      case actions.queryAssetIdsAction.SUCCESS:
        draft.selectedIds = payload.ids || [];
        draft.selectAllMatching = true;
        break;

      case actions.createAssetsAction.FAILURE:
      case actions.updateAssetAction.FAILURE:
      case actions.deleteAssetsAction.FAILURE:
      case actions.transferAssetsAction.FAILURE:
      case actions.proposeDisposeAssetsAction.FAILURE:
        draft.saving = false;
        break;

      default:
        break;
    }
  });
};

export default assetReducer;
