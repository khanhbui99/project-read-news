import { produce } from "immer";

import { getEmptyTransferForm } from "../transferHelpers";
import * as actions from "./actions";
import {
  RESET_STORE_TRANSFER_ACTION,
  SET_FIELD_VALUE_STORE_TRANSFER_ACTION,
} from "./constants";

export const initialTransferState = {
  form: getEmptyTransferForm(),
  keyword: "",
  standardDeviceFilter: "ALL",
  subjectFilter: "ALL",
  typeFilter: "ALL",
  page: 0,
  size: 10,

  roomOpts: [],
  standardDeviceOpts: [],
  subjectOpts: [],
  typeOpts: [],

  items: [],
  selectedIds: [],
  loadingOpts: false,
  loadingAssets: false,
  saving: false,
};

const transferReducer = (state = initialTransferState, action = {}) => {
  const { payload = {}, type } = action;

  return produce(state, (draft) => {
    switch (type) {
      case RESET_STORE_TRANSFER_ACTION:
        return { ...initialTransferState };

      case SET_FIELD_VALUE_STORE_TRANSFER_ACTION:
        draft[payload.field] = payload.value;
        break;

      case actions.queryTransferOptsAction.REQUEST:
        draft.loadingOpts = true;
        break;
      case actions.queryTransferOptsAction.SUCCESS:
        draft.loadingOpts = false;
        draft.roomOpts = payload.roomOpts || [];
        draft.standardDeviceOpts = payload.standardDeviceOpts || [];
        draft.subjectOpts = payload.subjectOpts || [];
        draft.typeOpts = payload.typeOpts || [];
        break;
      case actions.queryTransferOptsAction.FAILURE:
        draft.loadingOpts = false;
        break;

      case actions.queryTransferRoomAssetsAction.REQUEST:
        draft.loadingAssets = true;
        break;
      case actions.queryTransferRoomAssetsAction.SUCCESS:
        draft.loadingAssets = false;
        draft.items = payload.items || [];
        draft.selectedIds = [];
        draft.page = 0;
        break;
      case actions.queryTransferRoomAssetsAction.FAILURE:
        draft.loadingAssets = false;
        draft.items = [];
        draft.page = 0;
        break;

      case actions.createTransferAction.REQUEST:
        draft.saving = true;
        break;
      case actions.createTransferAction.SUCCESS:
        draft.saving = false;
        draft.form = getEmptyTransferForm();
        draft.keyword = "";
        draft.standardDeviceFilter = "ALL";
        draft.subjectFilter = "ALL";
        draft.typeFilter = "ALL";
        draft.page = 0;
        draft.items = [];
        draft.selectedIds = [];
        break;
      case actions.createTransferAction.FAILURE:
        draft.saving = false;
        break;

      default:
        break;
    }
  });
};

export default transferReducer;
