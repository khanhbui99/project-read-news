import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  min-height: calc(100vh - 140px);
  margin-top: 16px;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 20px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
`;

export const PageDesc = styled.p`
  margin: 0;
  font-size: 14px;
  line-height: 1.5;
  color: ${VPB_THEMES.colors.textLight};
`;
