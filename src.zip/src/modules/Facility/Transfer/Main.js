import AppHeader from "components/common/AppHeader";
import { useEffect } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import { DrawerTransfer } from "../components";
import {
  createTransferAction,
  queryTransferOptsAction,
  queryTransferRoomAssetsAction,
  resetStoreTransferAction,
  setFieldValueStoreTransferAction,
} from "../store/actions";
import { key } from "../store/constants";
import { getEmptyTransferForm } from "../transferHelpers";
import { CardPanel, PageDesc, PageWrap } from "./Styled";

const TransferMain = () => {
  const transferState = useOneState(key, "transfer") || {};
  const {
    form = getEmptyTransferForm(),
    keyword = "",
    standardDeviceFilter = "ALL",
    subjectFilter = "ALL",
    typeFilter = "ALL",
    page = 0,
    size = 10,
    roomOpts = [],
    standardDeviceOpts = [],
    subjectOpts = [],
    typeOpts = [],
    items = [],
    selectedIds = [],
    loadingAssets = false,
    saving = false,
  } = transferState;

  const setField = useDispatchRedux(setFieldValueStoreTransferAction);
  const fetchOpts = useDispatchRedux(queryTransferOptsAction);
  const fetchRoomAssets = useDispatchRedux(queryTransferRoomAssetsAction);
  const createTransfer = useDispatchRedux(createTransferAction);
  const resetStore = useDispatchRedux(resetStoreTransferAction);

  useEffect(() => {
    fetchOpts();
    return () => resetStore();
  }, []);

  const handleReset = () => {
    setField("form", getEmptyTransferForm());
    setField("keyword", "");
    setField("standardDeviceFilter", "ALL");
    setField("subjectFilter", "ALL");
    setField("typeFilter", "ALL");
    setField("page", 0);
    setField("items", []);
    setField("selectedIds", []);
  };

  const handleFormChange = (field, value) => {
    setField("form", { ...form, [field]: value });
  };

  const handleSourceRoomChange = (roomId) => {
    setField("selectedIds", []);
    setField("keyword", "");
    setField("standardDeviceFilter", "ALL");
    setField("subjectFilter", "ALL");
    setField("typeFilter", "ALL");
    setField("page", 0);
    if (roomId) {
      fetchRoomAssets({ roomId });
    } else {
      setField("items", []);
    }
  };

  const handleSearch = (next) => {
    setField("keyword", next);
    setField("page", 0);
  };

  const handleFilterChange = (field, value) => {
    setField(field, value);
    setField("page", 0);
  };

  const handlePageSizeChange = (nextSize) => {
    setField("size", nextSize);
    setField("page", 0);
  };

  const handleToggleRow = (id) => {
    if (selectedIds.includes(id)) {
      setField(
        "selectedIds",
        selectedIds.filter((x) => x !== id),
      );
    } else {
      setField("selectedIds", [...selectedIds, id]);
    }
  };

  const handleTogglePage = (checked, rows = []) => {
    const selectableIds = rows
      .filter((r) => r.transferable)
      .map((r) => r.id)
      .filter(Boolean);
    if (checked) {
      setField("selectedIds", [...new Set([...selectedIds, ...selectableIds])]);
    } else {
      setField(
        "selectedIds",
        selectedIds.filter((id) => !selectableIds.includes(id)),
      );
    }
  };

  const handleRemoveSelected = (id) => {
    setField(
      "selectedIds",
      selectedIds.filter((x) => x !== id),
    );
  };

  return (
    <>
      <AppHeader
        componentName="FacilityTransfer"
        pageTitle="Điều chuyển tài sản"
        isHiddenBtn
      />

      <PageWrap>
        <CardPanel>
          <PageDesc>
            Điều chuyển một hoặc nhiều đơn vị tài sản từ phòng nguồn sang phòng
            đích. Không cần phê duyệt — cập nhật ngay sau khi xác nhận.
          </PageDesc>
          <DrawerTransfer
            form={form}
            keyword={keyword}
            standardDeviceFilter={standardDeviceFilter}
            subjectFilter={subjectFilter}
            typeFilter={typeFilter}
            page={page}
            size={size}
            roomOpts={roomOpts}
            standardDeviceOpts={standardDeviceOpts}
            subjectOpts={subjectOpts}
            typeOpts={typeOpts}
            items={items}
            selectedIds={selectedIds}
            loadingAssets={loadingAssets}
            saving={saving}
            onReset={handleReset}
            onFormChange={handleFormChange}
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
            onSourceRoomChange={handleSourceRoomChange}
            onToggleRow={handleToggleRow}
            onTogglePage={handleTogglePage}
            onRemoveSelected={handleRemoveSelected}
            onPageChange={(nextPage) => setField("page", nextPage)}
            onPageSizeChange={handlePageSizeChange}
            onSubmit={createTransfer}
          />
        </CardPanel>
      </PageWrap>
    </>
  );
};

export default TransferMain;
