import AppHeader from "components/common/AppHeader";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import {
  FacilityDataTable,
  FacilityTabs,
  FacilityToolbar,
  ModalConfirm,
  ModalDelete,
  ModalRoomType,
  ModalStandardDevice,
  ModalSubject,
  ModalType,
} from "../components";
import {
  getEmptyDetail,
  filterCatalogLocal,
  getTabConfig,
  isCodeChanged,
  isDeviceTab,
} from "../helpers";
import {
  checkCodeChangeImpactAction,
  createFacilityCatalogAction,
  deleteFacilityCatalogAction,
  queryFacilityCatalogAction,
  resetStoreFacilityStandardCodeAction,
  setFieldValueStoreFacilityStandardCodeAction,
  toggleFacilityCatalogStatusAction,
  updateFacilityCatalogAction,
} from "../store/actions";
import {
  FACILITY_TAB_LIST,
  FACILITY_TABS,
  key,
  PAGE_SIZE,
} from "../store/constants";
import { CardPanel, PageWrap, TabsCard } from "./Styled";

const StandardCodeMain = () => {
  const activeTab = useOneState(key, "activeTab", FACILITY_TABS.SUBJECTS);
  const keyword = useOneState(key, "keyword", "");
  const statusFilter = useOneState(key, "statusFilter", "ALL");
  const assetGroupFilter = useOneState(key, "assetGroupFilter", "ALL");
  const page = useOneState(key, "page", 0);
  const size = useOneState(key, "size", PAGE_SIZE);
  const items = useOneState(key, "items", []);
  const loading = useOneState(key, "loading", false);
  const saving = useOneState(key, "saving", false);
  const isModalOpen = useOneState(key, "isModalOpen", false);
  const detail = useOneState(key, "detail", getEmptyDetail(activeTab));
  const isDeleteOpen = useOneState(key, "isDeleteOpen", false);
  const deleteId = useOneState(key, "deleteId", null);
  const isCodeChangeConfirmOpen = useOneState(
    key,
    "isCodeChangeConfirmOpen",
    false,
  );
  const codeChangeImpactCount = useOneState(key, "codeChangeImpactCount", 0);
  const pendingUpdate = useOneState(key, "pendingUpdate", null);

  const setField = useDispatchRedux(
    setFieldValueStoreFacilityStandardCodeAction,
  );
  const fetchList = useDispatchRedux(queryFacilityCatalogAction);
  const createItem = useDispatchRedux(createFacilityCatalogAction);
  const updateItem = useDispatchRedux(updateFacilityCatalogAction);
  const deleteItem = useDispatchRedux(deleteFacilityCatalogAction);
  const toggleStatus = useDispatchRedux(toggleFacilityCatalogStatusAction);
  const checkCodeImpact = useDispatchRedux(checkCodeChangeImpactAction);
  const resetStore = useDispatchRedux(resetStoreFacilityStandardCodeAction);

  const tabConfig = useMemo(() => getTabConfig(activeTab), [activeTab]);
  const deviceTab = isDeviceTab(activeTab);
  const canManage = true;

  useEffect(() => {
    return () => resetStore();
  }, []);

  useEffect(() => {
    fetchList({ tab: activeTab });
  }, [activeTab]);

  const filteredItems = useMemo(
    () =>
      filterCatalogLocal(items, {
        keyword,
        statusFilter,
        assetGroupFilter,
        isDevice: deviceTab,
      }),
    [items, keyword, statusFilter, assetGroupFilter, deviceTab],
  );

  const columns = useMemo(() => {
    const nameLabel = deviceTab ? "Tên thiết bị" : tabConfig.nameLabel;

    const cols = [
      { name: "STT", field: "stt", width: 64, align: "center" },
    ];

    if (deviceTab) {
      cols.push({ name: "Mã gốc", field: "code", width: 120 });
    }

    cols.push({ name: nameLabel, field: "name", width: 200 });

    if (deviceTab) {
      cols.push(
        { name: "Nhóm tài sản", field: "assetGroupName", width: 160 },
        { name: "Đơn vị", field: "unit", width: 120 },
      );
    } else {
      cols.push({ name: "Mô tả", field: "note", width: 180 });
    }

    cols.push({
      name: "SL tài sản đang sử dụng",
      field: "itemCount",
      width: 170,
      render:(val, row) => val || row?.unitCount || 0,
    });

    if (deviceTab) {
      cols.push({ name: "Trạng thái", field: "status", width: 150 });
    }

    cols.push({
      name: "Thao tác",
      field: "actions",
      width: deviceTab ? 140 : 100,
      align: "center",
    });

    return cols;
  }, [deviceTab, tabConfig]);

  const handleTabChange = (nextTab) => {
    if (nextTab === activeTab) return;
    setField("activeTab", nextTab);
    setField("page", 0);
    setField("statusFilter", "ALL");
    setField("assetGroupFilter", "ALL");
    setField("detail", getEmptyDetail(nextTab));
  };

  const handleSearch = (nextKeyword) => {
    setField("keyword", nextKeyword);
    setField("page", 0);
  };

  const handleStatusFilter = (nextStatus) => {
    setField("statusFilter", nextStatus);
    setField("page", 0);
  };

  const handleAssetGroupFilter = (nextGroup) => {
    setField("assetGroupFilter", nextGroup);
    setField("page", 0);
  };

  const handleOpenCreate = () => {
    setField("detail", getEmptyDetail(activeTab));
    setField("isModalOpen", true);
  };

  const handleOpenEdit = (row) => {
    const base = {
      id: row.id,
      name: row.name || "",
      description: row.description || row.note || "",
      status: row.status,
    };

    setField(
      "detail",
      deviceTab
        ? {
            id: row.id,
            code: row.code || "",
            name: row.name || "",
            unit: row.unit || "",
            assetGroup: row.assetGroup || "",
            status: row.status,
          }
        : base,
    );
    setField("isModalOpen", true);
  };

  const handleCloseModal = () => {
    setField("isModalOpen", false);
    setField("detail", getEmptyDetail(activeTab));
  };

  const handleSubmit = (values) => {
    const payload = {
      ...values,
      tab: activeTab,
    };

    if (values?.id) {
      if (deviceTab && isCodeChanged(values, detail)) {
        checkCodeImpact(payload);
        return;
      }
      updateItem(payload);
      return;
    }

    createItem(payload);
  };

  const handleCloseCodeChangeConfirm = () => {
    setField("isCodeChangeConfirmOpen", false);
    setField("codeChangeImpactCount", 0);
    setField("pendingUpdate", null);
  };

  const handleConfirmCodeChange = () => {
    if (!pendingUpdate) return;
    updateItem(pendingUpdate);
  };

  const handleOpenDelete = (row) => {
    setField("deleteId", row.id);
    setField("isDeleteOpen", true);
  };

  const handleCloseDelete = () => {
    setField("isDeleteOpen", false);
    setField("deleteId", null);
  };

  const handleConfirmDelete = () => {
    if (!deleteId) return;
    deleteItem({ id: deleteId, tab: activeTab });
  };

  const handleHide = (row) => {
    if (!deviceTab) return;
    toggleStatus({
      id: row.id,
      tab: activeTab,
      status: row.status,
    });
  };

  const modalTitle = detail?.id ? tabConfig.editTitle : tabConfig.createTitle;
  const sharedModalProps = {
    open: isModalOpen,
    title: modalTitle,
    nameLabel: tabConfig.nameLabel,
    namePlaceholder: tabConfig.namePlaceholder,
    initialValues: detail,
    tabKey: activeTab,
    saving,
    onClose: handleCloseModal,
    onSubmit: handleSubmit,
    ...(deviceTab
      ? {
          codeLabel: tabConfig.codeLabel,
          codePlaceholder: tabConfig.codePlaceholder,
        }
      : {}),
  };

  const renderCreateUpdateModal = () => {
    switch (activeTab) {
      case FACILITY_TABS.TYPES:
        return <ModalType {...sharedModalProps} />;
      case FACILITY_TABS.STANDARD_DEVICES:
        return <ModalStandardDevice {...sharedModalProps} />;
      case FACILITY_TABS.ROOM_TYPES:
        return <ModalRoomType {...sharedModalProps} />;
      case FACILITY_TABS.SUBJECTS:
      default:
        return <ModalSubject {...sharedModalProps} />;
    }
  };

  return (
    <>
      <AppHeader
        componentName="FacilityStandardCode"
        pageTitle="Danh mục chuẩn & mã"
        isHiddenBtn
      />

      <PageWrap>
        <TabsCard>
          <FacilityTabs
            tabs={FACILITY_TAB_LIST}
            activeTab={activeTab}
            onChange={handleTabChange}
          />
        </TabsCard>

        <CardPanel>
          <FacilityToolbar
            keyword={keyword}
            statusFilter={statusFilter}
            assetGroupFilter={assetGroupFilter}
            placeholder={tabConfig.searchPlaceholder}
            onSearch={handleSearch}
            onStatusChange={handleStatusFilter}
            onAssetGroupChange={handleAssetGroupFilter}
            onAdd={handleOpenCreate}
            canAdd={canManage}
            showStatusFilter={deviceTab}
            showAssetGroupFilter={deviceTab}
            loading={loading}
          />

          <FacilityDataTable
            columns={columns}
            rows={filteredItems}
            loading={loading}
            page={page}
            size={size}
            onPageChange={(nextPage) => setField("page", nextPage)}
            onPageSizeChange={(nextSize) => {
              setField("size", nextSize);
              setField("page", 0);
            }}
            onEdit={handleOpenEdit}
            onHide={handleHide}
            onDelete={handleOpenDelete}
            onAdd={handleOpenCreate}
            onAssetClick={() => {}}
            canManage={canManage}
            showHide={deviceTab}
            emptyText={tabConfig.emptyText}
          />
        </CardPanel>
      </PageWrap>

      {renderCreateUpdateModal()}

      <ModalDelete
        open={isDeleteOpen}
        title={tabConfig.deleteTitle}
        saving={saving}
        onClose={handleCloseDelete}
        onConfirm={handleConfirmDelete}
      />

      <ModalConfirm
        open={isCodeChangeConfirmOpen}
        title="Xác nhận đổi mã"
        message={`Có ${codeChangeImpactCount} đơn vị sẽ bị đổi mã. Bạn có chắc chắn muốn tiếp tục?`}
        confirmText="Đổi mã"
        saving={saving}
        onClose={handleCloseCodeChangeConfirm}
        onConfirm={handleConfirmCodeChange}
      />
    </>
  );
};

export default StandardCodeMain;
