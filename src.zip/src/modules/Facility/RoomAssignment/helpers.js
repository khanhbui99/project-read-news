import dayjs from "dayjs";
import { DateFormat4 } from "utils/constants";

import { ROOM_STATUS, ROOM_STATUS_MAP } from "./store/constants";

export const getEmptyRoomForm = () => ({
  id: 0,
  code: "",
  name: "",
  roomTypeId: "",
  area: "",
  status: ROOM_STATUS.ACTIVE,
  note: "",
});

export const getManagerRefs = (item = {}) => {
  const refs =
    item.managers ||
    item.roomManagers ||
    item.managerList ||
    item.managerUsers ||
    item.users ||
    item.teacherIds ||
    [];
  return Array.isArray(refs) ? refs : [];
};

export const getAssetRefs = (item = {}) => {
  const refs =
    item.assets ||
    item.roomAssets ||
    item.assetList ||
    item.devices ||
    item.items ||
    [];
  return Array.isArray(refs) ? refs : [];
};

export const getAssetGroups = (item = {}) => {
  const refs = item.assetGroups || [];
  return Array.isArray(refs) ? refs : [];
};

export const getRefId = (ref) => {
  if (ref == null) return "";
  if (typeof ref !== "object") return String(ref);
  return String(
    ref.accountId || ref.userId || ref.teacherId || ref.id || "",
  );
};

export const mapRoomItem = (item = {}) => {
  const updatedAt =
    item.updatedAt || item.updatedDate || item.modifiedAt || item.createdAt;
  const createdAt = item.createdAt || item.createdDate;
  const status = item.status || ROOM_STATUS.ACTIVE;
  const managers = getManagerRefs(item);
  const assets = getAssetRefs(item);
  const assetGroups = getAssetGroups(item);
  const area = item.area ?? item.acreage ?? item.square ?? null;
  const groupSumCount = assetGroups.reduce(
    (sum, a) => sum + (Number(a?.count) || 0),
    0,
  );
  const assetsSumCount = assets.reduce((sum, a) => {
    if (a && typeof a === "object" && a.count != null) {
      return sum + (Number(a.count) || 0);
    }
    return sum + 1;
  }, 0);
  const assetCount =
    item.assetCount ??
    item.totalAssets ??
    item.assetsCount ??
    item.totalAsset ??
    (groupSumCount || assetsSumCount);
  const managerCount =
    item.managerCount ?? item.managersCount ?? managers.length;

  return {
    ...item,
    code: item.code || item.roomCode || "",
    name: item.name || item.roomName || "",
    roomTypeId:
      item.roomTypeId || item.roomType?.id || item.type?.id || item.typeId || "",
    roomTypeName:
      item.roomTypeName ||
      item.roomType?.name ||
      item.type?.name ||
      item.typeName ||
      "--",
    area,
    areaDisplay: area != null && area !== "" ? `${area}` : "--",
    status,
    statusName: ROOM_STATUS_MAP[status] || status,
    note: item.note || item.description || item.remark || "",
    managerCount,
    assetCount,
    managers,
    assets,
    assetGroups,
    managerIds: managers.map((m) => getRefId(m)).filter(Boolean),
    updatedAtFormat: updatedAt ? dayjs(updatedAt).format(DateFormat4) : "--",
    createdAtFormat: createdAt ? dayjs(createdAt).format(DateFormat4) : "--",
    canDelete: !(assetCount > 0),
  };
};

// Detail API trả { room: {...}, managers: [...], assetGroups: [...] }
export const mapRoomDetail = (data = {}) => {
  const room = data?.room || data || {};
  return mapRoomItem({
    ...room,
    managers: getManagerRefs(data).length
      ? getManagerRefs(data)
      : getManagerRefs(room),
    assets: getAssetRefs(data).length ? getAssetRefs(data) : getAssetRefs(room),
    assetGroups: getAssetGroups(data).length
      ? getAssetGroups(data)
      : getAssetGroups(room),
  });
};

export const mapTeacherToManager = (teacher = {}) => {
  const accountId = getRefId(teacher);
  return {
    ...teacher,
    id: accountId,
    userId: accountId,
    accountId,
    name:
      teacher.fullName ||
      teacher.name ||
      teacher.userFullName ||
      teacher.userName ||
      teacher.displayName ||
      "--",
    email:
      teacher.email || teacher.mail || teacher.userEmail || teacher.code || "",
    title:
      teacher.title ||
      teacher.position ||
      teacher.positionName ||
      teacher.roleName ||
      "Giáo viên",
    unit:
      teacher.unit ||
      teacher.departmentName ||
      teacher.department ||
      teacher.orgName ||
      teacher.facultyName ||
      teacher.schoolName ||
      "--",
    avatar: teacher.avatar || teacher.avatarUrl || teacher.imageUrl || "",
  };
};

export const resolveManagersFromTeachers = (
  managerRefs = [],
  teachers = [],
) => {
  const teacherMap = teachers.reduce((acc, t) => {
    const id = getRefId(t);
    if (id) acc[id] = t;
    return acc;
  }, {});

  return (managerRefs || [])
    .map((ref) => {
      const id = getRefId(ref);
      if (!id && !(ref && typeof ref === "object")) return null;

      // managers từ detail đã có name → ưu tiên hiển thị luôn
      if (ref && typeof ref === "object") {
        const hasName = !!(
          ref.fullName ||
          ref.name ||
          ref.userFullName ||
          ref.displayName
        );
        const teacher = teacherMap[id];
        if (hasName) {
          return mapTeacherToManager({ ...teacher, ...ref });
        }
        if (teacher) return mapTeacherToManager({ ...teacher, ...ref });
        return mapTeacherToManager(ref);
      }

      const teacher = teacherMap[id];
      return mapTeacherToManager(teacher || { accountId: id, id });
    })
    .filter((m) => m?.accountId || m?.userId);
};

const mapAssetSummary = (item = {}, index = 0) => {
  const subjectName = item.subjectName || null;
  const typeName = item.typeName || null;
  const count = Number(item.count ?? item.quantity ?? 0) || 0;

  return {
    ...item,
    id: item.id || `${typeName || ""}-${subjectName || ""}-${index}`,
    subjectName,
    typeName,
    count,
  };
};

/** detail.assetGroups: [{ subjectName, typeName, count }] */
export const mapAssetsFromDetail = (detail = {}) => {
  const groups = getAssetGroups(detail);
  if (!groups.length) return [];
  return groups.map(mapAssetSummary);
};

export const mapManagersFromDetail = (detail = {}, teachers = []) => {
  const refs = getManagerRefs(detail);
  if (!refs.length) return [];
  return resolveManagersFromTeachers(refs, teachers);
};

export const getManagerAccountIds = (managers = []) =>
  (managers || []).map((m) => getRefId(m)).filter(Boolean);

export const isManagersUnchanged = (current = [], original = []) => {
  const a = getManagerAccountIds(current).map(String).sort();
  const b = getManagerAccountIds(original).map(String).sort();
  if (a.length !== b.length) return false;
  return a.every((id, idx) => id === b[idx]);
};

export const buildRoomPayload = (values = {}) => ({
  code: (values.code || "").trim().toUpperCase(),
  name: (values.name || "").trim(),
  roomTypeId: Number(values.roomTypeId),
  area:
    values.area === "" || values.area == null ? null : Number(values.area),
  status: values.status || ROOM_STATUS.ACTIVE,
  note: (values.note || "").trim(),
});

export const isRoomFormUnchanged = (values = {}, detail = {}) => {
  const same =
    (values.code || "").trim().toUpperCase() ===
      (detail.code || "").trim().toUpperCase() &&
    (values.name || "").trim() === (detail.name || "").trim() &&
    String(values.roomTypeId || "") === String(detail.roomTypeId || "") &&
    String(values.area ?? "") === String(detail.area ?? "") &&
    (values.status || "") === (detail.status || "") &&
    (values.note || "").trim() === (detail.note || "").trim();
  return same;
};

export const mapRoomTypeOpt = (item = {}) => ({
  value: item.id,
  label: item.name || item.code || `--`,
  ...item,
});

export const LIST_FETCH_SIZE = 10000;

export const filterRoomsLocal = (
  items = [],
  { keyword = "", roomTypeFilter = "ALL", statusFilter = "ALL" } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.code || ""} ${item.name || ""} ${item.roomTypeName || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (
      roomTypeFilter &&
      roomTypeFilter !== "ALL" &&
      String(item.roomTypeId) !== String(roomTypeFilter)
    ) {
      return false;
    }
    if (statusFilter && statusFilter !== "ALL" && item.status !== statusFilter) {
      return false;
    }
    return true;
  });
};

export const paginateLocal = (items = [], page = 0, size = 10) => {
  const start = Number(page) * Number(size);
  return items.slice(start, start + Number(size));
};
