import styled, { keyframes } from "styled-components";
import { VPB_THEMES } from "utils/configs";

const highlightFlash = keyframes`
  0%, 100% { background: transparent; }
  20%, 80% { background: ${VPB_THEMES.colors.f0f9ff}; }
`;

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: calc(100vh - 140px);
  margin-top: 8px;
`;

export const PageDesc = styled.p`
  margin: -4px 0 0;
  font-size: 15px;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  min-height: 0;
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: hidden;
`;

export const StatusBadge = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  line-height: 1.4;
  white-space: nowrap;
  background: ${({ $status }) => {
    if ($status === "MAINTENANCE") return VPB_THEMES.colors.statusMaintenanceBg;
    if ($status === "INACTIVE") return VPB_THEMES.colors.statusInactiveBg;
    return VPB_THEMES.colors.statusActiveBg;
  }};
  color: ${({ $status }) => {
    if ($status === "MAINTENANCE")
      return VPB_THEMES.colors.statusMaintenanceText;
    if ($status === "INACTIVE") return VPB_THEMES.colors.statusInactiveText;
    return VPB_THEMES.colors.statusActiveText;
  }};

  &::before {
    content: "";
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: ${({ $status }) => {
      if ($status === "MAINTENANCE")
        return VPB_THEMES.colors.statusMaintenanceDot;
      if ($status === "INACTIVE") return VPB_THEMES.colors.statusInactiveDot;
      return VPB_THEMES.colors.statusActiveDot;
    }};
  }
`;

export const HighlightRow = styled.tr`
  animation: ${highlightFlash} 2s ease;
`;

export const DrawerBox = styled.div`
  width: ${({ $width }) => $width || 620}px;
  max-width: 100vw;
  height: 100%;
  display: flex;
  flex-direction: column;
  font-family: SVN_Gilroy !important;

  .MuiDialogContent-root {
    padding: 0 20px 16px;
    flex: 1;
    overflow: auto;
  }
`;

export const PanelBox = styled.div`
  width: ${({ $width }) => $width || 680}px;
  max-width: 100vw;
  height: 100%;
  display: flex;
  flex-direction: column;
  font-family: SVN_Gilroy !important;
`;
