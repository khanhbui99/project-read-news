import { getAllTeachersAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import { ModalDelete } from "../components";
import {
  DetailPanel,
  DrawerAssignManagers,
  DrawerRoomForm,
  ModalConfirm,
  RoomDataTable,
  RoomToolbar,
} from "./components";
import {
  filterRoomsLocal,
  getEmptyRoomForm,
  getManagerAccountIds,
  isManagersUnchanged,
  paginateLocal,
} from "./helpers";
import {
  createRoomAction,
  deleteRoomAction,
  getRoomDetailAction,
  queryRoomTypesAction,
  queryRoomsAction,
  resetStoreRoomAssignmentAction,
  setFieldValueStoreRoomAssignmentAction,
  updateRoomAction,
} from "./store/actions";
import { DETAIL_TABS, PAGE_SIZE, key } from "./store/constants";
import { CardPanel, PageDesc, PageWrap } from "./Styled";

const RoomAssignmentMain = () => {
  const keyword = useOneState(key, "keyword", "");
  const roomTypeFilter = useOneState(key, "roomTypeFilter", "ALL");
  const statusFilter = useOneState(key, "statusFilter", "ALL");
  const page = useOneState(key, "page", 0);
  const size = useOneState(key, "size", PAGE_SIZE);
  const items = useOneState(key, "items", []);
  const loading = useOneState(key, "loading", false);
  const saving = useOneState(key, "saving", false);
  const roomTypeOpts = useOneState(key, "roomTypeOpts", []);

  const isDetailOpen = useOneState(key, "isDetailOpen", false);
  const detailTab = useOneState(key, "detailTab", DETAIL_TABS.INFO);
  const detail = useOneState(key, "detail", null);
  const detailLoading = useOneState(key, "detailLoading", false);
  const managers = useOneState(key, "managers", []);
  const managersOriginal = useOneState(key, "managersOriginal", []);
  const managersLoading = useOneState(key, "managersLoading", false);
  const assetGroups = useOneState(key, "assetGroups", []);
  const assetsLoading = useOneState(key, "assetsLoading", false);

  const isFormOpen = useOneState(key, "isFormOpen", false);
  const formDetail = useOneState(key, "formDetail", getEmptyRoomForm());

  const isAssignOpen = useOneState(key, "isAssignOpen", false);
  const isDeleteOpen = useOneState(key, "isDeleteOpen", false);
  const deleteId = useOneState(key, "deleteId", null);
  const isRemoveManagerOpen = useOneState(key, "isRemoveManagerOpen", false);
  const removeManagerId = useOneState(key, "removeManagerId", null);
  const isDiscardOpen = useOneState(key, "isDiscardOpen", false);
  const highlightId = useOneState(key, "highlightId", null);

  const setField = useDispatchRedux(setFieldValueStoreRoomAssignmentAction);
  const fetchRooms = useDispatchRedux(queryRoomsAction);
  const fetchRoomTypes = useDispatchRedux(queryRoomTypesAction);
  const getDetail = useDispatchRedux(getRoomDetailAction);
  const createRoom = useDispatchRedux(createRoomAction);
  const updateRoom = useDispatchRedux(updateRoomAction);
  const deleteRoom = useDispatchRedux(deleteRoomAction);
  const resetStore = useDispatchRedux(resetStoreRoomAssignmentAction);
  const fetchTeachers = useDispatchRedux(getAllTeachersAction);
  const teachersOpt = useOneState(injectKey.GLOBAL, "teachersOpt", []);

  useEffect(() => {
    fetchRoomTypes();
    fetchRooms();
    if (!teachersOpt?.length) fetchTeachers();
    return () => resetStore();
  }, []);

  useEffect(() => {
    if (!highlightId) return undefined;
    const timer = setTimeout(() => setField("highlightId", null), 2000);
    return () => clearTimeout(timer);
  }, [highlightId]);

  const filteredItems = useMemo(
    () =>
      filterRoomsLocal(items, {
        keyword,
        roomTypeFilter,
        statusFilter,
      }),
    [items, keyword, roomTypeFilter, statusFilter],
  );

  const pagedRows = useMemo(
    () => paginateLocal(filteredItems, page, size),
    [filteredItems, page, size],
  );

  const handleSearch = (nextKeyword) => {
    setField("keyword", nextKeyword);
    setField("page", 0);
  };

  const handleRoomTypeFilter = (next) => {
    setField("roomTypeFilter", next);
    setField("page", 0);
  };

  const handleStatusFilter = (next) => {
    setField("statusFilter", next);
    setField("page", 0);
  };

  const handlePageChange = (nextPage) => {
    setField("page", nextPage);
  };

  const handlePageSizeChange = (nextSize) => {
    setField("size", nextSize);
    setField("page", 0);
  };

  const openCreate = () => {
    setField("formDetail", getEmptyRoomForm());
    setField("isFormOpen", true);
  };

  const openEdit = (row) => {
    if (!row?.id) return;
    setField("detailTab", DETAIL_TABS.INFO);
    getDetail({ id: row.id });
  };

  const closeDetail = () => {
    setField("isDetailOpen", false);
    setField("detail", null);
    setField("managers", []);
    setField("managersOriginal", []);
    setField("assetGroups", []);
    setField("isAssignOpen", false);
  };

  const closeForm = () => {
    setField("isFormOpen", false);
    setField("formDetail", getEmptyRoomForm());
    setField("isDiscardOpen", false);
  };

  const handleCreateSubmit = (values) => {
    createRoom(values);
  };

  const handleDetailSubmit = (values) => {
    updateRoom({
      ...values,
      managerIds: getManagerAccountIds(managers),
      originalManagerIds: getManagerAccountIds(managersOriginal),
    });
  };

  const openAssign = () => {
    if (!detail?.id) return;
    setField("isAssignOpen", true);
  };

  const handleAssignSave = (nextManagers = []) => {
    setField("managers", nextManagers);
    setField("isAssignOpen", false);
  };

  const openDelete = (row) => {
    setField("deleteId", row.id);
    setField("isDeleteOpen", true);
  };

  const handleRemoveManagerRequest = (manager) => {
    setField("removeManagerId", manager.accountId || manager.userId || manager.id);
    setField("isRemoveManagerOpen", true);
  };

  const handleConfirmRemoveManager = () => {
    if (!removeManagerId) return;
    const next = managers.filter(
      (m) =>
        String(m.accountId || m.userId || m.id) !== String(removeManagerId),
    );
    setField("managers", next);
    setField("isRemoveManagerOpen", false);
    setField("removeManagerId", null);
  };

  const managersDirty = !isManagersUnchanged(managers, managersOriginal);

  return (
    <>
      <AppHeader
        componentName="FacilityRoomAssignment"
        pageTitle="Phòng & gán người phụ trách"
        isHiddenBtn
      />
      <PageDesc>
        Quản lý thông tin phòng, người phụ trách và tài sản.
      </PageDesc>

      <PageWrap>
        <CardPanel>
          <RoomToolbar
            keyword={keyword}
            roomTypeFilter={roomTypeFilter}
            statusFilter={statusFilter}
            roomTypeOpts={roomTypeOpts}
            onSearch={handleSearch}
            onRoomTypeChange={handleRoomTypeFilter}
            onStatusChange={handleStatusFilter}
            onAdd={openCreate}
            loading={loading}
          />

          <RoomDataTable
            rows={pagedRows}
            loading={loading}
            page={page}
            size={size}
            total={filteredItems.length}
            highlightId={highlightId}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            onRowClick={openEdit}
            onEdit={openEdit}
            onDelete={openDelete}
          />
        </CardPanel>
      </PageWrap>

      <DetailPanel
        open={isDetailOpen}
        detail={detail}
        loading={detailLoading}
        activeTab={detailTab}
        managers={managers}
        managersLoading={managersLoading}
        managersDirty={managersDirty}
        assetGroups={assetGroups}
        assetsLoading={assetsLoading}
        roomTypeOpts={roomTypeOpts}
        saving={saving}
        onClose={closeDetail}
        onTabChange={(tab) => setField("detailTab", tab)}
        onSubmit={handleDetailSubmit}
        onAssign={openAssign}
        onRemoveManager={handleRemoveManagerRequest}
      />

      <DrawerRoomForm
        open={isFormOpen}
        mode="create"
        initialValues={formDetail}
        roomTypeOpts={roomTypeOpts}
        saving={saving}
        onClose={closeForm}
        onSubmit={handleCreateSubmit}
        onRequestDiscard={() => setField("isDiscardOpen", true)}
      />

      <DrawerAssignManagers
        open={isAssignOpen}
        existingManagers={managers}
        onClose={() => setField("isAssignOpen", false)}
        onSubmit={handleAssignSave}
      />

      <ModalDelete
        open={isDeleteOpen}
        title="Xóa phòng"
        saving={saving}
        onClose={() => {
          setField("isDeleteOpen", false);
          setField("deleteId", null);
        }}
        onConfirm={() => {
          if (deleteId) deleteRoom({ id: deleteId });
        }}
      />

      <ModalConfirm
        open={isRemoveManagerOpen}
        title="Gỡ người phụ trách"
        message="Bạn có chắc muốn gỡ người phụ trách? Thay đổi sẽ được lưu khi nhấn Cập nhật."
        confirmText="Gỡ"
        onClose={() => {
          setField("isRemoveManagerOpen", false);
          setField("removeManagerId", null);
        }}
        onConfirm={handleConfirmRemoveManager}
      />

      <ModalConfirm
        open={isDiscardOpen}
        title="Bỏ thay đổi"
        message="Bạn có muốn bỏ các thay đổi chưa lưu?"
        confirmText="Bỏ thay đổi"
        onClose={() => setField("isDiscardOpen", false)}
        onConfirm={closeForm}
      />
    </>
  );
};

export default RoomAssignmentMain;
