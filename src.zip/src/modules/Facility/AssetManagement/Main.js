import AppHeader from "components/common/AppHeader";
import { useEffect, useMemo } from "react";
import injectKey from "utils/injectKey";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import {
  canManageAssets,
  filterAssetsLocal,
  getEmptyCreateForm,
  paginateLocal,
  resolveAssetRole,
} from "../assetHelpers";
import {
  AssetDataTable,
  AssetToolbar,
  DrawerAssetCreate,
  DrawerAssetDetail,
  FacilityTabs,
  ModalAssetDispose,
  ModalDelete,
} from "../components";
import { CardPanel, PageWrap, TabsCard } from "./Styled";
import {
  createAssetsAction,
  deleteAssetsAction,
  exportAssetCodesAction,
  getAssetDetailAction,
  proposeDisposeAssetsAction,
  queryAssetFilterOptsAction,
  queryAssetsAction,
  resetStoreAssetManagementAction,
  setFieldValueStoreAssetManagementAction,
  updateAssetAction,
} from "../store/actions";
import {
  ASSET_TAB_LIST,
  ASSET_TABS,
  DETAIL_TABS,
  PAGE_SIZE,
  key,
} from "../store/constants";

const AssetManagementMain = () => {
  const userInfo = useOneState(injectKey.GLOBAL, "userInfo") || {};
  const canManage = canManageAssets(resolveAssetRole(userInfo));
  const assetState = useOneState(key, "asset") || {};
  const {
    activeTab = ASSET_TABS.FIXED,
    keyword = "",
    standardDeviceFilter = "ALL",
    roomFilter = "ALL",
    typeFilter = "ALL",
    subjectFilter = "ALL",
    conditionFilter = "ALL",
    statusFilter = "ALL",
    acquisitionFilter = "ALL",
    page = 0,
    size = PAGE_SIZE,
    items = [],
    loading = false,
    saving = false,
    selectedIds = [],
    selectAllMatching = false,
    standardDeviceOpts = [],
    roomOpts = [],
    typeOpts = [],
    subjectOpts = [],
    isCreateOpen = false,
    createForm = getEmptyCreateForm(ASSET_TABS.FIXED),
    isDetailOpen = false,
    detailTab = DETAIL_TABS.INFO,
    detail = null,
    detailLoading = false,
    history = [],
    historyLoading = false,
    isDeleteOpen = false,
    isDisposeOpen = false,
    highlightId = null,
  } = assetState;

  const setField = useDispatchRedux(setFieldValueStoreAssetManagementAction);
  const fetchList = useDispatchRedux(queryAssetsAction);
  const fetchFilterOpts = useDispatchRedux(queryAssetFilterOptsAction);
  const getDetail = useDispatchRedux(getAssetDetailAction);
  const createAssets = useDispatchRedux(createAssetsAction);
  const updateAsset = useDispatchRedux(updateAssetAction);
  const deleteAssets = useDispatchRedux(deleteAssetsAction);
  const exportCodes = useDispatchRedux(exportAssetCodesAction);
  const proposeDispose = useDispatchRedux(proposeDisposeAssetsAction);
  const resetStore = useDispatchRedux(resetStoreAssetManagementAction);

  const isTeaching = activeTab === ASSET_TABS.TEACHING_DEVICE;

  useEffect(() => {
    fetchFilterOpts({ assetGroup: activeTab });
    fetchList({ assetGroup: activeTab });
    return () => resetStore();
  }, []);

  useEffect(() => {
    if (!highlightId) return undefined;
    const timer = setTimeout(() => setField("highlightId", null), 2000);
    return () => clearTimeout(timer);
  }, [highlightId]);

  const filteredItems = useMemo(
    () =>
      filterAssetsLocal(items, {
        keyword,
        standardDeviceFilter,
        roomFilter,
        typeFilter,
        subjectFilter,
        conditionFilter,
        statusFilter,
        acquisitionFilter,
      }),
    [
      items,
      keyword,
      standardDeviceFilter,
      roomFilter,
      typeFilter,
      subjectFilter,
      conditionFilter,
      statusFilter,
      acquisitionFilter,
    ],
  );

  const pagedRows = useMemo(
    () => paginateLocal(filteredItems, page, size),
    [filteredItems, page, size],
  );

  const handleTabChange = (tab) => {
    setField("activeTab", tab);
    setField("page", 0);
    setField("selectedIds", []);
    setField("selectAllMatching", false);
    setField("keyword", "");
    setField("standardDeviceFilter", "ALL");
    setField("roomFilter", "ALL");
    setField("typeFilter", "ALL");
    setField("subjectFilter", "ALL");
    setField("conditionFilter", "ALL");
    setField("statusFilter", "ALL");
    setField("acquisitionFilter", "ALL");
    setField("createForm", getEmptyCreateForm(tab));
    fetchFilterOpts({ assetGroup: tab });
    fetchList({ assetGroup: tab });
  };

  const handleSearch = (nextKeyword) => {
    setField("keyword", nextKeyword);
    setField("page", 0);
    setField("selectedIds", []);
    setField("selectAllMatching", false);
  };

  const handleFilterChangeSafe = (field, value) => {
    setField(field, value);
    setField("page", 0);
    setField("selectedIds", []);
    setField("selectAllMatching", false);
  };

  const handleClearFilters = () => {
    setField("keyword", "");
    setField("standardDeviceFilter", "ALL");
    setField("roomFilter", "ALL");
    setField("typeFilter", "ALL");
    setField("subjectFilter", "ALL");
    setField("conditionFilter", "ALL");
    setField("statusFilter", "ALL");
    setField("acquisitionFilter", "ALL");
    setField("page", 0);
    setField("selectedIds", []);
    setField("selectAllMatching", false);
  };

  const handlePageChange = (nextPage) => {
    setField("page", nextPage);
  };

  const handlePageSizeChange = (nextSize) => {
    setField("size", nextSize);
    setField("page", 0);
  };

  const handleToggleRow = (id) => {
    setField("selectAllMatching", false);
    if (selectedIds.includes(id)) {
      setField(
        "selectedIds",
        selectedIds.filter((x) => x !== id),
      );
    } else {
      setField("selectedIds", [...selectedIds, id]);
    }
  };

  const handleTogglePage = (checked) => {
    if (checked) {
      const ids = filteredItems.map((r) => r.id).filter(Boolean);
      setField("selectedIds", ids);
      setField("selectAllMatching", true);
      return;
    }
    setField("selectedIds", []);
    setField("selectAllMatching", false);
  };

  const handleSelectAllMatching = () => {
    const ids = filteredItems.map((r) => r.id).filter(Boolean);
    setField("selectedIds", ids);
    setField("selectAllMatching", true);
  };

  const openCreate = () => {
    setField("createForm", getEmptyCreateForm(activeTab));
    setField("isCreateOpen", true);
  };

  const openDetail = (row) => {
    if (!row?.id) return;
    setField("detailTab", DETAIL_TABS.INFO);
    getDetail({ id: row.id });
  };

  const getSelectedIds = () => selectedIds;

  return (
    <>
      <AppHeader
        componentName="FacilityAssetManagement"
        pageTitle="Quản lý tài sản"
        isHiddenBtn
      />

      <PageWrap>
        <TabsCard>
          <FacilityTabs
            tabs={ASSET_TAB_LIST}
            activeTab={activeTab}
            onChange={handleTabChange}
          />
        </TabsCard>

        <CardPanel>
          <AssetToolbar
            isTeaching={isTeaching}
            canManage={canManage}
            keyword={keyword}
            standardDeviceFilter={standardDeviceFilter}
            roomFilter={roomFilter}
            typeFilter={typeFilter}
            subjectFilter={subjectFilter}
            conditionFilter={conditionFilter}
            statusFilter={statusFilter}
            acquisitionFilter={acquisitionFilter}
            standardDeviceOpts={standardDeviceOpts}
            roomOpts={roomOpts}
            typeOpts={typeOpts}
            subjectOpts={subjectOpts}
            selectedCount={selectedIds.length}
            loading={loading}
            onSearch={handleSearch}
            onFilterChange={handleFilterChangeSafe}
            onClearFilters={handleClearFilters}
            onAdd={openCreate}
            onExport={() => exportCodes()}
            onDispose={() => setField("isDisposeOpen", true)}
            onDelete={() => setField("isDeleteOpen", true)}
          />

          <AssetDataTable
            isTeaching={isTeaching}
            canManage={canManage}
            rows={pagedRows}
            loading={loading}
            page={page}
            size={size}
            total={filteredItems.length}
            selectedIds={selectedIds}
            selectAllMatching={selectAllMatching}
            highlightId={highlightId}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            onToggleRow={handleToggleRow}
            onTogglePage={handleTogglePage}
            onSelectAllMatching={handleSelectAllMatching}
            onClearSelection={() => {
              setField("selectedIds", []);
              setField("selectAllMatching", false);
            }}
            onView={openDetail}
            onEdit={openDetail}
            onDelete={(row) => {
              setField("selectedIds", [row.id]);
              setField("selectAllMatching", false);
              setField("isDeleteOpen", true);
            }}
          />
        </CardPanel>
      </PageWrap>

      <DrawerAssetCreate
        open={isCreateOpen}
        assetGroup={activeTab}
        initialValues={createForm}
        standardDeviceOpts={standardDeviceOpts}
        roomOpts={roomOpts}
        typeOpts={typeOpts}
        subjectOpts={subjectOpts}
        saving={saving}
        onClose={() => setField("isCreateOpen", false)}
        onSubmit={(values) =>
          createAssets({
            ...values,
            assetGroup: activeTab,
          })
        }
      />

      <DrawerAssetDetail
        open={isDetailOpen}
        detail={detail}
        loading={detailLoading}
        activeTab={detailTab}
        history={history}
        historyLoading={historyLoading}
        readOnly={!canManage}
        isTeaching={
          detail?.assetGroup === ASSET_TABS.TEACHING_DEVICE || isTeaching
        }
        typeOpts={typeOpts}
        subjectOpts={subjectOpts}
        saving={saving}
        onClose={() => {
          setField("isDetailOpen", false);
          setField("detail", null);
        }}
        onTabChange={(tab) => setField("detailTab", tab)}
        onSubmit={updateAsset}
      />

      <ModalDelete
        open={isDeleteOpen}
        title="Xóa tài sản"
        saving={saving}
        onClose={() => setField("isDeleteOpen", false)}
        onConfirm={() => {
          const ids = getSelectedIds();
          if (ids.length) deleteAssets({ ids });
        }}
      />

      <ModalAssetDispose
        open={isDisposeOpen}
        selectedCount={selectedIds.length}
        saving={saving}
        onClose={() => setField("isDisposeOpen", false)}
        onConfirm={({ note, submit }) => {
          proposeDispose({ ids: getSelectedIds(), note, submit });
        }}
      />
    </>
  );
};

export default AssetManagementMain;
