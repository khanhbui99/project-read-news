import AppHeader from "components/common/AppHeader";
import { useEffect, useMemo, useRef } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import { filterBorrowOrdersLocal } from "../borrowHelpers";
import {
  BorrowOrderList,
  BorrowToolbar,
  DrawerBorrowCreate,
  DrawerBorrowReturn,
  FacilityTabs,
  ModalConfirm,
} from "../components";
import { handleRedirectRepairList } from "../RepairTicket/helpers";
import { CardPanel, PageWrap, TabsCard } from "./Styled";
import {
  createBorrowAction,
  queryBorrowAvailableAction,
  queryBorrowOptsAction,
  queryMyBorrowsAction,
  resetStoreBorrowAction,
  returnBorrowAction,
  setFieldValueStoreBorrowAction,
} from "../store/actions";
import { BORROW_TAB_LIST, BORROW_TABS, key } from "../store/constants";

const BorrowMain = () => {
  const canCreate = true;

  const borrowState = useOneState(key, "borrow") || {};
  const {
    activeTab = BORROW_TABS.BORROWING,
    keyword = "",
    subjectFilter = "ALL",
    typeFilter = "ALL",
    roomFilter = "ALL",
    borrowing = [],
    returned = [],
    loading = false,
    saving = false,
    roomOpts = [],
    subjectOpts = [],
    typeOpts = [],
    isCreateOpen = false,
    createDirty = false,
    dueDate = null,
    note = "",
    availableAssets = [],
    availableLoading = false,
    availableKeyword = "",
    availableSubjectFilter = "ALL",
    availableTypeFilter = "ALL",
    availableRoomFilter = "ALL",
    selectedAssetIds = [],
    isReturnOpen = false,
    returnReadOnly = false,
    returnBorrow = null,
    returnItemIds = [],
    conditionOnReturn = "",
    returnNote = "",
    returnDirty = false,
    isDiscardOpen = false,
    isRepairPromptOpen = false,
  } = borrowState;

  const setField = useDispatchRedux(setFieldValueStoreBorrowAction);
  const fetchOpts = useDispatchRedux(queryBorrowOptsAction);
  const fetchMyBorrows = useDispatchRedux(queryMyBorrowsAction);
  const fetchAvailable = useDispatchRedux(queryBorrowAvailableAction);
  const createBorrow = useDispatchRedux(createBorrowAction);
  const submitReturn = useDispatchRedux(returnBorrowAction);
  const resetStore = useDispatchRedux(resetStoreBorrowAction);

  const discardSourceRef = useRef(null);
  const isBorrowingTab = activeTab === BORROW_TABS.BORROWING;

  useEffect(() => {
    fetchOpts();
    fetchMyBorrows();
    return () => resetStore();
  }, []);

  const filterParams = useMemo(
    () => ({ keyword, subjectFilter, typeFilter, roomFilter }),
    [keyword, subjectFilter, typeFilter, roomFilter],
  );

  const filteredBorrowing = useMemo(
    () => filterBorrowOrdersLocal(borrowing, filterParams),
    [borrowing, filterParams],
  );

  const filteredReturned = useMemo(
    () => filterBorrowOrdersLocal(returned, filterParams),
    [returned, filterParams],
  );

  const displayRows = isBorrowingTab ? filteredBorrowing : filteredReturned;

  const handleTabChange = (tab) => {
    setField("activeTab", tab);
  };

  const handleSearch = (next) => {
    setField("keyword", next);
  };

  const handleFilterChange = (field, value) => {
    setField(field, value);
  };

  const handleOpenCreate = () => {
    if (!canCreate) return;
    setField("dueDate", null);
    setField("note", "");
    setField("selectedAssetIds", []);
    setField("availableKeyword", "");
    setField("availableSubjectFilter", "ALL");
    setField("availableTypeFilter", "ALL");
    setField("availableRoomFilter", "ALL");
    setField("createDirty", false);
    setField("isCreateOpen", true);
    fetchAvailable({});
  };

  const closeCreate = () => {
    setField("isCreateOpen", false);
    setField("createDirty", false);
    setField("dueDate", null);
    setField("note", "");
    setField("selectedAssetIds", []);
    setField("availableAssets", []);
  };

  const closeReturn = () => {
    setField("isReturnOpen", false);
    setField("returnReadOnly", false);
    setField("returnDirty", false);
    setField("returnBorrow", null);
    setField("returnItemIds", []);
    setField("conditionOnReturn", "");
    setField("returnNote", "");
  };

  const handleRequestCloseCreate = () => {
    if (createDirty) {
      discardSourceRef.current = "create";
      setField("isDiscardOpen", true);
      return;
    }
    closeCreate();
  };

  const handleRequestCloseReturn = () => {
    if (!returnReadOnly && returnDirty) {
      discardSourceRef.current = "return";
      setField("isDiscardOpen", true);
      return;
    }
    closeReturn();
  };

  const handleConfirmDiscard = () => {
    setField("isDiscardOpen", false);
    if (discardSourceRef.current === "return") {
      closeReturn();
    } else {
      closeCreate();
    }
    discardSourceRef.current = null;
  };

  const handleCreateFieldChange = (field, value) => {
    setField(field, value);
    setField("createDirty", true);
  };

  const handleAvailableFilterChange = (overrides = {}) => {
    if (overrides.keyword !== undefined) {
      setField("availableKeyword", overrides.keyword);
    }
    if (overrides.subjectFilter !== undefined) {
      setField("availableSubjectFilter", overrides.subjectFilter);
    }
    if (overrides.typeFilter !== undefined) {
      setField("availableTypeFilter", overrides.typeFilter);
    }
    if (overrides.roomFilter !== undefined) {
      setField("availableRoomFilter", overrides.roomFilter);
    }

    const nextKeyword =
      overrides.keyword !== undefined ? overrides.keyword : availableKeyword;
    const nextSubject =
      overrides.subjectFilter !== undefined
        ? overrides.subjectFilter
        : availableSubjectFilter;
    const nextType =
      overrides.typeFilter !== undefined
        ? overrides.typeFilter
        : availableTypeFilter;
    const nextRoom =
      overrides.roomFilter !== undefined
        ? overrides.roomFilter
        : availableRoomFilter;

    fetchAvailable({
      keyword: nextKeyword,
      facilitySubjectId: nextSubject,
      facilityTypeId: nextType,
      roomId: nextRoom,
    });
  };

  const handleToggleAssetRow = (row) => {
    const id = row?.id;
    if (id == null) return;
    const exists = selectedAssetIds.map(String).includes(String(id));
    if (exists) {
      setField(
        "selectedAssetIds",
        selectedAssetIds.filter((x) => String(x) !== String(id)),
      );
    } else {
      setField("selectedAssetIds", [...selectedAssetIds, id]);
    }
    setField("createDirty", true);
  };

  const handleToggleAssetPage = (checked, rows = []) => {
    const ids = rows.map((r) => r.id).filter((id) => id != null);
    if (checked) {
      setField("selectedAssetIds", [...new Set([...selectedAssetIds, ...ids])]);
    } else {
      const remove = new Set(ids.map(String));
      setField(
        "selectedAssetIds",
        selectedAssetIds.filter((id) => !remove.has(String(id))),
      );
    }
    setField("createDirty", true);
  };

  const handleRemoveSelected = (id) => {
    setField(
      "selectedAssetIds",
      selectedAssetIds.filter((x) => String(x) !== String(id)),
    );
    setField("createDirty", true);
  };

  const handleOpenReturn = (order) => {
    if (!order?.id || !order.canReturn) return;
    const unreturnedIds = (order.items || [])
      .filter((item) => !(item.returnedAt || item.returned))
      .map((item) => item.id)
      .filter((id) => id != null);

    setField("returnReadOnly", false);
    setField("returnBorrow", order);
    setField("returnItemIds", unreturnedIds);
    setField("conditionOnReturn", "");
    setField("returnNote", "");
    setField("returnDirty", false);
    setField("isReturnOpen", true);
  };

  const handleOpenReturnDetail = (order) => {
    if (!order?.id) return;
    const firstItem = (order.items || []).find(
      (item) => item.conditionOnReturn || item.returnNote,
    );
    setField("returnReadOnly", true);
    setField("returnBorrow", order);
    setField(
      "returnItemIds",
      (order.items || []).map((item) => item.id).filter((id) => id != null),
    );
    setField(
      "conditionOnReturn",
      order.conditionOnReturn || firstItem?.conditionOnReturn || "",
    );
    setField(
      "returnNote",
      order.returnNote || firstItem?.returnNote || "",
    );
    setField("returnDirty", false);
    setField("isReturnOpen", true);
  };

  const handleReturnFieldChange = (field, value) => {
    if (returnReadOnly) return;
    setField(field, value);
    setField("returnDirty", true);
  };

  const handleToggleReturnItem = (itemId) => {
    if (returnReadOnly) return;
    const exists = returnItemIds.map(String).includes(String(itemId));
    if (exists) {
      setField(
        "returnItemIds",
        returnItemIds.filter((x) => String(x) !== String(itemId)),
      );
    } else {
      setField("returnItemIds", [...returnItemIds, itemId]);
    }
    setField("returnDirty", true);
  };

  const handleToggleReturnAll = (checked) => {
    if (returnReadOnly) return;
    const unreturnedIds = (returnBorrow?.items || [])
      .filter((item) => !(item.returnedAt || item.returned))
      .map((item) => item.id)
      .filter((id) => id != null);
    setField("returnItemIds", checked ? unreturnedIds : []);
    setField("returnDirty", true);
  };

  const handleSubmitReturn = (payload) => {
    if (returnReadOnly || !returnBorrow?.id) return;
    submitReturn({
      borrowId: returnBorrow.id,
      ...payload,
    });
  };

  const handleCloseRepairPrompt = () => {
    setField("isRepairPromptOpen", false);
  };

  const handleConfirmRepairPrompt = () => {
    setField("isRepairPromptOpen", false);
    handleRedirectRepairList({ openCreate: true });
  };

  return (
    <>
      <AppHeader
        componentName="FacilityBorrow"
        pageTitle="Đơn mượn của tôi"
        isHiddenBtn
      />

      <PageWrap>
        <TabsCard>
          <FacilityTabs
            tabs={BORROW_TAB_LIST}
            activeTab={activeTab}
            onChange={handleTabChange}
          />
        </TabsCard>

        <CardPanel>
          <BorrowToolbar
            keyword={keyword}
            subjectFilter={subjectFilter}
            typeFilter={typeFilter}
            roomFilter={roomFilter}
            opts={{ subjectOpts, typeOpts, roomOpts }}
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
            onAdd={handleOpenCreate}
            canCreate={canCreate && isBorrowingTab}
            loading={loading}
          />

          <BorrowOrderList
            rows={displayRows}
            mode={activeTab}
            loading={loading}
            onReturn={handleOpenReturn}
            onReturnAll={handleOpenReturn}
            onDetail={handleOpenReturnDetail}
            canCreate={canCreate && isBorrowingTab}
            onAdd={handleOpenCreate}
          />
        </CardPanel>
      </PageWrap>

      <DrawerBorrowCreate
        open={isCreateOpen && canCreate}
        dueDate={dueDate}
        note={note}
        availableAssets={availableAssets}
        availableLoading={availableLoading}
        availableKeyword={availableKeyword}
        availableSubjectFilter={availableSubjectFilter}
        availableTypeFilter={availableTypeFilter}
        availableRoomFilter={availableRoomFilter}
        selectedAssetIds={selectedAssetIds}
        subjectOpts={subjectOpts}
        typeOpts={typeOpts}
        roomOpts={roomOpts}
        saving={saving}
        onRequestClose={handleRequestCloseCreate}
        onFieldChange={handleCreateFieldChange}
        onAvailableFilterChange={handleAvailableFilterChange}
        onToggleRow={handleToggleAssetRow}
        onTogglePage={handleToggleAssetPage}
        onRemoveSelected={handleRemoveSelected}
        onSubmit={createBorrow}
      />

      <DrawerBorrowReturn
        open={isReturnOpen}
        borrow={returnBorrow}
        returnItemIds={returnItemIds}
        conditionOnReturn={conditionOnReturn}
        returnNote={returnNote}
        saving={saving}
        readOnly={returnReadOnly}
        onRequestClose={handleRequestCloseReturn}
        onFieldChange={handleReturnFieldChange}
        onToggleItem={handleToggleReturnItem}
        onToggleAll={handleToggleReturnAll}
        onSubmit={handleSubmitReturn}
      />

      <ModalConfirm
        open={isDiscardOpen}
        title="Xác nhận đóng"
        message="Bạn có chắc chắn muốn đóng? Các thay đổi chưa lưu sẽ bị mất."
        confirmText="Đóng"
        cancelText="Tiếp tục chỉnh sửa"
        onClose={() => {
          setField("isDiscardOpen", false);
          discardSourceRef.current = null;
        }}
        onConfirm={handleConfirmDiscard}
      />

      <ModalConfirm
        open={isRepairPromptOpen}
        title="Tạo phiếu báo hỏng"
        message="Thiết bị có tình trạng Hỏng/Thiếu. Bạn có muốn tạo Phiếu báo hỏng không?"
        confirmText="Đồng ý"
        cancelText="Để sau"
        onClose={handleCloseRepairPrompt}
        onConfirm={handleConfirmRepairPrompt}
      />
    </>
  );
};

export default BorrowMain;
