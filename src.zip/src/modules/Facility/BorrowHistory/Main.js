import { getAllTeachersAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import dayjs from "dayjs";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import { ActivityDataTable, ActivityToolbar, FacilityTabs } from "../components";
import {
  buildActorNameByAccountId,
  filterActivityLogsLocal,
  mapActivityLogItem,
  mapActorOpt,
  paginateLocal,
} from "../historyHelpers";
import { CardPanel, PageWrap, TabsCard } from "./Styled";
import {
  queryActivityLogsAction,
  resetStoreActivityLogAction,
  setFieldValueStoreActivityLogAction,
} from "../store/actions";
import {
  BORROW_HISTORY_TAB_LIST,
  BORROW_HISTORY_TABS,
  key,
  PAGE_SIZE,
} from "../store/constants";

const BorrowHistoryMain = () => {
  const state = useOneState(key, "activityLog") || {};
  const {
    keyword = "",
    fromDate = null,
    toDate = null,
    actorAccountId = "ALL",
    actionType = "ALL",
    typeFilter = BORROW_HISTORY_TABS.BORROW,
    page = 0,
    size = PAGE_SIZE,
    items = [],
    loading = false,
  } = state;

  const teachersOpt = useOneState(injectKey.GLOBAL, "teachersOpt", []);
  const fetchTeachers = useDispatchRedux(getAllTeachersAction);
  const setField = useDispatchRedux(setFieldValueStoreActivityLogAction);
  const fetchLogs = useDispatchRedux(queryActivityLogsAction);
  const resetStore = useDispatchRedux(resetStoreActivityLogAction);

  const activeTab =
    typeFilter === BORROW_HISTORY_TABS.RETURN
      ? BORROW_HISTORY_TABS.RETURN
      : BORROW_HISTORY_TABS.BORROW;

  const actorOpts = useMemo(
    () => (teachersOpt || []).map(mapActorOpt).filter((opt) => opt.value),
    [teachersOpt],
  );

  const actorNameByAccountId = useMemo(
    () => buildActorNameByAccountId(teachersOpt),
    [teachersOpt],
  );

  const mappedItems = useMemo(
    () =>
      (items || []).map((item) =>
        mapActivityLogItem(item, actorNameByAccountId),
      ),
    [items, actorNameByAccountId],
  );

  const filteredItems = useMemo(
    () =>
      filterActivityLogsLocal(mappedItems, {
        keyword,
        fromDate,
        toDate,
        actorAccountId,
        actionType,
      }),
    [mappedItems, keyword, fromDate, toDate, actorAccountId, actionType],
  );

  const pagedRows = useMemo(
    () => paginateLocal(filteredItems, page, size),
    [filteredItems, page, size],
  );

  useEffect(() => {
    if (!teachersOpt?.length) fetchTeachers();
    setField("typeFilter", BORROW_HISTORY_TABS.BORROW);
    setField("page", 0);
    fetchLogs({ type: BORROW_HISTORY_TABS.BORROW });
    return () => resetStore();
  }, []);

  const handleTabChange = (tab) => {
    setField("typeFilter", tab);
    setField("page", 0);
    fetchLogs({ type: tab });
  };

  const handleSearch = (next) => {
    setField("keyword", next);
    setField("page", 0);
  };

  const handleFilterChange = (field, value) => {
    if (field === "fromDate") {
      setField("fromDate", value);
      if (
        value &&
        toDate &&
        dayjs(toDate).isValid() &&
        dayjs(value).isValid() &&
        dayjs(toDate).isBefore(dayjs(value), "day")
      ) {
        setField("toDate", value);
      }
      setField("page", 0);
      return;
    }
    setField(field, value);
    setField("page", 0);
  };

  return (
    <>
      <AppHeader
        componentName="FacilityBorrowHistory"
        pageTitle="Lịch sử mượn / trả"
        isHiddenBtn
      />

      <PageWrap>
        <TabsCard>
          <FacilityTabs
            tabs={BORROW_HISTORY_TAB_LIST}
            activeTab={activeTab}
            onChange={handleTabChange}
          />
        </TabsCard>

        <CardPanel>
          <ActivityToolbar
            keyword={keyword}
            fromDate={fromDate}
            toDate={toDate}
            actorAccountId={actorAccountId}
            actionType={actionType}
            actorOpts={actorOpts}
            loading={loading}
            onSearch={handleSearch}
            onFilterChange={handleFilterChange}
          />

          <ActivityDataTable
            rows={pagedRows}
            loading={loading}
            page={page}
            size={size}
            total={filteredItems.length}
            onPageChange={(nextPage) => setField("page", nextPage)}
            onPageSizeChange={(nextSize) => {
              setField("size", nextSize);
              setField("page", 0);
            }}
          />
        </CardPanel>
      </PageWrap>
    </>
  );
};

export default BorrowHistoryMain;
