import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-height: calc(100vh - 140px);
  margin-top: 16px;
`;

export const TabsCard = styled.div`
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  border-top-left-radius: 12px;
  border-top-right-radius: 12px;
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: auto;
  width: max-content;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  min-height: 0;
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: hidden;
`;

export const ForbiddenWrap = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 360px;
`;
