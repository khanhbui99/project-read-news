import dayjs from "dayjs";
import urlApi from "services/api.url";
import { DateFormat4 } from "utils/constants";

import {
  ASSET_GROUP_MAP,
  CATALOG_STATUS,
  CATALOG_STATUS_MAP,
  FACILITY_TABS,
  FACILITY_TAB_LIST,
} from "./store/constants";

export const isInDateRange = (value, fromDate, toDate) => {
  if (!fromDate && !toDate) return true;
  if (!value) return false;
  const date = dayjs(value);
  if (!date.isValid()) return false;
  if (fromDate) {
    const from = dayjs(fromDate).startOf("day");
    if (from.isValid() && date.isBefore(from)) return false;
  }
  if (toDate) {
    const to = dayjs(toDate).endOf("day");
    if (to.isValid() && date.isAfter(to)) return false;
  }
  return true;
};

export const getTabConfig = (tabKey) =>
  FACILITY_TAB_LIST.find((tab) => tab.key === tabKey) || FACILITY_TAB_LIST[0];

export const getCatalogApiByTab = (tabKey) => {
  const map = {
    [FACILITY_TABS.SUBJECTS]: urlApi.managementService.facility.subjects,
    [FACILITY_TABS.TYPES]: urlApi.managementService.facility.types,
    [FACILITY_TABS.STANDARD_DEVICES]:
      urlApi.managementService.facility.standardDevices,
    [FACILITY_TABS.ROOM_TYPES]: urlApi.managementService.facility.roomTypes,
  };
  return map[tabKey] || map[FACILITY_TABS.SUBJECTS];
};

export const isDeviceTab = (tabKey) =>
  tabKey === FACILITY_TABS.STANDARD_DEVICES;

export const normalizeStatus = (status) => {
  if (!status || status === "IN_USE" || status === "ACTIVE") {
    return CATALOG_STATUS.ACTIVE;
  }
  if (status === "HIDDEN" || status === "INACTIVE") {
    return CATALOG_STATUS.HIDDEN;
  }
  return status;
};

export const mapCatalogItem = (item = {}) => {
  const createdAt =
    item.createdAt || item.createdDate || item.created_at || item.createDate;
  const status = normalizeStatus(
    item.status || (item.codeHidden ? CATALOG_STATUS.HIDDEN : null),
  );
  const note = item.note || item.description || "";
  const code = item.code || item.originCode || item.maGoc || "";

  return {
    ...item,
    code,
    name: item.name || "",
    unit: item.unit || "",
    note,
    description: note,
    assetGroup: item.assetGroup || "",
    assetGroupName: ASSET_GROUP_MAP[item.assetGroup] || item.assetGroup || "--",
    assetCount:
      item.assetCount ??
      item.usingAssetCount ??
      item.activeAssetCount ??
      item.totalAssets ??
      0,
    status,
    statusName: CATALOG_STATUS_MAP[status] || CATALOG_STATUS_MAP.ACTIVE,
    createdAtFormat: createdAt ? dayjs(createdAt).format(DateFormat4) : "--",
  };
};

export const buildSavePayload = (values = {}, tabKey) => {
  if (isDeviceTab(tabKey)) {
    return {
      name: (values.name || "").trim(),
      unit: (values.unit || "").trim(),
      assetGroup: values.assetGroup,
      code: (values.code || "").trim().toUpperCase(),
    };
  }

  const description = String(values.description ?? values.note ?? "").trim();
  return {
    name: (values.name || "").trim(),
    note: description,
    description,
  };
};

export const isFormUnchanged = (values = {}, detail = {}, tabKey) => {
  const nameChanged =
    (values.name || "").trim() !== (detail.name || "").trim();

  if (isDeviceTab(tabKey)) {
    const codeChanged =
      (values.code || "").trim().toUpperCase() !==
      (detail.code || "").trim().toUpperCase();
    const unitChanged =
      (values.unit || "").trim() !== (detail.unit || "").trim();
    const assetGroupChanged =
      (values.assetGroup || "") !== (detail.assetGroup || "");
    return !codeChanged && !nameChanged && !unitChanged && !assetGroupChanged;
  }

  const noteChanged =
    (values.note || values.description || "").trim() !==
    (detail.note || detail.description || "").trim();

  return !nameChanged && !noteChanged;
};

export const isCodeChanged = (values = {}, detail = {}) =>
  (values.code || "").trim().toUpperCase() !==
  (detail.code || "").trim().toUpperCase();

export const getEmptyDetail = (tabKey) => {
  if (isDeviceTab(tabKey)) {
    return {
      id: 0,
      code: "",
      name: "",
      unit: "",
      assetGroup: "",
      status: CATALOG_STATUS.ACTIVE,
    };
  }

  return {
    id: 0,
    name: "",
    note: "",
    description: "",
    status: CATALOG_STATUS.ACTIVE,
  };
};

export const parseCodeChangeImpact = (data) => {
  if (typeof data === "number") return data;
  if (data == null) return 0;
  return (
    data.affectedUnitCount ??
    data.unitCount ??
    data.count ??
    data.total ??
    data.impactCount ??
    0
  );
};

/** Lọc danh mục local — không gọi API */
export const filterCatalogLocal = (
  items = [],
  {
    keyword = "",
    statusFilter = "ALL",
    assetGroupFilter = "ALL",
    isDevice = false,
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.code || ""} ${item.name || ""} ${item.note || ""} ${item.description || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }
    if (isDevice && statusFilter && statusFilter !== "ALL") {
      if (item.status !== statusFilter) return false;
    }
    if (isDevice && assetGroupFilter && assetGroupFilter !== "ALL") {
      if (String(item.assetGroup || "") !== String(assetGroupFilter)) {
        return false;
      }
    }
    return true;
  });
};
