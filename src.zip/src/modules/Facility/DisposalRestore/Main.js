import AppHeader from "components/common/AppHeader";
import dayjs from "dayjs";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  DrawerProposalCreate,
  DrawerProposalDetail,
  FacilityTabs,
  ProposalDataTable,
  ProposalToolbar,
} from "../components";
import {
  canCreateProposal,
  canDecideProposal,
  canSubmitDraft,
  buildRestoreRoomsFromCandidates,
  filterProposalsLocal,
  paginateLocal,
  resolveProposalRole,
} from "../proposalHelpers";
import { CardPanel, PageWrap, TabsCard } from "./Styled";
import {
  createProposalAction,
  decideProposalAction,
  getProposalDetailAction,
  prefillRestoreFromDisposalAction,
  queryProposalAssetsAction,
  queryProposalOptsAction,
  queryProposalsAction,
  resetStoreDisposalRestoreAction,
  setFieldValueStoreDisposalRestoreAction,
  submitProposalAction,
} from "../store/actions";
import {
  PAGE_SIZE,
  PROPOSAL_TABS,
  PROPOSAL_TAB_LIST,
  key,
} from "../store/constants";

const DisposalRestoreMain = () => {
  const userInfo = useOneState(injectKey.GLOBAL, "userInfo") || {};
  const role = resolveProposalRole(userInfo);
  const canCreate = canCreateProposal(role);
  const canDecide = canDecideProposal(role);
  const canSubmit = canCreate;

  const state = useOneState(key, "disposalRestore") || {};
  const {
    activeTab = PROPOSAL_TABS.DISPOSAL,
    keyword = "",
    statusFilter = "ALL",
    fromDate = null,
    toDate = null,
    page = 0,
    size = PAGE_SIZE,
    items = [],
    loading = false,
    saving = false,
    roomOpts = [],
    subjectOpts = [],
    typeOpts = [],
    isCreateOpen = false,
    createAssets = [],
    createAssetsLoading = false,
    createAssetsPrefill = false,
    createKeyword = "",
    createRoomFilter = "ALL",
    createSubjectFilter = "ALL",
    createTypeFilter = "ALL",
    selectedAssetIds = [],
    selectedProposalIds = [],
    restoreTargets = {},
    reason = "",
    isDetailOpen = false,
    detail = null,
    detailLoading = false,
    selectedItemIds = [],
    rejectReason = "",
    decideMode = null,
  } = state;

  const setField = useDispatchRedux(setFieldValueStoreDisposalRestoreAction);
  const fetchList = useDispatchRedux(queryProposalsAction);
  const fetchOpts = useDispatchRedux(queryProposalOptsAction);
  const fetchAssets = useDispatchRedux(queryProposalAssetsAction);
  const getDetail = useDispatchRedux(getProposalDetailAction);
  const createProposal = useDispatchRedux(createProposalAction);
  const submitProposal = useDispatchRedux(submitProposalAction);
  const decideProposal = useDispatchRedux(decideProposalAction);
  const prefillRestore = useDispatchRedux(prefillRestoreFromDisposalAction);
  const resetStore = useDispatchRedux(resetStoreDisposalRestoreAction);

  const isRestore = activeTab === PROPOSAL_TABS.RESTORE;

  const restoreRooms = useMemo(
    () =>
      createAssetsPrefill
        ? buildRestoreRoomsFromCandidates(createAssets)
        : [],
    [createAssetsPrefill, createAssets],
  );

  useEffect(() => {
    fetchOpts();
    return () => resetStore();
  }, []);

  useEffect(() => {
    fetchList({ tab: activeTab });
  }, [activeTab]);

  useEffect(() => {
    if (isCreateOpen && !createAssetsPrefill) {
      fetchAssets({ tab: activeTab });
    }
  }, [isCreateOpen, activeTab, createAssetsPrefill]);

  const filteredItems = useMemo(
    () =>
      filterProposalsLocal(items, { keyword, statusFilter, fromDate, toDate }),
    [items, keyword, statusFilter, fromDate, toDate],
  );

  const pagedRows = useMemo(
    () => paginateLocal(filteredItems, page, size),
    [filteredItems, page, size],
  );

  const handleTabChange = (nextTab) => {
    if (nextTab === activeTab) return;
    setField("activeTab", nextTab);
    setField("page", 0);
    setField("keyword", "");
    setField("statusFilter", "ALL");
    setField("fromDate", null);
    setField("toDate", null);
    setField("selectedProposalIds", []);
    setField("isCreateOpen", false);
    setField("isDetailOpen", false);
    setField("detail", null);
  };

  const handleSearch = (nextKeyword) => {
    setField("keyword", nextKeyword);
    setField("page", 0);
  };

  const handleStatusChange = (nextStatus) => {
    setField("statusFilter", nextStatus);
    setField("page", 0);
  };

  const handleDateChange = (field, value) => {
    setField(field, value);
    setField("page", 0);
    if (
      field === "fromDate" &&
      toDate &&
      value &&
      dayjs(toDate).isValid() &&
      dayjs(value).isValid() &&
      dayjs(toDate).isBefore(dayjs(value), "day")
    ) {
      setField("toDate", value);
    }
  };

  /**
   * CSVC tick đề xuất loại bỏ trên list → lấy phòng/tài sản từ data list
   * (thiếu thì saga lấy detail) để user tick chọn phòng cần khôi phục.
   */
  const handleRestoreProposeFromDisposalList = () => {
    if (!selectedProposalIds.length) return;

    const idSet = new Set(selectedProposalIds.map(String));
    const selectedProposals = (items || []).filter((p) =>
      idSet.has(String(p.id)),
    );

    prefillRestore({
      proposalIds: selectedProposalIds,
      proposals: selectedProposals,
    });
  };

  const handleCloseCreate = () => {
    setField("isCreateOpen", false);
    setField("createAssetsPrefill", false);
  };

  const handleToggleRestoreRoom = (room, checked) => {
    if (room?.selectable === false) return;
    const assetIds = room?.assetIds || [];
    if (!assetIds.length) return;

    const idSet = new Set(assetIds.map(String));
    if (checked) {
      const nextIds = [
        ...new Set([...selectedAssetIds, ...assetIds]),
      ];
      setField("selectedAssetIds", nextIds);
      const nextTargets = { ...restoreTargets };
      assetIds.forEach((id) => {
        if (nextTargets[id] !== undefined && nextTargets[id] !== "") return;
        const asset = (createAssets || []).find(
          (a) => String(a.id) === String(id),
        );
        nextTargets[id] =
          asset?.targetRoomId ||
          asset?.originalRoomId ||
          room.roomId ||
          "";
      });
      setField("restoreTargets", nextTargets);
      return;
    }

    setField(
      "selectedAssetIds",
      selectedAssetIds.filter((id) => !idSet.has(String(id))),
    );
    const nextTargets = { ...restoreTargets };
    assetIds.forEach((id) => {
      delete nextTargets[id];
      delete nextTargets[String(id)];
    });
    setField("restoreTargets", nextTargets);
  };

  const handleToggleAllRestoreRooms = (checked, rooms = []) => {
    const allowedRooms = (rooms || []).filter(
      (room) => room?.selectable !== false,
    );
    const allAssetIds = [];
    allowedRooms.forEach((room) => {
      (room.assetIds || []).forEach((id) => {
        if (!allAssetIds.map(String).includes(String(id))) {
          allAssetIds.push(id);
        }
      });
    });
    if (!allAssetIds.length) return;

    if (checked) {
      setField("selectedAssetIds", [
        ...new Set([...selectedAssetIds, ...allAssetIds]),
      ]);
      const nextTargets = { ...restoreTargets };
      allowedRooms.forEach((room) => {
        (room.assetIds || []).forEach((id) => {
          if (nextTargets[id] !== undefined && nextTargets[id] !== "") return;
          const asset = (createAssets || []).find(
            (a) => String(a.id) === String(id),
          );
          nextTargets[id] =
            asset?.targetRoomId ||
            asset?.originalRoomId ||
            room.roomId ||
            "";
        });
      });
      setField("restoreTargets", nextTargets);
      return;
    }

    const removeSet = new Set(allAssetIds.map(String));
    setField(
      "selectedAssetIds",
      selectedAssetIds.filter((id) => !removeSet.has(String(id))),
    );
    const nextTargets = { ...restoreTargets };
    allAssetIds.forEach((id) => {
      delete nextTargets[id];
      delete nextTargets[String(id)];
    });
    setField("restoreTargets", nextTargets);
  };

  const handleToggleProposalRow = (id) => {
    if (selectedProposalIds.includes(id)) {
      setField(
        "selectedProposalIds",
        selectedProposalIds.filter((x) => x !== id),
      );
    } else {
      setField("selectedProposalIds", [...selectedProposalIds, id]);
    }
  };

  const handleToggleProposalPage = (checked, rows = []) => {
    const ids = rows.map((r) => r.id).filter(Boolean);
    if (checked) {
      setField(
        "selectedProposalIds",
        [...new Set([...selectedProposalIds, ...ids])],
      );
    } else {
      setField(
        "selectedProposalIds",
        selectedProposalIds.filter((id) => !ids.includes(id)),
      );
    }
  };

  const handleToggleAsset = (row) => {
    if (!row?.id) return;
    const id = row.id;
    if (selectedAssetIds.includes(id)) {
      setField(
        "selectedAssetIds",
        selectedAssetIds.filter((x) => x !== id),
      );
      if (isRestore) {
        const next = { ...restoreTargets };
        delete next[id];
        delete next[String(id)];
        setField("restoreTargets", next);
      }
      return;
    }

    setField("selectedAssetIds", [...selectedAssetIds, id]);
    if (isRestore) {
      setField("restoreTargets", {
        ...restoreTargets,
        [id]: row.targetRoomId || "",
      });
    }
  };

  const handleToggleAssetPage = (checked, rows = []) => {
    const ids = rows.map((r) => r.id).filter(Boolean);
    if (checked) {
      const nextIds = [...new Set([...selectedAssetIds, ...ids])];
      setField("selectedAssetIds", nextIds);
      if (isRestore) {
        const nextTargets = { ...restoreTargets };
        rows.forEach((row) => {
          if (row?.id && nextTargets[row.id] === undefined) {
            nextTargets[row.id] = row.targetRoomId || "";
          }
        });
        setField("restoreTargets", nextTargets);
      }
      return;
    }

    setField(
      "selectedAssetIds",
      selectedAssetIds.filter((id) => !ids.includes(id)),
    );
    if (isRestore) {
      const nextTargets = { ...restoreTargets };
      ids.forEach((id) => {
        delete nextTargets[id];
        delete nextTargets[String(id)];
      });
      setField("restoreTargets", nextTargets);
    }
  };

  const handleRemoveSelected = (id) => {
    setField(
      "selectedAssetIds",
      selectedAssetIds.filter((x) => x !== id),
    );
    if (isRestore) {
      const next = { ...restoreTargets };
      delete next[id];
      delete next[String(id)];
      setField("restoreTargets", next);
    }
  };

  const handleRestoreTargetChange = (assetId, roomId) => {
    setField("restoreTargets", {
      ...restoreTargets,
      [assetId]: roomId,
    });
  };

  const handleCreateSubmit = (payload) => {
    createProposal({
      ...payload,
      tab: activeTab,
    });
  };

  const handleView = (row) => {
    if (!row?.id) return;
    getDetail({ id: row.id, tab: activeTab });
  };

  const handleCloseDetail = () => {
    setField("isDetailOpen", false);
    setField("detail", null);
    setField("selectedItemIds", []);
    setField("rejectReason", "");
    setField("decideMode", null);
  };

  const handleSubmitFromTable = (row) => {
    if (!row?.id) return;
    if (!canSubmitDraft(role, row.status)) return;
    submitProposal({ id: row.id, tab: activeTab });
  };

  const handleSubmitDraft = () => {
    if (!detail?.id) return;
    submitProposal({ id: detail.id, tab: activeTab });
  };

  const handleToggleItem = (id) => {
    if (selectedItemIds.includes(id)) {
      setField(
        "selectedItemIds",
        selectedItemIds.filter((x) => x !== id),
      );
    } else {
      setField("selectedItemIds", [...selectedItemIds, id]);
    }
  };

  const handleToggleItemPage = (checked, rows = []) => {
    const ids = rows.map((r) => r.id).filter(Boolean);
    if (checked) {
      setField("selectedItemIds", [...new Set([...selectedItemIds, ...ids])]);
    } else {
      setField(
        "selectedItemIds",
        selectedItemIds.filter((id) => !ids.includes(id)),
      );
    }
  };

  const handleDecide = ({ approve, reason: decideReason }) => {
    if (!detail?.id) return;
    decideProposal({
      id: detail.id,
      tab: activeTab,
      itemIds: selectedItemIds,
      approve,
      reason: decideReason,
    });
  };

  return (
    <>
      <AppHeader
        componentName="FacilityDisposalRestore"
        pageTitle="Loại bỏ & Khôi phục tài sản"
        isHiddenBtn
      />

      <PageWrap>
        <TabsCard>
          <FacilityTabs
            tabs={PROPOSAL_TAB_LIST}
            activeTab={activeTab}
            onChange={handleTabChange}
          />
        </TabsCard>

        <CardPanel>
          <ProposalToolbar
            keyword={keyword}
            statusFilter={statusFilter}
            fromDate={fromDate}
            toDate={toDate}
            onSearch={handleSearch}
            onStatusChange={handleStatusChange}
            onDateChange={handleDateChange}
            onRestorePropose={handleRestoreProposeFromDisposalList}
            canCreate={canCreate}
            isRestore={isRestore}
            selectedCount={isRestore ? 0 : selectedProposalIds.length}
            loading={loading}
            placeholder="Tìm theo mã đề xuất..."
          />

          <ProposalDataTable
            rows={pagedRows}
            allRows={filteredItems}
            loading={loading}
            page={page}
            size={size}
            total={filteredItems.length}
            isRestore={isRestore}
            canSubmit={canSubmit}
            canDecide={canDecide}
            selectable={canCreate && !canDecide && !isRestore}
            selectedIds={selectedProposalIds}
            onToggleRow={handleToggleProposalRow}
            onTogglePage={handleToggleProposalPage}
            onPageChange={(nextPage) => setField("page", nextPage)}
            onPageSizeChange={(nextSize) => {
              setField("size", nextSize);
              setField("page", 0);
            }}
            onView={handleView}
            onSubmit={handleSubmitFromTable}
          />
        </CardPanel>
      </PageWrap>

      <DrawerProposalCreate
        open={isCreateOpen}
        isRestore={isRestore}
        assets={createAssets}
        loadingAssets={createAssetsLoading}
        roomSelectMode={createAssetsPrefill && isRestore}
        restoreRooms={restoreRooms}
        roomOpts={roomOpts}
        subjectOpts={subjectOpts}
        typeOpts={typeOpts}
        keyword={createKeyword}
        roomFilter={createRoomFilter}
        subjectFilter={createSubjectFilter}
        typeFilter={createTypeFilter}
        selectedIds={selectedAssetIds}
        restoreTargets={restoreTargets}
        reason={reason}
        saving={saving}
        onClose={handleCloseCreate}
        onSearch={(next) => setField("createKeyword", next)}
        onFilterChange={(field, value) => setField(field, value)}
        onToggleRow={handleToggleAsset}
        onTogglePage={handleToggleAssetPage}
        onToggleRoom={handleToggleRestoreRoom}
        onToggleAllRooms={handleToggleAllRestoreRooms}
        onRemoveSelected={handleRemoveSelected}
        onRestoreTargetChange={handleRestoreTargetChange}
        onReasonChange={(next) => setField("reason", next)}
        onSubmit={handleCreateSubmit}
      />

      <DrawerProposalDetail
        open={isDetailOpen}
        detail={detail}
        loading={detailLoading}
        isRestore={isRestore}
        canDecide={canDecide}
        canSubmit={canSubmit}
        selectedItemIds={selectedItemIds}
        decideMode={decideMode}
        rejectReason={rejectReason}
        saving={saving}
        onClose={handleCloseDetail}
        onToggleItem={handleToggleItem}
        onTogglePage={handleToggleItemPage}
        onDecideMode={(mode) => setField("decideMode", mode)}
        onRejectReasonChange={(next) => setField("rejectReason", next)}
        onSubmitDraft={handleSubmitDraft}
        onDecide={handleDecide}
      />
    </>
  );
};

export default DisposalRestoreMain;
