import dayjs from "dayjs";
import { isBGH } from "utils/helpers";

import { ACTIVITY_ROLE } from "./store/constants";

const DATETIME_FORMAT = "DD/MM/YYYY HH:mm";

const collectRoleTokens = (userInfo = {}) => {
  const tokens = [];
  const push = (value) => {
    if (value == null || value === "") return;
    if (Array.isArray(value)) {
      value.forEach(push);
      return;
    }
    if (typeof value === "object") {
      push(value.code);
      push(value.roleCode);
      push(value.name);
      push(value.roleName);
      push(value.role);
      return;
    }
    String(value)
      .split(/[;,|]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((part) => tokens.push(part.toUpperCase()));
  };

  push(userInfo.listRole);
  push(userInfo.list_role);
  push(userInfo.roleName);
  push(userInfo.roleCode);
  push(userInfo.role);
  push(userInfo.currentRole);
  push(userInfo.roles);

  (userInfo.orgCharts || userInfo.org_charts || []).forEach((org) => {
    push(org?.roleName);
    push(org?.roleCode);
    push(org?.role);
  });

  return tokens;
};

const roleTextIncludes = (tokens = [], keywords = []) =>
  tokens.some((token) =>
    keywords.some((keyword) => token.includes(String(keyword).toUpperCase())),
  );

export const resolveHistoryRole = (userInfo = {}) => {
  const tokens = collectRoleTokens(userInfo);
  const exactRoles = new Set(tokens);

  if (
    (typeof isBGH === "function" && isBGH()) ||
    userInfo?.isBGH ||
    exactRoles.has("HIỆU TRƯỞNG") ||
    exactRoles.has("PHÓ HIỆU TRƯỞNG") ||
    roleTextIncludes(tokens, [
      "BGH",
      "BAN GIAM HIEU",
      "BAN_GIAM",
      "HIỆU TRƯỞNG",
      "HIEU TRUONG",
      "PHÓ HIỆU TRƯỞNG",
      "PHO HIEU TRUONG",
      "SCHOOL_MANAGER",
      "SCHOOL MANAGER",
    ])
  ) {
    return ACTIVITY_ROLE.SCHOOL_MANAGER;
  }

  if (
    roleTextIncludes(tokens, [
      "CSVC",
      "FACILITY",
      "QUAN_LY_CSVC",
      "QUẢN LÝ CSVC",
      "QUAN LY CSVC",
      "FACILITY_MANAGER",
    ])
  ) {
    return ACTIVITY_ROLE.FACILITY_MANAGER;
  }

  return ACTIVITY_ROLE.OTHER;
};

export const canAccessHistory = (role) =>
  role === ACTIVITY_ROLE.FACILITY_MANAGER ||
  role === ACTIVITY_ROLE.SCHOOL_MANAGER;

const formatDateTime = (value) => {
  if (!value) return "--";
  const d = dayjs(value);
  return d.isValid() ? d.format(DATETIME_FORMAT) : "--";
};

const getTeacherAccountId = (teacher = {}) =>
  teacher.accountId ??
  teacher.userId ??
  teacher.id ??
  teacher.teacherId ??
  "";

const getTeacherName = (teacher = {}) =>
  teacher.fullName ||
  teacher.full_name ||
  teacher.name ||
  teacher.userFullName ||
  teacher.userName ||
  teacher.displayName ||
  "";

/** Map actorAccountId → tên GV từ teachersOpt */
export const buildActorNameByAccountId = (teachers = []) => {
  const map = new Map();
  (teachers || []).forEach((teacher) => {
    const accountId = getTeacherAccountId(teacher);
    if (accountId == null || accountId === "") return;
    const name = getTeacherName(teacher);
    if (!name) return;
    map.set(String(accountId), name);
  });
  return map;
};

const formatActor = (item = {}, actorNameByAccountId) => {
  if (item.actorDisplay) return item.actorDisplay;

  const accountId = item.actorAccountId ?? item.accountId ?? item.userId;
  const mappedName =
    accountId != null && accountId !== "" && actorNameByAccountId
      ? actorNameByAccountId.get(String(accountId))
      : "";

  const name =
    mappedName ||
    item.actorName ||
    item.performedBy ||
    item.userName ||
    item.actorFullName ||
    "";
  const role =
    item.actorRole ||
    item.actorRoleName ||
    item.roleName ||
    item.role ||
    "";
  if (name && role) return `${name} (${role})`;
  if (name) return name;
  return "--";
};

/** Hiển thị đối tượng đúng dữ liệu BE — không tự nối chuỗi */
const formatObject = (item = {}) => {
  if (item.objectDisplay != null && item.objectDisplay !== "") {
    return item.objectDisplay;
  }
  if (item.objectText != null && item.objectText !== "") {
    return item.objectText;
  }
  if (Array.isArray(item.objects)) {
    return item.objects
      .map((obj) => {
        if (obj == null) return "";
        if (typeof obj === "string" || typeof obj === "number") return String(obj);
        return (
          obj.code ||
          obj.name ||
          obj.label ||
          obj.display ||
          obj.objectCode ||
          ""
        );
      })
      .filter(Boolean);
  }
  if (item.object != null && item.object !== "") {
    if (typeof item.object === "object" && !Array.isArray(item.object)) {
      return (
        item.object.code ||
        item.object.name ||
        item.object.label ||
        item.object.display ||
        "--"
      );
    }
    return item.object;
  }
  if (item.entityCode != null && item.entityCode !== "") {
    return item.entityCode;
  }
  if (item.objectCode) return item.objectCode;
  return "--";
};

const formatChange = (item = {}) => {
  if (item.changeText != null && item.changeText !== "") {
    return item.changeText;
  }
  if (item.change != null && item.change !== "") {
    return item.change;
  }
  if (item.description != null && item.description !== "") {
    return item.description;
  }
  const oldVal = item.oldValue ?? item.fromValue;
  const newVal = item.newValue ?? item.toValue;
  if (oldVal != null || newVal != null) {
    return `${oldVal ?? "--"} → ${newVal ?? "--"}`;
  }
  return "--";
};

export const mapActivityLogItem = (item = {}, actorNameByAccountId) => {
  const occurredAt =
    item.occurredAt ||
    item.time ||
    item.createdAt ||
    item.actedAt ||
    item.timestamp ||
    null;
  const accountId = item.actorAccountId ?? item.accountId ?? item.userId;
  const teacherName =
    accountId != null && accountId !== "" && actorNameByAccountId
      ? actorNameByAccountId.get(String(accountId))
      : "";

  return {
    ...item,
    id: item.id || item.logId,
    occurredAt,
    time: occurredAt,
    timeDisplay: formatDateTime(occurredAt),
    actorAccountId: accountId ?? "",
    actorDisplay: formatActor(item, actorNameByAccountId),
    actionDisplay:
      item.description ||
      item.actionName ||
      item.action ||
      item.eventType ||
      item.actionType ||
      "--",
    // Đối tượng: map danh sách GV theo actorAccountId
    objectDisplay: teacherName || formatObject(item),
    changeDisplay: formatChange(item),
  };
};

export const mapActorOpt = (item = {}) => {
  const value = getTeacherAccountId(item);
  const label = getTeacherName(item) || item.email || String(value);
  return {
    value,
    label,
  };
};

export const paginateLocal = (items = [], page = 0, size = 10) => {
  const start = page * size;
  return (items || []).slice(start, start + size);
};

export const toApiDate = (value) => {
  if (!value) return undefined;
  const d = dayjs(value);
  if (!d.isValid()) return undefined;
  return d.startOf("day").format("YYYY-MM-DD");
};

/** Lọc nhật ký trên FE (không gọi lại API) */
export const filterActivityLogsLocal = (
  items = [],
  {
    keyword = "",
    fromDate = null,
    toDate = null,
    actorAccountId = "ALL",
    actionType = "ALL",
  } = {},
) => {
  const kw = String(keyword || "")
    .trim()
    .toLowerCase();
  const from = fromDate ? dayjs(fromDate).startOf("day") : null;
  const to = toDate ? dayjs(toDate).endOf("day") : null;

  return (items || []).filter((item) => {
    if (kw) {
      const hay =
        `${item.timeDisplay || ""} ${item.actorDisplay || ""} ${item.actionDisplay || ""} ${item.objectDisplay || ""} ${item.changeDisplay || ""} ${item.description || ""}`.toLowerCase();
      if (!hay.includes(kw)) return false;
    }

    if (actorAccountId && actorAccountId !== "ALL") {
      if (String(item.actorAccountId) !== String(actorAccountId)) return false;
    }

    if (actionType && actionType !== "ALL") {
      const type =
        item.actionType || item.eventType || item.action || item.actionDisplay;
      if (String(type) !== String(actionType)) return false;
    }

    if (from || to) {
      const occurred = item.occurredAt || item.time || item.createdAt;
      if (!occurred) return false;
      const d = dayjs(occurred);
      if (!d.isValid()) return false;
      if (from && d.isBefore(from)) return false;
      if (to && d.isAfter(to)) return false;
    }

    return true;
  });
};
