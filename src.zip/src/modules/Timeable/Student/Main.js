import { getExamPeriodCategoryAction } from "App/store/actions";
import { TimetableBoard } from "components/Timetable";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import Filter from "../Administration/components/Filter";
import { resolveYearSemesterFilter } from "../Administration/helpers";
import Header from "./components/Header";
import InfoCard from "./components/InfoCard";
import { fetchTimetableAction, setFieldValueAction } from "./store/actions";
import { key } from "./store/constants";
import { ContainerStyled } from "./Styled";

const TimeTableMain = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchTimetable = useDispatchRedux(fetchTimetableAction);
  const setFieldValue = useDispatchRedux(setFieldValueAction);

  const examPeriodCategory = useOneState(
    injectKey.GLOBAL,
    "examPeriodCategory",
    {},
  );
  const filter = useOneState(key, "filter", {});
  const timetableData = useOneState(key, "timetable");
  const fetched = useOneState(key, "fetched", false);

  const academicYears = examPeriodCategory?.academicYears || [];
  const semesters = examPeriodCategory?.semesters || [];

  useEffect(() => {
    fetchExamPeriodCategory();
  }, []);

  useEffect(() => {
    const next = resolveYearSemesterFilter(filter, academicYears, semesters);
    if (next) setFieldValue("filter", next);
  }, [academicYears, semesters, filter.schoolYearId, filter.semesterId]);

  useEffect(() => {
    if (!filter.schoolYearId || !filter.semesterId) return;
    fetchTimetable({
      schoolYearId: filter.schoolYearId,
      semesterId: filter.semesterId,
    });
  }, [filter.schoolYearId, filter.semesterId]);

  const handleFilterChange = (partial) => {
    setFieldValue("filter", { ...filter, ...partial });
  };

  const scheduleDataToUse = useMemo(() => {
    if (!timetableData) {
      return {};
    }

    if (
      timetableData.scheduleData &&
      typeof timetableData.scheduleData === "object"
    ) {
      return timetableData.scheduleData;
    }

    return {};
  }, [timetableData]);

  return (
    <ContainerStyled>
      <Header />
      <Filter
        hideClass
        academicYears={academicYears}
        semesters={semesters}
        filter={filter}
        onChange={handleFilterChange}
      />
      <InfoCard />
      <TimetableBoard scheduleData={scheduleDataToUse} fetched={fetched} />
    </ContainerStyled>
  );
};

export default TimeTableMain;
