import { Box } from "@mui/material";
import { Text, Title } from "components/Styled";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;

  @media (max-width: 768px) {
    gap: 16px;
  }

  @media (max-width: 480px) {
    gap: 12px;
  }
`;

export const InfoCard = styled(Box)`
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.white} 0%,
    ${VPB_THEMES.colors.gray[100]} 50%,
    ${VPB_THEMES.colors.white} 100%
  );
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
    background: linear-gradient(
      180deg,
      ${VPB_THEMES.colors.blue} 0%,
      ${VPB_THEMES.colors.lightBlue} 100%
    );
  }

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    border-color: ${VPB_THEMES.colors.gray[300]};
  }

  @media (max-width: 768px) {
    padding: 16px;
    border-radius: 12px;
  }

  @media (max-width: 480px) {
    padding: 12px;
    border-radius: 8px;
  }
`;

export const InfoCardTitle = styled(Title)`
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 8px;

  &::before {
    content: "";
    width: 4px;
    height: 20px;
    background: ${VPB_THEMES.colors.blue};
    border-radius: 2px;
  }
`;

export const InfoCardGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 16px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 12px;
  }
`;

export const InfoCardItem = styled(Box)`
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  background: ${VPB_THEMES.colors.white};
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.table.borderMedium};
  transition: all 0.2s ease;
  cursor: pointer;

  &:hover {
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 4px 8px rgba(29, 66, 137, 0.15);
    transform: translateX(4px);
  }

  @media (max-width: 480px) {
    padding: 12px;
    gap: 12px;
  }
`;

export const InfoCardItemIcon = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: ${({ color }) => color || VPB_THEMES.colors.blue}15;
  color: ${({ color }) => color || VPB_THEMES.colors.blue};
  flex-shrink: 0;

  svg {
    font-size: 24px;
  }

  @media (max-width: 480px) {
    width: 40px;
    height: 40px;

    svg {
      font-size: 20px;
    }
  }
`;

export const InfoCardItemLabel = styled(Text)`
  margin-bottom: 4px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

export const InfoCardItemValue = styled(Title)`
  line-height: 1.4;
`;
