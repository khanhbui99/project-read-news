export { default as StudentTimeable } from "./Student";
export { default as TeacherTimeable } from "./Teacher";
export { default as AdministrationTimeable } from "./Administration";
