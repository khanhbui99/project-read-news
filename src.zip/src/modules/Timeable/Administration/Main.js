import { getExamPeriodCategoryAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import { TimetableBoard } from "components/Timetable";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import Filter from "./components/Filter";
import SchoolOverview from "./components/SchoolOverview";
import { resolveYearSemesterFilter } from "./helpers";
import {
  fetchSchoolTimetableAction,
  setFieldValueAction,
} from "./store/actions";
import { key } from "./store/constants";
import {
  ContainerStyled,
  SectionCard,
  SectionTitle,
  SummaryBar,
  SummaryChip,
} from "./Styled";

const AdministrationTimetableMain = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchSchoolTimetable = useDispatchRedux(fetchSchoolTimetableAction);
  const setFieldValue = useDispatchRedux(setFieldValueAction);

  const examPeriodCategory = useOneState(
    injectKey.GLOBAL,
    "examPeriodCategory",
    {},
  );
  const filter = useOneState(key, "filter", {});
  const classes = useOneState(key, "classes", []);
  const classOptions = useOneState(key, "classOptions", []);
  const unassignedScheduleData = useOneState(key, "unassignedScheduleData", {});
  const unassignedSlots = useOneState(key, "unassignedSlots", []);
  const hasUnassigned = useOneState(key, "hasUnassigned", false);
  const fetched = useOneState(key, "fetched", false);

  const academicYears = examPeriodCategory?.academicYears || [];
  const semesters = examPeriodCategory?.semesters || [];

  useEffect(() => {
    fetchExamPeriodCategory();
  }, []);

  useEffect(() => {
    const next = resolveYearSemesterFilter(filter, academicYears, semesters);
    if (next) {
      setFieldValue("filter", { ...next, classId: filter.classId || "" });
    }
  }, [academicYears, semesters, filter.schoolYearId, filter.semesterId]);

  useEffect(() => {
    if (!filter.schoolYearId || !filter.semesterId) return;
    fetchSchoolTimetable({
      schoolYearId: filter.schoolYearId,
      semesterId: filter.semesterId,
    });
  }, [filter.schoolYearId, filter.semesterId]);

  const handleFilterChange = (partial) => {
    const next = { ...filter, ...partial };

    setFieldValue("filter", next);
  };

  const selectedClass = useMemo(() => {
    if (!filter.classId) return null;
    return (
      classes.find((c) => `${c.classId}` === `${filter.classId}`) || null
    );
  }, [classes, filter.classId]);

  const isSchoolView = !filter.classId;

  return (
    <ContainerStyled>
      <AppHeader componentName="AdministrationTimeable" isHiddenBtn />

      <Filter
        academicYears={academicYears}
        semesters={semesters}
        classOptions={classOptions}
        filter={filter}
        onChange={handleFilterChange}
      />

      <SummaryBar>
        <SummaryChip>
          {classes.length} lớp
        </SummaryChip>
        {hasUnassigned ? (
          <SummaryChip $tone="warn">
            {unassignedSlots.length} tiết chưa gán lớp
          </SummaryChip>
        ) : null}
        {!isSchoolView && selectedClass ? (
          <SummaryChip>Đang xem: {selectedClass.className}</SummaryChip>
        ) : (
          <SummaryChip>Đang xem: Toàn trường</SummaryChip>
        )}
      </SummaryBar>

      <SectionCard>
        {isSchoolView ? (
          <>
            <SectionTitle>
              Thời khóa biểu tổng quan toàn trường
            </SectionTitle>
            <SchoolOverview
              classes={classes}
              unassignedScheduleData={unassignedScheduleData}
              hasUnassigned={hasUnassigned}
              fetched={fetched}
            />
          </>
        ) : (
          <>
            <SectionTitle>
              Thời khóa biểu lớp {selectedClass?.className || ""}
              {selectedClass?.homeroomTeacherName
                ? ` · GVCN: ${selectedClass.homeroomTeacherName}`
                : ""}
            </SectionTitle>
            <TimetableBoard
              scheduleData={selectedClass?.scheduleData || {}}
              fetched={fetched}
              emptyDescription="Không có dữ liệu thời khóa biểu lớp này"
            />
          </>
        )}
      </SectionCard>
    </ContainerStyled>
  );
};

export default AdministrationTimetableMain;
