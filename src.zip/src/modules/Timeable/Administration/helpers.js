import {
  convertSlotsTimetableToNested,
  daysOfWeek,
  getMaxPeriods,
  mapClassInfoFromTimetable,
} from "components/Timetable/helpers";
import { VPB_THEMES } from "utils/configs";

export const UNASSIGNED_COLUMN_ID = "__unassigned__";

export const buildDefaultFilter = () => ({
  schoolYearId: "",
  semesterId: "",
  classId: "",
});

/** Năm học mặc định = năm đầu; học kỳ = học kỳ đầu của năm đang chọn */
export const resolveYearSemesterFilter = (
  filter = {},
  academicYears = [],
  semesters = [],
) => {
  const next = { ...filter };
  let changed = false;

  if (!next.schoolYearId && academicYears.length) {
    next.schoolYearId = academicYears[0].id;
    changed = true;
  }

  if (next.schoolYearId && semesters.length) {
    const matched = semesters.filter(
      (item) => `${item.schoolYearId}` === `${next.schoolYearId}`,
    );
    if (matched.length) {
      const stillValid = matched.some(
        (item) => `${item.id}` === `${next.semesterId}`,
      );
      if (!stillValid) {
        next.semesterId = matched[0].id;
        changed = true;
      }
    }
  }

  return changed ? next : null;
};

export const mapSchoolClassItem = (item = {}) => {
  const classInfo = mapClassInfoFromTimetable(item);
  const scheduleData = convertSlotsTimetableToNested(item);
  return {
    classId: classInfo.classId,
    className: classInfo.className || "—",
    homeroomTeacherName: classInfo.homeroomTeacherName || "",
    scheduleData,
    slots: Array.isArray(item?.slots) ? item.slots : [],
  };
};

export const mapSchoolTimetableResponse = (raw = {}) => {
  const classesRaw = Array.isArray(raw?.classes) ? raw.classes : [];
  const unassignedSlots = Array.isArray(raw?.unassignedSlots)
    ? raw.unassignedSlots
    : [];

  const classes = classesRaw
    .map(mapSchoolClassItem)
    .filter((item) => item.classId != null && item.classId !== "");

  const unassignedScheduleData = convertSlotsTimetableToNested({
    slots: unassignedSlots,
  });

  const classOptions = [
    { id: "", name: "Tất cả lớp" },
    ...classes.map((c) => ({
      id: c.classId,
      name: c.className,
    })),
  ];

  return {
    classes,
    unassignedSlots,
    unassignedScheduleData,
    classOptions,
    hasUnassigned: unassignedSlots.length > 0,
  };
};

export const getSchoolMaxPeriods = (
  classes = [],
  unassignedScheduleData = {},
) => {
  let maxMorningPeriods = 0;
  let maxAfternoonPeriods = 0;

  const apply = (scheduleData) => {
    const { maxMorningPeriods: m, maxAfternoonPeriods: a } =
      getMaxPeriods(scheduleData || {});
    if (m > maxMorningPeriods) maxMorningPeriods = m;
    if (a > maxAfternoonPeriods) maxAfternoonPeriods = a;
  };

  classes.forEach((c) => apply(c.scheduleData));
  apply(unassignedScheduleData);

  return { maxMorningPeriods, maxAfternoonPeriods };
};

/**
 * Hàng TKB theo 1 ngày: session divider + các tiết
 */
export const buildDayOverviewRows = (
  dayOffset,
  classes = [],
  unassignedScheduleData = {},
) => {
  const { maxMorningPeriods, maxAfternoonPeriods } = getSchoolMaxPeriods(
    classes,
    unassignedScheduleData,
  );

  const day = daysOfWeek.find((d) => d.offset === dayOffset) || daysOfWeek[0];
  const rows = [];

  const pushSession = (sessionKey, sessionLabel, maxPeriods) => {
    if (maxPeriods <= 0) return;

    rows.push({
      key: `${day.offset}-${sessionKey}-divider`,
      type: "session",
      dayOffset: day.offset,
      dayLabel: day.label,
      sessionKey,
      sessionLabel,
    });

    for (let period = 1; period <= maxPeriods; period += 1) {
      rows.push({
        key: `${day.offset}-${sessionKey}-${period}`,
        type: "period",
        dayOffset: day.offset,
        dayLabel: day.label,
        sessionKey,
        sessionLabel,
        period,
      });
    }
  };

  pushSession("morning", "Buổi sáng", maxMorningPeriods);
  pushSession("afternoon", "Buổi chiều", maxAfternoonPeriods);

  return rows;
};

export const getLessonAt = (scheduleData = {}, dayOffset, period, sessionKey) => {
  return scheduleData?.[dayOffset]?.[period]?.[sessionKey] || null;
};

/** Tone màu pastel + chữ đậm — dễ đọc trên bảng tổng quan */
export const getOverviewLessonTone = (type) => {
  switch (type) {
    case "sport":
      return {
        bg: VPB_THEMES.colors.lessonSport.start,
        border: "#4caf50",
        text: "#1b5e20",
        sub: "#2e7d32",
      };
    case "art":
      return {
        bg: VPB_THEMES.colors.lessonArt.start,
        border: "#fb8c00",
        text: "#e65100",
        sub: "#ef6c00",
      };
    case "special":
      return {
        bg: VPB_THEMES.colors.lessonSpecial.start,
        border: "#8e24aa",
        text: "#4a148c",
        sub: "#6a1b9a",
      };
    default:
      return {
        bg: VPB_THEMES.colors.lessonDefault.start,
        border: VPB_THEMES.colors.primaryBlue,
        text: VPB_THEMES.colors.darkBlue || "#0c4a6e",
        sub: VPB_THEMES.colors.gray[400],
      };
  }
};
