import { Box } from "@mui/material";
import { Text, Title } from "components/Styled";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
`;

export const FilterBar = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 16px 18px;
  border-radius: 16px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  box-shadow: 0 2px 12px rgba(15, 23, 42, 0.04);
`;

export const SummaryBar = styled(Box)`
  display: flex;
  flex-wrap: wrap;
  gap: 8px 12px;
  align-items: center;
`;

export const SummaryChip = styled(Box)`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  color: ${({ $tone }) =>
    $tone === "warn"
      ? VPB_THEMES.colors.orange
      : VPB_THEMES.colors.gray[500]};
  background: ${({ $tone }) =>
    $tone === "warn" ? "rgba(255, 87, 34, 0.08)" : VPB_THEMES.colors.gray[100]};
  border: 1px solid
    ${({ $tone }) =>
      $tone === "warn"
        ? "rgba(255, 87, 34, 0.18)"
        : VPB_THEMES.colors.gray[200]};
`;

export const SectionCard = styled.div`
  background: ${VPB_THEMES.colors.white};
  border-radius: 16px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  box-shadow: 0 2px 12px rgba(15, 23, 42, 0.04);
  padding: 12px 12px 16px;
  overflow: hidden;
`;

export const SectionTitle = styled(Title)`
  margin: 4px 8px 14px;
  font-size: 16px;
`;

export const DayTabs = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 0 8px 14px;
`;

export const DayTab = styled.button`
  min-width: 72px;
  height: 36px;
  padding: 0 14px;
  border-radius: 8px;
  border: 1px solid
    ${({ $active }) =>
      $active ? VPB_THEMES.colors.primaryBlue : VPB_THEMES.colors.gray[200]};
  background: ${({ $active }) =>
    $active ? VPB_THEMES.colors.primaryBlue : VPB_THEMES.colors.white};
  color: ${({ $active }) =>
    $active ? VPB_THEMES.colors.white : VPB_THEMES.colors.gray[500]};
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;

  &:hover {
    border-color: ${VPB_THEMES.colors.primaryBlue};
    color: ${({ $active }) =>
      $active ? VPB_THEMES.colors.white : VPB_THEMES.colors.primaryBlue};
  }
`;

export const OverviewWrapper = styled.div`
  width: 100%;
  overflow: auto;
  max-height: calc(100vh - 300px);
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  background: ${VPB_THEMES.colors.white};
`;

export const OverviewTable = styled.table`
  width: max-content;
  min-width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  font-size: 12px;

  th,
  td {
    border-right: 1px solid ${VPB_THEMES.colors.gray[200]};
    border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
    vertical-align: middle;
  }

  thead th {
    position: sticky;
    top: 0;
    z-index: 3;
    background: ${VPB_THEMES.colors.f0f9ff};
    color: ${VPB_THEMES.colors.gray[500]};
    font-weight: 700;
    padding: 12px 10px;
    text-align: center;
    white-space: nowrap;
    border-bottom: 1px solid rgba(2, 132, 199, 0.16);
  }
`;

export const StickyMetaTh = styled.th`
  position: sticky !important;
  top: 0;
  z-index: 5 !important;
  left: ${({ $left }) => `${$left}px`};
  min-width: ${({ $width }) => `${$width}px`};
  width: ${({ $width }) => `${$width}px`};
  background: ${VPB_THEMES.colors.f0f9ff} !important;
  box-shadow: 1px 0 0 ${VPB_THEMES.colors.gray[200]};
`;

export const StickyMetaTd = styled.td`
  position: sticky;
  left: ${({ $left }) => `${$left}px`};
  z-index: 2;
  min-width: ${({ $width }) => `${$width}px`};
  width: ${({ $width }) => `${$width}px`};
  background: ${VPB_THEMES.colors.white};
  padding: 8px 10px;
  text-align: center;
  font-weight: ${({ $bold }) => ($bold ? 700 : 500)};
  color: ${VPB_THEMES.colors.gray[500]};
  box-shadow: 1px 0 0 ${VPB_THEMES.colors.gray[200]};
`;

export const SessionRow = styled.tr`
  td {
    background: ${VPB_THEMES.colors.gray[100]} !important;
    border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};
    padding: 8px 12px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.02em;
    text-transform: uppercase;
    color: ${VPB_THEMES.colors.gray[400]};
  }
`;

export const PeriodBadge = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.primaryBlue};
  background: ${VPB_THEMES.colors.f0f9ff};
`;

export const PeriodTime = styled.span`
  display: block;
  margin-top: 4px;
  font-size: 10px;
  font-weight: 600;
  line-height: 1.3;
  color: ${VPB_THEMES.colors.secondaryText};
  white-space: nowrap;
`;

export const ClassHeaderCell = styled.th`
  min-width: 140px;
  max-width: 168px;

  .class-name {
    display: block;
    font-size: 13px;
    font-weight: 700;
    color: ${VPB_THEMES.colors.primaryBlue};
  }

  .homeroom {
    display: block;
    margin-top: 3px;
    font-size: 11px;
    font-weight: 500;
    color: ${VPB_THEMES.colors.gray[400]};
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 150px;
  }
`;

export const UnassignedHeaderCell = styled(ClassHeaderCell)`
  background: rgba(255, 87, 34, 0.06) !important;

  .class-name {
    color: ${VPB_THEMES.colors.orange};
  }
`;

export const LessonTd = styled.td`
  min-width: 140px;
  max-width: 168px;
  padding: 6px;
  background: ${VPB_THEMES.colors.white};
`;

export const CompactLesson = styled.button`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 2px;
  width: 100%;
  min-height: 48px;
  padding: 8px 10px;
  border: 1px solid ${({ $border }) => $border || "transparent"};
  border-left-width: 3px;
  border-radius: 8px;
  cursor: pointer;
  text-align: left;
  background: ${({ $bg }) => $bg || VPB_THEMES.colors.f0f9ff};
  transition: box-shadow 0.12s ease, border-color 0.12s ease;

  &:hover {
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);
  }

  &:focus-visible {
    outline: 2px solid ${VPB_THEMES.colors.primaryBlue};
    outline-offset: 1px;
  }
`;

export const CompactSubject = styled(Text)`
  font-size: 12px;
  font-weight: 700;
  line-height: 1.3;
  color: ${({ $color }) => $color || VPB_THEMES.colors.gray[500]};
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

export const CompactTeacher = styled(Text)`
  display: block;
  font-size: 11px;
  font-weight: 500;
  line-height: 1.25;
  color: ${({ $color }) => $color || VPB_THEMES.colors.gray[400]};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
`;

export const EmptyLesson = styled(Box)`
  min-height: 48px;
  border-radius: 8px;
  background: ${VPB_THEMES.colors.gray[100]};
  border: 1px dashed ${VPB_THEMES.colors.gray[200]};
`;

export const ScheduleEmptyWrap = styled(Box)`
  padding: 56px 16px;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const LegendRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px 16px;
  padding: 0 8px 12px;
`;

export const LegendItem = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: ${VPB_THEMES.colors.gray[400]};

  &::before {
    content: "";
    width: 10px;
    height: 10px;
    border-radius: 3px;
    background: ${({ $bg }) => $bg};
    border: 1px solid ${({ $border }) => $border};
  }
`;
