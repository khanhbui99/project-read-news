import { Box } from "@mui/material";
import { Text, Title } from "components/Styled";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

export const InfoCard = styled(Box)`
  position: relative;
  overflow: hidden;
  border-radius: 18px;
  padding: 22px 24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.f0f9ff} 0%,
    #e0f2fe 48%,
    ${VPB_THEMES.colors.white} 100%
  );
  border: 1px solid rgba(2, 132, 199, 0.12);
  box-shadow: 0 8px 24px rgba(2, 62, 138, 0.06);
`;

export const InfoCardTitle = styled(Title)`
  margin-bottom: 16px;
`;

export const InfoCardGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px;
`;

export const InfoCardItem = styled(Box)`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.85);
  border: 1px solid rgba(148, 163, 184, 0.16);
`;

export const InfoCardItemIcon = styled(Box)`
  width: 42px;
  height: 42px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: ${({ color }) => color || VPB_THEMES.colors.primaryBlue};
  background: #e0f2fe;
`;

export const InfoCardItemLabel = styled(Text)`
  display: block;
  margin-bottom: 2px;
`;

export const InfoCardItemValue = styled(Text)`
  display: block;
`;

export const ScheduleSection = styled.div`
  background: ${VPB_THEMES.colors.white};
  border-radius: 16px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  box-shadow: 0 2px 12px rgba(15, 23, 42, 0.04);
  padding: 8px 8px 16px;
  overflow: hidden;
`;
