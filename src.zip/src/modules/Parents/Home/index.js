
const HomeParents = () => {
  return (
    <iframe
      src="/html/parent-home.html"
      sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
      referrerPolicy="no-referrer"
      style={{
        width: "calc(100% + 48px)",
        minHeight: "calc(100vh - 130px + 2.85714rem)",
        marginLeft: -24,
        marginTop: "-2.85714rem",
        border: 0,
      }}
      title="Trang Phụ Huynh"
    />
  );
};

export default HomeParents;