import { Box, Typography, CircularProgress } from "@mui/material";
import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { TOKEN_NAME } from "utils/constants";
import { getAbsoluteUrl } from "utils/helpers";

const ViewFileMain = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const fileUrl = searchParams.get('fileUrl') || location.pathname.split('/view-file/')[1];
  const [pdfUrl, setPdfUrl] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    if (!fileUrl) {
      setError('Không tìm thấy file');
      setLoading(false);
      return;
    }

    const loadPdf = async () => {
      try {
        const decodedFileUrl = decodeURIComponent(fileUrl);
        const absoluteUrl = getAbsoluteUrl(decodedFileUrl);
        const token = localStorage.getItem(TOKEN_NAME);

        const response = await fetch(absoluteUrl, {
          headers: {
            Authorization: token ? `Bearer ${token}` : '',
          },
        });

        if (!response.ok) {
          throw new Error('Không thể tải file');
        }

        const blob = await response.blob();
        
        // Tạo blob URL với type là application/pdf để đảm bảo browser hiển thị PDF
        const pdfBlob = new Blob([blob], { type: 'application/pdf' });
        const blobUrl = URL.createObjectURL(pdfBlob);
        setPdfUrl(blobUrl);
      } catch (err) {
        setError(err.message || 'Lỗi khi tải file');
      } finally {
        setLoading(false);
      }
    };

    loadPdf();

    return () => {
      if (pdfUrl) {
        URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [fileUrl]);

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  if (error || !pdfUrl) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <Typography variant="h6" color="error">
          {error || 'Không tìm thấy file'}
        </Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        width: "100%",
        height: "100vh",
        border: "none",
        overflow: "hidden",
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
      }}
    >
      <embed
        src={`${pdfUrl}#toolbar=1&navpanes=1&scrollbar=1`}
        type="application/pdf"
        style={{
          width: "100%",
          height: "100%",
          border: "none",
        }}
      />
    </Box>
  );
};

export default ViewFileMain;
