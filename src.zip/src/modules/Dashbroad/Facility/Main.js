import BuildIcon from "@mui/icons-material/Build";
import InventoryIcon from "@mui/icons-material/Inventory";
import PersonIcon from "@mui/icons-material/Person";
import ReportProblemIcon from "@mui/icons-material/ReportProblem";
import {
  getAllTeachersAction,
  getExamPeriodCategoryAction,
} from "App/store/actions";
import ColumnChart from "components/Charts/ColumnChart";
import StackColumnChart from "components/Charts/StackColumnChart";
import { mapActorOpt } from "modules/Facility/historyHelpers";
import {
  queryAssetFilterOptsAction,
  setFieldValueStoreActivityLogAction,
  setFieldValueStoreAssetManagementAction,
  setFieldValueStoreFacilityStandardCodeAction,
  setFieldValueStoreRepairTicketAction,
} from "modules/Facility/store/actions";
import {
  ACTIVITY_ACTION_TYPE,
  ASSET_CONDITION,
  ASSET_TABS,
  FACILITY_TABS,
  key as facilityCatalogKey,
} from "modules/Facility/store/constants";
import { useSnackbar } from "notistack";
import PropTypes from "prop-types";
import { useEffect, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import { findMenuByComponentName } from "utils/helpers";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import ChartEmptyState from "../Home/components/ChartEmptyState";
import SimpleColumnChartCard from "../Personnel/components/SimpleColumnChartCard";
import {
  ActiveFilterSummary,
  ASSET_GROUP_OPTIONS,
  buildFilterSummary,
  DASHBOARD_SCREENS,
  ExportButtons,
  getDefaultDateRange,
  useSharedDashboardFilters,
  withDefaultDateRange,
} from "../shared";
import { DASHBOARD_CHART_COLORS, getColumnColor } from "../shared/theme";
import DashboardHeader from "./components/DashboardHeader";
import FacilityStatsCards from "./components/FacilityStatsCards";
import {
  normalizeAssetGroup,
  resolveConditionByLabel,
  resolveOptionValueByLabel,
  resolveTicketStatusByLabel,
} from "./helpers";
import {
  exportFacilityExcelAction,
  exportFacilityWordAction,
  fetchFacilityDashboardAction,
} from "./store/actions";
import { key } from "./store/constants";
import {
  PageWrapper,
  Container,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Grid2,
  Card,
  CardHeader,
  CardTitle,
  CardBody,
} from "./Styled";

const PeriodButtons = ({ value, options, onChange }) => (
  <div style={{ display: "flex", gap: 8 }}>
    {options.map((item) => (
      <button
        key={item.value}
        type="button"
        onClick={() => onChange(item.value)}
        style={{
          border: "none",
          borderRadius: 8,
          padding: "6px 12px",
          cursor: "pointer",
          fontWeight: 700,
          fontSize: 12,
          background:
            value === item.value ? DASHBOARD_CHART_COLORS.primary : "#e2e8f0",
          color: value === item.value ? "#fff" : "#475569",
        }}
      >
        {item.label}
      </button>
    ))}
  </div>
);

PeriodButtons.propTypes = {
  value: PropTypes.string,
  options: PropTypes.array,
  onChange: PropTypes.func,
};

const toChartRows = (data = []) =>
  (Array.isArray(data) ? data : []).map((item, index) => ({
    name: item.name || item.label || "—",
    value: Number(item.value ?? item.count) || 0,
    color: getColumnColor(index),
  }));

const NamedBarChart = ({
  data = [],
  yAxisTitle = "Số lượng",
  horizontal = true,
  onPointClick = null,
}) => {
  const rows = toChartRows(data);
  return (
    <ColumnChart
      data={rows}
      categorieField="name"
      yAxisTitle={yAxisTitle}
      onPointClick={onPointClick}
      series={[
        {
          name: yAxisTitle,
          dataKey: "value",
          color: DASHBOARD_CHART_COLORS.primary,
        },
      ]}
      chartConfig={{
        chart: {
          type: horizontal ? "bar" : "column",
          height: Math.max(320, rows.length * 36),
        },
        plotOptions: {
          series: {
            borderRadius: 6,
            colorByPoint: true,
            colors: rows.map((row) => row.color),
            dataLabels: { enabled: true },
          },
        },
        legend: { enabled: false },
      }}
    />
  );
};

NamedBarChart.propTypes = {
  data: PropTypes.array,
  yAxisTitle: PropTypes.string,
  horizontal: PropTypes.bool,
  onPointClick: PropTypes.func,
};

const AssetsByStatusCard = ({ data = [], onPointClick = null }) => {
  const isEmpty = !Array.isArray(data) || data.length === 0;
  return (
    <Card $delay="0.2s">
      <CardHeader>
        <CardTitle>
          <InventoryIcon />
          Thiết bị theo tình trạng
        </CardTitle>
      </CardHeader>
      <CardBody>
        <ChartEmptyState
          isEmpty={isEmpty}
          description="Chưa có dữ liệu tình trạng thiết bị"
        >
          <StackColumnChart
            data={data}
            categorieField="name"
            yAxisTitle="Số lượng"
            onPointClick={onPointClick}
            series={[
              {
                name: "Bình thường",
                dataKey: "normal",
                color: DASHBOARD_CHART_COLORS.green,
              },
              {
                name: "Cũ",
                dataKey: "old",
                color: DASHBOARD_CHART_COLORS.secondary,
              },
              {
                name: "Hỏng",
                dataKey: "broken",
                color: DASHBOARD_CHART_COLORS.orange,
              },
              {
                name: "Thiếu",
                dataKey: "missing",
                color: DASHBOARD_CHART_COLORS.red,
              },
            ]}
            chartConfig={{ chart: { height: 340 } }}
          />
        </ChartEmptyState>
      </CardBody>
    </Card>
  );
};

AssetsByStatusCard.propTypes = {
  data: PropTypes.array,
  onPointClick: PropTypes.func,
};

const TARGET_MENUS = {
  roomTypes: {
    component: "FacilityStandardCode",
    label: "danh mục chuẩn & mã",
  },
  assets: { component: "FacilityAssetManagement", label: "quản lý tài sản" },
  repairTickets: {
    component: "RepairTicketFacility",
    label: "báo hỏng / sửa chữa",
  },
  borrowHistory: {
    component: "FacilityBorrowHistory",
    label: "lịch sử mượn / trả",
  },
  activityLogs: { component: "FacilityHistory", label: "nhật ký hệ thống" },
};

const Main = () => {
  const history = useHistory();
  const { enqueueSnackbar } = useSnackbar();

  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchFilterOpts = useDispatchRedux(queryAssetFilterOptsAction);
  const fetchDashboard = useDispatchRedux(fetchFacilityDashboardAction);
  const fetchAllTeachers = useDispatchRedux(getAllTeachersAction);
  const setCatalogField = useDispatchRedux(
    setFieldValueStoreFacilityStandardCodeAction,
  );
  const setAssetField = useDispatchRedux(
    setFieldValueStoreAssetManagementAction,
  );
  const setRepairField = useDispatchRedux(setFieldValueStoreRepairTicketAction);
  const setActivityLogField = useDispatchRedux(
    setFieldValueStoreActivityLogAction,
  );
  const exportWord = useDispatchRedux(exportFacilityWordAction);
  const exportExcel = useDispatchRedux(exportFacilityExcelAction);
  const dashboardData = useOneState(key, "dashboardData") || {};
  const teachersOpt = useOneState(injectKey.GLOBAL, "teachersOpt") || [];
  const assetFilterStore = useOneState(facilityCatalogKey, "asset") || {};
  const roomOpt = assetFilterStore.roomOpts || [];
  const assetTypeOpt = assetFilterStore.typeOpts || [];
  const [borrowPeriod, setBorrowPeriod] = useState("month");
  const [brokenMode, setBrokenMode] = useState("unit");

  const { filters, updateFilter } = useSharedDashboardFilters(
    DASHBOARD_SCREENS.FACILITY,
  );

  const examPeriodCategory = useOneState(injectKey.GLOBAL, "examPeriodCategory");
  const academicYears = examPeriodCategory?.academicYears || [];

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchFilterOpts({});
    fetchAllTeachers();
  }, []);

  useEffect(() => {
    if (academicYears.length && !filters.schoolYearId) {
      updateFilter({ schoolYearId: academicYears[0].id });
    }
  }, [academicYears, filters.schoolYearId, updateFilter]);

  useEffect(() => {
    if (!filters.dateFrom || !filters.dateTo) {
      updateFilter(getDefaultDateRange());
    }
  }, [filters.dateFrom, filters.dateTo, updateFilter]);

  useEffect(() => {
    if (!filters.dateFrom || !filters.dateTo) return;
    fetchDashboard({
      schoolYearId: filters.schoolYearId,
      assetGroup: filters.assetGroup,
      roomId: filters.roomIds?.[0],
      assetTypeId: filters.assetTypeIds?.[0],
      dateFrom: filters.dateFrom,
      dateTo: filters.dateTo,
    });
  }, [
    filters.schoolYearId,
    filters.assetGroup,
    filters.roomIds,
    filters.assetTypeIds,
    filters.dateFrom,
    filters.dateTo,
  ]);

  const yearName = useMemo(() => {
    const year = academicYears.find(
      (y) => `${y.id}` === `${filters.schoolYearId}`,
    );
    return year?.name || "";
  }, [academicYears, filters.schoolYearId]);

  const topBrokenData =
    brokenMode === "type"
      ? dashboardData.topBrokenTypes || []
      : dashboardData.topBrokenAssets || dashboardData.topBroken || [];

  const filterSummary = useMemo(
    () =>
      buildFilterSummary(filters, DASHBOARD_SCREENS.FACILITY, {
        yearName,
        roomOptions: roomOpt,
        assetTypeOptions: assetTypeOpt,
      }),
    [filters, yearName, roomOpt, assetTypeOpt],
  );

  const assetGroupLabel = useMemo(
    () =>
      ASSET_GROUP_OPTIONS.find((item) => item.value === filters.assetGroup)
        ?.label || "Tất cả nhóm",
    [filters.assetGroup],
  );

  const actorOpts = useMemo(
    () => (teachersOpt || []).map(mapActorOpt).filter((opt) => opt.value),
    [teachersOpt],
  );

  const resolveMenuPath = (targetKey) => {
    const target = TARGET_MENUS[targetKey];
    const path = target && findMenuByComponentName(target.component)?.url;
    if (!path) {
      enqueueSnackbar(`Bạn không có quyền xem ${target?.label || "màn này"}`, {
        variant: "warning",
      });
      return "";
    }
    return path;
  };

  /** Màn Quản lý tài sản: prefill nhóm / phòng / loại / tình trạng đang xem */
  const goToAssetList = ({ typeName = "", condition = "" } = {}) => {
    const path = resolveMenuPath("assets");
    if (!path) return;

    const assetGroup =
      normalizeAssetGroup(filters.assetGroup) || ASSET_TABS.FIXED;
    const typeId = typeName
      ? resolveOptionValueByLabel(assetTypeOpt, typeName)
      : filters.assetTypeIds?.[0];

    setAssetField("activeTab", assetGroup);
    setAssetField("keyword", "");
    setAssetField("page", 0);
    setAssetField("roomFilter", filters.roomIds?.[0] || "ALL");
    setAssetField("typeFilter", typeId || "ALL");
    setAssetField("conditionFilter", condition || "ALL");
    setAssetField("statusFilter", "ALL");
    history.push({ pathname: path });
  };

  const handleStatCardClick = (cardKey) => {
    if (cardKey === "rooms") {
      const path = resolveMenuPath("roomTypes");
      if (!path) return;
      setCatalogField("activeTab", FACILITY_TABS.ROOM_TYPES);
      history.push({ pathname: path });
      return;
    }
    if (cardKey === "pending") {
      const path = resolveMenuPath("repairTickets");
      if (path) history.push({ pathname: path });
      return;
    }
    if (cardKey === "assets") {
      goToAssetList();
      return;
    }
    if (cardKey === "broken") {
      goToAssetList({ condition: ASSET_CONDITION.BROKEN });
    }
  };

  const handleAssetStatusClick = (typeName, meta = {}) =>
    goToAssetList({
      typeName,
      condition: resolveConditionByLabel(meta?.seriesName),
    });

  const handleAssetTypeClick = (typeName) => goToAssetList({ typeName });

  const handleBorrowerClick = (borrowerName) => {
    const path = resolveMenuPath("borrowHistory");
    if (!path) return;

    const actorAccountId = resolveOptionValueByLabel(actorOpts, borrowerName);
    if (!actorAccountId) {
      enqueueSnackbar("Không tìm thấy người mượn trong danh sách GV-NV", {
        variant: "warning",
      });
      return;
    }

    setActivityLogField("keyword", "");
    setActivityLogField("actorAccountId", actorAccountId);
    setActivityLogField("actionType", "ALL");
    setActivityLogField("page", 0);
    history.push({ pathname: path });
  };

  const handleTicketStatusClick = (statusLabel) => {
    const status = resolveTicketStatusByLabel(statusLabel);
    if (!status) {
      enqueueSnackbar("Không xác định được trạng thái phiếu", {
        variant: "warning",
      });
      return;
    }

    const path = resolveMenuPath("repairTickets");
    if (!path) return;

    setRepairField("keyword", "");
    setRepairField("roomFilter", "ALL");
    setRepairField("statusFilter", status);
    setRepairField("page", 0);
    history.push({ pathname: path });
  };

  /** Nhật ký hệ thống: lọc theo mã thiết bị + hành động báo hỏng */
  const handleTopBrokenClick = (name) => {
    const row = (dashboardData.topBrokenAssets || []).find(
      (item) => item.name === name,
    );
    const assetCode = row?.assetCode;
    if (!assetCode) {
      enqueueSnackbar("Không tìm thấy mã thiết bị để xem lịch sử báo hỏng", {
        variant: "warning",
      });
      return;
    }

    const path = resolveMenuPath("activityLogs");
    if (!path) return;

    setActivityLogField("keyword", assetCode);
    setActivityLogField("actorAccountId", "ALL");
    setActivityLogField("actionType", ACTIVITY_ACTION_TYPE.REPORT_BROKEN);
    setActivityLogField("page", 0);
    history.push({ pathname: path });
  };

  return (
    <PageWrapper>
      <Container>
        <DashboardHeader
          assetGroup={filters.assetGroup}
          roomOpt={roomOpt}
          assetTypeOpt={assetTypeOpt}
          selectedRoomId={filters.roomIds?.[0] || ""}
          selectedAssetTypeId={filters.assetTypeIds?.[0] || ""}
          dateFrom={filters.dateFrom}
          dateTo={filters.dateTo}
          onConfirmFilters={(draft) =>
            updateFilter({
              assetGroup: draft.assetGroup,
              roomIds: draft.roomId ? [draft.roomId] : [],
              assetTypeIds: draft.assetTypeId ? [draft.assetTypeId] : [],
              ...withDefaultDateRange(draft),
            })
          }
        />

        <ActiveFilterSummary
          summary={filterSummary || `Đang xem: ${assetGroupLabel}`}
          actions={
            <ExportButtons
              onExportWord={() =>
                exportWord({
                  assetGroup: filters.assetGroup,
                  roomId: filters.roomIds?.[0],
                  facilityTypeId: filters.assetTypeIds?.[0],
                  dateFrom: filters.dateFrom,
                  dateTo: filters.dateTo,
                })
              }
              onExportExcel={() =>
                exportExcel({
                  assetGroup: filters.assetGroup,
                  roomId: filters.roomIds?.[0],
                  facilityTypeId: filters.assetTypeIds?.[0],
                  dateFrom: filters.dateFrom,
                  dateTo: filters.dateTo,
                })
              }
            />
          }
        />

        <FacilityStatsCards
          data={dashboardData.overview || {}}
          onCardClick={handleStatCardClick}
        />

        <SectionHeader>
          <SectionBadge>TS</SectionBadge>
          <SectionTitle>Tài sản theo tình trạng và loại</SectionTitle>
        </SectionHeader>
        <Grid2>
          <AssetsByStatusCard
            data={dashboardData.assetsByStatus}
            onPointClick={handleAssetStatusClick}
          />
          <SimpleColumnChartCard
            title="Loại thiết bị"
            icon={InventoryIcon}
            data={dashboardData.assetsByType}
            horizontal
            onPointClick={handleAssetTypeClick}
          />
        </Grid2>

        <SectionHeader>
          <SectionBadge>MT</SectionBadge>
          <SectionTitle>Mượn trả thiết bị</SectionTitle>
        </SectionHeader>
        <Grid2>
          <SimpleColumnChartCard
            title="Người mượn thiết bị"
            icon={PersonIcon}
            data={dashboardData.borrowers}
            horizontal
            onPointClick={handleBorrowerClick}
          />
          <Card $delay="0.25s">
            <CardHeader>
              <CardTitle>
                <InventoryIcon />
                Lượt mượn theo loại thiết bị
              </CardTitle>
              <PeriodButtons
                value={borrowPeriod}
                onChange={setBorrowPeriod}
                options={[
                  { value: "month", label: "Tháng" },
                  { value: "semester", label: "Học kỳ" },
                  { value: "year", label: "Năm" },
                ]}
              />
            </CardHeader>
            <CardBody>
              <ChartEmptyState
                isEmpty={
                  !Array.isArray(dashboardData.borrowByType) ||
                  !dashboardData.borrowByType.some(
                    (row) => Number(row.value ?? row.count) > 0,
                  )
                }
                description="Chưa có dữ liệu lượt mượn theo loại"
              >
                <NamedBarChart
                  data={dashboardData.borrowByType}
                  yAxisTitle="Lượt mượn"
                />
              </ChartEmptyState>
            </CardBody>
          </Card>
        </Grid2>

        <SectionHeader>
          <SectionBadge>BH</SectionBadge>
          <SectionTitle>Báo hỏng & sửa chữa</SectionTitle>
        </SectionHeader>
                <Grid2>
          <SimpleColumnChartCard
            title="Tình hình báo hỏng & sửa chữa"
            icon={BuildIcon}
            data={dashboardData.ticketStatus}
            onPointClick={handleTicketStatusClick}
          />
          <Card $delay="0.3s">
            <CardHeader>
              <CardTitle>
                <ReportProblemIcon />
                Thiết bị hay hỏng nhất (Top 5)
              </CardTitle>
              <PeriodButtons
                value={brokenMode}
                onChange={setBrokenMode}
                options={[
                  { value: "unit", label: "Theo đơn vị" },
                  { value: "type", label: "Theo loại" },
                ]}
              />
            </CardHeader>
            <CardBody>
              <ChartEmptyState
                isEmpty={
                  !Array.isArray(topBrokenData) ||
                  !topBrokenData.some(
                    (row) => Number(row.value ?? row.count) > 0,
                  )
                }
                description="Chưa có dữ liệu thiết bị hay hỏng"
              >
                <NamedBarChart
                  data={topBrokenData}
                  yAxisTitle={
                    brokenMode === "type" ? "Số lần" : "Số lần sửa"
                  }
                  onPointClick={
                    brokenMode === "type" ? null : handleTopBrokenClick
                  }
                />
              </ChartEmptyState>
            </CardBody>
          </Card>
        </Grid2>
      </Container>
    </PageWrapper>
  );
};

export default Main;
