import PropTypes from "prop-types";
import { useInjectReducer } from "utils/injectReducer";
import { useInjectSaga } from "utils/injectSaga";
import loadable from "utils/loadable";

import { DashboardPageSkeleton } from "../Home/components/skeletons";
import { key as facilityCatalogKey } from "../../Facility/store/constants";
import facilityReducer from "../../Facility/store/reducer";
import facilitySaga from "../../Facility/store/saga";
import { key } from "./store/constants";
import reducer from "./store/reducer";
import saga from "./store/saga";

const Provider = ({ children }) => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });
  // Dùng lại saga danh mục phòng / loại tài sản của Facility
  useInjectReducer({ key: facilityCatalogKey, reducer: facilityReducer });
  useInjectSaga({ key: facilityCatalogKey, saga: facilitySaga });
  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const FacilityDashboard = loadable(() => import("./Main"), {
  fallback: <DashboardPageSkeleton />,
  provider: Provider,
});

export default FacilityDashboard;
