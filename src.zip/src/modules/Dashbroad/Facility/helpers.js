import {
  ASSET_CONDITION,
  TICKET_STATUS,
} from "modules/Facility/store/constants";

const pickNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  const num = Number(found);
  return Number.isFinite(num) ? num : 0;
};

const pickNullableNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  if (found === undefined) return null;
  const num = Number(found);
  return Number.isFinite(num) ? num : null;
};

const asArray = (value) => (Array.isArray(value) ? value : []);

const mapNamedCountList = (list = []) =>
  asArray(list).map((item) => ({
    name:
      item.name ||
      item.label ||
      item.typeName ||
      item.assetTypeName ||
      item.assetCode ||
      item.fullName ||
      item.borrowerName ||
      item.status ||
      "—",
    value: pickNumber(
      item.value,
      item.count,
      item.total,
      item.y,
      item.times,
      item.repairCount,
    ),
    normal: pickNumber(item.normal, item.ok),
    old: pickNumber(item.old, item.aged),
    broken: pickNumber(item.broken, item.hong),
    missing: pickNumber(item.missing, item.thieu),
  }));

const mapConditionByType = (list = []) =>
  asArray(list).map((item) => ({
    name: item.typeName || item.name || item.label || "—",
    normal: pickNumber(item.normal, item.ok),
    old: pickNumber(item.old, item.aged),
    broken: pickNumber(item.broken, item.hong),
    missing: pickNumber(item.missing, item.thieu),
    value: pickNumber(
      item.count,
      pickNumber(item.normal) +
        pickNumber(item.old) +
        pickNumber(item.broken) +
        pickNumber(item.missing),
    ),
  }));

const REPAIR_STATUS_LABELS = {
  pending: "Chờ xử lý",
  inProgress: "Đang sửa",
  completed: "Hoàn thành",
  rejected: "Từ chối",
};

const mapRepairStatus = (status = {}) => {
  if (Array.isArray(status)) return mapNamedCountList(status);
  if (!status || typeof status !== "object") return [];

  return Object.entries(REPAIR_STATUS_LABELS).map(([key, label]) => ({
    name: label,
    value: pickNumber(status[key]),
  }));
};

/** topBrokenAssets: { assetId, assetCode, roomName, repairCount } */
const mapTopBrokenAssets = (list = []) =>
  asArray(list).map((item) => {
    const code = item.assetCode || item.code || item.label || "";
    const room = item.roomName || item.room || "";
    const name =
      code && room ? `${code} · ${room}` : code || room || item.name || "—";
    return {
      id: item.assetId ?? item.id,
      name,
      assetCode: code,
      roomName: room,
      value: pickNumber(item.repairCount, item.count, item.value),
    };
  });

export const EMPTY_FACILITY_DATA = {
  overview: {
    totalRooms: null,
    roomBreakdown: [],
    totalAssets: null,
    brokenOrMissing: null,
    brokenPercent: null,
    previousBrokenOrMissing: null,
    pendingTickets: null,
    overdueTickets: null,
  },
  assetsByStatus: [],
  assetsByType: [],
  borrowers: [],
  borrowByType: [],
  ticketStatus: [],
  topBrokenAssets: [],
  topBrokenTypes: [],
  topBroken: [],
  filterOptions: {
    rooms: [],
    assetTypes: [],
  },
};

export const normalizeAssetGroup = (value) => {
  if (!value) return "";
  if (value === "FIXED" || value === "TEACHING_DEVICE") return value;
  if (value === "FIXED_ASSET") return "FIXED";
  if (value === "TEACHING_EQUIPMENT") return "TEACHING_DEVICE";
  return "";
};

export const normalizeText = (value = "") =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

const CONDITION_BY_LABEL = {
  [normalizeText("Bình thường")]: ASSET_CONDITION.NORMAL,
  [normalizeText("Cũ")]: ASSET_CONDITION.OLD,
  [normalizeText("Hỏng")]: ASSET_CONDITION.BROKEN,
  [normalizeText("Thiếu")]: ASSET_CONDITION.MISSING,
};

export const resolveConditionByLabel = (label) =>
  CONDITION_BY_LABEL[normalizeText(label)] || "";

const TICKET_STATUS_GROUPS = [
  {
    labels: ["cho xu ly", "cho duyet", "pending", "waiting"],
    status: TICKET_STATUS.WAITING,
  },
  {
    labels: ["dang sua", "dang xu ly", "processing", "in progress"],
    status: TICKET_STATUS.PROCESSING,
  },
  {
    labels: ["hoan thanh", "hoan tat", "completed"],
    status: TICKET_STATUS.COMPLETED,
  },
  {
    labels: ["tu choi", "rejected"],
    status: TICKET_STATUS.REJECTED,
  },
  {
    labels: ["nhap", "draft"],
    status: TICKET_STATUS.DRAFT,
  },
];

/** Nhãn trạng thái trên biểu đồ → status filter của màn Báo hỏng */
export const resolveTicketStatusByLabel = (label) => {
  const normalized = normalizeText(label);
  if (!normalized) return "";
  const group = TICKET_STATUS_GROUPS.find((item) =>
    item.labels.some((text) => normalized.includes(text)),
  );
  return group ? group.status : "";
};

/** Tên hiển thị trên biểu đồ → value option của màn tương ứng */
export const resolveOptionValueByLabel = (options = [], label) => {
  const target = normalizeText(label);
  if (!target) return "";
  const found = asArray(options).find(
    (option) => normalizeText(option?.label ?? option?.name) === target,
  );
  return found?.value ?? "";
};

export const mapFacilityDashboardResponse = (apiData = {}) => {
  const root =
    apiData?.data && typeof apiData.data === "object" ? apiData.data : apiData;

  const headerStats =
    root.headerStats || root.overview || root.summary || root.kpi || {};
  const assetReport = root.assetReport || {};
  const borrowReport = root.borrowReport || {};
  const repairReport = root.repairReport || {};

  const topBrokenAssets = mapTopBrokenAssets(
    repairReport.topBrokenAssets || root.topBrokenAssets || root.mostBroken,
  );
  const topBrokenTypes = mapNamedCountList(
    repairReport.topBrokenDeviceTypes ||
      root.topBrokenDeviceTypes ||
      root.topBrokenTypes,
  );

  return {
    ...EMPTY_FACILITY_DATA,
    overview: {
      ...EMPTY_FACILITY_DATA.overview,
      totalRooms: pickNullableNumber(
        headerStats.totalRooms,
        headerStats.roomCount,
      ),
      roomBreakdown: asArray(
        headerStats.roomBreakdown || headerStats.roomsByType,
      ),
      totalAssets: pickNullableNumber(
        headerStats.totalAssets,
        headerStats.totalQuantity,
      ),
      brokenOrMissing: pickNullableNumber(
        headerStats.brokenOrMissingCount,
        headerStats.brokenOrMissing,
        headerStats.brokenMissing,
      ),
      brokenPercent: pickNullableNumber(
        headerStats.brokenOrMissingPercent,
        headerStats.brokenPercent,
      ),
      previousBrokenOrMissing: pickNullableNumber(
        headerStats.brokenOrMissingCountPrevious,
        headerStats.previousBrokenOrMissing,
      ),
      pendingTickets: pickNullableNumber(
        headerStats.pendingTicketCount,
        headerStats.pendingTickets,
        headerStats.ticketPending,
      ),
      overdueTickets: pickNullableNumber(
        headerStats.overdueTicketCount,
        headerStats.overdueTickets,
      ),
    },
    assetsByStatus: mapConditionByType(
      assetReport.byConditionAndType ||
        root.assetsByStatus ||
        root.assetStatusChart,
    ),
    assetsByType: mapNamedCountList(
      assetReport.byType || root.assetsByType || root.assetTypes,
    ),
    borrowers: mapNamedCountList(
      borrowReport.byBorrower || root.borrowers || root.borrowByPerson,
    ),
    borrowByType: mapNamedCountList(
      borrowReport.byDeviceType || root.borrowByType || root.borrowTypes,
    ),
    ticketStatus: mapRepairStatus(
      repairReport.statusBreakdown || root.ticketStatus || root.ticketsByStatus,
    ),
    topBrokenAssets,
    topBrokenTypes,
    topBroken: topBrokenAssets,
    filterOptions: {
      rooms: asArray(root.filterOptions?.rooms || root.rooms || []).map(
        (r) => ({
          value: r.id ?? r.value ?? r.roomId,
          label: r.name || r.label || r.roomName,
        }),
      ),
      assetTypes: asArray(
        root.filterOptions?.assetTypes ||
          root.filterOptions?.facilityTypes ||
          root.facilityTypes ||
          [],
      ).map((t) => ({
        value: t.id ?? t.value ?? t.facilityTypeId,
        label: t.name || t.label || t.typeName,
      })),
    },
  };
};
