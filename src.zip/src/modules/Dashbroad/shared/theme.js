/** Màu chart đồng bộ theme Dashboard Tổng quan (Home) */
export const DASHBOARD_CHART_COLORS = {
  primary: "#0077be",
  secondary: "#00a8e8",
  teal: "#48cae4",
  green: "#00ad53",
  orange: "#f97316",
  red: "#e10600",
  pink: "#ff6b9d",
  purple: "#667eea",
  yellow: "#ffbb33",
  slate: "#64748b",
};

export const DASHBOARD_COLUMN_PALETTE = [
  DASHBOARD_CHART_COLORS.primary,
  DASHBOARD_CHART_COLORS.secondary,
  DASHBOARD_CHART_COLORS.green,
  DASHBOARD_CHART_COLORS.orange,
  DASHBOARD_CHART_COLORS.purple,
  DASHBOARD_CHART_COLORS.pink,
  DASHBOARD_CHART_COLORS.teal,
  DASHBOARD_CHART_COLORS.red,
];

export const getColumnColor = (index = 0) =>
  DASHBOARD_COLUMN_PALETTE[index % DASHBOARD_COLUMN_PALETTE.length];
