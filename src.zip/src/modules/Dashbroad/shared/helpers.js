import dayjs from "dayjs";
import { DateFormat } from "utils/constants";

import {
  ASSET_GROUP_OPTIONS,
  DEFAULT_SHARED_FILTERS,
  FILTER_LABELS,
  SCREEN_FILTER_KEYS,
} from "./filterConstants";

/** Option «Tất cả» cho select filter (trừ năm học / học kỳ) */
export const withAllOption = (
  options = [],
  { valueKey = "value", labelKey = "label", label = "Tất cả" } = {},
) => {
  const list = Array.isArray(options) ? options : [];
  const hasAll = list.some(
    (item) =>
      item?.[valueKey] === "" ||
      item?.[valueKey] == null ||
      item?.[labelKey] === label,
  );
  if (hasAll) return list;
  return [{ [valueKey]: "", [labelKey]: label }, ...list];
};

/** Multi-select: chọn «Tất cả» (value rỗng) → coi như không lọc */
export const normalizeMultiFilterIds = (value) => {
  const list = [].concat(value || []);
  if (list.some((item) => item === "" || item == null)) return [];
  return list.filter((item) => item !== "" && item != null);
};

/** Chuẩn hóa giá trị DatePicker (dayjs/Date/string) → YYYY-MM-DD */
export const toDateParam = (value) => {
  if (value === undefined || value === null || value === "") return "";
  const parsed = dayjs(value);
  return parsed.isValid() ? parsed.format(DateFormat) : "";
};

/** Mặc định từ ngày / đến ngày = tháng hiện tại */
export const getDefaultDateRange = () => ({
  dateFrom: dayjs().startOf("month").format(DateFormat),
  dateTo: dayjs().endOf("month").format(DateFormat),
});

/** Điền tháng hiện tại cho các ô còn trống */
export const withDefaultDateRange = (partial = {}) => {
  const defaults = getDefaultDateRange();
  return {
    dateFrom: toDateParam(partial.dateFrom) || defaults.dateFrom,
    dateTo: toDateParam(partial.dateTo) || defaults.dateTo,
  };
};

/** Môn chỉ cấp THPT — loại khỏi biểu đồ bộ môn THCS */
const HIGH_SCHOOL_ONLY_SUBJECTS = [
  "công nghệ",
  "giáo dục quốc phòng",
  "gdqp",
  "quốc phòng",
  "an ninh",
];

export const isThcsSubjectName = (name = "") => {
  const normalized = String(name).trim().toLowerCase();
  if (!normalized) return false;
  return !HIGH_SCHOOL_ONLY_SUBJECTS.some((keyword) =>
    normalized.includes(keyword),
  );
};

export const filterThcsSubjects = (list = []) =>
  (Array.isArray(list) ? list : []).filter((item) =>
    isThcsSubjectName(item?.name || item?.subjectName || item?.label || ""),
  );

export const pickFiltersForScreen = (filters = {}, screen) => {
  const allowed = SCREEN_FILTER_KEYS[screen] || [];
  const next = {};
  allowed.forEach((key) => {
    if (filters[key] !== undefined) next[key] = filters[key];
  });
  return next;
};

/** Filter đặc thù màn khác — bỏ im lặng, không snackbar khi đổi màn */
const SILENT_DROPPED_FILTER_KEYS = new Set([
  "semesterId",
  "gradeIds",
  "classIds",
  "subjectIds",
  "assetGroup",
  "roomIds",
  "assetTypeIds",
  "departmentIds",
  "dateFrom",
  "dateTo",
]);

export const getDroppedFilterLabels = (filters = {}, screen) => {
  const allowed = new Set(SCREEN_FILTER_KEYS[screen] || []);
  return Object.keys(filters).filter((key) => {
    if (allowed.has(key)) return false;
    if (SILENT_DROPPED_FILTER_KEYS.has(key)) return false;

    const value = filters[key];
    const defaultValue = DEFAULT_SHARED_FILTERS[key];

    if (Array.isArray(value)) {
      if (!value.length) return false;
      return true;
    }

    // Giá trị mặc định không coi là bộ lọc đang áp dụng
    if (value === defaultValue || value === "" || value == null) return false;
    return Boolean(value);
  });
};

export const formatDroppedFilterMessage = (droppedKeys = []) => {
  if (!droppedKeys.length) return "";
  const labels = droppedKeys.map((key) => FILTER_LABELS[key] || key);
  return `Đã bỏ bộ lọc ${labels.join(", ")} vì màn này không áp dụng`;
};

const formatMultiLabels = (ids = [], options = []) => {
  if (!Array.isArray(ids) || !ids.length) return "";
  const labels = ids
    .map((id) => {
      const opt = options.find((o) => `${o.value ?? o.id}` === `${id}`);
      return opt?.label || opt?.name || id;
    })
    .filter(Boolean);
  return labels.length ? labels.join(", ") : "";
};

export const buildFilterSummary = (
  filters = {},
  screen,
  {
    yearName = "",
    semesterName = "",
    gradeOptions = [],
    classOptions = [],
    subjectOptions = [],
    departmentOptions = [],
    roomOptions = [],
    assetTypeOptions = [],
  } = {},
) => {
  const allowed = SCREEN_FILTER_KEYS[screen] || [];
  const parts = [];

  if (allowed.includes("schoolYearId") && yearName) {
    parts.push(`Năm học ${yearName}`);
  }
  if (allowed.includes("semesterId") && semesterName) {
    parts.push(semesterName);
  }
  if (allowed.includes("gradeIds")) {
    const text = formatMultiLabels(filters.gradeIds, gradeOptions);
    if (text) parts.push(`Khối: ${text}`);
  }
  if (allowed.includes("classIds")) {
    const text = formatMultiLabels(filters.classIds, classOptions);
    if (text) parts.push(`Lớp: ${text}`);
  }
  if (allowed.includes("subjectIds")) {
    const text = formatMultiLabels(filters.subjectIds, subjectOptions);
    if (text) parts.push(`Môn: ${text}`);
  }
  if (allowed.includes("departmentIds")) {
    const text = formatMultiLabels(filters.departmentIds, departmentOptions);
    if (text) parts.push(`Tổ: ${text}`);
  }
  if (allowed.includes("assetGroup") && filters.assetGroup) {
    const group = ASSET_GROUP_OPTIONS.find(
      (o) => o.value === filters.assetGroup,
    );
    if (group) parts.push(`Nhóm: ${group.label}`);
  }
  if (allowed.includes("roomIds")) {
    const text = formatMultiLabels(filters.roomIds, roomOptions);
    if (text) parts.push(`Phòng: ${text}`);
  }
  if (allowed.includes("assetTypeIds")) {
    const text = formatMultiLabels(filters.assetTypeIds, assetTypeOptions);
    if (text) parts.push(`Loại: ${text}`);
  }
  if (
    allowed.includes("dateFrom") &&
    (filters.dateFrom || filters.dateTo)
  ) {
    parts.push(
      `Thời gian: ${filters.dateFrom || "…"} → ${filters.dateTo || "…"}`,
    );
  }

  if (!parts.length) return "";
  return `Đang xem: ${parts.join(" · ")}`;
};

export const AGE_GROUP_ORDER = [
  "Dưới 30",
  "30–39",
  "40–49",
  "50–59",
  "Từ 60",
];

export const normalizeAgeGroupName = (name = "") => {
  const raw = String(name).trim().toLowerCase();
  if (!raw) return name;
  if (raw.includes("dưới") || raw.includes("under") || raw.startsWith("<")) {
    return "Dưới 30";
  }
  if (raw.includes("30") && (raw.includes("39") || raw.includes("40"))) {
    return "30–39";
  }
  if (raw.includes("40") && raw.includes("49")) return "40–49";
  if (raw.includes("50") && raw.includes("59")) return "50–59";
  if (raw.includes("60") || raw.includes("trở lên") || raw.includes("từ")) {
    return "Từ 60";
  }
  return name;
};

export const orderAgeGroups = (list = []) => {
  const mapped = (Array.isArray(list) ? list : []).map((item) => ({
    ...item,
    name: normalizeAgeGroupName(item?.name || item?.label || ""),
    value: Number(item?.value ?? item?.count ?? item?.total) || 0,
  }));

  return AGE_GROUP_ORDER.map((name) => {
    const found = mapped.find((item) => item.name === name);
    return found || { name, value: 0 };
  }).filter((item, _i, arr) => {
    const hasAny = arr.some((row) => row.value > 0);
    return hasAny ? true : true;
  });
};
