import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import { put as dispatch } from "redux-saga/effects";
import * as ApiReq from "services/api.request";

/**
 * Tải file xuất Word/Excel từ dashboard (GET + blob download).
 */
export function* downloadDashboardFileSaga({
  url,
  params = {},
  folderName,
  successMessage = "Xuất file thành công",
}) {
  try {
    yield dispatch(setLoadingAction(true));
    yield ApiReq.download({
      url,
      method: "GET",
      params,
      folderName,
    });
    yield dispatch(
      setMessageByFieldAction("success", { message: successMessage }),
    );
  } catch (err) {
    yield dispatch(
      setMessageByFieldAction(
        "error",
        err?.message || "Xuất file thất bại",
      ),
    );
  } finally {
    yield dispatch(setLoadingAction(false));
  }
}

export const isDashboardSuccessMeta = (meta = {}) =>
  meta?.code === "IL-200" ||
  meta?.code === "LMS-200" ||
  String(meta?.code || "").endsWith("200");
