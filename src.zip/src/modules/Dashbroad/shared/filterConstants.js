export const DASHBOARD_SCREENS = {
  HOME: "home",
  TRAINING: "training",
  PERSONNEL: "personnel",
  FACILITY: "facility",
  PARTY: "party",
};

/** Bộ lọc mỗi màn hỗ trợ (BR-06) */
export const SCREEN_FILTER_KEYS = {
  [DASHBOARD_SCREENS.HOME]: ["schoolYearId"],
  [DASHBOARD_SCREENS.TRAINING]: [
    "schoolYearId",
    "semesterId",
    "gradeIds",
    "classIds",
    "subjectIds",
  ],
  [DASHBOARD_SCREENS.PERSONNEL]: [
    "schoolYearId",
    "departmentIds",
    "dateFrom",
    "dateTo",
  ],
  [DASHBOARD_SCREENS.FACILITY]: [
    "schoolYearId",
    "assetGroup",
    "roomIds",
    "assetTypeIds",
    "dateFrom",
    "dateTo",
  ],
  [DASHBOARD_SCREENS.PARTY]: ["schoolYearId"],
};

export const FILTER_LABELS = {
  schoolYearId: "Năm học",
  semesterId: "Học kỳ",
  gradeIds: "Khối",
  classIds: "Lớp",
  subjectIds: "Môn",
  departmentIds: "Tổ chuyên môn",
  assetGroup: "Nhóm tài sản",
  roomIds: "Phòng",
  assetTypeIds: "Loại tài sản",
  dateFrom: "Từ ngày",
  dateTo: "Đến ngày",
};

export const ASSET_GROUP_OPTIONS = [
  { value: "TEACHING_DEVICE", label: "Thiết bị dạy học" },
  { value: "FIXED", label: "Tài sản cố định" },
];

export const DEFAULT_SHARED_FILTERS = {
  schoolYearId: "",
  semesterId: "",
  gradeIds: [],
  classIds: [],
  subjectIds: [],
  departmentIds: [],
  assetGroup: "",
  roomIds: [],
  assetTypeIds: [],
  dateFrom: "",
  dateTo: "",
};
