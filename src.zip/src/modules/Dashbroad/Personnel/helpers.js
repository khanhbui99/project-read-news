import dayjs from "dayjs";

import { normalizeAgeGroupName } from "../shared/helpers";

const pickNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  const num = Number(found);
  return Number.isFinite(num) ? num : 0;
};

const pickNullableNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  if (found === undefined) return null;
  const num = Number(found);
  return Number.isFinite(num) ? num : null;
};

const asArray = (value) => (Array.isArray(value) ? value : []);

const mapNamedCountList = (list = []) =>
  asArray(list).map((item) => ({
    name:
      item.name ||
      item.label ||
      item.departmentName ||
      item.department ||
      item.yearMonth ||
      item.month ||
      item.status ||
      item.criteriaName ||
      item.fullName ||
      item.teacherName ||
      "—",
    value: pickNumber(
      item.value,
      item.count,
      item.total,
      item.y,
      item.score,
      item.avgScore,
      item.averageScore,
      item.occurrenceCount,
    ),
  }));

/** leaveReport.ranking: { accountId, fullName, department, count } */
const mapLeaveRanking = (list = []) =>
  asArray(list).map((item) => ({
    id: item.accountId ?? item.id,
    name: item.fullName || item.name || item.teacherName || "—",
    department: item.department || item.departmentName || "",
    value: pickNumber(item.count, item.value, item.total),
  }));

const LEAVE_APPROVAL_STATUS_LABELS = {
  approved: "Đã duyệt",
  pendingHead: "Chờ tổ trưởng",
  pendingBoard: "Chờ BGH",
  rejected: "Từ chối",
};

const mapApprovalStatus = (status = {}) => {
  if (Array.isArray(status)) return mapNamedCountList(status);
  if (!status || typeof status !== "object") return [];

  return Object.entries(LEAVE_APPROVAL_STATUS_LABELS).map(([key, label]) => ({
    id: key,
    name: label,
    value: pickNumber(status[key]),
  }));
};

export const PERSONNEL_MENUS = {
  teachers: { component: "ManagementTeachers", label: "danh sách giáo viên" },
  leaveApprove: {
    component: "ApproveLeaveReqTeacher",
    label: "duyệt đơn nghỉ phép",
  },
  leaveBoard: {
    component: "ConfirmAndHistoryLeaveReqTeacher",
    label: "duyệt đơn BGH",
  },
  leaveSchool: {
    component: "BoardLeaveSummaryTeacher",
    label: "đơn nghỉ phép trường",
  },
  emulationBoard: {
    component: "EmulationReport2Teacher",
    label: "bảng thi đua giáo viên",
  },
};

export const LEAVE_PENDING_STATUS_FILTER = "Chờ duyệt";

export const getTeacherGenderLabel = (teacher = {}) => {
  const rawValue = teacher.gender ?? teacher.gioiTinh ?? teacher.sex;
  if (rawValue === 1 || rawValue === "1") return "Nam";
  if (
    rawValue === 0 ||
    rawValue === 2 ||
    rawValue === "0" ||
    rawValue === "2"
  ) {
    return "Nữ";
  }
  const raw = String(rawValue ?? "")
    .trim()
    .toLowerCase();
  if (!raw) return "";
  if (["nam", "male", "m"].includes(raw)) return "Nam";
  if (["nữ", "nu", "female", "f", "nữ giới"].includes(raw)) return "Nữ";
  if (raw.includes("nữ")) return "Nữ";
  if (raw.includes("nam")) return "Nam";
  return "";
};

export const getTeacherDepartmentName = (teacher = {}) => {
  const dept = teacher.department;
  if (dept && typeof dept === "object") {
    return dept.name || dept.label || dept.departmentName || "";
  }
  return (
    teacher.departmentName ||
    teacher.orgName ||
    teacher.unit ||
    (typeof dept === "string" ? dept : "") ||
    ""
  );
};

export const getTeacherBirthDate = (teacher = {}) =>
  teacher.dateOfBirth || teacher.birthDate || teacher.dob || teacher.birthday || "";

export const getTeacherAge = (teacher = {}) => {
  const raw = getTeacherBirthDate(teacher);
  if (!raw) return null;
  const birth = dayjs(raw);
  if (!birth.isValid()) return null;
  const age = dayjs().diff(birth, "year");
  return Number.isFinite(age) && age >= 0 ? age : null;
};

export const getTeacherAgeGroup = (teacher = {}) => {
  const age = getTeacherAge(teacher);
  if (age == null) return "";
  if (age < 30) return "Dưới 30";
  if (age < 40) return "30–39";
  if (age < 50) return "40–49";
  if (age < 60) return "50–59";
  return "Từ 60";
};

export const filterTeachersByGender = (teachers = [], genderLabel = "") => {
  const target = String(genderLabel || "").trim();
  if (!target) return [];
  return (Array.isArray(teachers) ? teachers : []).filter(
    (teacher) => getTeacherGenderLabel(teacher) === target,
  );
};

export const filterTeachersByAgeGroup = (teachers = [], groupName = "") => {
  const target = normalizeAgeGroupName(groupName);
  if (!target) return [];
  return (Array.isArray(teachers) ? teachers : []).filter(
    (teacher) => getTeacherAgeGroup(teacher) === target,
  );
};

export const resolveLeaveStatusMenuKey = (statusId = "", statusName = "") => {
  if (statusId === "pendingHead" || statusName === LEAVE_APPROVAL_STATUS_LABELS.pendingHead) {
    return "leaveApprove";
  }
  if (statusId === "pendingBoard" || statusName === LEAVE_APPROVAL_STATUS_LABELS.pendingBoard) {
    return "leaveBoard";
  }
  return "";
};

export const EMPTY_PERSONNEL_DATA = {
  overview: {
    totalStaff: null,
    departmentCount: null,
    teachingTeachers: null,
    otherStaff: null,
    leaveApprovedCount: null,
    leavePreviousCount: null,
    leavePendingCount: null,
  },
  gender: { male: 0, female: 0 },
  byAgeGroup: [],
  byContractType: [],
  byProfessionalDegree: [],
  byLanguageLevel: [],
  byItLevel: [],
  byTeacherRank: [],
  leaveByDepartment: [],
  leaveByStatus: [],
  leaveTrendByMonth: [],
  leaveRankByPerson: [],
  emulation: {
    schoolAvgScore: null,
    previousSchoolAvgScore: null,
    cityAvgScore: null,
    byDepartment: [],
    topDeductionCriteria: [],
    scoreTable: [],
  },
  filterOptions: {
    departments: [],
  },
};

export const mapPersonnelDashboardResponse = (apiData = {}) => {
  const root =
    apiData?.data && typeof apiData.data === "object" ? apiData.data : apiData;

  const headerStats = root.headerStats || root.overview || root.summary || root.kpi || {};
  const staffStructure = root.staffStructure || {};
  const leaveReport = root.leaveReport || {};
  const emulationReport = root.emulationReport || root.emulation || {};

  const gender =
    staffStructure.genderRatio || root.gender || root.genderRatio || {};

  return {
    ...EMPTY_PERSONNEL_DATA,
    overview: {
      ...EMPTY_PERSONNEL_DATA.overview,
      totalStaff: pickNullableNumber(
        headerStats.totalStaff,
        headerStats.total,
        headerStats.totalCbGvNv,
      ),
      departmentCount: pickNullableNumber(
        headerStats.departmentCount,
        headerStats.totalDepartments,
      ),
      teachingTeachers: pickNullableNumber(
        headerStats.teachingStaff,
        headerStats.teachingTeachers,
        headerStats.teachersTeaching,
      ),
      otherStaff: pickNullableNumber(
        headerStats.otherStaff,
        headerStats.staffOther,
      ),
      leaveApprovedCount: pickNullableNumber(
        headerStats.leaveRequestCount,
        headerStats.leaveApprovedCount,
        headerStats.leaveCount,
      ),
      leavePreviousCount: pickNullableNumber(
        headerStats.leaveRequestCountPrevious,
        headerStats.leavePreviousCount,
      ),
      leavePendingCount: pickNullableNumber(
        headerStats.pendingApprovalCount,
        headerStats.leavePendingCount,
        headerStats.pendingLeave,
      ),
    },
    gender: {
      male: pickNumber(gender.male, gender.nam),
      female: pickNumber(gender.female, gender.nu),
    },
    byAgeGroup: mapNamedCountList(
      staffStructure.ageGroups || root.byAgeGroup || root.ageGroups || root.ageChart,
    ),
    byContractType: mapNamedCountList(
      staffStructure.civilServantGroups ||
        root.byContractType ||
        root.contractTypes,
    ),
    byProfessionalDegree: mapNamedCountList(
      staffStructure.eduDegreeGroups ||
        root.byProfessionalDegree ||
        root.professionalDegrees ||
        root.eduLevels,
    ),
    byLanguageLevel: mapNamedCountList(
      staffStructure.languageLevelGroups ||
        root.byLanguageLevel ||
        root.languageLevels,
    ),
    byItLevel: mapNamedCountList(
      staffStructure.itLevelGroups || root.byItLevel || root.itLevels,
    ),
    byTeacherRank: mapNamedCountList(
      staffStructure.rankGroups || root.byTeacherRank || root.teacherRanks,
    ),
    leaveByDepartment: mapNamedCountList(
      leaveReport.byDepartment ||
        root.leaveByDepartment ||
        root.leaveDepartments,
    ),
    leaveByStatus: mapApprovalStatus(
      leaveReport.approvalStatus || root.leaveByStatus || root.leaveStatuses,
    ),
    leaveTrendByMonth: mapNamedCountList(
      leaveReport.monthlyTrend ||
        root.leaveTrendByMonth ||
        root.leaveByMonth,
    ),
    leaveRankByPerson: mapLeaveRanking(
      leaveReport.ranking || root.leaveRankByPerson || root.leaveByPerson,
    ),
    emulation: {
      ...EMPTY_PERSONNEL_DATA.emulation,
      schoolAvgScore: pickNullableNumber(
        emulationReport.averageScore,
        emulationReport.schoolAvgScore,
        emulationReport.avgScore,
      ),
      previousSchoolAvgScore: pickNullableNumber(
        emulationReport.averageScorePrevious,
        emulationReport.previousSchoolAvgScore,
      ),
      cityAvgScore: pickNullableNumber(
        emulationReport.averageScoreTP,
        emulationReport.cityAvgScore,
        emulationReport.cityScore,
      ),
      byDepartment: mapNamedCountList(
        emulationReport.byDepartment || emulationReport.scoresByDepartment,
      ),
      topDeductionCriteria: mapNamedCountList(
        emulationReport.topDeductedCriteria ||
          emulationReport.topDeductionCriteria ||
          emulationReport.topCriteria,
      ),
      scoreTable: asArray(
        emulationReport.scoreTable || emulationReport.scores,
      ).map((row) => ({
        id: row.accountId ?? row.id,
        name: row.fullName || row.name || row.teacherName || "—",
        department: row.department || row.departmentName || "",
        schoolScore: pickNullableNumber(row.schoolScore, row.score),
        cityScore: pickNullableNumber(row.tpScore, row.cityScore, row.convertedScore),
      })),
    },
    filterOptions: {
      departments: asArray(
        root.filterOptions?.departments || root.departments || [],
      ).map((d) => ({
        value: d.id ?? d.value ?? d.departmentId,
        label: d.name || d.label || d.departmentName,
      })),
    },
  };
};
