import PropTypes from "prop-types";
import { useInjectReducer } from "utils/injectReducer";
import { useInjectSaga } from "utils/injectSaga";
import loadable from "utils/loadable";

import { key } from "./store/constants";
import reducer from "./store/reducer";
import saga from "./store/saga";
import { DashboardPageSkeleton } from "../Home/components/skeletons";

const Provider = ({ children }) => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });
  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const PersonnelDashboard = loadable(() => import("./Main"), {
  fallback: <DashboardPageSkeleton />,
  provider: Provider,
});

export default PersonnelDashboard;
