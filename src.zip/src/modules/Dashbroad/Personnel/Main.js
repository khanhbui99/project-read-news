import CakeIcon from "@mui/icons-material/Cake";
import EventBusyIcon from "@mui/icons-material/EventBusy";
import SchoolIcon from "@mui/icons-material/School";
import TimelineIcon from "@mui/icons-material/Timeline";
import WorkspacePremiumIcon from "@mui/icons-material/WorkspacePremium";
import { getAllTeachersAction, getExamPeriodCategoryAction } from "App/store/actions";
import { useSnackbar } from "notistack";
import { useEffect, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import { findMenuByComponentName } from "utils/helpers";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  ActiveFilterSummary,
  buildFilterSummary,
  DASHBOARD_SCREENS,
  ExportButtons,
  getDefaultDateRange,
  orderAgeGroups,
  useSharedDashboardFilters,
  withDefaultDateRange,
} from "../shared";
import DashboardHeader from "./components/DashboardHeader";
import EmulationSection from "./components/EmulationSection";
import GenderDonutCard from "./components/GenderDonutCard";
import LeaveRankChart from "./components/LeaveRankChart";
import ModalPersonnelTeachers from "./components/ModalPersonnelTeachers";
import PersonnelStatsCards from "./components/PersonnelStatsCards";
import SimpleColumnChartCard from "./components/SimpleColumnChartCard";
import {
  filterTeachersByAgeGroup,
  filterTeachersByGender,
  LEAVE_PENDING_STATUS_FILTER,
  PERSONNEL_MENUS,
  resolveLeaveStatusMenuKey,
} from "./helpers";
import {
  exportPersonnelExcelAction,
  exportPersonnelWordAction,
  fetchPersonnelDashboardAction,
  fetchPersonnelDepartmentOptAction,
} from "./store/actions";
import { key } from "./store/constants";
import {
  PageWrapper,
  Container,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Grid2,
} from "./Styled";

const toIdList = (value) =>
  []
    .concat(value || [])
    .map((item) => (item === "" || item == null ? null : item))
    .filter((item) => item !== null);

const buildFetchPayload = (filters = {}) => ({
  departmentIds: toIdList(filters.departmentIds),
  dateFrom: filters.dateFrom,
  dateTo: filters.dateTo,
});

const Main = () => {
  const history = useHistory();
  const { enqueueSnackbar } = useSnackbar();
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchAllTeachers = useDispatchRedux(getAllTeachersAction);
  const fetchDepartmentOpt = useDispatchRedux(fetchPersonnelDepartmentOptAction);
  const fetchDashboard = useDispatchRedux(fetchPersonnelDashboardAction);
  const exportWord = useDispatchRedux(exportPersonnelWordAction);
  const exportExcel = useDispatchRedux(exportPersonnelExcelAction);
  const dashboardData = useOneState(key, "dashboardData") || {};
  const departmentOpt = useOneState(key, "departmentOpt") || [];
  const teachersOpt = useOneState(injectKey.GLOBAL, "teachersOpt", []);
  const [teacherModal, setTeacherModal] = useState({
    open: false,
    title: "",
    teachers: [],
  });

  const { filters, updateFilter } = useSharedDashboardFilters(
    DASHBOARD_SCREENS.PERSONNEL,
  );

  const examPeriodCategory = useOneState(injectKey.GLOBAL, "examPeriodCategory");
  const academicYears = examPeriodCategory?.academicYears || [];
  const selectedYearId = filters.schoolYearId || "";
  const selectedDepartmentIds = toIdList(filters.departmentIds);

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchAllTeachers();
  }, []);

  useEffect(() => {
    if (academicYears.length && !selectedYearId) {
      updateFilter({ schoolYearId: academicYears[0].id });
    }
  }, [academicYears, selectedYearId, updateFilter]);

  useEffect(() => {
    if (!filters.dateFrom || !filters.dateTo) {
      updateFilter(getDefaultDateRange());
    }
  }, [filters.dateFrom, filters.dateTo, updateFilter]);

  useEffect(() => {
    if (!selectedYearId) return;
    fetchDepartmentOpt({ schoolYearId: selectedYearId });
  }, [selectedYearId]);

  useEffect(() => {
    if (!filters.dateFrom || !filters.dateTo) return;
    fetchDashboard(buildFetchPayload(filters));
  }, [
    selectedDepartmentIds.join(","),
    filters.dateFrom,
    filters.dateTo,
  ]);

  const yearName = useMemo(() => {
    const year = academicYears.find((y) => `${y.id}` === `${selectedYearId}`);
    return year?.name || "";
  }, [academicYears, selectedYearId]);

  const filterSummary = useMemo(
    () =>
      buildFilterSummary(filters, DASHBOARD_SCREENS.PERSONNEL, {
        yearName,
        departmentOptions: departmentOpt,
      }),
    [filters, yearName, departmentOpt],
  );

  const exportPayload = buildFetchPayload(filters);
  const ageData = orderAgeGroups(dashboardData.byAgeGroup || []);

  const goToMenu = (menuKey, state) => {
    const target = PERSONNEL_MENUS[menuKey];
    const path = target && findMenuByComponentName(target.component)?.url;
    if (!path) {
      enqueueSnackbar(`Bạn không có quyền xem ${target?.label || "màn này"}`, {
        variant: "warning",
      });
      return;
    }
    history.push({ pathname: path, state: state || {} });
  };

  const handleStatCardClick = (cardKey) => {
    if (cardKey === "total") {
      goToMenu("teachers");
      return;
    }
    if (cardKey === "leave") {
      goToMenu("leaveBoard");
      return;
    }
    if (cardKey === "pending") {
      goToMenu("leaveBoard", {
        statusName: LEAVE_PENDING_STATUS_FILTER,
      });
    }
  };

  const openTeacherModal = (title, teachers) => {
    if (!teachers.length) {
      enqueueSnackbar("Chưa có dữ liệu giáo viên cho lựa chọn này", {
        variant: "warning",
      });
      return;
    }
    setTeacherModal({ open: true, title, teachers });
  };

  const handleGenderClick = (genderLabel) => {
    openTeacherModal(
      `Nhân sự · ${genderLabel}`,
      filterTeachersByGender(teachersOpt, genderLabel),
    );
  };

  const handleAgeClick = (groupName) => {
    openTeacherModal(
      `Nhân sự · ${groupName}`,
      filterTeachersByAgeGroup(teachersOpt, groupName),
    );
  };

  const handleLeaveStatusClick = (statusLabel) => {
    const row = (dashboardData.leaveByStatus || []).find(
      (item) => item.name === statusLabel,
    );
    const menuKey = resolveLeaveStatusMenuKey(row?.id, statusLabel);
    if (!menuKey) return;
    goToMenu(menuKey);
  };

  const handleLeaveRankClick = (teacherName) => {
    goToMenu("leaveSchool", {
      teacherName,
      fromDate: filters.dateFrom,
      toDate: filters.dateTo,
    });
  };

  const handleEmulationNavigate = () => goToMenu("emulationBoard");

  const handleEmulationDepartmentClick = (departmentName) => {
    goToMenu("emulationBoard", { departmentName });
  };

  return (
    <PageWrapper>
      <Container>
        <DashboardHeader
          academicYearOpt={academicYears}
          departmentOpt={departmentOpt}
          selectedYearId={selectedYearId}
          selectedDepartmentIds={selectedDepartmentIds}
          dateFrom={filters.dateFrom}
          dateTo={filters.dateTo}
          selectedYearName={yearName}
          onConfirmFilters={(draft) =>
            updateFilter({
              schoolYearId: draft.schoolYearId,
              departmentIds: toIdList(draft.departmentIds),
              ...withDefaultDateRange(draft),
            })
          }
        />

        <ActiveFilterSummary
          summary={filterSummary}
          actions={
            <ExportButtons
              onExportWord={() => exportWord(exportPayload)}
              onExportExcel={() => exportExcel(exportPayload)}
            />
          }
        />

        <PersonnelStatsCards
          data={dashboardData.overview || {}}
          onCardClick={handleStatCardClick}
        />

        <SectionHeader>
          <SectionBadge>CC</SectionBadge>
          <SectionTitle>Cơ cấu đội ngũ</SectionTitle>
        </SectionHeader>
        <>
          <Grid2>
            <GenderDonutCard
              data={dashboardData.gender}
              onPointClick={handleGenderClick}
            />
            <SimpleColumnChartCard
              title="Độ tuổi"
              icon={CakeIcon}
              data={ageData}
              onPointClick={handleAgeClick}
            />
          </Grid2>
          <Grid2>
            <SimpleColumnChartCard
              title="Viên chức / Hợp đồng"
              icon={SchoolIcon}
              data={dashboardData.byContractType}
              horizontal
            />
            <SimpleColumnChartCard
              title="Trình độ chuyên môn"
              icon={WorkspacePremiumIcon}
              data={dashboardData.byProfessionalDegree}
              horizontal
            />
          </Grid2>
          <Grid2>
            <SimpleColumnChartCard
              title="Trình độ ngoại ngữ"
              data={dashboardData.byLanguageLevel}
              horizontal
              emptyDescription="Chưa có dữ liệu!"
            />
            <SimpleColumnChartCard
              title="Trình độ tin học"
              data={dashboardData.byItLevel}
              horizontal
              emptyDescription="Chưa có dữ liệu!"
            />
          </Grid2>
          <SimpleColumnChartCard
            title="Hạng chức danh GV THCS"
            data={dashboardData.byTeacherRank}
            emptyDescription="Chưa có dữ liệu!"
          />
        </>

        <SectionHeader>
          <SectionBadge>NP</SectionBadge>
          <SectionTitle>Nghỉ phép</SectionTitle>
        </SectionHeader>
        <>
          <Grid2>
            <SimpleColumnChartCard
              title="Nghỉ phép theo tổ"
              icon={EventBusyIcon}
              data={dashboardData.leaveByDepartment}
              horizontal
            />
            <SimpleColumnChartCard
              title="Tình hình duyệt đơn"
              data={dashboardData.leaveByStatus}
              onPointClick={handleLeaveStatusClick}
            />
          </Grid2>
          <Grid2>
            <SimpleColumnChartCard
              title="Xu hướng nghỉ phép theo tháng"
              icon={TimelineIcon}
              data={dashboardData.leaveTrendByMonth}
            />
            <LeaveRankChart
              data={dashboardData.leaveRankByPerson}
              onPointClick={handleLeaveRankClick}
            />
          </Grid2>
        </>

        <SectionHeader>
          <SectionBadge>TĐ</SectionBadge>
          <SectionTitle>Thi đua giáo viên và nhân viên</SectionTitle>
        </SectionHeader>
                <EmulationSection
                  data={dashboardData.emulation || {}}
                  onAvgClick={handleEmulationNavigate}
                  onDepartmentClick={handleEmulationDepartmentClick}
                  onScoreRowClick={handleEmulationNavigate}
                />
      </Container>

      <ModalPersonnelTeachers
        open={Boolean(teacherModal.open)}
        title={teacherModal.title}
        teachers={teacherModal.teachers}
        onClose={() =>
          setTeacherModal({ open: false, title: "", teachers: [] })
        }
      />
    </PageWrapper>
  );
};

export default Main;
