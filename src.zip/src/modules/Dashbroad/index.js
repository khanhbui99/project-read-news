export { default as HomeDashboard } from "./Home";
export { default as TrainingEffectivenessDashboard } from "./TrainingEffectiveness";
export { default as PartyMemberDashboard } from "./PartyMember";
export { default as PersonnelDashboard } from "./Personnel";
export { default as FacilityDashboard } from "./Facility";
