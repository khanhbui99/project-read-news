import {
  getAllClassesAction,
  getAllTeachersAction,
  getExamPeriodCategoryAction,
} from "App/store/actions";
import { useSnackbar } from "notistack";
import { useEffect, useMemo } from "react";
import { useHistory } from "react-router-dom";
import { findMenuByComponentName } from "utils/helpers";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  ActiveFilterSummary,
  buildFilterSummary,
  DASHBOARD_SCREENS,
  ExportButtons,
  PendingTasksList,
  useSharedDashboardFilters,
} from "../shared";
import ClassGenderChart from "./components/ClassGenderChart";
import DashboardHeader from "./components/DashboardHeader";
import ModalClassDetail from "./components/ModalClassDetail";
import ModalClassesByGrade from "./components/ModalClassesByGrade";
import ModalTeachersBySubject from "./components/ModalTeachersBySubject";
import StatsCards from "./components/StatsCards";
import StudentGenderChart from "./components/StudentGenderChart";
import StudentGradeChart from "./components/StudentGradeChart";
import TeacherQualificationChart from "./components/TeacherQualificationChart";
import TeacherSubjectChart from "./components/TeacherSubjectChart";
import {
  filterTeachersByDepartment,
  resolveClassIdByName,
  resolvePendingTaskMenu,
} from "./helpers";
import {
  exportDashboardExcelAction,
  exportDashboardWordAction,
  fetchClassDetailAction,
  fetchDashboardAction,
  setFieldValueStoreHomeAction,
} from "./store/actions";
import { key } from "./store/constants";
import {
  PageWrapper,
  Container,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Grid2,
} from "./Styled";

const MENU_BY_STAT = {
  classes: { component: "ClassesTeacher", label: "danh sách lớp" },
  teachers: { component: "ManagementTeachers", label: "danh sách giáo viên" },
};

const Main = () => {
  const history = useHistory();
  const { enqueueSnackbar } = useSnackbar();

  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchDashboard = useDispatchRedux(fetchDashboardAction);
  const exportWord = useDispatchRedux(exportDashboardWordAction);
  const exportExcel = useDispatchRedux(exportDashboardExcelAction);
  const fetchClassDetail = useDispatchRedux(fetchClassDetailAction);
  const setFieldValue = useDispatchRedux(setFieldValueStoreHomeAction);
  const fetchAllTeachers = useDispatchRedux(getAllTeachersAction);
  const fetchAllClasses = useDispatchRedux(getAllClassesAction);

  const examPeriodCategory = useOneState(injectKey.GLOBAL, "examPeriodCategory");
  const dashboardData = useOneState(key, "dashboardData") || {};
  const teachersOpt = useOneState(injectKey.GLOBAL, "teachersOpt") || [];
  const classesOpt = useOneState(injectKey.GLOBAL, "classesOpt") || [];
  const teachersModal = useOneState(key, "teachersBySubject") || {
    open: false,
    departmentName: "",
  };
  const classesByGradeModal = useOneState(key, "classesByGrade") || {
    open: false,
    gradeLabel: "",
  };

  const { filters, updateFilter } = useSharedDashboardFilters(
    DASHBOARD_SCREENS.HOME,
  );

  const academicYears = examPeriodCategory?.academicYears || [];
  const selectedYearId = filters.schoolYearId || "";

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchAllTeachers();
    fetchAllClasses();
  }, []);

  useEffect(() => {
    if (academicYears.length && !selectedYearId) {
      updateFilter({ schoolYearId: academicYears[0].id });
    }
  }, [academicYears, selectedYearId, updateFilter]);

  useEffect(() => {
    if (selectedYearId) {
      fetchDashboard({ schoolYearId: selectedYearId });
    }
  }, [selectedYearId]);

  const selectedYearName = useMemo(() => {
    const year = academicYears.find((y) => `${y.id}` === `${selectedYearId}`);
    return year?.name || "";
  }, [academicYears, selectedYearId]);

  const filterSummary = useMemo(
    () =>
      buildFilterSummary(filters, DASHBOARD_SCREENS.HOME, {
        yearName: selectedYearName,
      }),
    [filters, selectedYearName],
  );

  const teachersInModal = useMemo(
    () =>
      filterTeachersByDepartment(teachersOpt, teachersModal.departmentName),
    [teachersOpt, teachersModal.departmentName],
  );

  const classesWithCount = useMemo(() => {
    const countByName = {};
    (dashboardData.studentsByClass || []).forEach((item) => {
      const name = String(item.name || "").trim();
      if (!name) return;
      countByName[name] =
        (Number(item.male) || 0) + (Number(item.female) || 0);
    });
    return (classesOpt || []).map((item) => {
      const className = item.className || item.name || "";
      return {
        ...item,
        totalStudents:
          item.totalStudents ??
          item.studentCount ??
          countByName[className] ??
          null,
      };
    });
  }, [classesOpt, dashboardData.studentsByClass]);

  const handlePendingClick = (item) => {
    const target = resolvePendingTaskMenu(item);
    if (!target) {
      enqueueSnackbar("Chưa cấu hình màn xử lý cho việc này", {
        variant: "warning",
      });
      return;
    }

    if (target.path) {
      history.push({ pathname: target.path });
      return;
    }

    const menuPath = findMenuByComponentName(target.component)?.url;
    if (!menuPath) {
      enqueueSnackbar(`Bạn không có quyền xem ${target.menuLabel}`, {
        variant: "warning",
      });
      return;
    }
    history.push({ pathname: menuPath });
  };

  const handleStatClick = (statKey) => {
    const target = MENU_BY_STAT[statKey];
    if (!target) return;
    const path = findMenuByComponentName(target.component)?.url;
    if (!path) {
      enqueueSnackbar(`Bạn không có quyền xem ${target.label}`, {
        variant: "warning",
      });
      return;
    }
    history.push({ pathname: path });
  };

  const handleClassColumnClick = (categoryName) => {
    const rows = dashboardData.studentsByClass || [];
    const row = rows.find((item) => item.name === categoryName);
    const classId =
      row?.classId || resolveClassIdByName(classesOpt, categoryName);

    if (!classId) {
      enqueueSnackbar("Không tìm thấy lớp để xem chi tiết", {
        variant: "warning",
      });
      return;
    }

    fetchClassDetail({ classId });
  };

  const handleGradeColumnClick = (gradeLabel) => {
    setFieldValue("classesByGrade", {
      open: true,
      gradeLabel: gradeLabel || "",
    });
  };

  const handleCloseClassesByGrade = () => {
    setFieldValue("classesByGrade", {
      open: false,
      gradeLabel: "",
    });
  };

  const handleClassFromGradeClick = (row) => {
    if (!row?.id) {
      enqueueSnackbar("Không tìm thấy lớp để xem học sinh", {
        variant: "warning",
      });
      return;
    }
    fetchClassDetail({ classId: row.id });
  };

  const handleSubjectColumnClick = (departmentName) => {
    setFieldValue("teachersBySubject", {
      open: true,
      departmentName: departmentName || "",
    });
  };

  const handleCloseTeachersModal = () => {
    setFieldValue("teachersBySubject", {
      open: false,
      departmentName: "",
    });
  };

  return (
    <PageWrapper>
      <Container>
        <DashboardHeader
          academicYearOpt={academicYears}
          selectedYearId={selectedYearId}
          onYearChange={(yearId) => updateFilter({ schoolYearId: yearId })}
          selectedYearName={selectedYearName}
        />

        <ActiveFilterSummary
          summary={filterSummary}
          actions={
            <ExportButtons
              disabled={!selectedYearId}
              onExportWord={() =>
                exportWord({ schoolYearId: selectedYearId })
              }
              onExportExcel={() =>
                exportExcel({ schoolYearId: selectedYearId })
              }
            />
          }
        />

        <StatsCards
          data={dashboardData.overview || {}}
          onStatClick={handleStatClick}
        />

        <PendingTasksList
          total={dashboardData.overview?.pendingTasksTotal}
          items={dashboardData.pendingTasks || []}
          onItemClick={handlePendingClick}
        />

        <SectionHeader>
          <SectionBadge>HS</SectionBadge>
          <SectionTitle>Cơ cấu học sinh</SectionTitle>
        </SectionHeader>
        <Grid2>
          <StudentGenderChart data={dashboardData.studentsByGender || {}} />
          <StudentGradeChart
            data={dashboardData.studentsByGrade}
            onPointClick={handleGradeColumnClick}
          />
        </Grid2>
        <ClassGenderChart
          data={dashboardData.studentsByClass}
          onPointClick={handleClassColumnClick}
        />

        <SectionHeader>
          <SectionBadge>GV</SectionBadge>
          <SectionTitle>Cơ cấu giáo viên</SectionTitle>
        </SectionHeader>
        <Grid2>
          <TeacherQualificationChart
            data={dashboardData.teacherQualification || []}
          />
          <TeacherSubjectChart
            data={dashboardData.subjectDistribution}
            onPointClick={handleSubjectColumnClick}
          />
        </Grid2>
      </Container>

      <ModalClassesByGrade
        open={Boolean(classesByGradeModal.open)}
        gradeLabel={classesByGradeModal.gradeLabel}
        classes={classesWithCount}
        onClose={handleCloseClassesByGrade}
        onClassClick={handleClassFromGradeClick}
      />
      <ModalClassDetail />
      <ModalTeachersBySubject
        open={Boolean(teachersModal.open)}
        departmentName={teachersModal.departmentName}
        teachers={teachersInModal}
        onClose={handleCloseTeachersModal}
      />
    </PageWrapper>
  );
};

export default Main;
