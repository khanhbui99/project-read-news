import styled, { keyframes } from "styled-components";

const fadeIn = keyframes`
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
`;

export const PageWrapper = styled.div`
  width: 100%;
  animation: ${fadeIn} 0.6s ease-out;
`;

export const Container = styled.div`
  max-width: 1800px;
  margin: 0 auto;
`;

export const HeroCard = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 24px;
  flex-wrap: wrap;
  padding: 28px 32px;
  margin-bottom: 28px;
  border-radius: 16px;
  background: linear-gradient(135deg, #0077be 0%, #00a8e8 55%, #48cae4 100%);
  box-shadow: 0 8px 32px rgba(0, 119, 190, 0.22);
  animation: ${fadeIn} 0.5s ease-out;

  @media (max-width: 768px) {
    padding: 20px;
  }
`;

export const HeroContent = styled.div`
  display: flex;
  align-items: flex-start;
  gap: 20px;
  flex: 1;
  min-width: 260px;
`;

export const HeroIconWrap = styled.div`
  width: 56px;
  height: 56px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;

  svg {
    font-size: 32px;
    color: white;
  }
`;

export const HeroText = styled.div`
  flex: 1;
`;

export const HeroTitle = styled.h1`
  font-size: 26px;
  font-weight: 700;
  margin: 0 0 8px;
  color: white;
  letter-spacing: -0.02em;

  @media (max-width: 768px) {
    font-size: 22px;
  }
`;

export const HeroSubtitle = styled.p`
  margin: 0;
  font-size: 14px;
  line-height: 1.6;
  color: rgba(255, 255, 255, 0.92);
  max-width: 640px;
`;

export const HeroFilter = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 240px;
  padding: 16px 20px;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.97);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);

  .MuiFormLabel-root,
  label {
    color: #1e293b !important;
  }
`;

export const FilterLabel = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #475569;

  svg {
    font-size: 18px;
    color: #0077be;
  }
`;

export const FilterSelectWrap = styled.div`
  min-width: 220px;
`;

export const SectionHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  margin: 36px 0 20px;
  padding-bottom: 14px;
  border-bottom: 2px solid #e2e8f0;
`;

export const SectionBadge = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 32px;
  height: 32px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 700;
  color: #0077be;
  background: #e0f2fe;
`;

export const SectionTitle = styled.h2`
  font-size: 20px;
  font-weight: 600;
  color: ${(props) => props.theme.colors.textDark};
  margin: 0;
`;

export const StatsScrollWrapper = styled.div`
  margin-bottom: 8px;
  overflow-x: auto;
  overflow-y: hidden;
  -webkit-overflow-scrolling: touch;
  scroll-snap-type: x proximity;
  padding-bottom: 10px;

  &::-webkit-scrollbar {
    height: 6px;
  }

  &::-webkit-scrollbar-track {
    background: ${(props) => props.theme.colors.lightBg};
    border-radius: 3px;
  }

  &::-webkit-scrollbar-thumb {
    background: ${(props) => props.theme.colors.gray["200"]};
    border-radius: 3px;
  }

  &:hover::-webkit-scrollbar-thumb {
    background: ${(props) => props.theme.colors.gray["300"]};
  }
`;

export const StatsScrollTrack = styled.div`
  display: flex;
  gap: 20px;
  width: 100%;
  min-width: 100%;
  padding: 4px 2px;
  box-sizing: border-box;
`;

export const StatCard = styled.div`
  flex: 1 1 0;
  min-width: 220px;
  scroll-snap-align: start;
  background: ${(props) => props.theme.colors.white};
  padding: 24px;
  border-radius: 14px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
  border: 1px solid ${(props) => props.theme.colors.gray["200"]};
  display: flex;
  align-items: center;
  gap: 16px;
  transition: transform 0.25s ease, box-shadow 0.25s ease;
  animation: ${fadeIn} 0.4s ease-out;
  animation-delay: ${(props) => props.$delay || "0s"};
  animation-fill-mode: both;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 28px rgba(0, 119, 190, 0.12);
    border-color: ${(props) => props.theme.colors.eff6ff};
  }
`;

export const StatIcon = styled.div`
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  color: white;
  flex-shrink: 0;
  background: ${(props) => {
    if (props.$type === "blue")
      return "linear-gradient(135deg, #0077be 0%, #00a8e8 100%)";
    if (props.$type === "green")
      return "linear-gradient(135deg, #00ad53 0%, #38d9a9 100%)";
    if (props.$type === "orange")
      return "linear-gradient(135deg, #f97316 0%, #fb923c 100%)";
    if (props.$type === "red")
      return "linear-gradient(135deg, #e10600 0%, #ff6b6b 100%)";
    if (props.$type === "purple")
      return "linear-gradient(135deg, #667eea 0%, #9c27b0 100%)";
    return "linear-gradient(135deg, #0077be 0%, #00a8e8 100%)";
  }};
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
`;

export const StatInfo = styled.div`
  flex: 1;
  min-width: 0;

  h3 {
    font-size: 30px;
    font-weight: 700;
    margin-bottom: 4px;
    color: ${(props) => props.theme.colors.textDark};
    line-height: 1.2;
  }

  p {
    color: ${(props) => props.theme.colors.textDark};
    font-size: 14px;
    font-weight: 600;
    margin: 0;
  }

  span {
    display: block;
    color: ${(props) => props.theme.colors.textLight};
    font-size: 12px;
    margin-top: 6px;
    line-height: 1.4;
    opacity: 0.9;
  }
`;

export const Card = styled.div`
  background: white;
  border-radius: 14px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
  border: 1px solid #f1f5f9;
  margin-bottom: 24px;
  overflow: hidden;
  animation: ${fadeIn} 0.6s ease-out;
  animation-delay: ${(props) => props.$delay || "0s"};
  animation-fill-mode: both;
  transition: all 0.3s ease;

  &:hover {
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    border-color: #e2e8f0;
  }
`;

export const CardHeader = styled.div`
  padding: 20px 24px;
  border-bottom: 1px solid #e8eef3;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: linear-gradient(180deg, #fafbfc 0%, #ffffff 100%);
`;

export const CardTitle = styled.h3`
  font-size: 17px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0;
  color: ${(props) => props.theme.colors.textDark};

  svg {
    color: #0077be;
    font-size: 22px;
  }
`;

export const CardBody = styled.div`
  padding: 24px;
`;

export const ChartContainer = styled.div`
  position: relative;
  height: 350px;

  @media (max-width: 768px) {
    height: 300px;
  }
`;

export const Grid2 = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
  gap: 24px;
  margin-bottom: 24px;

  @media (max-width: 1024px) {
    grid-template-columns: 1fr;
  }
`;

export const DataNote = styled.div`
  margin-top: 16px;
  padding: 12px 16px;
  background: #fff8e1;
  border-radius: 8px;
  border-left: 4px solid #ffbb33;
  font-size: 13px;
  color: #856404;
  line-height: 1.5;
`;
