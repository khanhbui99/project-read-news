const pickNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null);
  return Number(found) || 0;
};

const mapSubjectDistribution = (teacher = {}) => {
  const list =
    teacher.subjectDistribution ||
    teacher.subjectsByCount ||
    teacher.teachersBySubject ||
    teacher.subjectChart ||
    [];

  if (!Array.isArray(list)) return [];

  return list.map((item) => ({
    name: item.name || item.subjectName || item.subject || "",
    y: pickNumber(item.y, item.count, item.total, item.teacherCount, item.value),
  }));
};

const mapTeacherByDepartment = (payload = {}) => {
  const list = payload.byDepartment || [];

  if (!Array.isArray(list)) return [];

  return list
    .map((item) => ({
      name: item.department || item.name || item.subjectName || item.subject || "",
      y: pickNumber(item.count, item.y, item.value, item.teacherCount, item.total),
    }))
    .filter((item) => item.name);
};

const normalizeStudentGradeItem = (item = {}) => ({
  name:
    item.name ||
    item.gradeName ||
    (item.grade !== undefined && item.grade !== null ? `Khối ${item.grade}` : ""),
  value: pickNumber(item.value, item.total, item.count, item.studentCount),
});

const sortClassesByName = (classes = []) =>
  [...classes].sort((a, b) => {
    const parseName = (name = "") => {
      const match = String(name).match(/^(\d+)(.*)$/);
      if (!match) return [0, name];
      return [Number(match[1]), match[2] || ""];
    };
    const [gradeA, classA] = parseName(a.name);
    const [gradeB, classB] = parseName(b.name);
    if (gradeA !== gradeB) return gradeA - gradeB;
    return classA.localeCompare(classB, "vi", { numeric: true });
  });

export const hasStudentGenderData = (data = {}) =>
  pickNumber(data.male) + pickNumber(data.female) > 0;

export const hasStudentGradeData = (data = []) =>
  Array.isArray(data) && data.some((item) => pickNumber(item?.value) > 0);

export const hasClassGenderData = (data = []) =>
  Array.isArray(data) &&
  data.some((item) => pickNumber(item?.male) + pickNumber(item?.female) > 0);

export const hasTeacherQualificationData = (data = []) =>
  Array.isArray(data) &&
  data.some((item) => pickNumber(item?.value, item?.y, item?.count) > 0);

export const hasSubjectDistributionData = (data = []) =>
  Array.isArray(data) && data.some((item) => pickNumber(item?.y) > 0);

const filterThcsSubjectList = (list = []) => {
  const HIGH_SCHOOL_ONLY = [
    "công nghệ",
    "giáo dục quốc phòng",
    "gdqp",
    "quốc phòng",
  ];
  return (Array.isArray(list) ? list : []).filter((item) => {
    const name = String(item?.name || "").toLowerCase();
    if (!name) return false;
    return !HIGH_SCHOOL_ONLY.some((k) => name.includes(k));
  });
};

/** Map API teacher-edu-level.byEduLevel → cột biểu đồ { name, value } */
export const mapTeacherEduLevelResponse = (raw = {}) => {
  const source = raw?.data && typeof raw.data === "object" ? raw.data : raw;
  const list = Array.isArray(source?.byEduLevel)
    ? source.byEduLevel
    : Array.isArray(source)
      ? source
      : [];

  return list
    .map((item) => ({
      name:
        item.eduLevel ||
        item.name ||
        item.label ||
        item.levelName ||
        item.degreeName ||
        "—",
      value: pickNumber(item.count, item.value, item.total, item.y),
    }))
    .filter((item) => item.name);
};

const mapPendingTaskItems = (pendingTasks = {}) => {
  const list = Array.isArray(pendingTasks.items) ? pendingTasks.items : [];

  return list.map((item, index) => ({
    key: String(item.key || item.code || item.type || item.id || index),
    label:
      item.label ||
      item.name ||
      item.title ||
      item.content ||
      item.typeName ||
      "—",
    count: pickNumber(item.count, item.total, item.value, item.pendingCount),
    path: item.path || item.url || item.route || "",
  }));
};

export const mapDashboardResponse = (apiData = {}) => {
  const composite = apiData.compositeIndexGroup || {};
  const student = apiData.studentStructureChartGroup || {};
  const teacher = apiData.teacherStructureChartGroup || {};
  const genderRatio = student.genderRatio || student.gender || {};
  const awardReport = apiData?.awardReport || {};
  const classByGradeReport = apiData?.classByGradeReport || {};
  const teacherByDepartment = apiData?.teacherByDepartment || {};
  const subjectFromDepartment = mapTeacherByDepartment(teacherByDepartment);
  const totalStudent = pickNumber(genderRatio.male) + pickNumber(genderRatio.female);
  const pendingTasks = apiData.pendingTasks || {};
  const pendingTaskItems = mapPendingTaskItems(pendingTasks);
  const pendingTasksTotal = pickNumber(
    apiData.totalPending,
    pendingTasks.totalPending,
    pendingTasks.total,
  );

  const subjectDistribution = filterThcsSubjectList(
    subjectFromDepartment.length
      ? subjectFromDepartment
      : mapSubjectDistribution(teacher),
  );

  const teacherQualification = mapTeacherEduLevelResponse(apiData.teacherEduLevel);

  return {
    overview: {
      totalStudent,
      totalTeachers: pickNumber(composite.totalTeachers),
      totalClasses: pickNumber(classByGradeReport.totalClasses),
      totalAwards: pickNumber(awardReport.totalAwards),
      departmentCount: pickNumber(
        composite.departmentCount,
        composite.totalDepartments,
      ),
      teachersAtYearStart: pickNumber(
        composite.teachersAtYearStart,
        composite.totalTeachersStart,
      ),
      studentsAtYearStart: pickNumber(
        composite.studentsAtYearStart,
        composite.totalStudentsStart,
      ),
      pendingTasksTotal,
      pendingSubtext: "Cần BGH xử lý",
    },
    pendingTasks: pendingTaskItems,
    studentsByGender: {
      male: pickNumber(genderRatio.male),
      female: pickNumber(genderRatio.female),
    },
    studentsByGrade: (student.studentsByGrade || []).map(normalizeStudentGradeItem),
    studentsByClass: sortClassesByName(
      (student.studentsByClass || []).map((item) => ({
        classId: item.classId ?? item.id ?? item.class_id ?? null,
        name: item.className || item.name || "",
        male: pickNumber(item.male),
        female: pickNumber(item.female),
      })),
    ),
    teacherQualification,
    subjectDistribution,
  };
};

const normalizeDept = (value = "") =>
  String(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

/** Lọc GV từ teachersOpt theo tên bộ môn / tổ chuyên môn */
export const filterTeachersByDepartment = (teachers = [], departmentName = "") => {
  const target = normalizeDept(departmentName);
  if (!target) return [];
  return (Array.isArray(teachers) ? teachers : []).filter((teacher) => {
    const dept = normalizeDept(
      teacher.department ||
        teacher.departmentName ||
        teacher.orgName ||
        teacher.unit ||
        "",
    );
    if (!dept) return false;
    return dept === target || dept.includes(target) || target.includes(dept);
  });
};

export const resolveClassIdByName = (classes = [], className = "") => {
  const target = String(className || "").trim().toLowerCase();
  if (!target) return null;
  const found = (Array.isArray(classes) ? classes : []).find((item) => {
    const name = String(item.className || item.name || "").trim().toLowerCase();
    return name === target;
  });
  return found?.id ?? found?.classId ?? null;
};

/**
 * Map việc chờ xử lý → menu component
 * - Đơn nghỉ phép chờ duyệt → ConfirmAndHistoryLeaveReqTeacher
 * - Phiếu báo hỏng chưa xử lý → RepairTicketFacility
 * - Kiến nghị thi đua chờ xử lý → ReportComplaintClassEmulation
 */
export const resolvePendingTaskMenu = (item = {}) => {
  const key = String(item.key || item.code || item.type || "")
    .toLowerCase()
    .trim();
  const label = String(item.label || item.name || item.title || "")
    .toLowerCase()
    .trim();
  const path = String(item.path || item.url || item.route || "").trim();

  if (path) {
    return { path, component: null, menuLabel: item.label || "màn liên quan" };
  }

  const byKey = {
    leave: "ConfirmAndHistoryLeaveReqTeacher",
    leave_pending: "ConfirmAndHistoryLeaveReqTeacher",
    leave_request: "ConfirmAndHistoryLeaveReqTeacher",
    pending_leave: "ConfirmAndHistoryLeaveReqTeacher",
    repair: "RepairTicketFacility",
    repair_ticket: "RepairTicketFacility",
    broken: "RepairTicketFacility",
    facility_repair: "RepairTicketFacility",
    complaint: "ReportComplaintClassEmulation",
    emulation_complaint: "ReportComplaintClassEmulation",
    thi_dua: "ReportComplaintClassEmulation",
    kien_nghi: "ReportComplaintClassEmulation",
  };

  if (byKey[key]) {
    return {
      component: byKey[key],
      menuLabel:
        byKey[key] === "ConfirmAndHistoryLeaveReqTeacher"
          ? "đơn nghỉ phép"
          : byKey[key] === "RepairTicketFacility"
            ? "báo hỏng"
            : "khiếu nại",
    };
  }

  if (/nghỉ phép|leave/.test(label)) {
    return {
      component: "ConfirmAndHistoryLeaveReqTeacher",
      menuLabel: "đơn nghỉ phép",
    };
  }
  if (/báo hỏng|sửa chữa|repair/.test(label)) {
    return {
      component: "RepairTicketFacility",
      menuLabel: "báo hỏng",
    };
  }
  if (/thi đua|khiếu nại|kiến nghị|complaint/.test(label)) {
    return {
      component: "ReportComplaintClassEmulation",
      menuLabel: "khiếu nại",
    };
  }

  return null;
};

/** Lấy số khối từ label «Khối 6» / «6» / tên lớp «6A» */
export const parseGradeNumber = (value = "") => {
  const match = String(value || "").match(/(\d+)/);
  return match ? Number(match[1]) : null;
};

/** Lọc danh sách lớp theo khối */
export const filterClassesByGrade = (classes = [], gradeLabel = "") => {
  const grade = parseGradeNumber(gradeLabel);
  if (grade == null) return [];

  return (Array.isArray(classes) ? classes : [])
    .filter((item) => {
      const itemGrade =
        item.grade != null && item.grade !== ""
          ? Number(item.grade)
          : parseGradeNumber(item.className || item.name);
      return itemGrade === grade;
    })
    .map((item) => ({
      id: item.id ?? item.classId,
      className: item.className || item.name || "—",
      grade: item.grade ?? grade,
      classCode: item.classCode || item.code || "—",
      homeroomTeacherName: item.homeroomTeacherName || "—",
      totalStudents:
        item.totalStudents ??
        item.studentCount ??
        (Array.isArray(item.students) ? item.students.length : null),
    }))
    .sort((a, b) =>
      String(a.className).localeCompare(String(b.className), "vi", {
        numeric: true,
      }),
    );
};
