import { getAllClassesAction, getExamPeriodCategoryAction } from "App/store/actions";
import { useSnackbar } from "notistack";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  ActiveFilterSummary,
  buildFilterSummary,
  DASHBOARD_SCREENS,
  useSharedDashboardFilters,
} from "../shared";
import ClassResultGapChart from "./components/ClassResultGapChart";
import ClassSubjectScoreChart from "./components/ClassSubjectScoreChart";
import DashboardHeader from "./components/DashboardHeader";
import ModalTrainingList from "./components/ModalTrainingList";
import ProgramCompletionChart from "./components/ProgramCompletionChart";
import ResultHeatmapChart from "./components/ResultHeatmapChart";
import StudentAcademicLevelChart from "./components/StudentAcademicLevelChart";
import TrainingFilterActions from "./components/TrainingFilterActions";
import TrainingStatsCards from "./components/TrainingStatsCards";
import {
  buildClassAverageRows,
  buildProgramDetailRows,
  DRILLDOWN_KINDS,
} from "./helpers";
import {
  exportTrainingExcelAction,
  exportTrainingWordAction,
  fetchClassSubjectStudentsAction,
  fetchTrainingEffectivenessAction,
  setFieldValueStoreTrainingAction,
} from "./store/actions";
import { key } from "./store/constants";
import { EMPTY_LIST_MODAL } from "./store/reducer";
import {
  PageWrapper,
  Container,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Grid2,
} from "./Styled";

const toIdList = (value) =>
  []
    .concat(value || [])
    .map((item) => (item === "" || item == null ? null : item))
    .filter((item) => item !== null);

const buildFetchPayload = (filters = {}) => ({
  schoolYearId: filters.schoolYearId,
  semesterId: filters.semesterId,
  gradeIds: toIdList(filters.gradeIds),
  classIds: toIdList(filters.classIds),
  subjectIds: toIdList(filters.subjectIds),
});

const Main = () => {
  const { enqueueSnackbar } = useSnackbar();
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchAllClasses = useDispatchRedux(getAllClassesAction);
  const fetchDashboard = useDispatchRedux(fetchTrainingEffectivenessAction);
  const fetchClassStudents = useDispatchRedux(fetchClassSubjectStudentsAction);
  const setFieldValue = useDispatchRedux(setFieldValueStoreTrainingAction);
  const exportWord = useDispatchRedux(exportTrainingWordAction);
  const exportExcel = useDispatchRedux(exportTrainingExcelAction);

  const examPeriodCategory = useOneState(injectKey.GLOBAL, "examPeriodCategory");
  const classesOpt = useOneState(injectKey.GLOBAL, "classesOpt", []);
  const dashboardData = useOneState(key, "dashboardData") || {};
  const listModal = useOneState(key, "listModal") || EMPTY_LIST_MODAL;
  const isGlobalLoading = useOneState(injectKey.GLOBAL, "isLoading") || false;

  const { filters, updateFilter } = useSharedDashboardFilters(
    DASHBOARD_SCREENS.TRAINING,
  );

  const academicYears = examPeriodCategory?.academicYears || [];
  const allSemesters = examPeriodCategory?.semesters || [];
  const gradeOpt = examPeriodCategory?.grades || [];
  const subjectOpt = examPeriodCategory?.subjects || [];

  const selectedYearId = filters.schoolYearId || "";
  const selectedSemesterId = filters.semesterId || "";
  const selectedGradeIds = toIdList(filters.gradeIds);
  const selectedClassIds = toIdList(filters.classIds);
  const selectedSubjectIds = toIdList(filters.subjectIds);

  const semesterOptions = useMemo(() => {
    if (!selectedYearId) return [];
    return allSemesters.filter(
      (s) => `${s.schoolYearId}` === `${selectedYearId}`,
    );
  }, [allSemesters, selectedYearId]);

  const classOpt = useMemo(() => {
    const list = Array.isArray(classesOpt) ? classesOpt : [];
    if (!selectedGradeIds.length) return list;
    const gradeSet = new Set(selectedGradeIds.map(String));
    return list.filter((item) => {
      const grade =
        item.grade ?? item.gradeId ?? item.khoi ?? item.gradeLevel;
      return gradeSet.has(String(grade));
    });
  }, [classesOpt, selectedGradeIds]);

  const selectedSubjectNames = useMemo(
    () =>
      selectedSubjectIds
        .map((id) => subjectOpt.find((item) => `${item.id}` === `${id}`)?.name)
        .filter(Boolean),
    [subjectOpt, selectedSubjectIds],
  );

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchAllClasses();
  }, []);

  useEffect(() => {
    if (academicYears.length && !selectedYearId) {
      updateFilter({ schoolYearId: academicYears[0].id });
    }
  }, [academicYears, selectedYearId, updateFilter]);

  useEffect(() => {
    if (!selectedYearId) {
      updateFilter({ semesterId: "" });
      return;
    }
    if (!semesterOptions.length) {
      updateFilter({ semesterId: "" });
      return;
    }
    const isCurrentValid = semesterOptions.some(
      (s) => `${s.id}` === `${selectedSemesterId}`,
    );
    if (!isCurrentValid) {
      updateFilter({ semesterId: semesterOptions[0].id });
    }
  }, [selectedYearId, semesterOptions, selectedSemesterId, updateFilter]);

  useEffect(() => {
    if (!selectedClassIds.length) return;
    const validIds = new Set(classOpt.map((item) => String(item.id)));
    const nextClassIds = selectedClassIds.filter((id) =>
      validIds.has(String(id)),
    );
    if (nextClassIds.length !== selectedClassIds.length) {
      updateFilter({ classIds: nextClassIds });
    }
  }, [classOpt, selectedClassIds, updateFilter]);

  useEffect(() => {
    if (selectedYearId && selectedSemesterId) {
      fetchDashboard(buildFetchPayload(filters));
    }
  }, [
    selectedYearId,
    selectedSemesterId,
    selectedGradeIds.join(","),
    selectedClassIds.join(","),
    selectedSubjectIds.join(","),
  ]);

  const selectedYearName = useMemo(() => {
    const year = academicYears.find((y) => `${y.id}` === `${selectedYearId}`);
    return year?.name || "";
  }, [academicYears, selectedYearId]);

  const selectedSemesterName = useMemo(() => {
    const semester = semesterOptions.find(
      (s) => `${s.id}` === `${selectedSemesterId}`,
    );
    return semester?.semesterName || semester?.name || "";
  }, [semesterOptions, selectedSemesterId]);

  const handleRefresh = () => {
    if (!selectedYearId || !selectedSemesterId) return;
    fetchDashboard(buildFetchPayload(filters));
  };

  const exportPayload = buildFetchPayload(filters);
  const canLoad = Boolean(selectedYearId && selectedSemesterId);

  const filterSummary = useMemo(
    () =>
      buildFilterSummary(filters, DASHBOARD_SCREENS.TRAINING, {
        yearName: selectedYearName,
        semesterName: selectedSemesterName,
        gradeOptions: gradeOpt,
        classOptions: classOpt.map((item) => ({
          id: item.id,
          name: item.className || item.name,
        })),
        subjectOptions: subjectOpt,
      }),
    [
      filters,
      selectedYearName,
      selectedSemesterName,
      gradeOpt,
      classOpt,
      subjectOpt,
    ],
  );

  const classScores = dashboardData.classSubjectScores || [];

  const resolveClassId = (className, classId) => {
    if (classId) return classId;
    const found = (Array.isArray(classesOpt) ? classesOpt : []).find(
      (item) =>
        String(item.className || item.name || "") === String(className || ""),
    );
    return found?.id || "";
  };

  const openListModal = ({ kind, title, subtitle, items }) => {
    setFieldValue("listModal", {
      open: true,
      kind,
      title,
      subtitle: subtitle || "",
      loading: false,
      items,
    });
  };

  const closeListModal = () => setFieldValue("listModal", EMPTY_LIST_MODAL);

  const handleAvgCardClick = () => {
    const items = buildClassAverageRows(classScores);
    if (!items.length) {
      enqueueSnackbar("Chưa có dữ liệu điểm trung bình theo lớp", {
        variant: "warning",
      });
      return;
    }
    openListModal({
      kind: DRILLDOWN_KINDS.CLASS_AVG,
      title: "Điểm trung bình theo khối và lớp",
      items,
    });
  };

  const handleClassSubjectClick = (row = {}) => {
    const classId = resolveClassId(row.className, row.classId);
    if (!classId) {
      enqueueSnackbar("Không tìm thấy lớp để xem điểm môn", {
        variant: "warning",
      });
      return;
    }
    const typeSubject =
      subjectOpt.find((item) => `${item.id}` === `${row.subjectId}`)?.type || "";
    fetchClassStudents({
      kind: DRILLDOWN_KINDS.STUDENTS_SCORE,
      title: `Học sinh · ${row.className || ""} · ${row.subjectName || ""}`,
      classId,
      className: row.className,
      subjectId: row.subjectId,
      schoolYearId: selectedYearId,
      semesterId: selectedSemesterId,
      typeSubject,
    });
  };

  const handleProgramClick = (item) => {
    openListModal({
      kind: DRILLDOWN_KINDS.PROGRAM,
      title: `Chương trình · ${item?.subject || ""}`,
      items: buildProgramDetailRows(item),
    });
  };

  const handleGapClick = (gradeLabel) => {
    const items = buildClassAverageRows(classScores, gradeLabel);
    if (!items.length) {
      enqueueSnackbar("Chưa có dữ liệu điểm trung bình lớp trong khối", {
        variant: "warning",
      });
      return;
    }
    openListModal({
      kind: DRILLDOWN_KINDS.CLASS_AVG,
      title: `Điểm trung bình từng lớp · ${gradeLabel}`,
      items,
    });
  };

  return (
    <PageWrapper>
      <Container>
        <DashboardHeader
          academicYearOpt={academicYears}
          semesterOpt={allSemesters}
          gradeOpt={gradeOpt}
          classOpt={Array.isArray(classesOpt) ? classesOpt : []}
          subjectOpt={subjectOpt}
          selectedYearId={selectedYearId}
          selectedSemesterId={selectedSemesterId}
          selectedGradeIds={selectedGradeIds}
          selectedClassIds={selectedClassIds}
          selectedSubjectIds={selectedSubjectIds}
          selectedYearName={selectedYearName}
          selectedSemesterName={selectedSemesterName}
          onConfirmFilters={(draft) =>
            updateFilter({
              schoolYearId: draft.schoolYearId,
              semesterId: draft.semesterId,
              gradeIds: toIdList(draft.gradeIds),
              classIds: toIdList(draft.classIds),
              subjectIds: toIdList(draft.subjectIds),
            })
          }
        />

        <ActiveFilterSummary
          summary={filterSummary}
          actions={
            <TrainingFilterActions
              disabled={!canLoad}
              isRefreshing={isGlobalLoading}
              onRefresh={handleRefresh}
              onExportWord={() => exportWord(exportPayload)}
              onExportExcel={() => exportExcel(exportPayload)}
            />
          }
        />

        <TrainingStatsCards
          data={dashboardData.overview || {}}
          onCardClick={handleAvgCardClick}
        />

        <SectionHeader>
          <SectionBadge>HL</SectionBadge>
          <SectionTitle>Học lực & kết quả theo khối</SectionTitle>
        </SectionHeader>
        <>
          <StudentAcademicLevelChart
            data={dashboardData.studentsByAcademicLevel}
          />
          <ResultHeatmapChart data={dashboardData.resultHeatmap} />
        </>

        <SectionHeader>
          <SectionBadge>ML</SectionBadge>
          <SectionTitle>Điểm môn theo lớp và tiến độ chương trình</SectionTitle>
        </SectionHeader>
        <Grid2>
          <ClassSubjectScoreChart
            data={dashboardData.classSubjectScores || []}
            selectedSubjects={selectedSubjectNames}
            selectedSubjectIds={selectedSubjectIds}
            onPointClick={handleClassSubjectClick}
          />
          <ProgramCompletionChart
            data={dashboardData.programCompletion}
            onItemClick={handleProgramClick}
          />
        </Grid2>

        <SectionHeader>
          <SectionBadge>GD</SectionBadge>
          <SectionTitle>Chênh lệch giữa các lớp</SectionTitle>
        </SectionHeader>
        <ClassResultGapChart
          data={dashboardData.classResultGap}
          onPointClick={handleGapClick}
        />
      </Container>

      <ModalTrainingList
        open={Boolean(listModal.open)}
        kind={listModal.kind}
        title={listModal.title}
        subtitle={listModal.subtitle}
        loading={Boolean(listModal.loading)}
        items={listModal.items || []}
        onClose={closeListModal}
      />
    </PageWrapper>
  );
};

export default Main;
