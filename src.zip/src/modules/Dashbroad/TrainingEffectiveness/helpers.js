export const EMPTY_TRAINING_DATA = {
  overview: {
    averageScore: null,
    previousAverageScore: null,
    academicLevels: {
      excellent: 0,
      good: 0,
      average: 0,
      poor: 0,
    },
  },
  studentsByAcademicLevel: [],
  resultHeatmap: {
    subjects: [],
    subjectIds: [],
    grades: [],
    gradeValues: [],
    data: {},
  },
  programCompletion: [],
  classResultGap: [],
  classSubjectScores: [],
  filterOptions: {
    grades: [],
    classes: [],
    subjects: [],
  },
};

const pickNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  const num = Number(found);
  return Number.isFinite(num) ? num : 0;
};

const pickString = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  return found != null ? String(found) : "";
};

const toPercent = (value) => {
  const num = pickNumber(value);
  if (num > 0 && num <= 1) return Math.round(num * 10000) / 100;
  return num;
};

const asArray = (value) => (Array.isArray(value) ? value : []);

const toCamelCaseKey = (key = "") =>
  key.replace(/_([a-z])/g, (_, char) => char.toUpperCase());

const normalizePayloadKeys = (payload = {}) => {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return payload;
  }

  const normalized = { ...payload };
  Object.entries(payload).forEach(([key, value]) => {
    if (key.includes("_")) {
      normalized[toCamelCaseKey(key)] = value;
    }
  });

  return normalized;
};

const unwrapGroup = (source = {}, keys = []) => {
  for (const key of keys) {
    const group = source?.[key];
    if (!group) continue;
    if (Array.isArray(group)) return group;
    if (typeof group === "object") return group;
  }
  return source;
};

const extractList = (source = {}, listKeys = []) => {
  if (Array.isArray(source)) return source;

  for (const key of listKeys) {
    const value = source?.[key];
    if (Array.isArray(value)) return value;
  }

  if (typeof source === "object" && source !== null) {
    const values = Object.values(source);
    if (values.every((item) => typeof item === "object")) {
      return values;
    }
  }

  return [];
};

const ACADEMIC_KEYS = ["excellent", "good", "average", "poor", "weak"];

export const hasStudentsByAcademicLevelData = (data = []) =>
  Array.isArray(data) &&
  data.some((row) =>
    ACADEMIC_KEYS.some((key) => pickNumber(row?.[key]) > 0),
  );

export const hasResultHeatmapData = (data = {}) => {
  const scores = data?.data || {};
  return (
    Array.isArray(data?.subjects) &&
    data.subjects.length > 0 &&
    Object.values(scores).some(
      (row) =>
        Array.isArray(row) &&
        row.some((v) => v != null && Number.isFinite(Number(v)) && Number(v) > 0),
    )
  );
};

export const hasProgramCompletionData = (data = []) =>
  Array.isArray(data) && data.length > 0;

export const hasClassResultGapData = (data = []) =>
  Array.isArray(data) &&
  data.some(
    (item) =>
      pickNumber(item?.min) > 0 ||
      pickNumber(item?.max) > 0 ||
      pickNumber(item?.avg) > 0,
  );

const mapAcademicLevelRow = (row = {}, index = 0) => ({
  name: pickString(
    row.name,
    row.gradeName,
    row.gradeLabel,
    row.blockName,
    row.label,
    row.grade ? `Khối ${row.grade}` : "",
    `Khối ${index + 6}`,
  ),
  excellent: toPercent(
    pickNumber(
      row.excellent,
      row.excellentPercent,
      row.excellentRate,
      row.tot,
      row.totPercent,
      row.levelExcellent,
      row.goodLevel,
    ),
  ),
  good: toPercent(
    pickNumber(
      row.good,
      row.goodPercent,
      row.goodRate,
      row.kha,
      row.khaPercent,
      row.levelGood,
    ),
  ),
  average: toPercent(
    pickNumber(
      row.average,
      row.averagePercent,
      row.averageRate,
      row.dat,
      row.datPercent,
      row.levelAverage,
      row.pass,
    ),
  ),
  poor: toPercent(
    pickNumber(
      row.poor,
      row.poorPercent,
      row.poorRate,
      row.weak,
      row.weakPercent,
      row.chuaDat,
      row.chuaDatPercent,
      row.levelPoor,
      row.notAchieved,
    ),
  ),
});

const mapObjectGradeAcademicLevels = (obj = {}) =>
  Object.entries(obj).map(([gradeKey, row]) =>
    mapAcademicLevelRow(
      typeof row === "object" ? { ...row, name: row?.name || gradeKey } : {},
      pickNumber(gradeKey.replace(/\D/g, "")) - 6,
    ),
  );

const mapAcademicLevels = (apiData = {}) => {
  const group = unwrapGroup(apiData, [
    "academicPerformanceByGradeChartGroup",
    "studentAcademicLevelChartGroup",
    "studentLevelByGradeChartGroup",
    "studentsByAcademicLevelChartGroup",
    "academicLevelByGradeChartGroup",
    "scoreReportChartGroup",
  ]);

  const list = extractList(group, [
    "studentsByAcademicLevel",
    "academicPerformanceByGrade",
    "studentLevelByGrade",
    "byGrade",
    "academicLevels",
    "items",
    "chartData",
    "data",
    "grades",
  ]);

  if (list.length) {
    return list.map(mapAcademicLevelRow);
  }

  if (group?.grade6 || group?.grade7 || group?.grade8 || group?.grade9) {
    return ["grade6", "grade7", "grade8", "grade9"]
      .filter((key) => group[key])
      .map((key, index) =>
        mapAcademicLevelRow(
          {
            ...group[key],
            name: group[key]?.name || `Khối ${index + 6}`,
          },
          index,
        ),
      );
  }

  const objectList = mapObjectGradeAcademicLevels(
    group?.byGrades || group?.gradeMap || group?.gradeData || {},
  );
  if (objectList.length) return objectList;

  const single = unwrapGroup(apiData, [
    "academicPerformanceChartGroup",
    "academicPerformanceGroup",
  ]);
  const singleList = extractList(single, ["items", "chartData", "data"]);
  if (singleList.length) return singleList.map(mapAcademicLevelRow);

  if (single?.excellent || single?.good || single?.average || single?.weak) {
    return [mapAcademicLevelRow({ ...single, name: "Toàn trường" })];
  }

  return [];
};

const buildHeatmapFromMatrix = (matrix = [], subjects = [], grades = []) => {
  const data = {};
  const subjectNames =
    subjects.length > 0
      ? subjects
      : matrix.map((row) => pickString(row?.subject, row?.subjectName, row?.name));

  subjectNames.forEach((subject, subjectIdx) => {
    const row = matrix[subjectIdx];
    if (Array.isArray(row)) {
      data[subject] = row.map((v) => pickNumber(v));
      return;
    }
    if (row && typeof row === "object") {
      const scores = row.scores || row.values || row.gradeScores || row.data;
      if (Array.isArray(scores)) {
        data[subject] = scores.map((item) =>
          typeof item === "object"
            ? pickNumber(item?.score, item?.avgScore, item?.averageScore, item?.value)
            : pickNumber(item),
        );
      }
    }
  });

  return {
    subjects: subjectNames.filter(Boolean),
    grades,
    data,
  };
};

const buildHeatmapFromRows = (rows = []) => {
  const gradeSet = new Set();
  const data = {};

  rows.forEach((row) => {
    const subject = pickString(row.subject, row.subjectName, row.name);
    if (!subject) return;

    const gradeScores = row.gradeScores || row.scores || row.grades || row.items;
    if (Array.isArray(gradeScores)) {
      data[subject] = gradeScores.map((item) => {
        const gradeName = pickString(
          item.gradeName,
          item.grade,
          item.name,
          item.blockName,
        );
        if (gradeName) gradeSet.add(gradeName);
        return pickNumber(
          item.score,
          item.avgScore,
          item.averageScore,
          item.average,
          item.value,
        );
      });
      return;
    }

    Object.entries(row).forEach(([key, value]) => {
      if (["subject", "subjectName", "name", "id"].includes(key)) return;
      if (typeof value === "number" || typeof value === "string") {
        gradeSet.add(key);
        if (!data[subject]) data[subject] = [];
      }
    });
  });

  const grades = Array.from(gradeSet);
  return { subjects: Object.keys(data), grades, data };
};

const mapResultHeatmap = (apiData = {}) => {
  const group = unwrapGroup(apiData, [
    "averageScoreBySubjectAndGradeChartGroup",
    "scoreHeatmapChartGroup",
    "resultHeatmapChartGroup",
    "subjectGradeScoreChartGroup",
    "heatmapChartGroup",
  ]);

  const subjects = asArray(group.subjects || group.subjectList || group.subjectNames);
  const grades = asArray(
    group.grades ||
      group.gradeList ||
      group.gradeNames ||
      group.blocks ||
      group.columns,
  );
  const matrix = asArray(group.matrix || group.scoreMatrix || group.values);
  const rows = extractList(group, ["rows", "items", "chartData", "data", "subjects"]);

  if (matrix.length) {
    const resolvedGrades =
      grades.length > 0
        ? grades
        : asArray(matrix[0]).map((_, index) => `Khối ${index + 6}`);
    return buildHeatmapFromMatrix(matrix, subjects, resolvedGrades);
  }

  if (rows.length && rows[0]?.gradeScores) {
    return buildHeatmapFromRows(rows);
  }

  const rawData = group.data || group.scores || group.scoreMap || group.heatmap;
  if (rawData && typeof rawData === "object" && !Array.isArray(rawData)) {
    const builtSubjects = subjects.length ? subjects : Object.keys(rawData);
    const data = {};
    builtSubjects.forEach((subject) => {
      const row = rawData[subject];
      if (Array.isArray(row)) {
        data[subject] = row.map((v) => pickNumber(v));
      }
    });
    return {
      subjects: builtSubjects,
      grades,
      data,
    };
  }

  if (Array.isArray(rawData) && rawData.length) {
    return buildHeatmapFromRows(rawData);
  }

  return { subjects: [], grades: [], data: {} };
};

const mapProgramCompletionItem = (item = {}) => {
  const isFullyConfirmed = Boolean(
    item.isFullyConfirmed ??
      item.fullyConfirmed ??
      item.isComplete ??
      item.confirmedComplete ??
      item.fullCompleted ??
      item.isFullCompleted,
  );
  const target = toPercent(pickNumber(item.target, item.targetPercent, item.targetRate, 100)) || 100;
  let actual = toPercent(
    pickNumber(
      item.actual,
      item.actualPercent,
      item.completionRate,
      item.completedPercent,
      item.percent,
      item.progress,
      item.rate,
    ),
  );

  if (isFullyConfirmed) {
    actual = 100;
  }

  return {
    subject: pickString(item.subject, item.subjectName, item.name),
    actual,
    target,
    isFullyConfirmed,
  };
};

const mapProgramCompletion = (apiData = {}) => {
  const group = unwrapGroup(apiData, [
    "curriculumCompletionChartGroup",
    "programCompletionChartGroup",
    "teachingProgramCompletionChartGroup",
    "teachingProgramChartGroup",
    "lessonPlanCompletionChartGroup",
  ]);

  const list = extractList(group, [
    "programCompletion",
    "teachingProgramCompletion",
    "curriculumCompletion",
    "subjects",
    "items",
    "chartData",
    "data",
  ]);

  return list.map(mapProgramCompletionItem).filter((item) => item.subject);
};

const mapClassResultGap = (apiData = {}) => {
  const group = unwrapGroup(apiData, [
    "classScoreGapChartGroup",
    "classResultGapChartGroup",
    "classRangeChartGroup",
    "scoreGapByGradeChartGroup",
    "classScoreRangeChartGroup",
  ]);

  const list = extractList(group, [
    "classResultGap",
    "classRanges",
    "resultGapByGrade",
    "scoreRanges",
    "items",
    "chartData",
    "data",
    "grades",
  ]);

  return list
    .map((item) => ({
      grade: pickString(item.grade, item.gradeName, item.blockName, item.name),
      min: pickNumber(item.min, item.minScore, item.lowestScore, item.minAvg),
      max: pickNumber(item.max, item.maxScore, item.highestScore, item.maxAvg),
      avg: pickNumber(item.avg, item.average, item.avgScore, item.averageScore),
    }))
    .filter((item) => item.grade);
};

export const unwrapScoreReportPayload = (payload = {}) => {
  if (!payload || typeof payload !== "object") return {};

  const normalized = normalizePayloadKeys(payload);

  if (normalized.scoreReportChartGroup) return normalized.scoreReportChartGroup;
  if (normalized.scoreReportGroup) return normalized.scoreReportGroup;
  if (normalized.dashboardScoreReportGroup) {
    return normalized.dashboardScoreReportGroup;
  }

  const hasChartGroup = Object.keys(normalized).some((key) =>
    /chartgroup$/i.test(key),
  );
  if (hasChartGroup) return normalized;

  if (
    normalized.data &&
    typeof normalized.data === "object" &&
    !Array.isArray(normalized.data)
  ) {
    return unwrapScoreReportPayload(normalized.data);
  }

  return normalized;
};

const countToPercent = (count, total) => {
  const safeTotal = pickNumber(total);
  if (safeTotal <= 0) return 0;
  return Math.round((pickNumber(count) / safeTotal) * 1000) / 10;
};

/** academicLevelByGrade: { grade, tot, kha, dat, chuaDat, total } → % theo khối */
const mapAcademicLevelByGradeApi = (list = []) =>
  asArray(list).map((row) => {
    const total = pickNumber(
      row.total,
      pickNumber(row.tot) +
        pickNumber(row.kha) +
        pickNumber(row.dat) +
        pickNumber(row.chuaDat) +
        pickNumber(row.gioi) +
        pickNumber(row.trungBinh) +
        pickNumber(row.yeu),
    );

    return {
      name: `Khối ${row.grade}`,
      excellent: countToPercent(row.tot ?? row.gioi, total),
      good: countToPercent(row.kha, total),
      average: countToPercent(row.dat ?? row.trungBinh, total),
      poor: countToPercent(row.chuaDat ?? row.yeu, total),
    };
  });

/** avgScoreBySubjectAndGrade → heatmap { subjects, subjectIds, grades, gradeValues, data } */
const mapAvgScoreBySubjectAndGradeApi = (list = []) => {
  const items = asArray(list);
  const gradeNumbers = [
    ...new Set(
      items.flatMap((item) =>
        asArray(item.grades).map((g) => pickNumber(g.grade)),
      ),
    ),
  ]
    .filter((grade) => Number.isFinite(grade) && grade > 0)
    .sort((a, b) => a - b);

  const gradeLabels = gradeNumbers.map((grade) => `Khối ${grade}`);
  const subjects = [];
  const subjectIds = [];
  const data = {};

  items.forEach((item) => {
    const subject = pickString(item.subjectName, item.subject, item.name);
    if (!subject) return;

    subjects.push(subject);
    subjectIds.push(item.subjectId ?? item.id ?? null);
    data[subject] = gradeNumbers.map((gradeNum) => {
      const matched = asArray(item.grades).find(
        (g) => pickNumber(g.grade) === gradeNum,
      );
      return matched
        ? pickNumber(matched.avgScore, matched.score, matched.averageScore)
        : null;
    });
  });

  return {
    subjects,
    subjectIds,
    grades: gradeLabels,
    gradeValues: gradeNumbers,
    data,
  };
};

/** curriculumCompletion: { subjectId, subjectName, completionRate } */
const mapCurriculumCompletionApi = (list = []) =>
  asArray(list)
    .map((item) => {
      const rawRate = pickNumber(item.completionRate);
      // API có thể trả 0–1 hoặc 0–100
      const actual = rawRate > 0 && rawRate <= 1 ? rawRate * 100 : rawRate;
      const isFullyConfirmed = Boolean(
        item.isFullyConfirmed ??
          item.fullyConfirmed ??
          item.confirmedComplete ??
          actual >= 100,
      );

      return {
        subjectId: item.subjectId,
        subject: pickString(item.subjectName, item.subject, item.name),
        actual: isFullyConfirmed ? 100 : Math.round(actual * 10) / 10,
        target: 100,
        isFullyConfirmed,
      };
    })
    .filter((item) => item.subject)
    .sort((a, b) => a.subject.localeCompare(b.subject, "vi"));

/** classScoreVarianceByGrade: min/avg/max theo khối */
const mapClassScoreVarianceByGradeApi = (list = []) =>
  asArray(list).map((item) => ({
    grade: `Khối ${item.grade}`,
    min: pickNumber(item.minScore, item.min),
    max: pickNumber(item.maxScore, item.max),
    avg: pickNumber(item.avgScore, item.avg, item.average),
    minClassName: pickString(item.minClassName),
    maxClassName: pickString(item.maxClassName),
    delta: pickNumber(item.delta),
  }));

/** subjectClassRanking → danh sách điểm môn theo lớp */
const mapClassRankingRow = (cls = {}, block = {}, gradeBlock = {}) => ({
  classId: cls.classId ?? cls.id,
  className: pickString(cls.className, cls.name, cls.classId),
  grade: pickNumber(
    gradeBlock.grade,
    block.grade,
    cls.grade,
    cls.gradeName,
  ),
  subjectId: block.subjectId ?? gradeBlock.subjectId ?? cls.subjectId,
  subjectName: pickString(
    block.subjectName,
    gradeBlock.subjectName,
    cls.subjectName,
  ),
  score: pickNumber(cls.avgScore, cls.score, cls.averageScore),
  rank: pickNumber(cls.rank, cls.ranking),
  gradeAvg: pickNumber(
    gradeBlock.gradeAvgScore,
    gradeBlock.gradeAvg,
    block.gradeAvgScore,
    block.gradeAvg,
    cls.gradeAvg,
  ),
});

const mapSubjectClassRankingApi = (list = []) =>
  asArray(list).flatMap((block) => {
    const nestedGrades = asArray(block.grades);
    if (nestedGrades.length) {
      return nestedGrades.flatMap((gradeBlock) =>
        asArray(gradeBlock.classes || gradeBlock.items).map((cls) =>
          mapClassRankingRow(cls, block, gradeBlock),
        ),
      );
    }

    return asArray(block.classes).map((cls) =>
      mapClassRankingRow(cls, block),
    );
  });

const mapSchoolAverageScore = (root = {}) => {
  const schoolAvg = root.schoolAverageScore || {};
  const hasCurrent =
    schoolAvg.current != null ||
    root.averageScore != null ||
    root.overview?.averageScore != null;

  return {
    averageScore: hasCurrent
      ? pickNumber(
          schoolAvg.current,
          root.averageScore,
          root.overview?.averageScore,
        )
      : null,
    previousAverageScore:
      schoolAvg.previous != null ||
      root.previousAverageScore != null ||
      root.overview?.previousAverageScore != null
        ? pickNumber(
            schoolAvg.previous,
            root.previousAverageScore,
            root.overview?.previousAverageScore,
          )
        : null,
  };
};

const mapAcademicLevelPercent = (root = {}) => {
  const percent = root.academicLevelPercent || root.schoolAcademicLevel || {};
  if (
    percent.tot == null &&
    percent.excellent == null &&
    percent.kha == null &&
    percent.good == null
  ) {
    return null;
  }

  // API đã trả sẵn % (vd. tot: 99.95, chuaDat: 0.05) — không scale 0–1
  return {
    excellent: pickNumber(percent.tot ?? percent.excellent ?? 0),
    good: pickNumber(percent.kha ?? percent.good ?? 0),
    average: pickNumber(percent.dat ?? percent.average ?? 0),
    poor: pickNumber(percent.chuaDat ?? percent.poor ?? percent.weak ?? 0),
  };
};

const isScoreReportApiShape = (root = {}) =>
  Boolean(
    root.schoolAverageScore ||
      root.academicLevelPercent ||
      Array.isArray(root.academicLevelByGrade) ||
      Array.isArray(root.avgScoreBySubjectAndGrade) ||
      Array.isArray(root.subjectClassRanking) ||
      Array.isArray(root.curriculumCompletion) ||
      Array.isArray(root.classScoreVarianceByGrade) ||
      Array.isArray(root.scoreVarianceByGrade),
  );

export const DRILLDOWN_KINDS = {
  CLASS_AVG: "CLASS_AVG",
  PROGRAM: "PROGRAM",
  STUDENTS_SCORE: "STUDENTS_SCORE",
};

export const parseGradeNumber = (value = "") => {
  const match = String(value ?? "").match(/(\d+)/);
  return match ? Number(match[1]) : null;
};

export const formatScoreValue = (value, digits = 2) => {
  if (value === null || value === undefined || value === "") return "—";
  const num = Number(value);
  if (!Number.isFinite(num)) return String(value);
  return num.toLocaleString("vi-VN", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
};

const matchGrade = (itemGrade, gradeLabel) => {
  const target = parseGradeNumber(gradeLabel);
  const source = parseGradeNumber(itemGrade);
  return target != null && source != null && target === source;
};

/** Điểm TB từng lớp (gộp môn) — card Điểm TB toàn trường / chênh lệch khối */
export const buildClassAverageRows = (scores = [], gradeLabel = "") => {
  const grouped = new Map();

  asArray(scores)
    .filter((item) => (gradeLabel ? matchGrade(item.grade, gradeLabel) : true))
    .forEach((item) => {
      const key = String(item.classId || item.className || "");
      if (!key) return;
      if (!grouped.has(key)) {
        grouped.set(key, {
          id: item.classId || key,
          classId: item.classId,
          className: item.className || "—",
          grade: item.grade != null ? `Khối ${item.grade}` : "—",
          total: 0,
          count: 0,
        });
      }
      const row = grouped.get(key);
      row.total += pickNumber(item.score);
      row.count += 1;
    });

  return Array.from(grouped.values())
    .map((row) => ({
      ...row,
      score:
        row.count > 0
          ? Math.round((row.total / row.count) * 100) / 100
          : null,
    }))
    .sort((a, b) => {
      const gradeDiff =
        (parseGradeNumber(a.grade) || 0) - (parseGradeNumber(b.grade) || 0);
      if (gradeDiff !== 0) return gradeDiff;
      return String(a.className).localeCompare(String(b.className), "vi", {
        numeric: true,
      });
    });
};

export const buildProgramDetailRows = (item = {}) => {
  if (!item?.subject) return [];
  const actual = pickNumber(item.actual);
  const target = pickNumber(item.target, 100) || 100;
  return [
    {
      id: item.subjectId || item.subject,
      subject: item.subject,
      actual,
      target,
      delta: Math.round((actual - target) * 10) / 10,
      confirmed: item.isFullyConfirmed ? "Đã xác nhận đủ" : "Chưa xác nhận đủ",
    },
  ];
};

export const mapTrainingEffectivenessResponse = (apiData = {}) => {
  const root = unwrapScoreReportPayload(apiData);
  const schoolAvg = mapSchoolAverageScore(root);
  const levelPercents = mapAcademicLevelPercent(root);

  if (isScoreReportApiShape(root)) {
    const studentsByAcademicLevel = mapAcademicLevelByGradeApi(
      root.academicLevelByGrade,
    );

    return {
      overview: {
        averageScore: schoolAvg.averageScore,
        previousAverageScore: schoolAvg.previousAverageScore,
        academicLevels:
          levelPercents ||
          (() => {
            if (!studentsByAcademicLevel.length) {
              return { excellent: 0, good: 0, average: 0, poor: 0 };
            }
            const totals = studentsByAcademicLevel.reduce(
              (acc, row) => {
                acc.excellent += pickNumber(row.excellent);
                acc.good += pickNumber(row.good);
                acc.average += pickNumber(row.average);
                acc.poor += pickNumber(row.poor);
                return acc;
              },
              { excellent: 0, good: 0, average: 0, poor: 0 },
            );
            const sum =
              totals.excellent + totals.good + totals.average + totals.poor ||
              1;
            return {
              excellent: Math.round((totals.excellent / sum) * 1000) / 10,
              good: Math.round((totals.good / sum) * 1000) / 10,
              average: Math.round((totals.average / sum) * 1000) / 10,
              poor: Math.round((totals.poor / sum) * 1000) / 10,
            };
          })(),
      },
      studentsByAcademicLevel,
      resultHeatmap: mapAvgScoreBySubjectAndGradeApi(
        root.avgScoreBySubjectAndGrade,
      ),
      programCompletion: mapCurriculumCompletionApi(root.curriculumCompletion),
      classResultGap: mapClassScoreVarianceByGradeApi(
        root.classScoreVarianceByGrade || root.scoreVarianceByGrade,
      ),
      classSubjectScores: mapSubjectClassRankingApi(root.subjectClassRanking),
      filterOptions: {
        grades: [],
        classes: [],
        subjects: [],
      },
    };
  }

  const overview = root.overview || root.summary || root.kpi || {};
  const academicLevels =
    overview.academicLevels ||
    overview.learningLevels ||
    root.schoolAcademicLevel ||
    {};

  const classSubjectScores = asArray(
    root.classSubjectScores ||
      root.classSubjectAverages ||
      root.avgScoreByClassAndSubject ||
      [],
  ).map((item) => ({
    className: pickString(item.className, item.name, item.class),
    grade: pickString(item.grade, item.gradeName),
    subjectName: pickString(item.subjectName, item.subject),
    subjectId: item.subjectId,
    score: pickNumber(item.score, item.avg, item.average),
    rank: pickNumber(item.rank, item.ranking),
    gradeAvg: pickNumber(item.gradeAvg, item.gradeAverage, item.blockAvg),
  }));

  const mappedLevels = mapAcademicLevels(root);

  const schoolLevelPercents = (() => {
    if (
      academicLevels.excellent != null ||
      academicLevels.tot != null ||
      academicLevels.good != null
    ) {
      return {
        excellent: toPercent(
          academicLevels.excellent ?? academicLevels.tot ?? 0,
        ),
        good: toPercent(academicLevels.good ?? academicLevels.kha ?? 0),
        average: toPercent(academicLevels.average ?? academicLevels.dat ?? 0),
        poor: toPercent(
          academicLevels.poor ??
            academicLevels.weak ??
            academicLevels.chuaDat ??
            0,
        ),
      };
    }

    if (!mappedLevels.length) {
      return { excellent: 0, good: 0, average: 0, poor: 0 };
    }

    const totals = mappedLevels.reduce(
      (acc, row) => {
        acc.excellent += pickNumber(row.excellent);
        acc.good += pickNumber(row.good);
        acc.average += pickNumber(row.average);
        acc.poor += pickNumber(row.poor ?? row.weak);
        return acc;
      },
      { excellent: 0, good: 0, average: 0, poor: 0 },
    );
    const sum =
      totals.excellent + totals.good + totals.average + totals.poor || 1;
    return {
      excellent: Math.round((totals.excellent / sum) * 1000) / 10,
      good: Math.round((totals.good / sum) * 1000) / 10,
      average: Math.round((totals.average / sum) * 1000) / 10,
      poor: Math.round((totals.poor / sum) * 1000) / 10,
    };
  })();

  return {
    studentsByAcademicLevel: mappedLevels,
    resultHeatmap: mapResultHeatmap(root),
    programCompletion: mapProgramCompletion(root),
    classResultGap: mapClassResultGap(root),
    overview: {
      averageScore:
        schoolAvg.averageScore != null
          ? schoolAvg.averageScore
          : overview.averageScore != null
            ? pickNumber(overview.averageScore, overview.avgScore)
            : null,
      previousAverageScore:
        schoolAvg.previousAverageScore != null
          ? schoolAvg.previousAverageScore
          : overview.previousAverageScore != null
            ? pickNumber(
                overview.previousAverageScore,
                overview.prevAvgScore,
                overview.previousAvg,
              )
            : null,
      academicLevels: schoolLevelPercents,
    },
    classSubjectScores,
    filterOptions: {
      grades: asArray(root.gradeOptions || root.grades || []).map((g) => ({
        value: g.id ?? g.value ?? g.grade ?? g.name,
        label: g.name || g.label || `Khối ${g.grade || g.id}`,
      })),
      classes: asArray(root.classOptions || root.classes || []).map((c) => ({
        value: c.id ?? c.value ?? c.classId,
        label: c.name || c.className || c.label,
        gradeId: c.gradeId ?? c.grade ?? c.gradeName,
      })),
      subjects: asArray(root.subjectOptions || root.subjects || []).map((s) => ({
        value: s.id ?? s.value ?? s.subjectId,
        label: s.name || s.subjectName || s.label,
      })),
    },
  };
};
