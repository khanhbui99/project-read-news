import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export {
  PageWrapper,
  Container,
  HeroCard,
  HeroContent,
  HeroIconWrap,
  HeroText,
  HeroTitle,
  HeroSubtitle,
  HeroFilter,
  FilterLabel,
  FilterSelectWrap,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  ChartContainer,
  Grid2,
  DataNote,
} from "../Home/Styled";

export const HeroFiltersGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-width: 240px;

  @media (min-width: 900px) {
    flex-direction: row;
    gap: 16px;
    min-width: 520px;
  }
`;

export const FilterPanel = styled.section`
  margin: 0 0 20px;
  padding: 20px 24px;
  border-radius: 16px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
`;

export const FilterPanelHeader = styled.div`
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 16px;
`;

export const FilterPanelTitle = styled.h2`
  margin: 0;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 800;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  color: ${VPB_THEMES.colors.textDark};

  svg {
    font-size: 18px;
    color: ${VPB_THEMES.colors.primaryBlue};
  }
`;

export const FilterPanelHint = styled.p`
  margin: 0;
  font-size: 13px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
`;

export const FilterGroups = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;

  @media (min-width: 1100px) {
    grid-template-columns: minmax(280px, 0.9fr) minmax(360px, 1.4fr);
    gap: 20px;
  }
`;

export const FilterGroup = styled.div`
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.lightBg};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;

export const FilterGroupTitle = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.primaryBlue};

  svg {
    font-size: 18px;
  }
`;

export const FilterGroupFields = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 12px;
`;

export const FilterField = styled.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
`;

export const FilterFieldLabel = styled.label`
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};

  svg {
    font-size: 16px;
    color: ${VPB_THEMES.colors.primaryBlue};
  }
`;

export const FilterFieldControl = styled.div`
  width: 100%;
  min-width: 0;
`;

export const OverviewGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(${({ $cols }) => $cols || 5}, minmax(0, 1fr));
  gap: 14px;
  margin-bottom: 8px;

  @media (max-width: 900px) {
    grid-template-columns: ${({ $cols }) =>
      $cols === 2 ? "1fr" : "repeat(2, minmax(0, 1fr))"};
  }

  @media (max-width: 520px) {
    grid-template-columns: 1fr;
  }
`;

export const OverviewCard = styled.div`
  position: relative;
  overflow: hidden;
  padding: 20px 22px 18px;
  border-radius: 14px;
  border: 1px solid ${({ $border }) => $border || VPB_THEMES.colors.gray["200"]};
  background: ${({ $bg }) => $bg || VPB_THEMES.colors.white};
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.04);
  transition: transform 0.2s ease, box-shadow 0.2s ease;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 22px rgba(15, 23, 42, 0.08);
  }
`;

export const OverviewCardTop = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 8px;
`;

export const OverviewCardLabel = styled.div`
  font-size: 13px;
  font-weight: 800;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  color: ${VPB_THEMES.colors.textDark};
  line-height: 1.35;
`;

export const OverviewCardIcon = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: ${VPB_THEMES.colors.white};
  background: ${({ $accent }) => $accent || VPB_THEMES.colors.primaryBlue};
  box-shadow: 0 4px 10px rgba(15, 23, 42, 0.12);

  svg {
    font-size: 20px;
  }
`;

export const OverviewCardValue = styled.div`
  font-size: 34px;
  font-weight: 800;
  line-height: 1.1;
  color: ${({ $accent }) => $accent || VPB_THEMES.colors.textDark};
  letter-spacing: -0.02em;
`;

export const OverviewCardSub = styled.div`
  margin-top: 6px;
  font-size: 12px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
  line-height: 1.4;
`;

export const ToolbarWrap = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  margin-bottom: 28px;
  padding: 14px 20px;
  border-radius: 12px;
  background: white;
  border: 1px solid #e2e8f0;
  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04);
`;

export const ToolbarHint = styled.p`
  margin: 0;
  flex: 1;
  min-width: 200px;
  font-size: 14px;
  line-height: 1.5;
  color: #64748b;
`;

export const ToolbarActions = styled.div`
  display: flex;
  align-items: center;
  flex-shrink: 0;
`;

export const ChartListScroll = styled.div`
  max-height: 320px;
  overflow-y: auto;
  overflow-x: hidden;
  padding-right: 6px;
  margin-bottom: 4px;
  -webkit-overflow-scrolling: touch;

  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  &::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 3px;
  }

  &::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 3px;
  }

  &:hover::-webkit-scrollbar-thumb {
    background: #94a3b8;
  }
`;

export const HeatmapContainer = styled(ChartListScroll)`
  // max-height: 400px;
  overflow-x: auto;
`;

export const HeatmapTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
`;

export const HeatmapTh = styled.th`
  padding: 14px 12px;
  text-align: center;
  border: 1px solid #e2e8f0;
  font-weight: 600;
  background: #f8fafc;
  color: ${(props) => props.theme.colors.textDark};

  &.subject-header {
    text-align: left;
    min-width: 140px;
  }
`;

export const HeatmapTd = styled.td`
  padding: 8px;
  text-align: center;
  border: 1px solid #e2e8f0;
  min-width: 96px;
`;

export const HeatmapCell = styled.div`
  font-weight: 700;
  font-size: 16px;
  border-radius: 8px;
  padding: 10px 8px;

  ${({ $level }) => {
    if ($level === "excellent") {
      return `
        background: linear-gradient(135deg, #00ad53, #38d9a9);
        color: white;
      `;
    }
    if ($level === "good") {
      return `
        background: linear-gradient(135deg, #0077be, #48cae4);
        color: white;
      `;
    }
    if ($level === "average") {
      return `
        background: linear-gradient(135deg, #f97316, #fb923c);
        color: white;
      `;
    }
    if ($level === "empty") {
      return `
        background: #f8fafc;
        color: #94a3b8;
      `;
    }
    return `
      background: linear-gradient(135deg, #e10600, #ff6b6b);
      color: white;
    `;
  }}
`;

export const ChartLegend = styled.div`
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  margin-top: 16px;
  justify-content: center;
`;

export const ChartLegendItem = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: ${(props) => props.theme.colors.textDark};
`;

export const ChartLegendBox = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 4px;
  background: ${(props) => props.$color};
`;

export const InfoNote = styled.div`
  margin-top: 16px;
  padding: 12px 16px;
  background: #e0f2fe;
  border-radius: 8px;
  border-left: 4px solid #0077be;
  font-size: 13px;
  color: #0c4a6e;
  line-height: 1.5;
  display: flex;
  align-items: flex-start;
  gap: 8px;

  svg {
    font-size: 18px;
    color: #0077be;
    flex-shrink: 0;
    margin-top: 2px;
  }
`;

export const BulletChartScroll = styled(ChartListScroll)``;

export const BulletChart = styled.div`
  display: flex;
  flex-direction: column;
  gap: 14px;
`;

export const BulletItem = styled.div``;

export const BulletLabel = styled.div`
  font-weight: 600;
  margin-bottom: 6px;
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 13px;
  color: ${(props) => props.theme.colors.textDark};

  span:first-child {
    flex: 1;
    min-width: 0;
  }

  span:last-child {
    flex-shrink: 0;
    white-space: nowrap;
  }
`;

export const BulletBarContainer = styled.div`
  position: relative;
  height: 28px;
  background: #e2e8f0;
  border-radius: 14px;
  overflow: hidden;
`;

export const BulletTarget = styled.div`
  position: absolute;
  width: 3px;
  height: 100%;
  background: #475569;
  z-index: 2;
`;

export const BulletActual = styled.div`
  height: 100%;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 10px;
  color: white;
  font-weight: 700;
  font-size: 11px;
  transition: width 0.8s ease;
  background: ${(props) => {
    if (props.$status === "warning") {
      return "linear-gradient(90deg, #f97316, #fb923c)";
    }
    if (props.$status === "danger") {
      return "linear-gradient(90deg, #e10600, #ff6b6b)";
    }
    return "linear-gradient(90deg, #00ad53, #38d9a9)";
  }};
`;

export const RangeChartScroll = styled(ChartListScroll)``;

export const RangeChart = styled.div`
  display: flex;
  flex-direction: column;
  gap: 14px;
`;

export const RangeItem = styled.div``;

export const RangeHeader = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  font-size: 13px;
  flex-wrap: wrap;
  gap: 8px;
`;

export const RangeLabel = styled.span`
  font-weight: 600;
  color: ${(props) => props.theme.colors.textDark};
`;

export const RangeValues = styled.span`
  color: #64748b;
  font-size: 13px;
`;

export const RangeBar = styled.div`
  position: relative;
  height: 28px;
  background: #f1f5f9;
  border-radius: 14px;
`;

export const RangeSegment = styled.div`
  position: absolute;
  height: 100%;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: 600;
  font-size: 12px;
  transition: width 0.5s ease, left 0.5s ease;
`;
