import PropTypes from "prop-types";
import { useInjectReducer } from "utils/injectReducer";
import { useInjectSaga } from "utils/injectSaga";
import loadable from "utils/loadable";

import { PartyPageSkeleton } from "./components/skeletons";
import { key } from "./store/constants";
import reducer from "./store/reducer";
import saga from "./store/saga";

const Provider = ({ children }) => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });

  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const PartyMemberDashboard = loadable(() => import("./Main"), {
  fallback: <PartyPageSkeleton />,
  provider: Provider,
});

export default PartyMemberDashboard;
