import styled from "styled-components";

export {
  PageWrapper,
  Container,
  HeroCard,
  HeroContent,
  HeroIconWrap,
  HeroText,
  HeroTitle,
  HeroSubtitle,
  HeroFilter,
  FilterLabel,
  FilterSelectWrap,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  ChartContainer,
  Grid2,
  OverviewGrid,
  OverviewCard,
  OverviewCardTop,
  OverviewCardLabel,
  OverviewCardIcon,
  OverviewCardValue,
  OverviewCardSub,
} from "../TrainingEffectiveness/Styled";

export {
  StatCard,
  StatIcon,
  StatInfo,
  StatsScrollWrapper,
  StatsScrollTrack,
} from "../Home/Styled";

export { ChartWrapper as ChartScrollWrapper } from "components/Charts/ColumnChart/Styled";

export const BarChartScrollWrapper = styled.div`
  width: 100%;
  max-height: ${(props) => props.$maxHeight || "420px"};
  overflow-y: ${(props) => (props.$scrollable ? "auto" : "visible")};
  overflow-x: hidden;

  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    // background:rgb(216, 231, 239);
    border-radius: 4px;

    // &:hover {
    //   background: #005f99;
    // }
  }
`;

export const ProgressContainer = styled.div`
  margin: 8px 0 4px;
`;

export const ProgressHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  flex-wrap: wrap;
  gap: 8px;
`;

export const ProgressBar = styled.div`
  height: 40px;
  background: #e2e8f0;
  border-radius: 20px;
  overflow: hidden;
  position: relative;
`;

export const ProgressFill = styled.div`
  height: 100%;
  background: linear-gradient(90deg, #0077be, #00a8e8);
  border-radius: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 15px;
  font-weight: 700;
  transition: width 0.8s ease;
  min-width: 56px;
`;

export const ProgressTarget = styled.div`
  position: absolute;
  top: 0;
  height: 100%;
  width: 3px;
  background: #1e293b;
  z-index: 1;

  &::after {
    content: attr(data-label);
    position: absolute;
    top: -26px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 12px;
    color: #475569;
    white-space: nowrap;
    font-weight: 600;
  }
`;

export const InfoBox = styled.div`
  padding: 14px 16px;
  border-radius: 10px;
  margin-top: 16px;
  border-left: 4px solid;
  font-size: 14px;
  line-height: 1.5;
  display: flex;
  align-items: flex-start;
  gap: 8px;

  ${({ $type }) =>
    $type === "success"
      ? `
    background: #ecfdf5;
    border-left-color: #00ad53;
    color: #065f46;
  `
      : `
    background: #fffbeb;
    border-left-color: #f59e0b;
    color: #92400e;
  `}

  svg {
    flex-shrink: 0;
    margin-top: 2px;
  }
`;

export const ProgressMeta = styled.p`
  margin: 12px 0 0;
  font-size: 13px;
  color: #64748b;
`;
