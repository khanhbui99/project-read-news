import { getExamPeriodCategoryAction } from "App/store/actions";
import { useEffect, useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  ActiveFilterSummary,
  buildFilterSummary,
  DASHBOARD_SCREENS,
  ExportButtons,
  useSharedDashboardFilters,
} from "../shared";
import AgeChart from "./components/AgeChart";
import DashboardHeader from "./components/DashboardHeader";
import DepartmentChart from "./components/DepartmentChart";
import GenderChart from "./components/GenderChart";
import PositionChart from "./components/PositionChart";
import RatingChart from "./components/RatingChart";
import SeniorityChart from "./components/SeniorityChart";
import StaffRatioCard from "./components/StaffRatioCard";
import TotalStatsCard from "./components/TotalStatsCard";
import {
  exportPartyMemberExcelAction,
  exportPartyMemberWordAction,
  fetchPartyMemberDashboardAction,
} from "./store/actions";
import { key } from "./store/constants";
import {
  PageWrapper,
  Container,
  SectionHeader,
  SectionBadge,
  SectionTitle,
  Grid2,
} from "./Styled";

const Main = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchDashboard = useDispatchRedux(fetchPartyMemberDashboardAction);
  const exportWord = useDispatchRedux(exportPartyMemberWordAction);
  const exportExcel = useDispatchRedux(exportPartyMemberExcelAction);

  const examPeriodCategory = useOneState(injectKey.GLOBAL, "examPeriodCategory");
  const dashboardData = useOneState(key, "dashboardData") || {};

  const { filters, updateFilter } = useSharedDashboardFilters(
    DASHBOARD_SCREENS.PARTY,
  );

  const academicYears = examPeriodCategory?.academicYears || [];
  const selectedYearId = filters.schoolYearId || "";

  useEffect(() => {
    fetchExamPeriodCategory();
  }, []);

  useEffect(() => {
    if (academicYears.length && !selectedYearId) {
      updateFilter({ schoolYearId: academicYears[0].id });
    }
  }, [academicYears, selectedYearId, updateFilter]);

  useEffect(() => {
    if (selectedYearId) {
      fetchDashboard({ schoolYearId: selectedYearId });
    }
  }, [selectedYearId]);

  const selectedYearName = useMemo(() => {
    const year = academicYears.find((y) => `${y.id}` === `${selectedYearId}`);
    return year?.name || "";
  }, [academicYears, selectedYearId]);

  const filterSummary = useMemo(
    () =>
      buildFilterSummary(filters, DASHBOARD_SCREENS.PARTY, {
        yearName: selectedYearName,
      }),
    [filters, selectedYearName],
  );

  const genderData = useMemo(
    () => ({
      male: dashboardData.male,
      female: dashboardData.female,
    }),
    [dashboardData.male, dashboardData.female],
  );

  return (
    <PageWrapper>
      <Container>
        <DashboardHeader
          academicYearOpt={academicYears}
          selectedYearId={selectedYearId}
          selectedYearName={selectedYearName}
          onYearChange={(yearId) => updateFilter({ schoolYearId: yearId })}
        />

        <ActiveFilterSummary
          summary={filterSummary}
          actions={
            <ExportButtons
              disabled={!selectedYearId}
              onExportWord={() =>
                exportWord({ schoolYearId: selectedYearId })
              }
              onExportExcel={() =>
                exportExcel({ schoolYearId: selectedYearId })
              }
            />
          }
        />

        <TotalStatsCard total={dashboardData.total || 0} />

        <SectionHeader>
          <SectionBadge>CB</SectionBadge>
          <SectionTitle>Cơ cấu Đảng viên</SectionTitle>
        </SectionHeader>
        <Grid2>
          <GenderChart data={genderData} />
          <RatingChart data={dashboardData} />
        </Grid2>

        <SectionHeader>
          <SectionBadge>PT</SectionBadge>
          <SectionTitle>Phân tích nhân sự</SectionTitle>
        </SectionHeader>
        <>
          <Grid2>
            <AgeChart data={dashboardData} />
            <PositionChart data={dashboardData} />
          </Grid2>
          <Grid2>
            <DepartmentChart data={dashboardData} />
            <SeniorityChart data={dashboardData} />
          </Grid2>
          <StaffRatioCard data={dashboardData} />
        </>
      </Container>
    </PageWrapper>
  );
};

export default Main;
