export const EMPTY_PARTY_DATA = {
  total: 0,
  male: 0,
  female: 0,
  byClassification: [],
  byAgeGroup: [],
  byPosition: [],
  byChiBo: [],
  bySeniority: [],
  ratio: {
    partyMembers: 0,
    totalStaff: 0,
    percentage: 0,
    target: 15,
  },
};

const LIST_KEYS = ["items", "chartData", "data"];

const pickNumber = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  const num = Number(found);
  return Number.isFinite(num) ? num : 0;
};

const pickString = (...values) => {
  const found = values.find((v) => v !== undefined && v !== null && v !== "");
  return found != null ? String(found) : "";
};

const asArray = (value) => (Array.isArray(value) ? value : []);

const toCamelCaseKey = (key = "") =>
  key.replace(/_([a-z])/g, (_, char) => char.toUpperCase());

const normalizePayloadKeys = (payload = {}) => {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return payload;
  }

  const normalized = { ...payload };
  Object.entries(payload).forEach(([key, value]) => {
    if (key.includes("_")) {
      normalized[toCamelCaseKey(key)] = value;
    }
  });

  return normalized;
};

const hasPartySeries = (payload = {}) => {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return false;
  }

  return (
    payload.byClassification ||
    payload.byAgeGroup ||
    payload.byPosition ||
    payload.byChiBo ||
    payload.bySeniority ||
    payload.byGender ||
    payload.headerStats ||
    Object.keys(payload).some((key) => /chartgroup$/i.test(key))
  );
};

const unwrapPayload = (apiData = {}) => {
  const normalized = normalizePayloadKeys(apiData);
  if (
    normalized?.data &&
    typeof normalized.data === "object" &&
    !Array.isArray(normalized.data)
  ) {
    const inner = normalizePayloadKeys(normalized.data);
    if (hasPartySeries(inner)) return inner;
  }
  return normalized;
};

const unwrapGroup = (source = {}, keys = []) => {
  for (const key of keys) {
    const group = source?.[key];
    if (!group) continue;
    if (Array.isArray(group)) return group;
    if (typeof group === "object") return group;
  }
  return null;
};

const extractList = (source = {}, listKeys = LIST_KEYS) => {
  if (Array.isArray(source)) return source;

  for (const key of listKeys) {
    const value = source?.[key];
    if (Array.isArray(value)) return value;
  }

  return [];
};

const pickSeriesList = (source = {}, groupKeys = [], listKeys = LIST_KEYS) => {
  const group = unwrapGroup(source, groupKeys);
  if (!group) return [];
  return extractList(group, listKeys);
};

const countToPercent = (count, total) => {
  const safeTotal = pickNumber(total);
  if (safeTotal <= 0) return 0;
  return Math.round((pickNumber(count) / safeTotal) * 1000) / 10;
};

const sumValues = (obj = {}) =>
  Object.values(obj).reduce((acc, value) => acc + pickNumber(value), 0);

const sumListValues = (list = []) =>
  asArray(list).reduce(
    (acc, item) => acc + pickNumber(item?.value, item?.count),
    0,
  );

const POSITION_BUCKETS = [
  {
    label: "Bí thư Chi bộ",
    keys: ["secretary", "biThu", "biThuChiBo"],
  },
  {
    label: "Phó Bí thư Chi bộ",
    keys: ["deputySecretary", "phoBiThu"],
  },
  {
    label: "Chi ủy viên Chi bộ",
    keys: ["executiveCommittee", "uyVienBCH", "uyVien"],
  },
  {
    label: "Đảng viên",
    keys: ["member", "dangVien"],
  },
];

const splitPositionLabels = (label = "") =>
  pickString(label)
    .split(/[,;/|]+/)
    .map((part) => part.trim())
    .filter(Boolean);

const POSITION_ORDER = [
  "Bí thư Đảng ủy",
  "Phó Bí thư Đảng ủy",
  "Đảng ủy viên",
  "Chủ nhiệm Uỷ ban Kiểm tra",
  "Ủy viên Uỷ ban Kiểm tra",
  "Bí thư Chi bộ",
  "Phó Bí thư Chi bộ",
  "Chi ủy viên Chi bộ",
  "Đảng viên",
];

const stripDiacritics = (value = "") =>
  pickString(value)
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/đ/gi, "d")
    .toLocaleLowerCase("vi")
    .replace(/\s+/g, " ")
    .trim();

const POSITION_ORDER_MAP = POSITION_ORDER.reduce((acc, label) => {
  acc[stripDiacritics(label)] = label;
  return acc;
}, {});

POSITION_ORDER_MAP[stripDiacritics("Không xác định")] =
  POSITION_ORDER_MAP[stripDiacritics("Đảng viên")];

const normalizePositionLabel = (label = "") => {
  const key = stripDiacritics(label);
  return POSITION_ORDER_MAP[key] || pickString(label).trim();
};

const isKnownPositionLabel = (label = "") => POSITION_ORDER.includes(label);

const mapPositionFromObject = (obj = {}) => {
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) return [];

  return POSITION_BUCKETS.map(({ label, keys }) => ({
    label,
    value: pickNumber(...keys.map((key) => obj[key])),
  })).filter((item) => item.value > 0);
};

const mapPositionFromList = (list = []) => {
  const positionMap = new Map();

  asArray(list).forEach((item) => {
    const count = pickNumber(
      item.count,
      item.value,
      item.total,
      item.quantity,
      item.memberCount,
    );
    const labels = splitPositionLabels(
      pickString(
        item.label,
        item.name,
        item.positionName,
        item.position,
        item.title,
      ),
    );

    if (!labels.length) return;

    labels.forEach((rawLabel) => {
      const label = normalizePositionLabel(rawLabel);
      positionMap.set(label, (positionMap.get(label) || 0) + count);
    });
  });

  return POSITION_ORDER.filter((label) => positionMap.has(label))
    .map((label) => ({
      label,
      value: positionMap.get(label),
    }))
    .concat(
      Array.from(positionMap.entries())
        .filter(([label]) => !isKnownPositionLabel(label))
        .map(([label, value]) => ({ label, value }))
        .sort((a, b) =>
          stripDiacritics(a.label).localeCompare(stripDiacritics(b.label), "vi"),
        ),
    );
};

const itemName = (item = {}) =>
  pickString(
    item.name,
    item.label,
    item.groupName,
    item.category,
    item.type,
    item.title,
    item.ageGroup,
    item.ageGroupName,
    item.range,
    item.subjectName,
    item.subject,
    item.departmentName,
    item.department,
    item.chiBoName,
    item.chiBo,
    item.seniorityGroup,
    item.seniorityName,
    item.seniority,
    item.classificationName,
    item.classification,
    item.ratingName,
    item.rating,
    item.rank,
  );

const itemValue = (item = {}) =>
  pickNumber(
    item.count,
    item.value,
    item.total,
    item.quantity,
    item.memberCount,
  );

const mapChiBoList = (list = []) =>
  asArray(list)
    .map((item) => ({
      label: itemName(item),
      count: itemValue(item),
    }))
    .filter((item) => item.label);

const mapChartList = (list = []) =>
  asArray(list)
    .map((item) => ({
      name: itemName(item),
      value: itemValue(item),
    }))
    .filter((item) => item.name);

const mapGenderFromList = (list = []) => {
  let male = 0;
  let female = 0;

  asArray(list).forEach((item) => {
    const name = stripDiacritics(
      pickString(item.name, item.label, item.gender, item.genderName),
    );
    const count = itemValue(item);
    if (name === "nam" || name === "male") male += count;
    if (name === "nu" || name === "female") female += count;
  });

  return { male, female };
};

export const hasGenderData = (data = {}) =>
  pickNumber(data.male) > 0 || pickNumber(data.female) > 0;

export const hasClassificationData = (list = []) =>
  Array.isArray(list) && list.some((item) => pickNumber(item.value) > 0);

export const hasAgeGroupData = (list = []) =>
  Array.isArray(list) && list.some((item) => pickNumber(item.value) > 0);

export const hasPositionData = (byPosition = []) => {
  if (Array.isArray(byPosition)) {
    return byPosition.some((item) => pickNumber(item.value, item.count) > 0);
  }
  return sumValues(byPosition) > 0;
};

export const hasChiBoData = (list = []) =>
  Array.isArray(list) && list.some((item) => pickNumber(item.count) > 0);

export const hasSubjectData = hasChiBoData;

export const hasSeniorityData = (list = []) =>
  Array.isArray(list) && list.some((item) => pickNumber(item.value) > 0);

export const hasRatioData = (ratio = {}) =>
  pickNumber(ratio.totalStaff) > 0 || pickNumber(ratio.partyMembers) > 0;

export const mapPartyMemberResponse = (apiData = {}) => {
  const root = unwrapPayload(apiData);
  const headerStats = root.headerStats || root.overview || root.summary || {};

  const genderGroup = unwrapGroup(root, [
    "genderRatioChartGroup",
    "genderChartGroup",
    "genderRatio",
    "gender",
    "byGender",
  ]);

  const genderList = pickSeriesList(root, [
    "byGender",
    "genderRatioChartGroup",
    "genderChartGroup",
    "genderRatio",
    "gender",
  ]);

  const genderFromFields = {
    male: pickNumber(
      genderGroup?.male,
      genderGroup?.maleCount,
      root.male,
      root.maleCount,
      headerStats.male,
    ),
    female: pickNumber(
      genderGroup?.female,
      genderGroup?.femaleCount,
      root.female,
      root.femaleCount,
      headerStats.female,
    ),
  };
  const genderFromList = mapGenderFromList(genderList);
  const male = genderFromFields.male || genderFromList.male;
  const female = genderFromFields.female || genderFromList.female;

  const byClassification = mapChartList(
    pickSeriesList(root, [
      "byClassification",
      "classificationChartGroup",
      "ratingChartGroup",
      "classifications",
    ]),
  );

  const byAgeGroup = mapChartList(
    pickSeriesList(root, [
      "byAgeGroup",
      "ageGroupChartGroup",
      "ageChartGroup",
      "ageGroups",
      "ages",
    ]),
  );

  const positionList = pickSeriesList(root, [
    "byPosition",
    "positionChartGroup",
    "partyPositionChartGroup",
    "positionDistribution",
  ], [...LIST_KEYS, "positions"]);

  const positionGroup = unwrapGroup(root, [
    "byPosition",
    "positionChartGroup",
    "partyPositionChartGroup",
    "positionDistribution",
  ]);

  const byPosition = positionList.length
    ? mapPositionFromList(positionList)
    : mapPositionFromObject(positionGroup);

  const byChiBo = mapChiBoList(
    pickSeriesList(root, [
      "byChiBo",
      "chiBoChartGroup",
      "partyChiBoChartGroup",
      "chiBoDistribution",
      "chiBo",
      "chiBos",
    ], [...LIST_KEYS, "chiBos"]),
  );

  const bySeniority = mapChartList(
    pickSeriesList(root, [
      "bySeniority",
      "seniorityChartGroup",
      "seniorities",
    ]),
  );

  const ratioGroup =
    unwrapGroup(root, [
      "staffRatioChartGroup",
      "partyStaffRatioChartGroup",
      "ratio",
      "staffRatio",
    ]) || {};

  const partyMembers = pickNumber(
    ratioGroup.partyMembers,
    ratioGroup.partyMemberCount,
    headerStats.totalPartyMembers,
    headerStats.totalPartyMember,
    root.total,
    root.totalPartyMembers,
    root.totalPartyMember,
    sumListValues(byPosition) ||
      sumListValues(byClassification) ||
      male + female,
  );

  const totalStaff = pickNumber(
    ratioGroup.totalStaff,
    ratioGroup.totalEmployees,
    headerStats.totalStaff,
    root.totalStaff,
    root.totalCbGvNv,
  );

  const percentage = pickNumber(
    ratioGroup.percentage,
    ratioGroup.percent,
    ratioGroup.ratio,
    countToPercent(partyMembers, totalStaff),
  );

  const target = pickNumber(ratioGroup.target, ratioGroup.targetPercent, 15);

  const total = pickNumber(
    headerStats.total,
    headerStats.totalPartyMembers,
    headerStats.totalPartyMember,
    root.total,
    root.totalPartyMembers,
    root.totalPartyMember,
    partyMembers,
    male + female,
    sumListValues(byPosition),
    sumListValues(byClassification),
  );

  return {
    total,
    male,
    female,
    byClassification,
    byAgeGroup,
    byPosition,
    byChiBo,
    bySeniority,
    ratio: {
      partyMembers: partyMembers || total,
      totalStaff,
      percentage,
      target: target || 15,
    },
  };
};
