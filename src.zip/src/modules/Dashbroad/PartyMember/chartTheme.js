/** Palette đồng bộ Dashboard Hiệu quả đào tạo — giao diện chuyên nghiệp cho hiệu trưởng */
export const CHART_COLORS = {
  primary: "#0077be",
  primaryLight: "#00a8e8",
  green: "#00ad53",
  orange: "#f97316",
  red: "#e10600",
  purple: "#667eea",
  pink: "#ff6b9d",
  column: ["#0077be", "#00a8e8", "#00ad53", "#667eea", "#f97316", "#38bdf8"],
  bar: [
    "rgba(0, 119, 190, 0.95)",
    "rgba(0, 168, 232, 0.85)",
    "rgba(0, 173, 83, 0.75)",
    "rgba(102, 126, 234, 0.65)",
  ],
};

export const getColumnColor = (index) =>
  CHART_COLORS.column[index % CHART_COLORS.column.length];
