import { TOKEN_NAME } from "utils/constants";
import { isBGH } from "utils/helpers";

import {
  ASPECT_LABEL_MAP,
  CRITERION_ROLE,
  TARGET_TYPE_LABEL_MAP,
} from "./saga/constants";

const resolveAbsoluteUrl = (url = "") => {
  if (!url) return "";
  if (/^https?:\/\//i.test(url) || url.startsWith("blob:")) return url;
  const rootUri = import.meta.env.VITE_ROOT_URI || "";
  const cleanUrl = url.startsWith("/") ? url : `/${url}`;
  return `${rootUri}${cleanUrl}`;
};

/** Lấy đuôi file từ tên hoặc URL (vd: pdf, png, docx). */
export const getFileExtension = (file = {}) => {
  const name = String(file.fileName || file.name || "");
  const fromName = name.match(/\.([a-zA-Z0-9]+)$/);
  if (fromName) return fromName[1].toLowerCase();

  const url = String(file.fileUrl || file.url || "");
  const fromUrl = url.match(/\.([a-zA-Z0-9]+)(?:\?|#|$)/);
  if (fromUrl) return fromUrl[1].toLowerCase();
  return "";
};

/** Tên file tải về — giữ/đính đuôi theo định dạng file. */
export const getDownloadFileName = (file = {}) => {
  const raw = String(file.fileName || file.name || "minh-chung").trim();
  const base = raw || "minh-chung";
  const ext = getFileExtension(file);
  if (!ext) return base;
  if (/\.[a-zA-Z0-9]+$/.test(base)) return base;
  return `${base}.${ext}`;
};

/**
 * Tải minh chứng: POST tới fileUrl (API link), lưu blob với tên theo đuôi file.
 */
export const downloadEvidenceFile = async (file = {}) => {
  const fileUrl = file.fileUrl || file.url;
  if (!fileUrl) {
    throw new Error("File chưa có đường dẫn tải.");
  }

  const token = localStorage.getItem(TOKEN_NAME) || "";
  const response = await fetch(resolveAbsoluteUrl(fileUrl), {
    method: "POST",
    headers: token ? { Authorization: token } : {},
  });

  if (!response.ok) {
    throw new Error("Không thể tải file.");
  }

  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = objectUrl;
  link.download = getDownloadFileName(file);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(objectUrl);
};

const collectRoleTokens = (userInfo = {}) => {
  const tokens = [];
  const push = (value) => {
    if (value == null || value === "") return;
    if (Array.isArray(value)) {
      value.forEach(push);
      return;
    }
    if (typeof value === "object") {
      push(value.code);
      push(value.roleCode);
      push(value.name);
      push(value.roleName);
      push(value.role);
      return;
    }
    String(value)
      .split(/[;,|]/)
      .map((part) => part.trim())
      .filter(Boolean)
      .forEach((part) => tokens.push(part.toUpperCase()));
  };

  push(userInfo.listRole);
  push(userInfo.list_role);
  push(userInfo.roleName);
  push(userInfo.roleCode);
  push(userInfo.role);
  push(userInfo.currentRole);
  push(userInfo.roles);

  (userInfo.orgCharts || userInfo.org_charts || []).forEach((org) => {
    push(org?.roleName);
    push(org?.roleCode);
    push(org?.role);
  });

  return tokens;
};

const roleTextIncludes = (tokens = [], keywords = []) =>
  tokens.some((token) =>
    keywords.some((keyword) => token.includes(String(keyword).toUpperCase())),
  );

export const resolveCriterionRole = (userInfo = {}) => {
  const tokens = collectRoleTokens(userInfo);
  const exactRoles = new Set(tokens);

  if (
    roleTextIncludes(tokens, [
      "ADMIN",
      "QUAN TRI",
      "QUẢN TRỊ",
      "SYSTEM_ADMIN",
      "SYSADMIN",
    ])
  ) {
    return CRITERION_ROLE.ADMIN;
  }

  if (
    (typeof isBGH === "function" && isBGH()) ||
    userInfo?.isBGH ||
    exactRoles.has("HIỆU TRƯỞNG") ||
    exactRoles.has("PHÓ HIỆU TRƯỞNG") ||
    roleTextIncludes(tokens, [
      "BGH",
      "BAN GIAM HIEU",
      "BAN_GIAM",
      "HIỆU TRƯỞNG",
      "HIEU TRUONG",
      "PHÓ HIỆU TRƯỞNG",
      "PHO HIEU TRUONG",
      "SCHOOL_MANAGER",
      "SCHOOL MANAGER",
    ])
  ) {
    return CRITERION_ROLE.BGH;
  }

  if (
    roleTextIncludes(tokens, [
      "GVCN",
      "GIAO VIEN CHU NHIEM",
      "GIÁO VIÊN CHỦ NHIỆM",
      "GIAO_VIEN_CHU_NHIEM",
      "HOMEROOM",
    ])
  ) {
    return CRITERION_ROLE.GVCN;
  }

  return CRITERION_ROLE.TPT;
};

export const canManageCriterion = (role) =>
  role === CRITERION_ROLE.TPT || role === CRITERION_ROLE.ADMIN;

export const canManageDailyScore = (role) =>
  role === CRITERION_ROLE.TPT || role === CRITERION_ROLE.ADMIN;

export const canManageComplaint = (role) => role === CRITERION_ROLE.GVCN;

export const canResolveComplaint = (role) =>
  role === CRITERION_ROLE.TPT || role === CRITERION_ROLE.ADMIN;

export const canViewComplaintClassScores = (role) =>
  role === CRITERION_ROLE.GVCN;

/** F-04: chỉ TPT (và Admin). BGH / GVCN không vào màn này. */
export const canAccessComplaintList = (role) =>
  role === CRITERION_ROLE.TPT || role === CRITERION_ROLE.ADMIN;

/** F-05: chỉ TPT (và Admin). BGH / GVCN không vào màn này. */
export const canAccessMovement = (role) =>
  role === CRITERION_ROLE.TPT || role === CRITERION_ROLE.ADMIN;

export const getAspectLabel = (aspect) => ASPECT_LABEL_MAP[aspect] || aspect || "—";

export const getTargetTypeLabel = (targetType) =>
  TARGET_TYPE_LABEL_MAP[targetType] || targetType || "—";

/** Tiêu chí nhập điểm tay (BE có thể trả boolean / 1 / "true"). */
export const isRequiresManualPoints = (item) => {
  const value = item?.requiresManualPoints;
  return value === true || value === 1 || value === "true" || value === "1";
};

export const mapCriteriaOptions = (items = []) =>
  (items || []).map((item) => ({
    ...item,
    value: item.id,
    label: `${item.code || ""} - ${item.content || item.name || ""}`.trim(),
    requiresManualPoints: isRequiresManualPoints(item),
  }));

const normalizeText = (value) =>
  String(value ?? "")
    .trim()
    .toLowerCase();

export const filterCriteriaLocal = (items = [], filter = {}) => {
  const code = normalizeText(filter.code);
  const content = normalizeText(filter.content);
  const aspect = normalizeText(filter.aspect);
  const targetType = normalizeText(filter.targetType);
  const points = normalizeText(filter.defaultPoints);

  return items.filter((item) => {
    if (code && !normalizeText(item.code).includes(code)) return false;
    if (content && !normalizeText(item.content).includes(content)) return false;
    if (aspect && String(item.aspect || "") !== String(filter.aspect)) {
      return false;
    }
    if (
      targetType &&
      String(item.targetType || "") !== String(filter.targetType)
    ) {
      return false;
    }
    if (points && !normalizeText(item.defaultPoints).includes(points)) {
      return false;
    }
    return true;
  });
};
