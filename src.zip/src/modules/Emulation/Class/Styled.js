import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  min-height: calc(100vh - 140px);
  margin-top: 16px;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  min-height: 0;
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: hidden;
`;

export const FilterGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(5, minmax(140px, 1fr));
  gap: 12px;

  @media (max-width: 1200px) {
    grid-template-columns: repeat(3, minmax(140px, 1fr));
  }

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const DailyScoreFilterGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, minmax(140px, 1fr));
  gap: 12px;

  @media (max-width: 1200px) {
    grid-template-columns: repeat(2, minmax(140px, 1fr));
  }

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const MonthNavBar = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: ${({ $compact }) => ($compact ? "0" : "12px 16px")};
  border-radius: 10px;
  background: ${({ $compact }) =>
    $compact ? "transparent" : VPB_THEMES.colors.lightBg};
  border: ${({ $compact }) =>
    $compact ? "none" : `1px solid ${VPB_THEMES.colors.gray["200"]}`};
`;

export const MonthNavLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  min-width: 0;
`;

export const MonthNavLabel = styled.span`
  font-size: 14px;
  font-weight: 500;
  color: ${({ $onHero }) =>
    $onHero ? "rgba(255,255,255,0.85)" : VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
  white-space: nowrap;
`;

export const MonthNavCenter = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
`;

export const MonthNavButton = styled.button`
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: ${VPB_THEMES.colors.primaryBlue};
  transition: all 0.2s ease;
  flex-shrink: 0;
  padding: 0;

  &:hover:not(:disabled) {
    background: ${VPB_THEMES.colors.eff6ff};
    border-color: ${VPB_THEMES.colors.primaryBlue};
  }

  &:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  svg {
    font-size: 20px;
  }
`;

export const MonthNavMonth = styled.div`
  display: flex;
  align-items: baseline;
  gap: 8px;
  font-size: 15px;
  font-weight: 700;
  color: ${({ $onHero }) =>
    $onHero ? VPB_THEMES.colors.white : VPB_THEMES.colors.primaryBlue};
  font-family: SVN_Gilroy, sans-serif;
  white-space: nowrap;
  line-height: 1.2;
`;

export const MonthNavHint = styled.span`
  font-size: 13px;
  font-weight: 500;
  color: ${({ $onHero }) =>
    $onHero ? "rgba(255,255,255,0.8)" : VPB_THEMES.colors.textLight};
`;

export const MonthNavCount = styled.div`
  font-size: 13px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
  white-space: nowrap;
  margin-left: auto;
`;

export const FilterActions = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
`;

export const HelperText = styled.div`
  margin-top: 14px;
  font-size: 12px;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const PointsText = styled.span`
  font-weight: 600;
  color: ${({ $tone }) => {
    if ($tone === "negative") return VPB_THEMES.colors.red;
    if ($tone === "positive") return VPB_THEMES.colors.green;
    return VPB_THEMES.colors.textDark;
  }};
`;

export const CriteriaInfoBar = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-top: 8px;
  padding: 10px 12px;
  border-radius: 8px;
  background: ${VPB_THEMES.colors.f0f9ff};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  font-size: 13px;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;

  strong {
    font-weight: 700;
    margin-right: 4px;
  }
`;

export const StudentListHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
`;

export const StudentSelectAllBtn = styled.button`
  border: none;
  background: transparent;
  padding: 0;
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.primaryBlue};
  font-family: SVN_Gilroy, sans-serif;

  &:hover {
    text-decoration: underline;
  }
`;

export const StudentListBox = styled.div`
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  border-radius: 10px;
  overflow: hidden;
  background: ${VPB_THEMES.colors.white};
`;

export const StudentListSearch = styled.div`
  padding: 12px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.lightBg};
`;

export const StudentRow = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${({ $selected }) =>
    $selected ? VPB_THEMES.colors.eff6ff : VPB_THEMES.colors.white};

  &:last-child {
    border-bottom: none;
  }
`;

export const StudentStepper = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
`;

export const StudentStepperBtn = styled.button`
  width: 28px;
  height: 28px;
  border-radius: 6px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: ${VPB_THEMES.colors.primaryBlue};
  padding: 0;

  &:hover:not(:disabled) {
    background: ${VPB_THEMES.colors.eff6ff};
    border-color: ${VPB_THEMES.colors.primaryBlue};
  }

  &:disabled {
    opacity: 0.35;
    cursor: not-allowed;
  }
`;

export const StudentStepperInput = styled.input`
  width: 40px;
  height: 28px;
  border-radius: 6px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  text-align: center;
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;
  outline: none;

  &:focus {
    border-color: ${VPB_THEMES.colors.primaryBlue};
  }

  &:disabled {
    background: ${VPB_THEMES.colors.gray["100"]};
    color: ${VPB_THEMES.colors.textLight};
  }

  /* hide spinner */
  &::-webkit-outer-spin-button,
  &::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  -moz-appearance: textfield;
`;

export const StudentListFooter = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  padding: 8px 4px 0;
`;

export const ImpactCard = styled.div`
  margin-top: 8px;
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.lightBg};
`;

export const ImpactHeader = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 10px;
`;

export const ImpactTitle = styled.div`
  font-size: 14px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;
`;

export const ImpactLineCount = styled.div`
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.primaryBlue};
  font-family: SVN_Gilroy, sans-serif;
  white-space: nowrap;
`;

export const ImpactRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 6px 0;
  font-size: 13px;
  color: ${({ $muted }) =>
    $muted ? VPB_THEMES.colors.textLight : VPB_THEMES.colors.textDark};
  opacity: ${({ $muted }) => ($muted ? 0.65 : 1)};
  font-family: SVN_Gilroy, sans-serif;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};

  &:last-child {
    border-bottom: none;
  }
`;

export const ImpactWarning = styled.div`
  margin-top: 10px;
  padding: 8px 12px;
  border-radius: 8px;
  background: ${VPB_THEMES.colors.fffbeb};
  border: 1px solid ${VPB_THEMES.colors.statusMaintenanceText};
  color: ${VPB_THEMES.colors.statusMaintenanceText};
  font-size: 12px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
`;

export const MovementClassPanel = styled.div`
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  border-radius: 10px;
  overflow: hidden;
  background: ${VPB_THEMES.colors.white};
`;

export const MovementClassToolbar = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  padding: 10px 12px;
  background: ${VPB_THEMES.colors.lightBg};
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;

export const MovementClassRow = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};
  font-family: SVN_Gilroy, sans-serif;

  &:last-child {
    border-bottom: none;
  }
`;

export const MovementClassSummary = styled.div`
  padding: 10px 12px;
  background: ${VPB_THEMES.colors.f0f9ff};
  color: ${VPB_THEMES.colors.primaryBlue};
  font-size: 13px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
`;

export const MovementCapHint = styled.span`
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.red};
  white-space: nowrap;
  font-family: SVN_Gilroy, sans-serif;
`;

export const MovementPreviewPanel = styled.div`
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
`;

export const MovementPreviewHeader = styled.div`
  padding: 12px 14px;
  background: ${VPB_THEMES.colors.f0f9ff};
  color: ${VPB_THEMES.colors.darkBlue};
  font-size: 13px;
  font-weight: 700;
  font-family: SVN_Gilroy, sans-serif;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;

export const MovementPreviewRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 14px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray["200"]};
  font-family: SVN_Gilroy, sans-serif;

  &:last-child {
    border-bottom: none;
  }
`;

export const MovementPager = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 8px 12px;
  border-top: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.lightBg};
  font-size: 12px;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const MovementPagerBtn = styled.button`
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.primaryBlue};
  border-radius: 6px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  font-family: SVN_Gilroy, sans-serif;

  &:disabled {
    opacity: 0.45;
    cursor: not-allowed;
  }
`;

export const MovementLinkBtn = styled.button`
  border: none;
  background: transparent;
  color: ${VPB_THEMES.colors.primaryBlue};
  font-weight: 600;
  font-size: 13px;
  cursor: pointer;
  font-family: SVN_Gilroy, sans-serif;
  padding: 0;
`;

export const ComplaintFilterGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 12px;

  > *:not(.filter-actions) {
    flex: 1 1 160px;
    min-width: 140px;
    max-width: 280px;
  }

  .filter-actions {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: 8px;
    padding-bottom: 0;
  }
`;

export const SectionTitle = styled.h3`
  margin: 0;
  font-size: 16px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;
`;

export const EmptyStateWrap = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  min-height: 280px;
  padding: 32px 16px;
  text-align: center;
`;

export const EmptyStateText = styled.div`
  font-size: 15px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const SectionDesc = styled.p`
  margin: 4px 0 0;
  font-size: 13px;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const SummaryGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(5, minmax(100px, 1fr));
  gap: 12px;

  @media (max-width: 1200px) {
    grid-template-columns: repeat(3, minmax(100px, 1fr));
  }

  @media (max-width: 768px) {
    grid-template-columns: repeat(2, minmax(100px, 1fr));
  }
`;

export const SummaryCard = styled.div`
  padding: 12px 14px;
  border-radius: 10px;
  background: ${VPB_THEMES.colors.lightBg};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;

export const SummaryLabel = styled.div`
  font-size: 12px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
  margin-bottom: 4px;
`;

export const SummaryValue = styled.div`
  font-size: 18px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.primaryBlue};
  font-family: SVN_Gilroy, sans-serif;
`;

export const ClassScoreHero = styled.div`
  border-radius: 12px;
  overflow: hidden;
  background: ${VPB_THEMES.colors.primaryBlue};
  color: ${VPB_THEMES.colors.white};
  font-family: SVN_Gilroy, sans-serif;
`;

export const ClassScoreHeroTop = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 16px 18px 12px;
`;

export const ClassScoreHeroTitle = styled.h2`
  margin: 0;
  font-size: 18px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.white};
`;

export const ClassScoreHeroDesc = styled.p`
  margin: 6px 0 0;
  font-size: 13px;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.85);
  max-width: 520px;
`;

export const ClassScoreHeroControls = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 10px;
`;

export const PeriodTabs = styled.div`
  display: inline-flex;
  padding: 3px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.18);
`;

export const PeriodTab = styled.button`
  border: none;
  cursor: pointer;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
  color: ${({ $active }) =>
    $active ? VPB_THEMES.colors.primaryBlue : VPB_THEMES.colors.white};
  background: ${({ $active }) =>
    $active ? VPB_THEMES.colors.white : "transparent"};
`;

export const ClassScoreMetrics = styled.div`
  display: grid;
  grid-template-columns: repeat(5, minmax(120px, 1fr));
  gap: 10px;
  padding: 0 18px 16px;

  @media (max-width: 1200px) {
    grid-template-columns: repeat(3, minmax(120px, 1fr));
  }

  @media (max-width: 768px) {
    grid-template-columns: repeat(2, minmax(120px, 1fr));
  }
`;

export const ClassScoreMetricCard = styled.div`
  background: ${VPB_THEMES.colors.white};
  border-radius: 10px;
  padding: 12px 14px;
  min-height: 88px;
`;

export const ClassScoreMetricLabel = styled.div`
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
  margin-bottom: 6px;
`;

export const ClassScoreMetricValue = styled.div`
  font-size: 22px;
  font-weight: 800;
  color: ${({ $tone }) =>
    $tone === "rank"
      ? VPB_THEMES.colors.statusMaintenanceText
      : VPB_THEMES.colors.textDark};
  line-height: 1.2;
`;

export const ClassScoreMetricSub = styled.div`
  margin-top: 4px;
  font-size: 12px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
`;

export const WindowStatusText = styled.span`
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
  color: ${({ $closed }) =>
    $closed
      ? VPB_THEMES.colors.textLight
      : VPB_THEMES.colors.statusMaintenanceText};
  background: ${({ $closed }) =>
    $closed
      ? VPB_THEMES.colors.gray["100"]
      : VPB_THEMES.colors.statusMaintenanceBg};
`;

export const ClassScoreMonthNavWrap = styled.div`
  .month-nav-on-hero {
    background: rgba(255, 255, 255, 0.12);
    border-color: rgba(255, 255, 255, 0.2);
  }

  .month-nav-on-hero span,
  .month-nav-on-hero div {
    color: ${VPB_THEMES.colors.white};
  }

  .month-nav-on-hero button {
    background: rgba(255, 255, 255, 0.95);
  }
`;

export const ClassScoreSemesterBar = styled.div`
  display: flex;
  align-items: stretch;
  gap: 8px;
  padding: 8px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.14);
  border: 1px solid rgba(255, 255, 255, 0.22);
  min-width: 320px;

  @media (max-width: 768px) {
    min-width: 0;
    width: 100%;
    flex-direction: column;
  }
`;

export const ClassScoreSemesterField = styled.div`
  flex: 1;
  min-width: 140px;

  .MuiFormControl-root,
  .MuiOutlinedInput-root {
    background: ${VPB_THEMES.colors.white};
    border-radius: 8px;
  }

  .MuiOutlinedInput-notchedOutline {
    border-color: transparent !important;
  }

  .MuiInputBase-input,
  .MuiSelect-select,
  .MuiAutocomplete-input {
    font-family: SVN_Gilroy, sans-serif !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    color: ${VPB_THEMES.colors.textDark} !important;
    padding-top: 8px !important;
    padding-bottom: 8px !important;
  }

  .MuiInputLabel-root,
  label {
    display: none !important;
  }

  fieldset {
    border: none !important;
  }
`;

export const ClassScoreSemesterLabel = styled.div`
  font-size: 11px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 4px;
  font-family: SVN_Gilroy, sans-serif;
`;

export const StatusChip = styled.span`
  display: inline-flex;
  align-items: center;
  padding: 4px 10px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
  color: ${({ $status }) =>
    $status === "RESOLVED"
      ? VPB_THEMES.colors.green
      : VPB_THEMES.colors.statusMaintenanceText};
  background: ${({ $status }) =>
    $status === "RESOLVED"
      ? VPB_THEMES.colors.lightBg
      : VPB_THEMES.colors.statusMaintenanceBg};
`;

export const ResolveHeaderRow = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 12px;
`;

export const ResolveBlock = styled.div`
  padding: 12px 14px;
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.lightBg};
  margin-bottom: 12px;
`;

export const ResolveBlockTitle = styled.div`
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;
  margin-bottom: 8px;
`;

export const ResolveActionRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  padding: 8px 16px 16px;
`;

export const DetailGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px 16px;
  padding: 8px 0 16px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const DetailItem = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;

  &.full {
    grid-column: 1 / -1;
  }
`;

export const DetailLabel = styled.div`
  font-size: 12px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
`;

export const DetailValue = styled.div`
  font-size: 14px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark};
  font-family: SVN_Gilroy, sans-serif;
  white-space: pre-wrap;
  word-break: break-word;
`;

export const ComplaintDetailHero = styled.div`
  margin: 0 16px 14px;
  padding: 16px 18px;
  border-radius: 12px;
  background: ${VPB_THEMES.gradient.ocean};
  color: ${VPB_THEMES.colors.white};
  font-family: SVN_Gilroy, sans-serif;
`;

export const ComplaintDetailHeroTop = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
`;

export const ComplaintDetailCode = styled.div`
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 0.2px;
  color: ${VPB_THEMES.colors.white};
`;

export const ComplaintDetailMeta = styled.div`
  margin-top: 8px;
  font-size: 13px;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.9);
  display: flex;
  flex-wrap: wrap;
  gap: 6px 14px;
`;

export const ComplaintDetailMetaItem = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 6px;
`;

export const ComplaintDetailBody = styled.div`
  padding: 0 16px 8px;
`;

export const ComplaintDetailStatusChip = styled(StatusChip)`
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.12);
`;

export const ComplaintEvidenceList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 4px;
`;

export const ComplaintEvidenceItem = styled.button`
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.primaryBlue};
  font-size: 13px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
  text-align: left;
  cursor: pointer;
  transition: border-color 0.15s ease, background 0.15s ease;

  &:hover:not(:disabled) {
    border-color: ${VPB_THEMES.colors.primaryBlue};
    background: ${VPB_THEMES.colors.f0f9ff};
  }

  &:disabled {
    opacity: 0.7;
    cursor: wait;
  }
`;

export const ComplaintEvidenceItemStatic = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.textDark};
  font-size: 13px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
`;

export const ComplaintEmptyHint = styled.div`
  font-size: 13px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
  font-family: SVN_Gilroy, sans-serif;
  font-style: italic;
`;

export const ComplaintFeedbackBox = styled.div`
  padding: 12px 14px;
  border-radius: 8px;
  background: ${({ $empty }) =>
    $empty ? VPB_THEMES.colors.white : VPB_THEMES.colors.f0fdf4};
  border: 1px solid
    ${({ $empty }) =>
      $empty
        ? VPB_THEMES.colors.gray["200"]
        : VPB_THEMES.colors.statusActiveDot};
  color: ${({ $empty }) =>
    $empty ? VPB_THEMES.colors.textLight : VPB_THEMES.colors.statusActiveText};
  font-size: 14px;
  font-weight: 600;
  font-family: SVN_Gilroy, sans-serif;
  white-space: pre-wrap;
  word-break: break-word;
`;

export const ComplaintScorePoints = styled.div`
  min-width: 64px;
  text-align: center;
  padding: 8px 10px;
  border-radius: 10px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;
