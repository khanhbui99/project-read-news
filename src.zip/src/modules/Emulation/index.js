export { default as CriterionClassEmulation } from "./Class/screens/Criterion";
export { default as DailyScoreClassEmulation } from "./Class/screens/DailyScore";
export { default as ClassScoreClassEmulation } from "./Class/screens/ClassScore";
export { default as TaskComplaintClassEmulation } from "./Class/screens/TaskComplaint";
export { default as ReportComplaintClassEmulation } from "./Class/screens/ReportComplaint";
export { default as MovementClassEmulation } from "./Class/screens/Movement";
export { default as ReportClassEmulation } from "./Class/screens/ClassReport";

