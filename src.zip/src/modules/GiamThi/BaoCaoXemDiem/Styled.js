import { Chip, TableCell } from "@mui/material";
import styled, { css } from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const Container = styled.div`
  // padding: 24px;
  // max-width: 1400px;
  margin: 0 auto;
`;

export const FilterBar = styled.form`
  padding: 24px;
  background: linear-gradient(135deg, ${VPB_THEMES.colors.lightBg || "#f8fafc"} 0%, #fff 100%);
  border-radius: 16px;
  margin-bottom: 24px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
`;

export const FilterGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 160px;
`;

export const FilterLabel = styled.span`
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark || "#1e293b"};
`;

export const ScoreCard = styled.div`
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  margin-bottom: 24px;
`;

export const ScoreTableWrapper = styled.div`
  overflow-x: auto;
`;

export const ScoreTableStyled = styled.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
`;

export const ScoreTableHeader = styled.thead`
  background: linear-gradient(135deg, ${VPB_THEMES.colors.primaryBlue || "#0077be"} 0%, ${VPB_THEMES.colors.darkBlue || "#023e8a"} 100%);
  color: #fff;
`;

export const ScoreTableHeaderCell = styled.th`
  padding: 14px 12px;
  text-align: left;
  font-weight: 600;
  white-space: nowrap;
  &:first-child {
    min-width: 48px;
    text-align: center;
  }
`;

export const ScoreTableBody = styled.tbody``;

export const ScoreTableRow = styled.tr`
  &:nth-child(even) {
    background: ${VPB_THEMES.colors.lightBg || "#f8fafc"};
  }
  &:hover {
    background: rgba(0, 119, 190, 0.04);
  }
`;

export const ScoreTableCell = styled.td`
  padding: 10px 12px;
  border-bottom: 1px solid #e2e8f0;
  vertical-align: middle;
  &:first-child {
    text-align: center;
  }
`;

export const ScoreInput = styled.input`
  width: 100%;
  max-width: 56px;
  padding: 6px 8px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 13px;
  text-align: center;
  &:focus {
    outline: none;
    border-color: ${VPB_THEMES.colors.primaryBlue};
    box-shadow: 0 0 0 2px rgba(0, 119, 190, 0.2);
  }
`;

export const EmptyState = styled.div`
  text-align: center;
  padding: 48px 24px;
  color: #64748b;
`;

export const EmptyStateIcon = styled.div`
  margin-bottom: 16px;
  opacity: 0.5;
`;

export const ActionBar = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 16px 20px;
  background: #f8fafc;
  border-top: 1px solid #e2e8f0;
`;

export const StickyCell = styled(TableCell)`
  position: sticky;
  left: 0;
  background-color: white !important;
  z-index: 5 !important;
  border-right: 2px solid #e2e8f0;

  &:nth-of-type(2) {
    left: 60px;
  }

  &:nth-of-type(3) {
    left: 180px;
  }
`;

const gradeStyles = {
  excellent: css`
    background-color: #d1fae5;
    color: #065f46;
  `,
  good: css`
    background-color: #fef3c7;
    color: #92400e;
  `,
  average: css`
    background-color: #dbeafe;
    color: #1e40af;
  `,
  weak: css`
    background-color: #fee2e2;
    color: #991b1b;
  `,
};

export const GradeDisplay = styled(Chip).withConfig({
  shouldForwardProp: (prop) => prop !== "gradeclass",
})`
  font-weight: 700;
  font-size: 14px;

  ${({ gradeclass }) => gradeStyles[gradeclass] || ""}
`;

