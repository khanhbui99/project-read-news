import {
  getAllClassesAction,
  getExamPeriodCategoryAction,
} from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import { useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import Filter from "./components/Filter";
import ScoreTable from "./components/ScoreTable";
import { resetStoreScoringAction } from "./store/actions";
import { key } from "./store/constants";
import { Container } from "./Styled";

const Main = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const resetStoreScoring = useDispatchRedux(resetStoreScoringAction);
  const fetchAllClasses = useDispatchRedux(getAllClassesAction);

  const filter = useOneState(key, "filter", []);
  const classesOpt = useOneState(injectKey.GLOBAL, "classesOpt", []);
  const examPeriodCategory = useOneState(
    injectKey.GLOBAL,
    "examPeriodCategory",
    {},
  );

  const typeSubject = useMemo(() => {
    return (
      (examPeriodCategory?.subjects || [])?.find(
        (item) => item?.id == filter?.subjectId,
      )?.type || ""
    );
  }, [filter?.subjectId]);

  const scoringState = useSelector((state) => state[key]) || {};
  const { classDetail, hocSinh } = scoringState;

  useEffect(() => {
    fetchAllClasses();
    fetchExamPeriodCategory();

    // Cleanup on unmount
    return () => {
      resetStoreScoring();
    };
  }, []);
  return (
    <Container>
      <AppHeader componentName="BaoCaoXemDiemGiamThi" isHiddenBtn />

      <Filter
        classesOpt={classesOpt}
        subjectOpt={examPeriodCategory?.subjects}
        semesters={examPeriodCategory?.semesters}
        academicYearOpt={examPeriodCategory?.academicYears}
      />

      <ScoreTable
        filter={filter}
        typeSubject={typeSubject}
        classDetail={classDetail}
        hocSinh={hocSinh}
      />
    </Container>
  );
};

export default Main;
