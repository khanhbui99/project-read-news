import isNumber from "lodash/isNumber";
import { SUBJECT_TYPE_MAPPING } from "utils/constants";

export const covertNumber = (_v) => {
  if (isNumber(_v)) return _v;
  return _v ? Number(_v) : null;
};

export const genScoreByType = (type, scores) => {
  switch (type) {
    case SUBJECT_TYPE_MAPPING.LOAI_1.type: {
      if (
        scores?.oral1 &&
        scores?.oral2 &&
        scores?.oral3 &&
        scores?.oral4 &&
        scores?.midterm &&
        scores?.finalTerm
      ) {
        const total = 9;

        return (
          (Number(scores.oral1) * 1) / total +
          (Number(scores.oral2) * 1) / total +
          (Number(scores.oral3) * 1) / total +
          (Number(scores.oral4) * 1) / total +
          (Number(scores.midterm) * 2) / total +
          (Number(scores.finalTerm) * 3) / total
        ).toFixed(1);
      }
      return "";
    }
    case SUBJECT_TYPE_MAPPING.LOAI_2.type: {
      const { oral1, oral2, midterm, finalTerm } = scores || {};

      const values = [oral1, oral2, midterm, finalTerm];
      if (values.some((v) => v == null || v === "")) return "";

      const totalWeight = 7;

      const result =
        (Number(oral1) * 1 +
          Number(oral2) * 1 +
          Number(midterm) * 2 +
          Number(finalTerm) * 3) /
        totalWeight;

      return result.toFixed(1);
    }
    case SUBJECT_TYPE_MAPPING.LOAI_3.type: {
      const FIELDS = ["oral1", "oral2", "midterm", "finalTerm"];

      const values = FIELDS.map((f) => scores?.[f]);
      if (values.some((v) => !v)) return "";
      return values.every((v) => Number(v) === 10) ? "Đ" : "CĐ";
    }
    default:
      return "";
  }
};

export const initValueTable = (
  students = [],
  scoreFinal = [],
  typeSubject = "",
) => {
  if (!students || !students.length) return [];

  const result = [];
  const scoreFinalMap = {};

  // Create a map for quick lookup of scoreFinal by studentId
  if (Array.isArray(scoreFinal) && scoreFinal?.length > 0) {
    scoreFinal.forEach((final) => {
      if (!scoreFinalMap[final?.studentId]) {
        scoreFinalMap[final?.studentId] = {};
      }

      if (final?.semesterId === 1) {
        scoreFinalMap[final.studentId]["objHk1"] = {
          oral1: covertNumber(final.oral1),
          oral2: covertNumber(final.oral2),
          oral3: covertNumber(final.oral3),
          oral4: covertNumber(final.oral4),
          midterm: covertNumber(final.midterm),
          finalTerm: covertNumber(final.finalTerm),
        };
      }

      if (final?.semesterId === 2) {
        scoreFinalMap[final.studentId]["objHk2"] = {
          oral1: covertNumber(final.oral1),
          oral2: covertNumber(final.oral2),
          oral3: covertNumber(final.oral3),
          oral4: covertNumber(final.oral4),
          midterm: covertNumber(final.midterm),
          finalTerm: covertNumber(final.finalTerm),
        };
      }
    });
  }

  // mapping students to hocSinh structure, and merge scoreDraft data
  if (Array.isArray(students) && students?.length) {
    students.forEach((_s) => {
      const vals = scoreFinalMap[_s?.id];
      const item = {
        ..._s,
        ...(vals?.objHk1 || {}),
        ...(vals?.objHk2 || {}),
        hk1: genScoreByType(typeSubject, vals?.objHk1),
        hk2: genScoreByType(typeSubject, vals?.objHk2),
      };

      item["dtb"] =
        Number(item?.hk1) && Number(item?.hk2)
          ? ((Number(item?.hk1) + Number(item?.hk2)) / 2).toFixed(1)
          : "";

      if (typeSubject === SUBJECT_TYPE_MAPPING.LOAI_3.type) {
        item.oral1 = item.oral1 == 0 ? "CĐ" : item.oral1 == 10 ? "Đ" : null;
        item.oral2 = item.oral2 == 0 ? "CĐ" : item.oral2 == 10 ? "Đ" : null;
        item.midterm =
          item.midterm == 0 ? "CĐ" : item.midterm == 10 ? "Đ" : null;
        item.finalTerm =
          item.finalTerm == 0 ? "CĐ" : item.finalTerm == 10 ? "Đ" : null;
      }

      result.push(item);
    });
  }

  return {
    students: result,
  };
};

export const getGradeClass = (score) => {
  if (!score || score == "") return "";
  // Nếu là "Đ" hoặc "Đạt" thì return "excellent"
  if (
    String(score).toUpperCase() === "Đ" ||
    String(score).toUpperCase() === "ĐẠT"
  ) {
    return "excellent";
  }
  // Nếu là "CĐ" hoặc "Chưa Đạt" thì return "weak"
  if (
    String(score).toUpperCase() === "CĐ" ||
    String(score).toUpperCase() === "CHƯA ĐẠT"
  ) {
    return "weak";
  }
  const num = parseFloat(score);
  if (num >= 8) return "excellent";
  if (num >= 6.5) return "good";
  if (num >= 5) return "average";
  return "weak";
};
