import { ArrowBack as ArrowBackIcon } from "@mui/icons-material";
import { getExamPeriodCategoryAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import { Text } from "components/Styled";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import ConfigCard from "./components/ConfigCard";
import ConfirmModal from "./components/ConfirmModal";
import ExamSelectCard from "./components/ExamSelectCard";
import RoomsList from "./components/RoomsList";
import SaveBar from "./components/SaveBar";
import StepIndicator from "./components/StepIndicator";
import SummaryBar from "./components/SummaryBar";
import { ToastContainer } from "./components/Toast";
import { createRoomsAction, queryExamsAction } from "./store/actions";
import { key } from "./store/constants";
import {
  ButtonGhost,
  LeftPanel,
  MainLayout,
  RightPanel,
  TwoColLayout,
} from "./Styled";
import { handleScrollToPosition } from "utils/helpers";
import {
  exportAllRoomsToExcel,
  exportSingleRoomToExcel,
} from "./utils/exportExcel";

const Main = () => {
  const queryExams = useDispatchRedux(queryExamsAction);
  const createRooms = useDispatchRedux(createRoomsAction);
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  // State từ store
  const exams = useOneState(key, "exams") || [];

  // Local state
  const [selectedExamId, setSelectedExamId] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [configMode, setConfigMode] = useState("perRoom"); // 'perRoom' | 'roomCount'
  const [perRoom, setPerRoom] = useState(20);
  const [roomCount, setRoomCount] = useState(3);
  const [roomPrefix, setRoomPrefix] = useState("Phòng ");
  const [sbdPrefix, setSbdPrefix] = useState("");
  const [roomStartNum, setRoomStartNum] = useState(101);
  const [sortType, setSortType] = useState("alpha");
  const [generatedRooms, setGeneratedRooms] = useState([]);
  const [isSaved, setIsSaved] = useState(false);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    fetchExamPeriodCategory();

    setTimeout(() => {
      queryExams();
    }, 500);
  }, []);

  // Lọc kỳ thi hết hạn đăng ký
  const expiredExams = exams;

  // Selected exam
  const selectedExam = useMemo(() => {
    return expiredExams.find((e) => e.id === selectedExamId);
  }, [expiredExams, selectedExamId]);

  // Approved students count
  const approvedCount = useMemo(() => {
    if (!selectedExam) return 0;
    return (selectedExam.students || []).filter(
      (student) => student?.status !== "CANCELLED",
    ).length;
  }, [selectedExam]);

  // Preview text
  const previewText = useMemo(() => {
    if (!selectedExam || approvedCount === 0) return null;

    let numRooms,
      perRoomVal,
      lastRoom,
      lines = [];

    if (configMode === "perRoom") {
      perRoomVal = perRoom;
      numRooms = Math.ceil(approvedCount / perRoomVal);
      lastRoom = approvedCount % perRoomVal || perRoomVal;
    } else {
      numRooms = roomCount;
      perRoomVal = Math.ceil(approvedCount / numRooms);
      lastRoom =
        approvedCount - (numRooms - 1) * Math.floor(approvedCount / numRooms);
    }

    lines.push(
      `📋 <strong>${approvedCount} học sinh</strong> → <strong>${numRooms} phòng</strong> (${roomPrefix}${roomStartNum} → ${roomPrefix}${roomStartNum + numRooms - 1})`,
    );
    if (numRooms > 1) {
      const mainCount = approvedCount - lastRoom;
      const mainRooms = numRooms - 1;
      lines.push(
        `👥 ${mainRooms} phòng đầu: <strong>${Math.floor(mainCount / mainRooms)} HS</strong> · Phòng cuối: <strong>${lastRoom} HS</strong>`,
      );
    } else {
      lines.push(`👥 1 phòng: <strong>${approvedCount} HS</strong>`);
    }

    return lines.join("<br>");
  }, [
    selectedExam,
    approvedCount,
    configMode,
    perRoom,
    roomCount,
    roomPrefix,
    roomStartNum,
  ]);

  // Handlers
  const handleSelectExam = useCallback((examId) => {
    setSelectedExamId(examId);
    setCurrentStep(2);
    setIsSaved(false);
    setGeneratedRooms([]);
  }, []);

  const handleConfigModeChange = useCallback((mode) => {
    setConfigMode(mode);
  }, []);

  const handlePerRoomChange = useCallback((delta, value) => {
    if (value !== undefined) {
      setPerRoom(Math.max(1, Math.min(200, value)));
    } else {
      setPerRoom((prev) => Math.max(1, Math.min(200, prev + delta)));
    }
  }, []);

  const handleRoomCountChange = useCallback((delta, value) => {
    if (value !== undefined) {
      setRoomCount(Math.max(1, Math.min(100, value)));
    } else {
      setRoomCount((prev) => Math.max(1, Math.min(100, prev + delta)));
    }
  }, []);

  const handleRoomPrefixChange = useCallback((value) => {
    setRoomPrefix(value);
  }, []);

  const handleSbdPrefixChange = useCallback((value) => {
    setSbdPrefix(value);
  }, []);

  const handleRoomStartNumChange = useCallback((value) => {
    setRoomStartNum(Math.max(1, value));
  }, []);

  const handleSortTypeChange = useCallback((type) => {
    setSortType(type);
  }, []);

  const handleGenerateRooms = useCallback(() => {
    if (!selectedExam) return;

    setTimeout(() => {
      let students = (selectedExam.students || []).filter(
        (student) => student?.status !== "CANCELLED",
      );

      // Sort students
      if (sortType === "alpha") {
        students.sort((a, b) => {
          const splitName = (student) => {
            const rawName = (student?.name || student?.fullName || "")
              .trim()
              .replace(/\s+/g, " ");
            if (!rawName) return { lastName: "", familyName: "" };

            const parts = rawName.split(" ");
            const lastName = parts[parts.length - 1] || "";
            const familyName = parts.slice(0, -1).join(" ");

            return { lastName, familyName };
          };

          const compareText = (x, y) =>
            (x || "").localeCompare(y || "", "vi", { sensitivity: "base" });

          const aName = splitName(a);
          const bName = splitName(b);

          const byLastName = compareText(aName.lastName, bName.lastName);
          if (byLastName !== 0) return byLastName;

          const byFamilyName = compareText(aName.familyName, bName.familyName);
          if (byFamilyName !== 0) return byFamilyName;

          const bySchool = compareText(a?.school, b?.school);
          if (bySchool !== 0) return bySchool;

          const byClass = compareText(
            a?.class || a?.className,
            b?.class || b?.className,
          );
          if (byClass !== 0) return byClass;

          return compareText(a?.name || a?.fullName, b?.name || b?.fullName);
        });
      } else if (sortType === "random") {
        for (let i = students.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [students[i], students[j]] = [students[j], students[i]];
        }
      } else if (sortType === "score_desc") {
        students.sort(
          (a, b) =>
            (b.avgScore || b.averageScore || 0) -
            (a.avgScore || a.averageScore || 0),
        );
      } else if (sortType === "class") {
        students.sort((a, b) =>
          (a.class || a.className || "").localeCompare(
            b.class || b.className || "",
            "vi",
          ),
        );
      }

      // Split into rooms
      const rooms = [];
      let sbdCounter = 1;
      const formatSbd = (counter) =>
        `${sbdPrefix || ""}${String(counter).padStart(3, "0")}`;

      if (configMode === "roomCount") {
        // Distribute into exactly roomCount rooms using floor + remainder spread
        const baseSize = Math.floor(students.length / roomCount);
        const remainder = students.length % roomCount;
        let offset = 0;
        for (let i = 0; i < roomCount; i++) {
          const size = baseSize + (i < remainder ? 1 : 0);
          if (size === 0) break; // fewer students than rooms requested
          const chunk = students.slice(offset, offset + size);
          offset += size;
          const roomNum = roomStartNum + rooms.length;
          rooms.push({
            id: `R${rooms.length + 1}`,
            name: `${roomPrefix}${roomNum}`,
            students: chunk.map((s) => {
              const sbd = formatSbd(sbdCounter++);
              return {
                ...s,
                sbd,
                registrationNumber: sbd,
              };
            }),
          });
        }
      } else {
        const perRoomVal = perRoom;
        for (let i = 0; i < students.length; i += perRoomVal) {
          const chunk = students.slice(i, i + perRoomVal);
          const roomNum = roomStartNum + rooms.length;
          rooms.push({
            id: `R${rooms.length + 1}`,
            name: `${roomPrefix}${roomNum}`,
            students: chunk.map((s) => {
              const sbd = formatSbd(sbdCounter++);
              return {
                ...s,
                sbd,
                registrationNumber: sbd,
              };
            }),
          });
        }
      }

      setGeneratedRooms(rooms);
      setCurrentStep(3);
      addToast("Đã phân chia phòng thi thành công!", "success");
      handleScrollToPosition(200);
    }, 900);
  }, [
    selectedExam,
    configMode,
    perRoom,
    roomCount,
    roomPrefix,
    sbdPrefix,
    roomStartNum,
    sortType,
  ]);

  const handleRoomNameChange = useCallback((roomId, newName) => {
    setGeneratedRooms((prev) =>
      prev.map((r) => (r.id === roomId ? { ...r, name: newName } : r)),
    );
  }, []);

  const handleReshuffle = useCallback(() => {
    if (
      !window.confirm(
        "Xáo trộn lại sẽ thay đổi toàn bộ danh sách phòng. Tiếp tục?",
      )
    )
      return;
    handleGenerateRooms();
  }, [handleGenerateRooms]);

  const handleExportAllExcel = useCallback(async () => {
    if (generatedRooms.length === 0) return;
    addToast("Đang xuất file Excel...", "default");
    await exportAllRoomsToExcel(generatedRooms, selectedExam);
    addToast("Đã xuất file Excel thành công!", "success");
  }, [generatedRooms, selectedExam]);

  const handleExportRoomExcel = useCallback(
    async (roomIndex) => {
      const room = generatedRooms[roomIndex];
      if (!room) return;
      addToast(`Đang xuất Excel phòng ${room.name}...`, "default");
      await exportSingleRoomToExcel(room, selectedExam);
      addToast(`Đã xuất Excel phòng ${room.name}`, "success");
    },
    [generatedRooms, selectedExam],
  );

  const handlePrintRoom = useCallback(
    (roomIndex) => {
      addToast(
        `Đang in danh sách ${generatedRooms[roomIndex]?.name}...`,
        "default",
      );
    },
    [generatedRooms],
  );

  const handlePrintAll = useCallback(() => {
    addToast("Đang in toàn bộ danh sách phòng thi...", "default");
  }, []);

  const handleSave = useCallback(() => {
    setConfirmModalOpen(true);
  }, []);

  const handleConfirmSave = useCallback(async () => {
    if (!selectedExam || generatedRooms.length === 0) return;

    setConfirmModalOpen(false);

    await createRooms({
      contestId: selectedExam.id,
      rooms: generatedRooms,
      cb: () => {
        setCurrentStep(4);
        setIsSaved(true);
      },
    });
  }, [selectedExam, generatedRooms, createRooms]);

  const handleReset = useCallback(() => {
    if (!window.confirm("Làm lại sẽ xóa toàn bộ phòng thi đã tạo. Tiếp tục?"))
      return;
    setGeneratedRooms([]);
    setSelectedExamId(null);
    setCurrentStep(1);
    setIsSaved(false);
  }, []);

  const addToast = useCallback((message, type = "default") => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type }]);
  }, []);

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <>
      <AppHeader
        isHiddenBtn
        componentName="CreateRoomGiamThi"
        externalBtn={
          <ButtonGhost
            variant="outlined"
            startIcon={<ArrowBackIcon />}
            onClick={() => window.history.back()}
          >
            Quay lại
          </ButtonGhost>
        }
      />
      <Text> Phân chia học sinh vào các phòng và sinh số báo danh tự động</Text>

      <MainLayout mt={3}>
        <StepIndicator currentStep={currentStep} />

        <TwoColLayout>
          <LeftPanel>
            <ExamSelectCard
              exams={exams}
              selectedExamId={selectedExamId}
              onSelectExam={handleSelectExam}
            />
            <ConfigCard
              approvedCount={approvedCount}
              configMode={configMode}
              onConfigModeChange={handleConfigModeChange}
              perRoom={perRoom}
              onPerRoomChange={handlePerRoomChange}
              roomCount={roomCount}
              onRoomCountChange={handleRoomCountChange}
              roomPrefix={roomPrefix}
              onRoomPrefixChange={handleRoomPrefixChange}
              sbdPrefix={sbdPrefix}
              onSbdPrefixChange={handleSbdPrefixChange}
              roomStartNum={roomStartNum}
              onRoomStartNumChange={handleRoomStartNumChange}
              sortType={sortType}
              onSortTypeChange={handleSortTypeChange}
              previewText={previewText}
              onGenerate={handleGenerateRooms}
              disabled={!selectedExam}
            />
          </LeftPanel>

          <RightPanel>
            {generatedRooms.length > 0 && <SummaryBar rooms={generatedRooms} />}
            <RoomsList
              rooms={generatedRooms}
              onRoomNameChange={handleRoomNameChange}
              onReshuffle={handleReshuffle}
              onExportAll={handleExportAllExcel}
              onExportRoom={handleExportRoomExcel}
            />
          </RightPanel>
        </TwoColLayout>

        {generatedRooms.length > 0 && (
          <SaveBar
            rooms={generatedRooms}
            isSaved={isSaved}
            onReset={handleReset}
            onSave={handleSave}
            onExportAll={handleExportAllExcel}
          />
        )}
      </MainLayout>

      <ConfirmModal
        open={confirmModalOpen}
        exam={selectedExam}
        rooms={generatedRooms}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={handleConfirmSave}
      />
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </>
  );
};

export default Main;
