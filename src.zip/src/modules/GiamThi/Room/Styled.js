import { Box, Button, Chip, Typography } from "@mui/material";
import { styled } from "@mui/material/styles";

// ── COLORS & THEME ──
const colors = {
  bg: "#f0f4f8",
  surface: "#ffffff",
  surface2: "#f8fafc",
  border: "#e2e8f0",
  borderFocus: "#3b82f6",
  primary: "#1e40af",
  primaryLight: "#3b82f6",
  primaryGradient: "linear-gradient(135deg, #1e40af 0%, #3b82f6 100%)",
  accent: "#0ea5e9",
  success: "#10b981",
  warning: "#f59e0b",
  danger: "#ef4444",
  purple: "#8b5cf6",
  text: "#0f172a",
  text2: "#475569",
  text3: "#94a3b8",
};

// ── LAYOUT ──
export const MainLayout = styled(Box)({
  minHeight: "calc(100vh - 64px)",
});

export const TwoColLayout = styled(Box)({
  display: "grid",
  gridTemplateColumns: "360px 1fr",
  gap: "20px",
  alignItems: "start",
  "@media (max-width: 1100px)": {
    gridTemplateColumns: "320px 1fr",
  },
  "@media (max-width: 900px)": {
    gridTemplateColumns: "1fr",
  },
});

export const LeftPanel = styled(Box)({
  display: "flex",
  flexDirection: "column",
  gap: "20px",
});

export const RightPanel = styled(Box)({
  display: "flex",
  flexDirection: "column",
  gap: "16px",
});

// ── PAGE HEADER ──
export const PageHeader = styled(Box)({
  display: "flex",
  alignItems: "flex-start",
  justifyContent: "space-between",
  marginBottom: "24px",
  gap: "16px",
  flexWrap: "wrap",
});

export const Breadcrumb = styled(Box)({
  display: "flex",
  alignItems: "center",
  gap: "8px",
  fontSize: "13px",
  color: colors.text3,
  marginBottom: "6px",
});

export const BreadcrumbLink = styled(Box)({
  color: colors.text3,
  textDecoration: "none",
  cursor: "pointer",
  "&:hover": {
    color: colors.primaryLight,
  },
});

export const PageTitle = styled(Typography)({
  fontSize: "26px",
  fontWeight: 800,
  color: colors.text,
  letterSpacing: "-0.5px",
  "@media (max-width: 640px)": {
    fontSize: "22px",
  },
});

export const PageSubtitle = styled(Typography)({
  fontSize: "14px",
  color: colors.text2,
  marginTop: "4px",
});

// ── STEPS INDICATOR ──
export const StepsContainer = styled(Box)({
  display: "flex",
  alignItems: "center",
  gap: 0,
  marginBottom: "28px",
  background: colors.surface,
  border: `1px solid ${colors.border}`,
  borderRadius: "12px",
  padding: "16px 24px",
  boxShadow: "0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)",
  "@media (max-width: 640px)": {
    flexDirection: "column",
    gap: "8px",
    padding: "12px 16px",
  },
});

export const Step = styled(Box)({
  display: "flex",
  alignItems: "center",
  gap: "10px",
  flex: 1,
});

export const StepNum = styled(Box)(({ status }) => {
  const baseStyle = {
    width: "32px",
    height: "32px",
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 800,
    fontSize: "13px",
    flexShrink: 0,
    transition: "all 0.3s",
  };

  if (status === "pending") {
    return {
      ...baseStyle,
      background: colors.bg,
      color: colors.text3,
      border: `2px solid ${colors.border}`,
    };
  }
  if (status === "active") {
    return {
      ...baseStyle,
      background: colors.primaryGradient,
      color: "white",
      boxShadow: "0 2px 8px rgba(59,130,246,0.4)",
    };
  }
  if (status === "done") {
    return {
      ...baseStyle,
      background: colors.success,
      color: "white",
    };
  }
  return baseStyle;
});

export const StepInfo = styled(Box)({});

export const StepLabel = styled(Typography)(({ status }) => ({
  fontSize: "13px",
  fontWeight: 700,
  color: status === "pending" ? colors.text3 : colors.text,
}));

export const StepDesc = styled(Typography)({
  fontSize: "11px",
  color: colors.text3,
  marginTop: "1px",
});

export const StepSep = styled(Box)(({ done }) => ({
  width: "40px",
  height: "2px",
  background: done ? colors.success : colors.border,
  margin: "0 8px",
  flexShrink: 0,
  transition: "background 0.3s",
  "@media (max-width: 640px)": {
    width: "2px",
    height: "20px",
  },
}));

// ── CARD ──
export const Card = styled(Box)({
  background: colors.surface,
  border: `1px solid ${colors.border}`,
  borderRadius: "16px",
  boxShadow: "0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)",
  overflow: "hidden",
  marginBottom: "20px",
});

export const CardHeader = styled(Box)({
  padding: "18px 24px",
  borderBottom: `1px solid ${colors.border}`,
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
});

export const CardTitle = styled(Box)({
  fontSize: "16px",
  fontWeight: 700,
  display: "flex",
  alignItems: "center",
  gap: "10px",
});

export const TitleIcon = styled(Box)(({ color }) => ({
  width: "32px",
  height: "32px",
  borderRadius: "8px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "14px",
  flexShrink: 0,
  background:
    color === "blue"
      ? "#eff6ff"
      : color === "orange"
      ? "#fffbeb"
      : color === "green"
      ? "#f0fdf4"
      : color === "purple"
      ? "#f5f3ff"
      : "#eff6ff",
  color:
    color === "blue"
      ? colors.primaryLight
      : color === "orange"
      ? colors.warning
      : color === "green"
      ? colors.success
      : color === "purple"
      ? colors.purple
      : colors.primaryLight,
}));

export const CardBody = styled(Box)({
  padding: "20px 24px",
});

// ── EXAM SELECT ──
export const ExamOption = styled(Box)(({ selected }) => ({
  display: "flex",
  alignItems: "center",
  gap: "12px",
  padding: "14px 16px",
  border: `1.5px solid ${selected ? colors.primaryLight : colors.border}`,
  borderRadius: "10px",
  cursor: "pointer",
  transition: "all 0.15s",
  marginBottom: "8px",
  background: selected ? "#eff6ff" : "transparent",
  "&:hover": {
    borderColor: colors.primaryLight,
    background: "#f8faff",
  },
}));

export const ExamRadio = styled(Box)(({ selected }) => ({
  width: "18px",
  height: "18px",
  borderRadius: "50%",
  border: `2px solid ${selected ? colors.primaryLight : colors.border}`,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  transition: "all 0.15s",
  background: selected ? colors.primaryLight : "transparent",
  "&::after": selected
    ? {
        content: '""',
        width: "7px",
        height: "7px",
        borderRadius: "50%",
        background: "white",
      }
    : {},
}));

export const ExamInfoName = styled(Typography)({
  fontWeight: 700,
  fontSize: "13px",
  color: colors.text,
  marginBottom: "4px",
});

export const ExamInfoMeta = styled(Box)({
  display: "flex",
  gap: "6px",
  flexWrap: "wrap",
});

export const MetaPill = styled(Chip)(({ type }) => {
  const config = {
    grade: { bg: "#f1f5f9", color: colors.text2 },
    stu: { bg: "#d1fae5", color: "#065f46" },
    date: { bg: "#fef3c7", color: "#92400e" },
  };
  const { bg, color } = config[type] || config.grade;
  return {
    padding: "2px 7px",
    borderRadius: "4px",
    fontSize: "11px",
    fontWeight: 600,
    background: bg,
    color: color,
    height: "auto",
    "& .MuiChip-label": {
      padding: 0,
    },
  };
});

// ── FORM FIELDS ──
export const Field = styled(Box)({
  display: "flex",
  flexDirection: "column",
  gap: "6px",
  marginBottom: "16px",
  "&:last-child": {
    marginBottom: 0,
  },
});

export const FieldLabel = styled(Typography)({
  fontSize: "12px",
  fontWeight: 700,
  color: colors.text2,
  textTransform: "uppercase",
  letterSpacing: "0.3px",
});

export const FieldHint = styled(Typography)({
  fontSize: "11px",
  color: colors.text3,
});

export const Input = styled("input")({
  width: "100%",
  padding: "9px 13px",
  border: `1.5px solid ${colors.border}`,
  borderRadius: "8px",
  fontFamily: "inherit",
  fontSize: "14px",
  color: colors.text,
  background: colors.surface,
  outline: "none",
  transition: "all 0.15s",
  "&:focus": {
    borderColor: colors.borderFocus,
    boxShadow: "0 0 0 3px rgba(59,130,246,0.1)",
  },
});

export const SelectWrap = styled(Box)({
  position: "relative",
  "&::after": {
    content: '"▼"',
    position: "absolute",
    right: "12px",
    top: "50%",
    transform: "translateY(-50%)",
    color: colors.text3,
    fontSize: "11px",
    pointerEvents: "none",
  },
});

export const Select = styled("select")({
  width: "100%",
  padding: "9px 32px 9px 13px",
  border: `1.5px solid ${colors.border}`,
  borderRadius: "8px",
  fontFamily: "inherit",
  fontSize: "14px",
  color: colors.text,
  background: colors.surface,
  outline: "none",
  cursor: "pointer",
  appearance: "none",
  transition: "all 0.15s",
  "&:focus": {
    borderColor: colors.borderFocus,
    boxShadow: "0 0 0 3px rgba(59,130,246,0.1)",
  },
});

export const NumInput = styled(Box)({
  display: "flex",
  alignItems: "center",
  border: `1.5px solid ${colors.border}`,
  borderRadius: "8px",
  overflow: "hidden",
});

export const NumBtn = styled(Button)({
  width: "36px",
  height: "38px",
  border: "none",
  background: colors.surface2,
  cursor: "pointer",
  fontSize: "16px",
  color: colors.text2,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  transition: "background 0.15s",
  flexShrink: 0,
  minWidth: "36px",
  padding: 0,
  "&:hover": {
    background: colors.border,
  },
});

export const NumInputField = styled("input")({
  flex: 1,
  padding: "8px",
  border: "none",
  outline: "none",
  textAlign: "center",
  fontFamily: "'JetBrains Mono', monospace",
  fontSize: "15px",
  fontWeight: 700,
  color: colors.text,
  minWidth: 0,
});

// ── CONFIG MODE TABS ──
export const ConfigModeTabs = styled(Box)({
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: "8px",
  marginTop: "6px",
});

export const ConfigModeTab = styled(Box)(({ active }) => ({
  display: "flex",
  alignItems: "center",
  gap: "9px",
  padding: "10px 13px",
  borderRadius: "9px",
  border: `2px solid ${active ? colors.primaryLight : colors.border}`,
  background: active ? "#eff6ff" : colors.surface2,
  cursor: "pointer",
  transition: "all 0.15s",
}));

// ── SORT OPTIONS ──
export const SortOptions = styled(Box)({
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: "8px",
});

export const SortOpt = styled(Box)(({ selected }) => ({
  display: "flex",
  alignItems: "center",
  gap: "8px",
  padding: "10px 12px",
  border: `1.5px solid ${selected ? colors.primaryLight : colors.border}`,
  borderRadius: "8px",
  cursor: "pointer",
  transition: "all 0.15s",
  background: selected ? "#eff6ff" : "transparent",
  "&:hover": {
    borderColor: colors.primaryLight,
  },
}));

export const SortRadio = styled(Box)(({ selected }) => ({
  width: "16px",
  height: "16px",
  borderRadius: "50%",
  border: `2px solid ${selected ? colors.primaryLight : colors.border}`,
  flexShrink: 0,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  transition: "all 0.15s",
  background: selected ? colors.primaryLight : "transparent",
  "&::after": selected
    ? {
        content: '""',
        width: "6px",
        height: "6px",
        borderRadius: "50%",
        background: "white",
      }
    : {},
}));

export const SortOptLabel = styled(Typography)(({ selected }) => ({
  fontSize: "13px",
  fontWeight: 600,
  color: selected ? colors.primary : colors.text2,
}));

// ── PREVIEW ──
export const PreviewBox = styled(Box)({
  display: "none",
  padding: "12px 16px",
  background: "#eff6ff",
  border: `1.5px solid ${colors.primaryLight}`,
  borderRadius: "8px",
  marginBottom: "16px",
  "&.show": {
    display: "block",
  },
});

export const PreviewText = styled(Typography)({
  fontSize: "13px",
  color: colors.primary,
  fontWeight: 600,
  lineHeight: 1.6,
});

// ── BUTTONS ──
export const ButtonPrimary = styled(Button)({
  background: colors.primaryGradient,
  color: "white",
  boxShadow: "0 2px 8px rgba(30,64,175,0.25)",
  textTransform: "none",
  fontSize: "13px",
  fontWeight: 600,
  padding: "9px 18px",
  borderRadius: "8px",
  "&:hover": {
    transform: "translateY(-1px)",
    boxShadow: "0 4px 14px rgba(30,64,175,0.35)",
    background: colors.primaryGradient,
  },
  "&:disabled": {
    opacity: 0.5,
    cursor: "not-allowed",
    transform: "none",
  },
});

export const ButtonGhost = styled(Button)({
  background: "transparent",
  color: colors.text2,
  border: `1.5px solid ${colors.border}`,
  textTransform: "none",
  fontSize: "13px",
  fontWeight: 600,
  padding: "9px 18px",
  borderRadius: "8px",
  "&:hover": {
    background: colors.bg,
    color: colors.text,
    borderColor: colors.border,
  },
});

export const ButtonSuccess = styled(Button)({
  background: colors.success,
  color: "white",
  boxShadow: "0 2px 8px rgba(16,185,129,0.25)",
  textTransform: "none",
  fontSize: "13px",
  fontWeight: 600,
  padding: "9px 18px",
  borderRadius: "8px",
  "&:hover": {
    background: "#059669",
    transform: "translateY(-1px)",
  },
});

export const ButtonSmall = styled(Button)({
  padding: "6px 12px",
  fontSize: "12px",
  textTransform: "none",
});

export const ButtonIcon = styled(Button)({
  width: "30px",
  height: "30px",
  padding: 0,
  minWidth: "30px",
  borderRadius: "6px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
});

export const GenerateButton = styled(Button)({
  width: "100%",
  padding: "14px",
  borderRadius: "10px",
  background: colors.primaryGradient,
  color: "white",
  border: "none",
  fontFamily: "inherit",
  fontSize: "15px",
  fontWeight: 700,
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "10px",
  boxShadow: "0 8px 32px rgba(30,64,175,0.12)",
  textTransform: "none",
  "&:hover": {
    transform: "translateY(-2px)",
    boxShadow: "0 8px 24px rgba(30,64,175,0.4)",
    background: colors.primaryGradient,
  },
  "&:active": {
    transform: "translateY(0)",
  },
  "&:disabled": {
    opacity: 0.5,
    cursor: "not-allowed",
    transform: "none",
  },
});

// ── SUMMARY BAR ──
export const SummaryBar = styled(Box)({
  display: "grid",
  gridTemplateColumns: "repeat(4, 1fr)",
  gap: "12px",
  marginBottom: "20px",
  "@media (max-width: 900px)": {
    gridTemplateColumns: "repeat(2, 1fr)",
  },
  "@media (max-width: 640px)": {
    gridTemplateColumns: "1fr 1fr",
  },
});

export const SummaryItem = styled(Box)({
  background: colors.surface,
  border: `1px solid ${colors.border}`,
  borderRadius: "10px",
  padding: "14px 18px",
  boxShadow: "0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)",
});

export const SummaryVal = styled(Typography)({
  fontSize: "22px",
  fontWeight: 800,
  color: colors.primary,
});

export const SummaryLabel = styled(Typography)({
  fontSize: "12px",
  color: colors.text3,
  marginTop: "2px",
  fontWeight: 500,
});

// ── ROOMS ──
export const RoomsArea = styled(Box)({
  display: "flex",
  flexDirection: "column",
  gap: "16px",
});

export const RoomCard = styled(Box)({
  background: colors.surface,
  border: `1px solid ${colors.border}`,
  borderRadius: "14px",
  boxShadow: "0 1px 3px rgba(0,0,0,0.06), 0 4px 16px rgba(0,0,0,0.04)",
  overflow: "hidden",
  transition: "box-shadow 0.2s",
  "&:hover": {
    boxShadow: "0 8px 32px rgba(30,64,175,0.12)",
  },
});

export const RoomCardHeader = styled(Box)({
  padding: "14px 20px",
  background: colors.surface2,
  borderBottom: `1px solid ${colors.border}`,
  display: "flex",
  alignItems: "center",
  gap: "12px",
});

export const RoomNumberBadge = styled(Box)({
  width: "36px",
  height: "36px",
  borderRadius: "10px",
  background: colors.primaryGradient,
  color: "white",
  fontWeight: 800,
  fontSize: "14px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  fontFamily: "'JetBrains Mono', monospace",
});

export const RoomNameInput = styled("input")({
  flex: 1,
  padding: "7px 12px",
  border: `1.5px solid ${colors.border}`,
  borderRadius: "7px",
  fontFamily: "'Be Vietnam Pro', sans-serif",
  fontSize: "14px",
  fontWeight: 700,
  color: colors.text,
  outline: "none",
  background: "white",
  transition: "border-color 0.15s",
  "&:focus": {
    borderColor: colors.primaryLight,
    boxShadow: "0 0 0 3px rgba(59,130,246,0.1)",
  },
});

export const RoomCountBadge = styled(Chip)({
  padding: "4px 10px",
  borderRadius: "20px",
  background: "#eff6ff",
  color: colors.primary,
  fontSize: "12px",
  fontWeight: 700,
  whiteSpace: "nowrap",
  height: "auto",
  "& .MuiChip-label": {
    padding: 0,
  },
});

export const RoomActions = styled(Box)({
  display: "flex",
  gap: "6px",
  marginLeft: "auto",
});

export const RoomTableWrap = styled(Box)({
  overflowX: "auto",
});

export const RoomTable = styled("table")({
  width: "100%",
  borderCollapse: "collapse",
  minWidth: "520px",
});

export const RoomTableHead = styled("thead")({});

export const RoomTableHeader = styled("th")({
  padding: "8px 14px",
  fontSize: "11px",
  fontWeight: 700,
  color: colors.text3,
  textTransform: "uppercase",
  letterSpacing: "0.4px",
  background: colors.surface2,
  borderBottom: `1px solid ${colors.border}`,
  textAlign: "left",
});

export const RoomTableBody = styled("tbody")({});

export const RoomTableRow = styled("tr")({
  "&:hover": {
    background: "#f8faff",
  },
  "&:last-child td": {
    borderBottom: "none",
  },
});

export const RoomTableCell = styled("td")({
  padding: "10px 14px",
  fontSize: "13px",
  borderBottom: `1px solid ${colors.border}`,
  verticalAlign: "middle",
});

export const SbdBadge = styled(Chip)({
  fontSize: "12px",
  fontWeight: 700,
  background: colors.bg,
  color: colors.text2,
  padding: "3px 8px",
  borderRadius: "5px",
  height: "auto",
  "& .MuiChip-label": {
    padding: 0,
  },
});

export const ScoreVal = styled(Typography)(({ level }) => ({
  fontWeight: 700,
  color:
    level === "high" ? colors.success : level === "mid" ? colors.warning : colors.danger,
}));

export const OvergradeBadge = styled(Chip)({
  padding: "2px 6px",
  borderRadius: "4px",
  fontSize: "10px",
  fontWeight: 700,
  background: "#fef3c7",
  color: "#92400e",
  height: "auto",
  "& .MuiChip-label": {
    padding: 0,
  },
});

// ── EMPTY STATE ──
export const RoomsEmpty = styled(Box)({
  textAlign: "center",
  padding: "60px 20px",
  background: colors.surface,
  border: `2px dashed ${colors.border}`,
  borderRadius: "16px",
});

export const RoomsEmptyIcon = styled(Box)({
  fontSize: "52px",
  color: colors.text3,
  marginBottom: "16px",
  opacity: 0.4,
});

export const RoomsEmptyTitle = styled(Typography)({
  fontSize: "17px",
  fontWeight: 700,
  color: colors.text2,
  marginBottom: "8px",
});

export const RoomsEmptyDesc = styled(Typography)({
  fontSize: "13px",
  color: colors.text3,
});

// ── SAVE BAR ──
export const SaveBar = styled(Box)({
  position: "sticky",
  bottom: 0,
  left: 0,
  right: 0,
  background: colors.surface,
  borderTop: `1px solid ${colors.border}`,
  padding: "16px 36px",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  zIndex: 50,
  boxShadow: "0 -4px 16px rgba(0,0,0,0.06)",
  marginLeft: "-24px",
  marginRight: "-23px",
  marginBottom: "-36px",
  "@media (max-width: 1024px)": {
    marginLeft: "-20px",
    marginRight: "-20px",
    marginBottom: "-24px",
    padding: "16px 20px",
  },
  "@media (max-width: 640px)": {
    marginLeft: "-16px",
    marginRight: "-16px",
    marginBottom: "-16px",
    padding: "-16px 16px",
    flexDirection: "column",
    gap: "12px",
    alignItems: "stretch",
  },
});

export const SaveBarInfo = styled(Typography)({
  fontSize: "13px",
  color: colors.text2,
  "& strong": {
    color: colors.text,
  },
});

export const SaveBarActions = styled(Box)({
  display: "flex",
  gap: "10px",
  "@media (max-width: 640px)": {
    width: "100%",
    flexDirection: "column",
  },
});

// ── LOADING OVERLAY ──
export const LoadingOverlay = styled(Box)(({ show }) => ({
  display: show ? "flex" : "none",
  position: "fixed",
  inset: 0,
  background: "rgba(255,255,255,0.85)",
  zIndex: 300,
  alignItems: "center",
  justifyContent: "center",
  flexDirection: "column",
  gap: "16px",
  backdropFilter: "blur(4px)",
}));

export const Spinner = styled(Box)({
  width: "48px",
  height: "48px",
  border: `4px solid ${colors.border}`,
  borderTopColor: colors.primaryLight,
  borderRadius: "50%",
  animation: "spin 0.8s linear infinite",
  "@keyframes spin": {
    to: {
      transform: "rotate(360deg)",
    },
  },
});

export const LoadingText = styled(Typography)({
  fontSize: "16px",
  fontWeight: 600,
  color: colors.text2,
});

// ── TOAST ──
export const ToastWrap = styled(Box)({
  position: "fixed",
  bottom: "80px",
  right: "24px",
  zIndex: 999,
  display: "flex",
  flexDirection: "column",
  gap: "8px",
});

export const Toast = styled(Box)(({ type }) => ({
  display: "flex",
  alignItems: "center",
  gap: "10px",
  padding: "13px 18px",
  borderRadius: "10px",
  background: type === "success" ? colors.success : type === "error" ? colors.danger : colors.text,
  color: "white",
  boxShadow: "0 8px 24px rgba(0,0,0,0.18)",
  fontSize: "13px",
  fontWeight: 500,
  animation: "slideUp 0.3s ease",
  maxWidth: "360px",
  "@keyframes slideUp": {
    from: {
      transform: "translateY(14px)",
      opacity: 0,
    },
    to: {
      transform: "translateY(0)",
      opacity: 1,
    },
  },
}));

// ── MODAL ──
export const ModalOverlay = styled(Box)(({ show }) => ({
  display: show ? "flex" : "none",
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,0.45)",
  zIndex: 200,
  alignItems: "center",
  justifyContent: "center",
}));

export const Modal = styled(Box)({
  background: colors.surface,
  borderRadius: "16px",
  padding: "28px",
  width: "100%",
  maxWidth: "420px",
  boxShadow: "0 24px 64px rgba(0,0,0,0.2)",
  animation: "popIn 0.2s ease",
  "@keyframes popIn": {
    from: {
      transform: "scale(0.95)",
      opacity: 0,
    },
    to: {
      transform: "scale(1)",
      opacity: 1,
    },
  },
});

export const ModalIcon = styled(Box)({
  width: "52px",
  height: "52px",
  borderRadius: "14px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: "24px",
  marginBottom: "16px",
  background: "#f0fdf4",
});

export const ModalTitle = styled(Typography)({
  fontSize: "18px",
  fontWeight: 800,
  marginBottom: "8px",
});

export const ModalDesc = styled(Typography)({
  fontSize: "14px",
  color: colors.text2,
  lineHeight: 1.6,
  marginBottom: "20px",
});

export const ModalFooter = styled(Box)({
  display: "flex",
  gap: "10px",
  justifyContent: "flex-end",
});

// ── TOOLBAR ──
export const RoomsToolbar = styled(Box)({
  display: "flex",
  alignItems: "center",
  gap: "10px",
  flexWrap: "wrap",
  marginBottom: "16px",
});

export const ToolbarText = styled(Typography)({
  fontSize: "13px",
  color: colors.text2,
  fontWeight: 600,
});

export const ToolbarActions = styled(Box)({
  marginLeft: "auto",
  display: "flex",
  gap: "8px",
});

// ── APPROVED COUNT DISPLAY ──
export const ApprovedCountBox = styled(Box)({
  display: "flex",
  alignItems: "center",
  gap: "10px",
  padding: "10px 14px",
  background: colors.surface2,
  border: `1.5px solid ${colors.border}`,
  borderRadius: "8px",
});

export const ApprovedCountValue = styled(Typography)({
  fontSize: "18px",
  fontWeight: 800,
  color: colors.text,
});

export const ApprovedCountLabel = styled(Typography)({
  fontSize: "13px",
  color: colors.text3,
});
