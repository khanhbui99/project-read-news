import { Box, TextField } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

const { colors } = VPB_THEMES;

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
  // max-width: 1440px;
  margin: 0 auto;
  padding: 0 4px 32px;
`;

export const FilterCard = styled(Box)`
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  justify-content: space-between;
  gap: 20px;
  padding: 20px 24px;
  border-radius: 16px;
  background: linear-gradient(
    135deg,
    ${colors.white} 0%,
    #f0f7fc 50%,
    #e8f4fc 100%
  );
  border: 1px solid ${colors.table.borderMedium};
  box-shadow: 0 4px 24px rgba(2, 62, 138, 0.08);
`;

export const FilterLeft = styled.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
`;

export const FilterRight = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
`;

export const FilterControlsRow = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 12px 20px;
  width: 100%;
`;

export const DateWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 200px;
`;

export const FilterLabel = styled.span`
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: ${colors.neutral};
`;

export const DateField = styled(TextField)`
  min-width: 240px;

  & .MuiOutlinedInput-root {
    height: 42px;
    border-radius: 8px;
    background: ${colors.white};
    font-weight: 600;
    color: ${colors.darkBlue};

    & .MuiOutlinedInput-input {
      height: 42px;
      box-sizing: border-box;
      padding-top: 0;
      padding-bottom: 0;
      // display: flex;
      align-items: center;
    }

    &:hover fieldset {
      border-color: ${colors.primaryBlue};
    }

    &.Mui-focused fieldset {
      border-width: 2px;
      border-color: ${colors.primaryBlue};
    }
  }

  & .MuiInputLabel-root.Mui-focused {
    color: ${colors.primaryBlue};
  }
`;

export const ScheduleCard = styled(Box)`
  border-radius: 16px;
  border: 1px solid ${colors.table.borderMedium};
  background: ${colors.white};
  box-shadow: 0 8px 32px rgba(15, 23, 42, 0.06);
  overflow: hidden;
`;

export const ScheduleScroll = styled.div`
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
`;

export const ScheduleGrid = styled.div`
  display: grid;
  grid-template-columns: 150px repeat(8, minmax(120px, 1fr));
  min-width: 1110px;
`;

export const HeaderCorner = styled.div`
  position: sticky;
  left: 0;
  z-index: 3;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 150px;
  min-width: 150px;
  max-width: 150px;
  padding: 12px 8px;
  background: linear-gradient(
    180deg,
    ${colors.darkBlue} 0%,
    #0a4a8c 100%
  );
  color: ${colors.white};
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  border-bottom: 2px solid ${colors.primaryBlue};
  box-shadow: 4px 0 12px rgba(15, 23, 42, 0.12);
`;

export const HeaderPeriod = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 12px 8px;
  background: ${colors.table.headerBg};
  border-left: 1px solid ${colors.table.borderLight};
  border-bottom: 2px solid ${colors.primaryBlue};
  text-align: center;
`;

export const HeaderPeriodTitle = styled.span`
  font-size: 13px;
  font-weight: 800;
  color: ${colors.darkBlue};
`;

export const HeaderPeriodSub = styled.span`
  font-size: 11px;
  font-weight: 600;
  color: ${colors.neutral};
`;

export const BodyRow = styled.div`
  display: contents;
`;

export const ClassNameCell = styled.div`
  position: sticky;
  left: 0;
  z-index: 2;
  display: flex;
  align-items: center;
  width: 150px;
  min-width: 150px;
  max-width: 150px;
  padding: 10px 8px;
  background: #f8fafc;
  border-top: 1px solid ${colors.table.borderLight};
  border-right: 1px solid ${colors.table.borderLight};
  font-size: 13px;
  font-weight: 700;
  color: ${colors.darkBlue};
  box-shadow: 4px 0 12px rgba(15, 23, 42, 0.08);
  overflow: hidden;
  word-break: break-word;
  hyphens: auto;
`;

export const PeriodCell = styled.div`
  padding: 8px;
  border-top: 1px solid ${colors.table.borderLight};
  border-left: 1px solid ${colors.table.borderLight};
  min-height: 96px;
  vertical-align: top;
  background: ${colors.white};
`;

export const PeriodCard = styled.div`
  height: 100%;
  min-height: 80px;
  padding: 10px 10px 12px;
  border-radius: 10px;
  background: linear-gradient(
    145deg,
    #f0f9ff 0%,
    ${colors.white} 100%
  );
  border: 1px solid rgba(0, 119, 190, 0.22);
  box-shadow: 0 2px 8px rgba(2, 62, 138, 0.06);
  display: flex;
  flex-direction: column;
  gap: 6px;
`;

export const PeriodCardSubstitute = styled(PeriodCard)`
  background: linear-gradient(145deg, #fffbeb 0%, #ffffff 100%);
  border: 2px solid #f59e0b;
  box-shadow: 0 2px 10px rgba(245, 158, 11, 0.14);
`;

export const PeriodSubject = styled.span`
  font-size: 12px;
  font-weight: 800;
  color: ${colors.primaryBlue};
  line-height: 1.25;
`;

export const PeriodTeacher = styled.span`
  font-size: 12px;
  font-weight: 600;
  color: #1e293b;
  line-height: 1.3;
`;

export const PeriodMeta = styled.span`
  font-size: 11px;
  font-weight: 500;
  color: ${colors.neutral};
  line-height: 1.25;
`;

export const PeriodAbsent = styled.span`
  font-size: 10px;
  font-weight: 600;
  color: ${colors.gray["400"]};
  padding-top: 4px;
  border-top: 1px dashed ${colors.table.borderMedium};
`;

export const EmptyCellInner = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 72px;
  font-size: 13px;
  font-weight: 600;
  color: ${colors.gray["300"]};
`;

export const EmptySchedule = styled.div`
  padding: 48px 24px;
  text-align: center;
  color: ${colors.neutral};
  font-size: 14px;
  font-weight: 500;
`;

export const ScheduleLegendBar = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 14px 28px;
  padding: 12px 18px;
  border-bottom: 1px solid ${colors.table.borderLight};
  background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
  font-size: 12px;
  font-weight: 700;
  color: ${colors.neutral};
`;

export const LegendInline = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 8px;
`;

export const LegendSwatchDefault = styled.span`
  width: 30px;
  height: 20px;
  border-radius: 6px;
  border: 1px solid rgba(0, 119, 190, 0.22);
  background: linear-gradient(145deg, #f0f9ff 0%, #ffffff 100%);
  flex-shrink: 0;
`;

export const LegendSwatchSubstitute = styled.span`
  width: 30px;
  height: 20px;
  border-radius: 6px;
  border: 2px solid #f59e0b;
  background: linear-gradient(145deg, #fffbeb 0%, #ffffff 100%);
  flex-shrink: 0;
`;

export const TimetableSectionCard = styled(Box)`
  border-radius: 16px;
  border: 1px solid ${colors.table.borderMedium};
  background: ${colors.white};
  box-shadow: 0 8px 32px rgba(15, 23, 42, 0.06);
  overflow: hidden;
`;

export const TimetableSectionHead = styled.div`
  padding: 18px 22px 10px;
  border-bottom: 1px solid ${colors.table.borderLight};
  background: linear-gradient(180deg, #f8fafc 0%, ${colors.white} 100%);
`;

export const TimetableLegendRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 10px 20px;
  padding: 0 22px 14px;
  align-items: center;
`;

export const LegendSwatch = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  font-weight: 700;
  color: ${colors.neutral};
`;

export const LegendRedBox = styled.span`
  width: 20px;
  height: 14px;
  border-radius: 4px;
  border: 2px solid #dc2626;
  background: #fef2f2;
  flex-shrink: 0;
`;

export const TimetableScroll = styled.div`
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
`;

export const TimetableGrid = styled.div`
  display: grid;
  grid-template-columns: 168px repeat(8, minmax(118px, 1fr));
  min-width: 1120px;
`;

export const TimetableCorner = styled.div`
  position: sticky;
  left: 0;
  z-index: 3;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px 8px;
  background: linear-gradient(180deg, ${colors.darkBlue} 0%, #0a4a8c 100%);
  color: ${colors.white};
  font-size: 11px;
  font-weight: 800;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  border-bottom: 2px solid ${colors.primaryBlue};
  box-shadow: 4px 0 12px rgba(15, 23, 42, 0.12);
`;

export const TimetableHeaderCell = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  padding: 10px 6px;
  background: ${colors.table.headerBg};
  border-left: 1px solid ${colors.table.borderLight};
  border-bottom: 2px solid ${colors.primaryBlue};
  text-align: center;
`;

export const TimetableHeaderTitle = styled.span`
  font-size: 12px;
  font-weight: 800;
  color: ${colors.darkBlue};
`;

export const TimetableHeaderSub = styled.span`
  font-size: 10px;
  font-weight: 600;
  color: ${colors.neutral};
`;

export const TimetableRowTitle = styled.div`
  position: sticky;
  left: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 4px;
  padding: 12px 10px;
  background: #f1f5f9;
  border-top: 1px solid ${colors.table.borderLight};
  border-right: 1px solid ${colors.table.borderLight};
  font-size: 12px;
  font-weight: 800;
  color: ${colors.darkBlue};
  box-shadow: 4px 0 12px rgba(15, 23, 42, 0.06);
`;

export const TimetableBodyCell = styled.div`
  padding: 8px;
  border-top: 1px solid ${colors.table.borderLight};
  border-left: 1px solid ${colors.table.borderLight};
  min-height: 108px;
  vertical-align: top;
  background: ${colors.white};
`;

export const TimetableLessonCard = styled.div`
  height: 100%;
  min-height: 92px;
  padding: 10px;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  border: 1px solid rgba(15, 23, 42, 0.08);
  background: linear-gradient(145deg, #f8fafc 0%, ${colors.white} 100%);
  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.04);
`;

export const TimetableLessonCardLeave = styled(TimetableLessonCard)`
  border: 2px solid #dc2626;
  background: linear-gradient(145deg, #fef2f2 0%, #fffbfb 100%);
  box-shadow:
    0 0 0 1px rgba(220, 38, 38, 0.12),
    0 4px 14px rgba(220, 38, 38, 0.08);
`;

export const TimetableLessonLabel = styled.span`
  font-size: 10px;
  font-weight: 700;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.04em;
`;

export const TimetableLessonSubject = styled.span`
  font-size: 12px;
  font-weight: 800;
  color: #0f172a;
  line-height: 1.25;
`;

export const TimetableLessonTeacher = styled.span`
  font-size: 11px;
  font-weight: 600;
  color: #334155;
  line-height: 1.3;
`;

export const TimetableLeaveBadge = styled.span`
  font-size: 10px;
  font-weight: 800;
  color: #b91c1c;
  background: rgba(220, 38, 38, 0.12);
  padding: 3px 8px;
  border-radius: 999px;
  align-self: flex-start;
`;

export const ClassSelectWrap = styled.div`
  flex: 1 1 280px;
  min-width: 260px;
  max-width: 480px;
  margin-bottom: 25px;
`;
