import dayjs from "dayjs";
import {
  convertApiTimetableToNested,
  convertScheduleDataToNested,
} from "components/Timetable/helpers";

export const safeString = (val) => {
  if (val === null || val === undefined) return null;
  const s = String(val).trim();
  return s.length > 0 ? s : null;
};

export const PERIOD_COUNT = 8;

export const getPeriodLabels = () => [
  ...Array.from({ length: 5 }, (_, i) => ({
    key: `p${i + 1}`,
    label: `Tiết ${i + 1}`,
    session: "Sáng",
  })),
  ...Array.from({ length: 3 }, (_, i) => ({
    key: `p${i + 6}`,
    label: `Tiết ${i + 1}`,
    session: "Chiều",
  })),
];

export const flattenLeaveApprovedToScheduleRecords = (input) => {
  const requests = Array.isArray(input) ? input : [];
  const out = [];

  requests.forEach((req) => {
    const periods = Array.isArray(req?.periods) ? req.periods : [];

    periods.forEach((period) => {
      out.push({
        leaveDate: safeString(period?.leaveDate) || safeString(req?.leaveDate) || null,
        periodNo:
          typeof period?.periodNo === "number"
            ? period.periodNo
            : Number(period?.periodNo) || null,
        classId: safeString(period?.classId) || null,
        className: safeString(period?.className) || null,
        backupTeacherId: safeString(period?.backupTeacherId) || safeString(period?.assignedTeacherId) || null,
        backupTeacherName:
          safeString(period?.backupTeacherName) ||
          safeString(period?.assignedTeacherName) ||
          safeString(period?.backupTeacher?.fullName) ||
          safeString(period?.backupTeacher?.name) ||
          safeString(period?.assignedTeacher?.fullName) ||
          safeString(period?.assignedTeacher?.name) ||
          null,

        teacherId: safeString(req?.teacherId) || null,
        teacherName: safeString(req?.teacherName) || safeString(req?.teacher?.fullName) || safeString(req?.teacher?.name) || null,
        leaveCategory: safeString(req?.leaveCategory) || null,
        status: safeString(req?.status) || null,
      });
    });
  });

  return out;
};

export const buildScheduleRowsFromRecords = (records) => {
  const items = Array.isArray(records) ? records : [];
  const byClassKey = new Map();

  items.forEach((r) => {
    const classId = safeString(r?.classId) || "";
    const className = safeString(r?.className) || "--";
    const key = classId || className;

    if (!byClassKey.has(key)) {
      byClassKey.set(key, {
        id: key,
        className,
        slots: Array.from({ length: PERIOD_COUNT }, () => null),
      });
    }

    const row = byClassKey.get(key);
    const periodNo = typeof r?.periodNo === "number" ? r.periodNo : Number(r?.periodNo);
    if (!periodNo || periodNo < 1 || periodNo > PERIOD_COUNT) return;

    row.slots[periodNo - 1] = {
      subject: safeString(r?.leaveCategory) || "Nghỉ phép",
      substituteName: safeString(r?.backupTeacherName) || "--",
      room: safeString(r?.status) || "--",
      absentTeacher: safeString(r?.teacherName) || "--",
      record: r,
      hasSubstituteLeave: !!safeString(r?.backupTeacherName),
      modalRecord: {
        ...r,
        className: row.className,
        classId: safeString(r?.classId) || null,
      },
    };
  });

  return Array.from(byClassKey.values());
};

export const normalizeClassTimetableApiPayload = (payload) => {
  if (payload === null || payload === undefined) return {};

  let inner = payload;
  if (
    inner &&
    typeof inner === "object" &&
    !Array.isArray(inner) &&
    inner.data !== undefined &&
    (inner.meta !== undefined ||
      inner.data?.SANG ||
      inner.data?.CHIEU ||
      inner.data?.slots ||
      Array.isArray(inner.data))
  ) {
    inner = inner.data;
  }

  if (!inner || typeof inner !== "object") return {};
  if (Array.isArray(inner.slots)) {
    return convertApiTimetableToNested(inner);
  }
  if (Array.isArray(inner)) {
    const looksLikeSlots = inner.some(
      (item) => item?.weekday != null || item?.contentText,
    );
    return looksLikeSlots
      ? convertApiTimetableToNested(inner)
      : convertScheduleDataToNested(inner);
  }
  if (inner.SANG || inner.CHIEU) {
    return convertApiTimetableToNested(inner);
  }
  if (inner.schedule || inner.timetable || inner.scheduleData) {
    return normalizeClassTimetableApiPayload(
      inner.schedule || inner.timetable || inner.scheduleData,
    );
  }
  return {};
};

export const getWeekDayOffsetMondayZero = (dateStr) => {
  const d = dayjs(dateStr);
  if (!d.isValid()) return null;
  const dow = d.day();
  if (dow === 0) return null;
  return dow - 1;
};

export const getTimetableLessonForGlobalPeriod = (nested, dayOffset, globalPeriod) => {
  if (
    dayOffset === null ||
    dayOffset === undefined ||
    !nested ||
    typeof nested !== "object"
  ) {
    return null;
  }
  const day = nested[dayOffset];
  if (!day || typeof day !== "object") return null;

  if (globalPeriod >= 1 && globalPeriod <= 5) {
    const cell = day[globalPeriod];
    return cell?.morning || null;
  }
  if (globalPeriod >= 6 && globalPeriod <= 8) {
    const ap = globalPeriod - 5;
    const cell = day[ap];
    return cell?.afternoon || null;
  }
  return null;
};

export const normalizeTeacherComparable = (val) => {
  const s = safeString(val);
  if (!s) return "";
  return s.toLowerCase().replace(/\s+/g, " ").trim();
};

export const lessonTeacherNameParts = (lessonTeacherStr) => {
  const raw = safeString(lessonTeacherStr);
  if (!raw) return [];
  return raw
    .split(/[,;/|]+|\s+và\s+/i)
    .map((x) => normalizeTeacherComparable(x))
    .filter(Boolean);
};

export const teacherNameAppearsInLessonTeachers = (name, lessonTeacherStr) => {
  const target = normalizeTeacherComparable(name);
  if (!target) return false;
  const parts = lessonTeacherNameParts(lessonTeacherStr);
  if (parts.length === 0) {
    const whole = normalizeTeacherComparable(lessonTeacherStr);
    if (!whole) return false;
    if (whole === target) return true;
    if (whole.length >= 3 && target.length >= 3) {
      return whole.includes(target) || target.includes(whole);
    }
    return false;
  }
  return parts.some((p) => {
    if (p === target) return true;
    if (p.length >= 3 && target.length >= 3) {
      return p.includes(target) || target.includes(p);
    }
    return false;
  });
};

export const mergeTimetableIntoScheduleSlots = (
  slots,
  nested,
  selectedDate,
  classMeta = {},
) => {
  const dayOffset = getWeekDayOffsetMondayZero(selectedDate);
  if (dayOffset === null || !nested || typeof nested !== "object") {
    return slots;
  }
  const list = Array.isArray(slots) ? slots : [];
  const cn = safeString(classMeta.className) || "";
  const cid = safeString(classMeta.classId) || "";

  return list.map((s, i) => {
    const p = i + 1;
    const lesson = getTimetableLessonForGlobalPeriod(nested, dayOffset, p);
    if (!lesson) {
      return s;
    }
    const ts = safeString(lesson.subject);
    const tt = safeString(lesson.teacher);
    const tr = safeString(lesson.room);

    if (s?.record) {
      const absentName = safeString(s.record?.teacherName);
      const backupName = safeString(s.record?.backupTeacherName);
      const periodRec = Number(s.record?.periodNo);
      const periodMatchesSlot =
        !Number.isFinite(periodRec) ||
        Number.isNaN(periodRec) ||
        periodRec === p;
      const absentInTimetableTeachers = teacherNameAppearsInLessonTeachers(absentName, tt);

      return {
        ...s,
        subject: ts || s.subject || "Nghỉ phép",
        mainTeacher: tt || null,
        substituteName: backupName || safeString(s.substituteName) || "--",
        absentTeacher: absentName || safeString(s.absentTeacher) || null,
        hasSubstituteLeave: !!backupName,
        modalRecord: {
          ...(s.modalRecord || s.record),
          className: safeString(s.modalRecord?.className) || cn,
          classId: safeString(s.modalRecord?.classId) || cid,
          timetableSubject: ts,
          timetableTeacher: tt,
          timetableRoom: tr,
          leavePeriodMatchesSlot: periodMatchesSlot,
          leaveAbsentMatchesTimetableTeachers: absentInTimetableTeachers,
        },
      };
    }
    return {
      subject: ts || "—",
      substituteName: tt || "—",
      room: null,
      absentTeacher: null,
      record: null,
      hasSubstituteLeave: false,
      modalRecord: {
        viewKind: "timetable_only",
        leaveDate: safeString(selectedDate),
        periodNo: p,
        className: cn,
        classId: cid,
        teacherName: tt || "--",
        timetableSubject: ts,
        timetableTeacher: tt,
        timetableRoom: tr,
        backupTeacherName: null,
        leaveCategory: null,
        status: null,
      },
    };
  });
};

export const buildGiamThiScheduleRows = (
  records,
  selectedClassId,
  selectedClassName,
  selectedDate,
  timetableNested,
) => {
  const baseRows = buildScheduleRowsFromRecords(records);
  const sid = safeString(selectedClassId);
  if (!sid) {
    return baseRows;
  }

  const match = baseRows.find((r) => String(r.id) === String(sid));
  let row;
  if (match) {
    row = {
      ...match,
      slots: [...match.slots],
    };
  } else {
    row = {
      id: sid,
      className: safeString(selectedClassName) || sid,
      slots: Array.from({ length: PERIOD_COUNT }, () => null),
    };
  }

  row.slots = mergeTimetableIntoScheduleSlots(
    row.slots,
    timetableNested,
    selectedDate,
    { className: row.className, classId: row.id },
  );

  return [row];
};
