import { getAllClassesAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import dayjs from "dayjs";
import "dayjs/locale/vi";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import { findMenuByComponentName } from "utils/helpers";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import LeaveInfoModal from "./components/LeaveInfoModal";
import ScheduleFilterBar from "./components/ScheduleFilterBar";
import ScheduleTable from "./components/ScheduleTable";
import { buildGiamThiScheduleRows } from "./helpers";
import {
  clearClassTimetableViewAction,
  fetchClassTimetableAction,
  queryLeaveScheduleAction,
  resetLeaveScheduleStoreAction,
} from "./store/actions";
import { key } from "./store/constants";
import { PageWrap } from "./Styled";

dayjs.locale("vi");

const Main = () => {
  const history = useHistory();
	const fetchLeaveSchedule = useDispatchRedux(queryLeaveScheduleAction)
	const resetLeaveScheduleStore = useDispatchRedux(resetLeaveScheduleStoreAction)
	const fetchAllClasses = useDispatchRedux(getAllClassesAction)
	const fetchClassTimetable = useDispatchRedux(fetchClassTimetableAction)
	const clearClassTimetable = useDispatchRedux(clearClassTimetableViewAction)
	
	const [selectedDate, setSelectedDate] = useState(() =>
    dayjs().format("YYYY-MM-DD"),
  );
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [selectedClassId, setSelectedClassId] = useState("");

	useEffect(() => {
		fetchLeaveSchedule({ fromDate: selectedDate, toDate: selectedDate })
	}, [selectedDate])

	useEffect(() => {
		fetchAllClasses();
	}, []);

	useEffect(() => {
		if (!selectedClassId) {
			clearClassTimetable();
			return;
		}
		fetchClassTimetable({ classId: selectedClassId });
	}, [selectedClassId]);

	useEffect(() => {
		return () => {
			resetLeaveScheduleStore()
		}
	}, [])

  const items = useOneState(key, "items");
  const classesOptRaw = useOneState(injectKey.GLOBAL, "classesOpt", []);
  const classesOpt = useMemo(
    () =>
      (classesOptRaw || []).map((row) => ({
        ...row,
        className:
          row.className ||
          row.name ||
          [row.code, row.name].filter(Boolean).join(" · ") ||
          String(row.id ?? ""),
      })),
    [classesOptRaw],
  );
  const timetableNested = useOneState(key, "timetableNested");
  const timetableLoading = useOneState(key, "timetableLoading");
  const timetableError = useOneState(key, "timetableError");

  const handleDateChange = useCallback((event) => {
    setSelectedDate(event.target.value);
  }, []);

  const formattedDate = useMemo(
    () =>
      dayjs(selectedDate).isValid()
        ? dayjs(selectedDate).format("dddd, DD/MM/YYYY")
        : "—",
    [selectedDate],
  );

  const selectedClassLabel = useMemo(() => {
    const c = (classesOpt || []).find(
      (x) => String(x?.id) === String(selectedClassId),
    );
    return c?.className || "";
  }, [classesOpt, selectedClassId]);

  const scheduleRows = useMemo(
    () =>
      buildGiamThiScheduleRows(
        items || [],
        selectedClassId,
        selectedClassLabel,
        selectedDate,
        timetableNested || {},
      ),
    [items, selectedClassId, selectedClassLabel, selectedDate, timetableNested],
  );

  const handleClassChange = useCallback((nextId) => {
    setSelectedClassId(nextId ? String(nextId) : "");
  }, []);

  const handleSlotClick = useCallback((record) => {
    if (!record) return;
    setSelectedRecord(record);
  }, []);

  const handleCloseModal = useCallback(() => {
    setSelectedRecord(null);
  }, []);

  const handleEvaluate = useCallback((record) => {
    if (!record) return;
    const targetUrl =
      findMenuByComponentName("ChamDiemThiDuaGiaoVienGiamThi")?.url || "";
    if (!targetUrl) return;

    const d = dayjs(record?.leaveDate);
    const dateText = d.isValid() ? d.format("DD/MM/YYYY") : "—";
    const classText = record?.className || "—";
    const periodText = record?.periodNo ? `tiết ${record.periodNo}` : "giờ —";

    const reason = `Chấm điểm khi đi kiểm tra tại ${classText}, ${periodText}, ngày ${dateText}`;

    setSelectedRecord(null);
    history.push({
      pathname: targetUrl,
      state: {
        autoOpenScoreModal: true,
        prefill: {
          teacherId: record?.teacherId || null,
          reason,
        },
      },
    });
  }, [history]);

  return (
    <>
      <AppHeader componentName="LeaveScheduleGiamThi" isHiddenBtn />
      <PageWrap>
        <ScheduleFilterBar
          value={selectedDate}
          onChange={handleDateChange}
          formattedDate={formattedDate}
          classValue={selectedClassId}
          classesOpt={classesOpt || []}
          onClassChange={handleClassChange}
        />
        <ScheduleTable
          rows={scheduleRows}
          onSlotClick={handleSlotClick}
          timetableLoading={!!selectedClassId && timetableLoading}
          timetableError={
            selectedClassId ? timetableError : null
          }
        />
      </PageWrap>

      <LeaveInfoModal
        open={!!selectedRecord}
        record={selectedRecord}
        onClose={handleCloseModal}
        onEvaluate={handleEvaluate}
      />
    </>
  );
};

export default Main;
