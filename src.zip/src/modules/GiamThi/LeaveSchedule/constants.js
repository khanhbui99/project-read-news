export { PERIOD_TIME_HINTS } from "components/Timetable/helpers";
