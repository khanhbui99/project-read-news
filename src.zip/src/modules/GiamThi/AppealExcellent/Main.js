import {
  getExamPeriodCategoryAction,
} from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import { useEffect } from "react";
import styled from "styled-components";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Form from "./components/Detail";
import * as acts from "./store/actions";

const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  display: flex;
  flex-direction: column;
  // margin-top: -24px;
  // margin-left: -24px;
  // width: calc(100% + 48px);
`;

const DetailExcellentStudentContest = () => {

  const resetStoreExcellentStudentContest = useDispatchRedux(
    acts.resetStoreExcellentStudentContestAction,
  );
  const fetchAllExcellentStudentContest = useDispatchRedux(
    acts.queryExcellentStudentContestAction,
  );

  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchAllExcellentStudentContest();

    return () => {
      resetStoreExcellentStudentContest();
    };
  }, []);

  return (
    <PageWrapper>
      <AppHeader
        isHiddenBtn
        componentName="AppealExcellentGiamThi"
      />
      <Form />
    </PageWrapper>
  );
};

export default DetailExcellentStudentContest;
