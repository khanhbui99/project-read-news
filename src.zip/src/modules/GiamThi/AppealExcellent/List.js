import { getExamPeriodCategoryAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import PropTypes from "prop-types";
import { useEffect } from "react";
import React from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import TableExcellentStudentContest from "./components/List/Table";
import {
  queryAppealExcellentAction,
  resetStoreExcellentStudentContestAction,
} from "./store/actions";

const ListAppealExcellent = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchAllAppealExcellent = useDispatchRedux(
    queryAppealExcellentAction,
  );
  const resetStoreExcellentStudentContest = useDispatchRedux(
    resetStoreExcellentStudentContestAction,
  );

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchAllAppealExcellent();

    return () => {
      resetStoreExcellentStudentContest();
    };
  }, []);

  return (
    <React.Fragment>
      <AppHeader
        isHiddenBtn
        componentName="ListAppealExcellent"
      />

      <TableExcellentStudentContest />
    </React.Fragment>
  );
};

ListAppealExcellent.propTypes = {
  historyPathCreate: PropTypes.string,
  historyPathEdit: PropTypes.string,
};

export default ListAppealExcellent;
