import PropTypes from "prop-types";
import ListSkeleton from "skeletons/ListSkeleton";
import { useInjectReducer } from "utils/injectReducer";
import { useInjectSaga } from "utils/injectSaga";
import loadable from "utils/loadable";

import { key } from "./store/constants";
import reducer from "./store/reducer";
import saga from "./store/saga";

const Provider = ({ children }) => {
  useInjectReducer({ key, reducer });
  useInjectSaga({ key, saga });

  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

export const DetailAppealExcellent = loadable(() => import("./Detail"), {
  fallback: <ListSkeleton />,
  provider: Provider,
});

export const ListAppealExcellent = loadable(() => import("./List"), {
  fallback: <ListSkeleton />,
  provider: Provider,
});
