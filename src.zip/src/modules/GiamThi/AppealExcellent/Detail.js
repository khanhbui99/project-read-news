import { getExamPeriodCategoryAction } from "App/store/actions";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Form from "./components/Detail";
import * as acts from "./store/actions";

const DetailExcellentStudentContest = () => {
  const { id } = useParams();

  const rqDetailExcellentStudentContest = useDispatchRedux(
    acts.detailExcellentStudentContestAction,
  );
  const resetStoreExcellentStudentContest = useDispatchRedux(
    acts.resetStoreExcellentStudentContestAction,
  );

  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  useEffect(() => {
    fetchExamPeriodCategory();
    if (id) {
      rqDetailExcellentStudentContest(id);
    }

    return () => {
      resetStoreExcellentStudentContest();
    };
  }, [id]);

  return (
    <Form />
  );
};

export default DetailExcellentStudentContest;
