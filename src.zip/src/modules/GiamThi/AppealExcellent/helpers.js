import dayjs from "dayjs";
import {
  DateFormat,
  DateFormat3,
  DateFormat4,
  HourFormat,
  MAX_STUDENTS,
} from "utils/constants";
import { STATUS_EXCELLENT } from "utils/constants";

export const transformInitDetails = (vals, examPeriodCategory) => {
  const results = { ...vals };

  const {
    grades = [],
    subjects = [],
    semesters = [],
    typeOfExams = [],
    academicYears = [],
    testSessions = [],
  } = examPeriodCategory;
  const endTime = String(vals.endTime).split(":");
  const startTime = String(vals.startTime).split(":");

  endTime.pop();
  startTime.pop();

  results.endTime = endTime.join(":");
  results.startTime = startTime.join(":");

  results.gradeName = grades.find((item) => item.id === vals.gradeId)?.name;
  results.subjectName = subjects.find(
    (item) => item.id === vals.subjectId,
  )?.name;
  results.semesterName = semesters.find(
    (item) => item.id === vals.semesterId,
  )?.name;
  results.typeOfExamName = typeOfExams.find(
    (item) => item.id === vals.typeOfExamId,
  )?.code;
  results.academicYearName = academicYears.find(
    (item) => item.id === vals.academicYearId,
  )?.name;
  results.testSessionName = testSessions.find(
    (item) => item.id === vals.testSessionId,
  )?.name;

  results.subjectId = [vals.subjectId];
  results.totalStudent =
    (vals?.totalInternal || 0) + (vals?.totalExternal || 0);
  results.students = [
    ...(vals?.internalStudents || []),
    ...(vals?.externalStudents || []),
  ]?.map((s) => ({
    ...s,
    registrationId: s.registrationId || s.id,
    name: s.fullName || s.name,
    class: s.className || s.class,
    school: s.schoolName || "THCS Cầu Giấy",
    room: s.examRoom || s.room,
    code: s.code || s.studentCode || s.id?.toString(),
    grade: s.grade || s.gradeId,
    isOvergrade: s.isOvergrade || false,
    // regStatus: s.regStatus || s.status || "REGISTERED",
    // avgScore: s.avgScore || s.averageScore,
    examScore: s.examScore || s.score,
    type: s?.studentCode ? "INTERNAL" : "EXTERNAL",
    isExternal: !s?.studentCode,
    status: s?.status || "REGISTER",
    dateOfBirth: dayjs(s.dateOfBirth).format(DateFormat4),
    registeredAtFormat: dayjs(s.registeredAt).format(
      `${DateFormat4} ${HourFormat}`,
    ),
  }));

  results.isDisableReviewDeadline = vals.reviewDeadline
    ? dayjs(vals.reviewDeadline).isBefore(dayjs())
    : true;
  results.isDisable = ![
    STATUS_EXCELLENT.DRAFT.value,
    STATUS_EXCELLENT.REGISTERING.value,
  ].includes(vals.status);

  return results;
};

export const transformFormValuesToSubmit = (values) => {
  const payload = {};

  if (values.id) payload.id = values.id;

  payload.minCrossGradeAverageScore = values.minCrossGradeAverageScore;
  if (!values?.allowCrossGrade) payload.minCrossGradeAverageScore = null;

  payload.name = values.name;
  payload.typeOfExamId = values.typeOfExamId;
  payload.gradeId = values.gradeId;
  payload.subjectId = values.subjectId[0];
  payload.academicYearId = values.academicYearId;
  payload.testSessionId = values.testSessionId;
  payload.minAverageScore = values.minAverageScore;
  payload.maxStudents = values.maxStudents || MAX_STUDENTS;
  payload.allowCrossGrade = values.allowCrossGrade;
  payload.registrationStartDate = values.registrationStartDate
    ? dayjs(values.registrationStartDate).format(DateFormat3)
    : null;
  payload.registrationEndDate = values.registrationEndDate
    ? dayjs(values.registrationEndDate).format(DateFormat3)
    : null;
  payload.officialExamDate = values.officialExamDate
    ? dayjs(values.officialExamDate).format(DateFormat)
    : null;
  payload.reviewDeadline = values.reviewDeadline
    ? dayjs(values.reviewDeadline).format(DateFormat)
    : null;
  payload.note = values.note;
  payload.startTime = `${values.startTime}:00`;
  payload.endTime = `${values.endTime}:00`;
  payload.semesterId = values.semesterId;
  payload.scoreSubjectIds = values.scoreSubjectIds;

  return payload;
};

export const mappingPreviewScoreStudent = (
  students = [],
  scorePreview = [],
) => {
  const mapPreScoreStudent = {};

  scorePreview.forEach(
    (_ps) => (mapPreScoreStudent[_ps?.registrationNumber] = _ps?.score || 0),
  );

  return students.map((s) => {
    const score = mapPreScoreStudent[s?.registrationNumber];
    return {
      ...s,
      score: score || s?.score,
    };
  });
};

export const mappingAppealStudents = (students = []) => {
  return (students || []).map((s, i) => ({
    ...s,
    id: s?.id || s?.registrationId || i + 1,
    registrationId: s?.registrationId || s?.id,
    registrationNumber:
      s?.registrationNumber || s?.registrationCode || s?.sbd || s?.code || "---",
    name: s?.fullName || s?.name || "---",
    fullName: s?.fullName || s?.name || "---",
    className: s?.className || s?.class || "---",
    class: s?.className || s?.class || "---",
    schoolName:
      s?.schoolName || s?.school || s?.schoolUnitName || s?.organizationName || "THCS Cầu Giấy",
    school:
      s?.schoolName || s?.school || s?.schoolUnitName || s?.organizationName || "THCS Cầu Giấy",
    dateOfBirth: s?.dateOfBirth || s?.birthDate || s?.dob || "",
    room: s?.examRoom || s?.room || "---",
    examRoom: s?.examRoom || s?.room || "---",
    studentCode: s?.studentCode || s?.code || "---",
    code: s?.code || s?.studentCode || s?.registrationNumber || "---",
    isOvergrade: Boolean(s?.isOvergrade),
    type: s?.studentCode ? "INTERNAL" : "EXTERNAL",
    isExternal: !s?.studentCode,
    score: s?.score ?? s?.currentScore ?? s?.newScore ?? null,
    oldScore: s?.oldScore ?? s?.previousScore ?? null,
    newScore: s?.newScore ?? s?.score ?? null,
    status: s?.status || "APPEAL",
  }));
};
