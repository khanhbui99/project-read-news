import dayjs from "dayjs";
import { DateFormat, DateFormat3, DateFormat4, HourFormat, MAX_STUDENTS, STATUS_EXCELLENT } from "utils/constants";
import { findMenuByComponentName } from "utils/helpers";
import history from "utils/history";

export const transformInitDetails = (vals, examPeriodCategory, configRank = []) => {
  const results = {...vals}

  const { grades = [],subjects = [], semesters = [], typeOfExams = [], academicYears = [], testSessions = [] } = examPeriodCategory
  const endTime = String(vals.endTime).split(":")
  const startTime = String(vals.startTime).split(":")
  
  endTime.pop()
  startTime.pop()
  
  results.endTime = endTime.join(':')
  results.startTime = startTime.join(':')

  results.gradeName = grades.find((item) => item.id === vals.gradeId)?.name;
  results.subjectName = subjects.find((item) => item.id === vals.subjectId)?.name;
  results.semesterName = semesters.find((item) => item.id === vals.semesterId)?.name;
  results.typeOfExamName = typeOfExams.find((item) => item.id === vals.typeOfExamId)?.code;
  results.academicYearName = academicYears.find((item) => item.id === vals.academicYearId)?.name;
  results.testSessionName = testSessions.find((item) => item.id === vals.testSessionId)?.name;
  results.rankName = (configRank || [])?.find((_r) => vals?.score >= _r?.minScore && vals?.score <= _r?.maxScore)?.rangeName || "---";

  results.subjectId = [vals.subjectId]
  results.totalStudent = (vals?.totalInternal || 0) + (vals?.totalExternal || 0)
  results.students = [...(vals?.internalStudents || []), ...(vals?.externalStudents || [])]?.map(s=>({
    ...s,
    registrationId: s.registrationId || s.id,
    name: s.fullName || s.name,
    class: s.className || s.class,
    school: s.schoolName || "THCS Cầu Giấy",
    room: s.examRoom || s.room,
    code: s.code || s.studentCode || s.id?.toString(),
    grade: s.grade || s.gradeId,
    isOvergrade: s.isOvergrade || false,
    // regStatus: s.regStatus || s.status || "REGISTERED",
    // avgScore: s.avgScore || s.averageScore,
    examScore: s.examScore || s.score,
    type: s?.studentCode ? "INTERNAL" : "EXTERNAL",
    isExternal: !s?.studentCode,
    status: s?.status || "REGISTER",
    dateOfBirth: dayjs(s.dateOfBirth).format(DateFormat4),
    registeredAtFormat: dayjs(s.registeredAt).format(`${DateFormat4} ${HourFormat}`),
  }))
  
  results.isDisableReviewDeadline = vals.reviewDeadline ? dayjs().isAfter(dayjs(vals.reviewDeadline).endOf("day")) : false;
  results.isDisable = ![STATUS_EXCELLENT.DRAFT.value, STATUS_EXCELLENT.REGISTERING.value].includes(vals.status)

  return results;
}

export const transformFormValuesToSubmit = (values) => {
  const payload = {}

  if(values.id) payload.id = values.id

  payload.minCrossGradeAverageScore = values.minCrossGradeAverageScore;
  if (!values?.allowCrossGrade) payload.minCrossGradeAverageScore = null

  payload.name = values.name
  payload.typeOfExamId = values.typeOfExamId
  payload.gradeId = values.gradeId
  payload.subjectId = values.subjectId[0]
  payload.academicYearId = values.academicYearId
  payload.testSessionId = values.testSessionId
  payload.minAverageScore = values.minAverageScore
  payload.maxStudents = values.maxStudents || MAX_STUDENTS
  payload.allowCrossGrade = values.allowCrossGrade
  payload.registrationStartDate = values.registrationStartDate ? dayjs(values.registrationStartDate).format(DateFormat3) : null
  payload.registrationEndDate = values.registrationEndDate ? dayjs(values.registrationEndDate).format(DateFormat3) : null
  payload.officialExamDate = values.officialExamDate ? dayjs(values.officialExamDate).format(DateFormat) : null
  payload.reviewDeadline = values.reviewDeadline ? dayjs(values.reviewDeadline).format(DateFormat) : null
  payload.note = values.note
  payload.startTime = `${values.startTime}:00`
  payload.endTime = `${values.endTime}:00`
  payload.semesterId = values.semesterId
  payload.scoreSubjectIds = values.scoreSubjectIds
  
  return payload
}

export const handleRedirect = (comp) => {
  const pathList = findMenuByComponentName(comp)?.url || "";
  history.push(pathList);
}