import { getExamPeriodCategoryAction } from "App/store/actions";
// import AppHeader from "components/common/AppHeader";
import ModalNotification from "components/common/Modal/ModalNotification";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import styled from "styled-components";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Form from "./components/Detail";
import * as acts from './store/actions';

const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

const DetailExcellentStudentContest = () => {
  const { id } = useParams();

  const rqEditExcellentStudentContest = useDispatchRedux(acts.editExcellentStudentContestAction);
  const rqDetailExcellentStudentContest = useDispatchRedux(acts.detailExcellentStudentContestAction);
  const resetStoreExcellentStudentContest = useDispatchRedux(acts.resetStoreExcellentStudentContestAction);
  // const setModalNotification = useDispatchRedux(setModalNotificationAction);

  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  useEffect(() => {
    fetchExamPeriodCategory();

    setTimeout(() => { rqDetailExcellentStudentContest(id) }, 100);
    
    return () => {
      resetStoreExcellentStudentContest();
    };
  }, []);

  const handleSubmit = (values) => {
    return rqEditExcellentStudentContest(values);
  };

  return (
    <PageWrapper>
      {/* <AppHeader
        isHiddenBtn
        componentName="DetailExcellentStudentContest"
      /> */}
      <Form onSubmit={handleSubmit} />

      <ModalNotification componentName="AddExcellentStudentContest" />
    </PageWrapper>
  );
};

export default DetailExcellentStudentContest;
