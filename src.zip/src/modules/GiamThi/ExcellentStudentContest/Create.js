import { getExamPeriodCategoryAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import ModalNotification from "components/common/Modal/ModalNotification";
import { useEffect } from "react";
// import { useParams } from "react-router-dom";
import styled from "styled-components";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Form from "./components/Form";
import * as acts from './store/actions';

const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

const CreateExcellentStudentContest = () => {
  // const { id } = useParams();

  // const rqEditExcellentStudentContest = useDispatchRedux(acts.editExcellentStudentContestAction);
  // const rqDetailExcellentStudentContest = useDispatchRedux(acts.detailExcellentStudentContestAction);
  const rqCreateExcellentStudentContest = useDispatchRedux(acts.createExcellentStudentContestAction);
  const resetStoreExcellentStudentContest = useDispatchRedux(acts.resetStoreExcellentStudentContestAction);
  // const setModalNotification = useDispatchRedux(setModalNotificationAction);

  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  useEffect(() => {
    setTimeout(() => {
      // if (id) rqDetailExcellentStudentContest(id);
    }, 100);

    fetchExamPeriodCategory();
    return () => {
      resetStoreExcellentStudentContest();
    };
  }, []);

  const handleSubmit = (values) => {
    // if (id) return rqEditExcellentStudentContest(values);
    return rqCreateExcellentStudentContest(values);
  };

  return (
    <PageWrapper>
      <AppHeader
        isHiddenBtn
        componentName="AddExcellentStudentContest"
      />

      <Form onSubmit={handleSubmit} />

      <ModalNotification componentName="ListExcellentStudentContest" />
    </PageWrapper>
  );
};

export default CreateExcellentStudentContest;
