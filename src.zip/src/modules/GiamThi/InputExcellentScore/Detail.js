import {
  awardScoreRangeAction,
  getExamPeriodCategoryAction,
} from "App/store/actions";
import ModalNotification from "components/common/Modal/ModalNotification";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import styled from "styled-components";
import { useDispatchRedux } from "utils/hooks/useRedux";

import Form from "./components/Detail";
import * as acts from "./store/actions";

const PageWrapper = styled.div`
  display: flex;
  flex-direction: column;
  display: flex;
  flex-direction: column;
  margin-top: -24px;
  margin-left: -24px;
  width: calc(100% + 48px);
`;

const DetailExcellentStudentContest = () => {
  const { id } = useParams();

  const rqDetailExcellentStudentContest = useDispatchRedux(
    acts.detailExcellentStudentContestAction,
  );
  const resetStoreExcellentStudentContest = useDispatchRedux(
    acts.resetStoreExcellentStudentContestAction,
  );

  const fetchawardScoreRange = useDispatchRedux(awardScoreRangeAction);
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  useEffect(() => {
    fetchExamPeriodCategory();
    fetchawardScoreRange(id);
    rqDetailExcellentStudentContest(id);

    return () => {
      resetStoreExcellentStudentContest();
    };
  }, []);

  return (
    <PageWrapper>
      <Form />
      <ModalNotification componentName="AddExcellentStudentContest" />
    </PageWrapper>
  );
};

export default DetailExcellentStudentContest;
