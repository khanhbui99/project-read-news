import dayjs from "dayjs";
import {
  DateFormat,
  DateFormat3,
  MAX_STUDENTS,
} from "utils/constants";

export const transformFormValuesToSubmit = (values) => {
  const payload = {};

  if (values.id) payload.id = values.id;

  payload.minCrossGradeAverageScore = values.minCrossGradeAverageScore;
  if (!values?.allowCrossGrade) payload.minCrossGradeAverageScore = null;

  payload.name = values.name;
  payload.typeOfExamId = values.typeOfExamId;
  payload.gradeId = values.gradeId;
  payload.subjectId = values.subjectId[0];
  payload.academicYearId = values.academicYearId;
  payload.testSessionId = values.testSessionId;
  payload.minAverageScore = values.minAverageScore;
  payload.maxStudents = values.maxStudents || MAX_STUDENTS;
  payload.allowCrossGrade = values.allowCrossGrade;
  payload.registrationStartDate = values.registrationStartDate
    ? dayjs(values.registrationStartDate).format(DateFormat3)
    : null;
  payload.registrationEndDate = values.registrationEndDate
    ? dayjs(values.registrationEndDate).format(DateFormat3)
    : null;
  payload.officialExamDate = values.officialExamDate
    ? dayjs(values.officialExamDate).format(DateFormat)
    : null;
  payload.reviewDeadline = values.reviewDeadline
    ? dayjs(values.reviewDeadline).format(DateFormat)
    : null;
  payload.note = values.note;
  payload.startTime = `${values.startTime}:00`;
  payload.endTime = `${values.endTime}:00`;
  payload.semesterId = values.semesterId;
  payload.scoreSubjectIds = values.scoreSubjectIds;

  return payload;
};

export const mappingPreviewScoreStudent = (
  students = [],
  scorePreview = [],
  configRank = [],
) => {
  const mapPreScoreStudent = {};

  scorePreview.forEach(
    (_ps) => (mapPreScoreStudent[_ps?.registrationNumber] = _ps?.score || 0),
  );

  return students.map((s) => {
    const score = mapPreScoreStudent[s?.registrationNumber];
    
    const rank = configRank?.find(
      (_r) => s?.score >= _r?.minScore && s?.score <= _r?.maxScore,
    );

    return {
      ...s,
      score: score || s?.score,
      rankName: rank?.rangeName || "---",
    };
  });
};
