export const parseScoreToggleLocked = (data) => {
  if (typeof data === "boolean") return data;
  if (data?.locked != null) return Boolean(data.locked);
  if (data?.isLocked != null) return Boolean(data.isLocked);
  if (typeof data?.status === "string") {
    return data.status.toUpperCase() === "LOCKED";
  }
  return false;
};
