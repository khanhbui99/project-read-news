import dayjs from "dayjs"
import { awardLevelOpt, DateFormat4, HourFormat, STATUS_EXCELLENT } from "utils/constants"

export const transformInitDetails = (vals, examPeriodCategory, configRank = []) => {
    const results = {...vals}
  
    const { grades = [],subjects = [], semesters = [], typeOfExams = [], academicYears = [], testSessions = [] } = examPeriodCategory
    const endTime = String(vals.endTime).split(":")
    const startTime = String(vals.startTime).split(":")
    
    endTime.pop()
    startTime.pop()
    
    results.endTime = endTime.join(':')
    results.startTime = startTime.join(':')
  
    results.gradeName = grades.find((item) => item.id === vals.gradeId)?.name;
    results.subjectName = subjects.find((item) => item.id === vals.subjectId)?.name;
    results.semesterName = semesters.find((item) => item.id === vals.semesterId)?.name;
    results.typeOfExamName = typeOfExams.find((item) => item.id === vals.typeOfExamId)?.code;
    results.academicYearName = academicYears.find((item) => item.id === vals.academicYearId)?.name;
    results.testSessionName = testSessions.find((item) => item.id === vals.testSessionId)?.name;
    results.rankName = (configRank || [])?.find((_r) => vals?.score >= _r?.minScore && vals?.score <= _r?.maxScore)?.rangeName || "---";
  
    results.subjectId = [vals.subjectId]
    results.totalStudent = (vals?.totalInternal || 0) + (vals?.totalExternal || 0)
    results.students = [...(vals?.internalStudents || []), ...(vals?.externalStudents || [])]?.map(s=>({
      ...s,
      registrationId: s.registrationId || s.id,
      name: s.fullName || s.name,
      class: s.className || s.class,
      school: s.schoolName || "THCS Cầu Giấy",
      room: s.examRoom || s.room,
      code: s.code || s.studentCode || s.id?.toString(),
      grade: s.grade || s.gradeId,
      isOvergrade: s.isOvergrade || false,
      // regStatus: s.regStatus || s.status || "REGISTERED",
      // avgScore: s.avgScore || s.averageScore,
      examScore: s.examScore || s.score,
      type: s?.studentCode ? "INTERNAL" : "EXTERNAL",
      isExternal: !s?.studentCode,
      status: s?.status || "REGISTER",
      dateOfBirth: dayjs(s.dateOfBirth).format(DateFormat4),
      registeredAtFormat: dayjs(s.registeredAt).format(`${DateFormat4} ${HourFormat}`),
    }))
    
    results.isDisableReviewDeadline = vals.reviewDeadline ? dayjs().isAfter(dayjs(vals.reviewDeadline).endOf("day")) : false;
    results.isDisable = ![STATUS_EXCELLENT.DRAFT.value, STATUS_EXCELLENT.REGISTERING.value].includes(vals.status)
  
    return results;
}

export const sortAwardScoreRanges = (data = []) => {
	const orderMap = {
		FIRST: 1,
		SECOND: 2,
		THIRD: 3,
		CONSOLATION: 4
	};

	const mapAwardRange = {};
	awardLevelOpt.forEach((_a) => (mapAwardRange[_a?.value] = _a.label));

	return data
	.map((_r) => ({
		..._r,
		rangeName: mapAwardRange[_r.awardLevel] || "",
	}))
	?.sort((a, b) => orderMap[a?.awardLevel] - orderMap[b?.awardLevel]);
}
