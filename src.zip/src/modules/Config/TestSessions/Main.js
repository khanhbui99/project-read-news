import AppHeader from "components/common/AppHeader";
import React, { useEffect } from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import ModalCreateUpdate from "./components/ModalCreateUpdate";
import Table from "./components/Table";
import { querySubjectAction, resetStoreSubjectAction, setFieldValueStoreSubjectAction } from "./store/actions";

const Main = () => {
  const setFieldValueStoreSubject = useDispatchRedux(setFieldValueStoreSubjectAction);

  const fetchSubjectList = useDispatchRedux(querySubjectAction);
  const resetSubjectStore = useDispatchRedux(resetStoreSubjectAction);

  useEffect(() => {
    setTimeout(() => {
      fetchSubjectList();
    }, 100);

    // Cleanup function to reset the store when unmounting
    return () => {
      resetSubjectStore();
    };
  }, []);

  const handleAdd = () => {
    setFieldValueStoreSubject("isModalCreateOrUpdate", true);
  }

  return (
    <React.Fragment>
      <AppHeader 
        componentName="TestSessionConfig"
        handleBtnClick={handleAdd}
      />
      <Table />
      <ModalCreateUpdate />
    </React.Fragment>
  );
};

export default Main;
