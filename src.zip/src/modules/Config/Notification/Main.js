import AppHeader from "components/common/AppHeader";
import React, { useEffect, useMemo, useState } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import ModalCreateUpdate from "./components/ModalCreateUpdate";
import NotificationFilter from "./components/NotificationFilter";
import Table from "./components/Table";
import { filterNotificationsLocal } from "./helpers";
import {
  queryNotificationDetailAction,
  queryNotificationListAction,
  queryTargetOptionsAction,
  resetStoreNotificationAction,
  setFieldValueStoreNotificationAction,
} from "./store/actions";
import {
  DRAWER_MODE,
  key,
  PAGE_SIZE,
} from "./store/constants";
import { initialFormDetail } from "./store/reducer";
import { CardPanel, PageWrap } from "./Styled";

const initialFilter = { keyword: "" };

const Main = () => {
  const setField = useDispatchRedux(setFieldValueStoreNotificationAction);
  const fetchList = useDispatchRedux(queryNotificationListAction);
  const fetchDetail = useDispatchRedux(queryNotificationDetailAction);
  const fetchTargetOptions = useDispatchRedux(queryTargetOptionsAction);
  const resetStore = useDispatchRedux(resetStoreNotificationAction);

  const items = useOneState(key, "items") || [];
  const loading = !!useOneState(key, "loading");

  const [filter, setFilter] = useState(initialFilter);
  const [appliedFilter, setAppliedFilter] = useState(initialFilter);
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(PAGE_SIZE);

  useEffect(() => {
    setTimeout(() => {
      fetchList();
    }, 100);

    return () => {
      resetStore();
    };
  }, []);

  const filteredItems = useMemo(
    () => filterNotificationsLocal(items, appliedFilter.keyword),
    [items, appliedFilter.keyword],
  );

  const handleFilterChange = (field, value) => {
    setFilter((prev) => ({ ...prev, [field]: value }));
  };

  const handleSearch = () => {
    setAppliedFilter({ ...filter });
    setPage(0);
  };

  const handleReset = () => {
    setFilter(initialFilter);
    setAppliedFilter(initialFilter);
    setPage(0);
  };

  const handlePageChange = (nextPage) => setPage(nextPage);

  const handlePageSizeChange = (nextSize) => {
    setSize(nextSize);
    setPage(0);
  };

  const handleAdd = () => {
    fetchTargetOptions({ skipIfLoaded: true });
    setField("detail", { ...initialFormDetail });
    setField("viewDetail", null);
    setField("drawerMode", DRAWER_MODE.CREATE);
    setField("isModalCreateOrUpdate", true);
  };

  const handleDetail = (row) => {
    if (!row?.id) return;
    setField("viewDetail", null);
    setField("drawerMode", DRAWER_MODE.VIEW);
    setField("isModalCreateOrUpdate", true);
    fetchDetail({ id: row.id });
  };

  return (
    <React.Fragment>
      <AppHeader
        componentName="NotificationConfig"
        handleBtnClick={handleAdd}
      />
      <PageWrap>
        <CardPanel>
          <NotificationFilter
            filter={filter}
            loading={loading}
            onChange={handleFilterChange}
            onSearch={handleSearch}
            onReset={handleReset}
          />
          <Table
            rows={filteredItems}
            loading={loading}
            page={page}
            size={size}
            onPageChange={handlePageChange}
            onPageSizeChange={handlePageSizeChange}
            onDetail={handleDetail}
          />
        </CardPanel>
      </PageWrap>
      <ModalCreateUpdate />
    </React.Fragment>
  );
};

export default Main;
