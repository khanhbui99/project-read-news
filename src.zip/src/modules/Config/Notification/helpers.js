import dayjs from "dayjs";

import {
  DEFAULT_GRADES,
  getTargetChipLabel,
  getTargetTypeLabel,
} from "./notification.config";
import { AUTO_TARGET_TYPES, TARGET_TYPE } from "./store/constants";

export const isSuccessMeta = (meta = {}) =>
  meta?.code === "IL-200" || meta?.code === "LMS-200";

export const getListData = (res) => {
  if (Array.isArray(res)) return res;
  if (Array.isArray(res?.data)) return res.data;
  return [];
};

export const getObjectData = (res) => {
  if (res?.data && typeof res.data === "object" && !Array.isArray(res.data)) {
    return res.data;
  }
  return res?.data ?? res ?? null;
};

export const formatNotificationDate = (value) => {
  if (!value) return "—";
  const date = dayjs(value);
  return date.isValid() ? date.format("DD/MM/YYYY HH:mm") : "—";
};

export const formatFileSize = (bytes) => {
  const size = Number(bytes);
  if (!Number.isFinite(size) || size < 0) return "—";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
};

export const truncateText = (value, max = 80) => {
  const text = String(value || "").trim();
  if (!text) return "—";
  if (text.length <= max) return text;
  return `${text.slice(0, max)}...`;
};

export const getTargetKey = (target = {}) =>
  [
    target.targetType || "",
    target.targetRefId ?? "",
    target.targetRefCode || "",
  ].join("|");

export const isAutoTargetType = (targetType) =>
  AUTO_TARGET_TYPES.includes(targetType);

export const buildAutoTarget = (targetType, label) => ({
  targetType,
  targetRefId: null,
  targetRefCode: null,
  targetRefName: label || targetType,
});

export const isSameTarget = (a = {}, b = {}) => {
  if (!a?.targetType || a.targetType !== b?.targetType) return false;
  if (isAutoTargetType(a.targetType)) return true;

  const idA =
    a.targetRefId === "" || a.targetRefId == null
      ? null
      : String(a.targetRefId);
  const idB =
    b.targetRefId === "" || b.targetRefId == null
      ? null
      : String(b.targetRefId);
  const codeA = a.targetRefCode || null;
  const codeB = b.targetRefCode || null;

  return idA === idB && codeA === codeB;
};

export const addTargetUnique = (targets = [], next) => {
  if (!next) return targets || [];
  if ((targets || []).some((item) => isSameTarget(item, next))) {
    return targets;
  }

  if (isAutoTargetType(next.targetType)) {
    return [next];
  }

  const withoutAuto = (targets || []).filter(
    (item) => !isAutoTargetType(item.targetType),
  );
  return [...withoutAuto, next];
};

export const removeTarget = (targets = [], target) =>
  (targets || []).filter((item) => !isSameTarget(item, target));

export const normalizeTargetOptions = (raw = {}) => {
  const grades = Array.isArray(raw.grades) ? raw.grades : [];
  const classes = Array.isArray(raw.classes) ? raw.classes : [];
  const departments = Array.isArray(raw.departments) ? raw.departments : [];
  const subjectGroups = Array.isArray(raw.subjectGroups)
    ? raw.subjectGroups
    : [];

  const gradeValues = grades.length ? grades : DEFAULT_GRADES;

  return {
    grades: gradeValues.map((grade) => ({
      targetType: TARGET_TYPE.GRADE,
      targetRefId: Number(grade),
      targetRefCode: null,
      targetRefName: `Khối ${grade}`,
      grade: Number(grade),
    })),
    classes: classes.map((item) => ({
      id: item.id,
      name: item.name || String(item.id),
      grade: item.grade,
    })),
    departments: departments.map((name) => ({
      targetType: TARGET_TYPE.DEPARTMENT,
      targetRefId: null,
      targetRefCode: String(name),
      targetRefName: String(name),
    })),
    subjectGroups: subjectGroups.map((item) => ({
      targetType: TARGET_TYPE.SUBJECT_GROUP,
      targetRefId: item.id,
      targetRefCode: null,
      targetRefName: item.name || String(item.id),
    })),
  };
};

export const mapGlobalClassesToOptions = (classesOpt = []) =>
  (classesOpt || []).map((item) => ({
    id: item.id ?? item.classId,
    name: item.name || item.className || String(item.id ?? item.classId),
    grade: item.grade ?? item.khoi ?? item.gradeLevel,
  }));

export const mapTeachersToOptions = (teachersOpt = []) =>
  (teachersOpt || [])
    .map((item) => {
      const targetRefId = item.accountId ?? item.id ?? item.teacherId;
      if (targetRefId == null || targetRefId === "") return null;
      return {
        targetType: TARGET_TYPE.HOMEROOM_TEACHERS,
        targetRefId,
        targetRefCode: null,
        targetRefName:
          item.fullName ||
          item.full_name ||
          item.name ||
          item.teacherCode ||
          String(targetRefId),
      };
    })
    .filter(Boolean);

export const buildClassTarget = (targetType, classItem) => ({
  targetType,
  targetRefId: classItem?.id,
  targetRefCode: null,
  targetRefName: classItem?.name || String(classItem?.id || ""),
  grade: classItem?.grade,
});

export const toSerializableTargetRefId = (value) => {
  if (value === "" || value == null) return null;
  const asNumber = Number(value);
  return Number.isNaN(asNumber) ? value : asNumber;
};

/** API: targets = JSON string mảng { targetType, targetRefId, targetRefCode } */
export const serializeTargets = (targets = []) =>
  JSON.stringify(
    (targets || []).map((item) => {
      const isAuto = isAutoTargetType(item.targetType);
      const isDepartment = item.targetType === TARGET_TYPE.DEPARTMENT;

      return {
        targetType: item.targetType,
        targetRefId:
          isAuto || isDepartment
            ? null
            : toSerializableTargetRefId(item.targetRefId),
        targetRefCode: isDepartment ? item.targetRefCode || null : null,
      };
    }),
  );

export const buildCreateFormData = (payload = {}) => {
  const formData = new FormData();
  formData.append("title", (payload.title || "").trim());
  formData.append("content", (payload.content || "").trim());
  formData.append("targets", serializeTargets(payload.targets || []));
  (payload.files || []).forEach((file) => {
    if (file instanceof File) {
      formData.append("files", file);
    }
  });
  return formData;
};

export const filterNotificationsLocal = (items = [], keyword = "") => {
  const key = String(keyword || "")
    .trim()
    .toLowerCase();
  if (!key) return items || [];

  return (items || []).filter((item) => {
    const targetText = (item.targets || [])
      .map((target) =>
        [
          target.targetType,
          getTargetTypeLabel(target.targetType),
          target.targetRefCode,
          target.targetRefName,
          getTargetChipLabel(target),
        ].join(" "),
      )
      .join(" ");

    return [item.title, item.content, targetText]
      .join(" ")
      .toLowerCase()
      .includes(key);
  });
};

export const formatTargetsSummary = (targets = [], maxVisible = 2) => {
  const list = targets || [];
  if (!list.length) return { labels: [], extra: 0 };
  const labels = list.slice(0, maxVisible).map(getTargetChipLabel);
  return {
    labels,
    extra: Math.max(list.length - maxVisible, 0),
  };
};

export const computeReadStats = (detail = {}) => {
  const recipientCount = Math.max(Number(detail.recipientCount) || 0, 0);
  const readCount = Math.max(Number(detail.readCount) || 0, 0);
  const unreadCount = Math.max(recipientCount - readCount, 0);
  const readRate =
    recipientCount > 0
      ? Number(((readCount / recipientCount) * 100).toFixed(1))
      : 0;
  return { recipientCount, readCount, unreadCount, readRate };
};

export const normalizeTargetForForm = (target = {}) => ({
  targetType: target.targetType,
  targetRefId:
    target.targetRefId === "" || target.targetRefId == null
      ? null
      : toSerializableTargetRefId(target.targetRefId),
  targetRefCode: target.targetRefCode || null,
  targetRefName:
    target.targetRefName ||
    getTargetChipLabel(target) ||
    getTargetTypeLabel(target.targetType),
});

export const mapDetailToForm = (detail = {}) => ({
  title: detail.title || "",
  content: detail.content || "",
  targets: (detail.targets || []).map(normalizeTargetForForm),
  files: [],
});

/** Chuẩn hóa file đính kèm từ detail API (files / attachments / ...) */
export const normalizeDetailFiles = (detail = {}) => {
  const raw =
    detail.files ||
    detail.attachments ||
    detail.attachmentFiles ||
    detail.evidenceFiles ||
    [];

  if (!Array.isArray(raw)) return [];

  return raw
    .map((file, index) => {
      if (!file) return null;
      const id = file.id ?? file.fileId ?? file.attachmentId ?? index;
      const fileName =
        file.fileName ||
        file.name ||
        file.originalFileName ||
        file.originalName ||
        file.fileKey ||
        "Tệp đính kèm";
      const fileSize = file.fileSize ?? file.size ?? file.byteSize ?? 0;
      return {
        ...file,
        id,
        fileName,
        fileSize,
        fileKey: file.fileKey || file.key || null,
      };
    })
    .filter(Boolean);
};

export const normalizeNotificationDetail = (detail = null) => {
  if (!detail) return null;
  return {
    ...detail,
    targets: (detail.targets || []).map(normalizeTargetForForm),
    files: normalizeDetailFiles(detail),
  };
};
