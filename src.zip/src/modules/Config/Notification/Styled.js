import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const PageWrap = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  min-height: calc(100vh - 140px);
  margin-top: 16px;
  font-family: SVN_Gilroy, sans-serif;
`;

export const Toolbar = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
`;

export const SearchWrap = styled.div`
  min-width: 280px;
  flex: 1;
  max-width: 420px;
`;

export const CardPanel = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  flex: 1;
  min-height: 0;
  padding: 16px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  box-shadow: ${VPB_THEMES.colors.cardShadow};
  overflow: hidden;
`;

export const FilterGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: 12px;

  > *:not(.filter-actions) {
    flex: 1 1 220px;
    min-width: 200px;
    max-width: 420px;
  }

  .filter-actions {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    gap: 8px;
  }
`;

export const TargetChipRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  align-items: center;
`;

export const TargetChip = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  background: ${VPB_THEMES.colors.f0f9ff};
  color: ${VPB_THEMES.colors.primaryBlue};
  border: 1px solid ${VPB_THEMES.colors.modal?.summaryBorder || "#e0f2fe"};
`;

export const ExtraChip = styled.button`
  border: none;
  cursor: pointer;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  font-family: SVN_Gilroy, sans-serif;
  background: ${VPB_THEMES.colors.lightBg};
  color: ${VPB_THEMES.colors.textDark};
`;

export const DrawerBody = styled.div`
  padding: 0 20px 16px;
  overflow: auto;
  max-height: calc(100vh - 160px);
  font-family: SVN_Gilroy, sans-serif;
`;

export const SectionTitle = styled.h3`
  margin: 0 0 10px;
  font-size: 13px;
  font-weight: 800;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: ${VPB_THEMES.colors.textDark};
`;

export const SectionBlock = styled.div`
  margin-bottom: 16px;
`;

export const HelperText = styled.div`
  margin-top: 6px;
  font-size: 12px;
  color: ${VPB_THEMES.colors.textLight};
`;

export const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
  margin-bottom: 16px;
`;

export const StatCard = styled.div`
  padding: 12px 14px;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.lightBg};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;

export const StatLabel = styled.div`
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
  margin-bottom: 4px;
`;

export const StatValue = styled.div`
  font-size: 20px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.primaryBlue};
`;

export const DetailLabel = styled.div`
  font-size: 12px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textLight};
  margin-bottom: 4px;
`;

export const DetailValue = styled.div`
  font-size: 14px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark};
  white-space: pre-wrap;
  word-break: break-word;
`;

export const FileList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

export const FileItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 10px;
  background: ${VPB_THEMES.colors.lightBg};
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
`;

export const FileMeta = styled.div`
  min-width: 0;
  flex: 1;
`;

export const FileName = styled.div`
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
`;

export const FileSize = styled.div`
  margin-top: 2px;
  font-size: 12px;
  color: ${VPB_THEMES.colors.textLight};
`;

export const OptionList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 6px;
  max-height: 220px;
  overflow: auto;
  padding: 8px;
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.gray["200"]};
  background: ${VPB_THEMES.colors.white};
`;

export const OptionRow = styled.label`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textDark};
  cursor: pointer;
`;

export const EmptyHint = styled.div`
  padding: 16px;
  text-align: center;
  color: ${VPB_THEMES.colors.textLight};
  font-size: 13px;
`;

/* —— Detail view: nhẹ nhàng, rõ ràng, đa thế hệ —— */

export const SoftHeader = styled.div`
  & > div {
    margin-bottom: 0;
    padding: 14px 16px;
    background: rgba(255, 255, 255, 0.86);
    border-bottom: 1px solid ${VPB_THEMES.colors.borderMedium};
    backdrop-filter: blur(8px);

    .title {
      padding-right: 44px;
      font-size: 16px;
      font-weight: 700;
      line-height: 1.35;
      color: ${VPB_THEMES.colors.textDark};
    }

    .close-icon {
      top: 50%;
      right: 0;
      transform: translateY(-50%);
      width: 36px;
      height: 36px;
      border-radius: 12px;
      color: ${VPB_THEMES.colors.textDark};
      background: ${VPB_THEMES.colors.lightBg};
      transition: background 0.15s ease, color 0.15s ease;

      &:hover {
        color: ${VPB_THEMES.colors.primaryBlue};
        background: ${VPB_THEMES.colors.f0f9ff};
      }
    }
  }
`;

export const HeaderLead = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
`;

export const HeaderIconBox = styled.span`
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: ${VPB_THEMES.colors.primaryBlue};
  background: ${VPB_THEMES.colors.f0f9ff};

  .MuiSvgIcon-root {
    font-size: 22px;
  }
`;

export const HeaderText = styled.div`
  min-width: 0;
`;

export const HeaderTitle = styled.div`
  font-family: SVN_Gilroy, sans-serif;
  font-size: 16px;
  font-weight: 800;
  line-height: 1.3;
  color: ${VPB_THEMES.colors.textDark};
`;

export const HeaderCaption = styled.div`
  margin-top: 2px;
  font-family: SVN_Gilroy, sans-serif;
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
`;

export const DetailShell = styled.div`
  margin: 0;
  padding: 16px 8px 8px;
  border-radius: 0;
  background: linear-gradient(
    180deg,
    ${VPB_THEMES.colors.eff6ff} 0%,
    ${VPB_THEMES.colors.lightBg} 45%,
    transparent 100%
  );
`;

export const DetailRoot = styled.div`
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding-bottom: 8px;
  font-family: SVN_Gilroy, sans-serif;
`;

export const DetailIntro = styled.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
`;

export const DetailHeroTitle = styled.h2`
  margin: 0;
  font-size: 22px;
  font-weight: 800;
  line-height: 1.35;
  color: ${VPB_THEMES.colors.textDark};
  word-break: break-word;
`;
export const DetailHeroMeta = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
`;
export const DetailMetaItem = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 7px 12px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.05);

  .MuiSvgIcon-root {
    font-size: 16px;
    color: ${VPB_THEMES.colors.primaryBlue};
  }
`;

export const DetailCard = styled.section`
  padding: 18px;
  border-radius: 18px;
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 4px 20px rgba(15, 23, 42, 0.05);
`;

export const DetailCardHead = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 14px;
`;

export const DetailPanelDot = styled.span`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: ${({ $tone }) => {
    if ($tone === "green") return VPB_THEMES.colors.statusActiveDot;
    if ($tone === "orange") return VPB_THEMES.colors.sunnyOrange;
    if ($tone === "teal") return VPB_THEMES.colors.teal;
    return VPB_THEMES.colors.secondaryBlue;
  }};
  box-shadow: 0 0 0 4px
    ${({ $tone }) => {
      if ($tone === "green") return VPB_THEMES.colors.f0fdf4;
      if ($tone === "orange") return VPB_THEMES.colors.fffbeb;
      if ($tone === "teal") return VPB_THEMES.colors.lessonSport.start;
      return VPB_THEMES.colors.f0f9ff;
    }};
`;

export const DetailCardTitle = styled.h3`
  margin: 0;
  font-size: 15px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.textDark};
`;

export const DetailContentBox = styled.div`
  padding: 16px 18px;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.lightBg};
  font-size: 15px;
  font-weight: 500;
  line-height: 1.8;
  color: ${VPB_THEMES.colors.textDark};
  white-space: pre-wrap;
  word-break: break-word;
`;

export const DetailStatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;

  @media (max-width: 520px) {
    grid-template-columns: 1fr;
  }
`;

export const DetailStatCard = styled.div`
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 14px 12px;
  border-radius: 14px;
  background: ${({ $tone }) => {
    if ($tone === "success") return VPB_THEMES.colors.f0fdf4;
    if ($tone === "warn") return VPB_THEMES.colors.fffbeb;
    if ($tone === "teal") return VPB_THEMES.colors.lessonSport.start;
    return VPB_THEMES.colors.f0f9ff;
  }};
`;

export const DetailStatIcon = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  flex-shrink: 0;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  color: ${({ $tone }) => {
    if ($tone === "success") return VPB_THEMES.colors.statusActiveDot;
    if ($tone === "warn") return VPB_THEMES.colors.sunnyOrange;
    if ($tone === "teal") return VPB_THEMES.colors.teal;
    return VPB_THEMES.colors.secondaryBlue;
  }};
  box-shadow: 0 2px 8px rgba(15, 23, 42, 0.06);

  .MuiSvgIcon-root {
    font-size: 18px;
  }
`;

export const DetailStatBody = styled.div`
  min-width: 0;
`;

export const DetailStatLabel = styled.div`
  font-size: 12px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textLight};
  margin-bottom: 4px;
`;

export const DetailStatValue = styled.div`
  font-size: 22px;
  font-weight: 800;
  line-height: 1.15;
  color: ${({ $tone }) => {
    if ($tone === "success") return VPB_THEMES.colors.statusActiveText;
    if ($tone === "warn") return VPB_THEMES.colors.statusMaintenanceText;
    if ($tone === "teal") return VPB_THEMES.colors.teal;
    return VPB_THEMES.colors.primaryBlue;
  }};
`;

export const DetailFileItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 14px;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.lightBg};
  transition: background 0.15s ease, box-shadow 0.15s ease;

  &:hover {
    background: ${VPB_THEMES.colors.f0f9ff};
    box-shadow: 0 4px 14px rgba(0, 119, 190, 0.08);
  }
`;

export const DetailFileLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  flex: 1;
`;

export const DetailFileIcon = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  flex-shrink: 0;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.primaryBlue};
  box-shadow: 0 2px 10px rgba(0, 119, 190, 0.1);

  .MuiSvgIcon-root {
    font-size: 22px;
  }
`;

export const DetailEmpty = styled.div`
  padding: 22px 12px;
  text-align: center;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.shade};
  color: ${VPB_THEMES.colors.textLight};
  font-size: 13px;
  font-weight: 600;
`;

export const DetailLoadingWrap = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  min-height: 240px;
  color: ${VPB_THEMES.colors.textLight};
  font-size: 13px;
  font-weight: 600;
`;

export const DetailTargetChip = styled(TargetChip)`
  background: ${VPB_THEMES.colors.f0f9ff};
  color: ${VPB_THEMES.colors.primaryBlue};
  border: none;
  padding: 7px 12px;
  font-size: 13px;
`;

export const DetailDownloadBtn = styled.button`
  border: none;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 9px 14px;
  border-radius: 999px;
  font-family: SVN_Gilroy, sans-serif;
  font-size: 13px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.primaryBlue};
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 2px 10px rgba(0, 119, 190, 0.12);

  &:hover {
    background: ${VPB_THEMES.colors.f0f9ff};
  }

  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;
