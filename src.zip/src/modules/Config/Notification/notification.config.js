export const TARGET_CONFIG = {
  ALL_SCHOOL: {
    label: "Toàn trường",
    chipPrefix: "Toàn trường",
    mode: "auto",
  },
  GRADE: {
    label: "Theo khối",
    chipPrefix: "Khối",
    mode: "grade",
  },
  CLASS: {
    label: "Theo lớp",
    chipPrefix: "Lớp",
    mode: "class",
  },
  DEPARTMENT: {
    label: "Tổ chuyên môn",
    chipPrefix: "TCM",
    mode: "department",
  },
  SUBJECT_GROUP: {
    label: "Nhóm bộ môn",
    chipPrefix: "NBM",
    mode: "subjectGroup",
  },
  HOMEROOM_TEACHERS: {
    label: "Nhóm giáo viên",
    chipPrefix: "GV",
    mode: "teacher",
  },
  CLASS_SUBJECT_TEACHERS: {
    label: "GV bộ môn của lớp",
    chipPrefix: "GVBM",
    mode: "class",
  },
  CLASS_STUDENTS: {
    label: "HS trong lớp",
    chipPrefix: "HS",
    mode: "class",
  },
  BGH_DEPARTMENT: {
    label: "Ban giám hiệu",
    chipPrefix: "BGH",
    mode: "auto",
  },
  ALL_STAFF: {
    label: "Toàn trường (trừ HS & PH)",
    chipPrefix: "Cán bộ",
    mode: "auto",
  },
};

export const TARGET_TYPE_OPTIONS = Object.keys(TARGET_CONFIG).map((value) => ({
  value,
  label: TARGET_CONFIG[value].label,
}));

export const DEFAULT_GRADES = [6, 7, 8, 9];

export const getTargetTypeLabel = (targetType) =>
  TARGET_CONFIG[targetType]?.label || targetType || "—";

export const getTargetMode = (targetType) =>
  TARGET_CONFIG[targetType]?.mode || null;

export const getTargetChipLabel = (target = {}) => {
  if (!target) return "—";
  const config = TARGET_CONFIG[target.targetType];
  if (!config) {
    return (
      target.targetRefName ||
      target.targetRefCode ||
      target.targetType ||
      "—"
    );
  }

  if (config.mode === "auto") {
    return config.chipPrefix;
  }

  const name =
    target.targetRefName ||
    target.targetRefCode ||
    (target.targetRefId != null ? String(target.targetRefId) : "");

  if (target.targetType === "GRADE") {
    return `${config.chipPrefix} ${name.replace(/^Khối\s*/i, "") || target.targetRefId}`.trim();
  }

  if (!name) return config.label;
  return `${config.chipPrefix} ${name}`.trim();
};
