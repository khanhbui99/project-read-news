import urlApi from "services/api.url";

/** Cách tải template: gọi API backend hoặc link tĩnh từ LINK_VIEW_DOC */
export const DOWNLOAD_TEMPLATE_MODE = {
  API: "api",
  URL: "url",
};

/** Flow import: 1 bước hoặc validate rồi commit */
export const IMPORT_FLOW = {
  DIRECT: "direct",
  VALIDATE_THEN_COMMIT: "validateThenCommit",
};

export const IMPORT_TYPES = [
  {
    id: "partyMembers",
    label: "Đảng viên",
    description:
      "Import danh sách Đảng viên theo template Excel. Dữ liệu dùng cho dashboard và báo cáo Chi bộ.",
    importFlow: IMPORT_FLOW.DIRECT,
    importUrl: urlApi.configImports.partyMembers.import,
    downloadTemplateMode: DOWNLOAD_TEMPLATE_MODE.URL,
    downloadTemplatePath: "/lms/template-dang-vien.xlsx",
    downloadTemplateUrl: urlApi.configImports.partyMembers.downloadTemplate,
    downloadFileName: "Template_DangVien.xlsx",
    successMessage: "Import đảng viên thành công",
    importButtonLabel: "Import Đảng viên",
    stepTitle: "Import file Đảng viên",
    fileHint: "💡 Định dạng hỗ trợ: Excel (.xlsx, .xls)",
    acceptedFileTypes: ".xlsx,.xls",
    validExtensions: [".xlsx", ".xls"],
  },
  {
    id: "timetable",
    label: "Thời khoá biểu",
    description:
      "Import thời khoá biểu toàn trường từ file Excel. Hệ thống sẽ kiểm tra (validate) trước khi ghi dữ liệu.",
    importFlow: IMPORT_FLOW.VALIDATE_THEN_COMMIT,
    hideDownloadTemplate: true,
    validateUrl: urlApi.configImports.timetable.validate,
    commitUrl: urlApi.configImports.timetable.commit,
    successMessage: "Import thời khoá biểu thành công",
    importButtonLabel: "Import Thời khoá biểu",
    stepTitle: "Import file Thời khoá biểu",
    fileHint: "💡 Định dạng hỗ trợ: Excel (.xlsx, .xls)",
    acceptedFileTypes: ".xlsx,.xls",
    validExtensions: [".xlsx", ".xls"],
  },
];

export const DEFAULT_IMPORT_TYPE = IMPORT_TYPES[0]?.id || "";

export const getImportTypeById = (typeId = "") =>
  IMPORT_TYPES.find((item) => item.id === typeId) || IMPORT_TYPES[0];

export const hasDownloadTemplate = (type = {}) => {
  if (type.hideDownloadTemplate) return false;

  if (type.downloadTemplateMode === DOWNLOAD_TEMPLATE_MODE.URL) {
    return Boolean(type.downloadTemplatePath);
  }

  return Boolean(type.downloadTemplateUrl);
};

export const isApiDownloadTemplate = (type = {}) =>
  type.downloadTemplateMode === DOWNLOAD_TEMPLATE_MODE.API ||
  (!type.downloadTemplateMode && Boolean(type.downloadTemplateUrl));

export const isUrlDownloadTemplate = (type = {}) =>
  type.downloadTemplateMode === DOWNLOAD_TEMPLATE_MODE.URL &&
  Boolean(type.downloadTemplatePath);

export const isValidateThenCommitFlow = (type = {}) =>
  type.importFlow === IMPORT_FLOW.VALIDATE_THEN_COMMIT;
