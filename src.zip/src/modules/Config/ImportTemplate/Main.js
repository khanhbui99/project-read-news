import { setLoadingAction, setMessageByFieldAction } from "App/store/actions";
import AppHeader from "components/common/AppHeader";
import DownloadTemplate from "components/ImportTemp/DownloadTemplate";
import ImportSection from "components/ImportTemp/ImportSection";
import { ContainerStyled, ContentWrapper } from "components/ImportTemp/Styled";
import { useMemo } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import ImportTypeSelect from "./components/ImportTypeSelect";
import { downloadTemplateFromUrl } from "./helpers/downloadTemplate";
import {
  DEFAULT_IMPORT_TYPE,
  getImportTypeById,
  hasDownloadTemplate,
  IMPORT_TYPES,
  isApiDownloadTemplate,
  isUrlDownloadTemplate,
} from "./importTypes";
import {
  downloadImportTemplateAction,
  importTemplateAction,
  setImportTypeAction,
} from "./store/actions";
import { key } from "./store/constants";

const Main = () => {
  const importType = useOneState(key, "importType", DEFAULT_IMPORT_TYPE);
  const setImportType = useDispatchRedux(setImportTypeAction);
  const setMessageByField = useDispatchRedux(setMessageByFieldAction);
  const setLoadingPage = useDispatchRedux(setLoadingAction);
  const rqImportTemplate = useDispatchRedux(importTemplateAction);
  const rqDownloadTemplate = useDispatchRedux(downloadImportTemplateAction);

  const selectedType = useMemo(
    () => getImportTypeById(importType),
    [importType],
  );

  const showDownloadTemplate = hasDownloadTemplate(selectedType);

  const handleImportTypeChange = (typeId) => {
    setImportType(typeId);
  };

  const handleDownloadTemplate = async () => {
    if (isUrlDownloadTemplate(selectedType)) {
      try {
      setLoadingPage(true);
      await downloadTemplateFromUrl(
          selectedType.downloadTemplatePath,
          selectedType.downloadFileName,
        );
      } catch (error) {
        setMessageByField("error", error);
      } finally {
        setLoadingPage(false);
      }
    }

    if (isApiDownloadTemplate(selectedType)) {
      rqDownloadTemplate({ importType: selectedType.id });
    }
  };

  const handleImportFile = ({ file }) => {
    rqImportTemplate({
      file,
      importType: selectedType.id,
    });
  };

  const downloadDescription = isUrlDownloadTemplate(selectedType)
    ? `Tải template từ cấu hình URL cho loại "${selectedType.label}"`
    : `Tải template qua API cho loại "${selectedType.label}"`;

  return (
    <>
      <AppHeader isHiddenBtn componentName="ImportTemplateConfig" />
      <ContainerStyled>
        <ContentWrapper>
          <ImportTypeSelect
            options={IMPORT_TYPES}
            value={selectedType.id}
            onChange={handleImportTypeChange}
            description={selectedType.description}
          />

          {showDownloadTemplate && (
            <DownloadTemplate
              handleDownloadTemp={handleDownloadTemplate}
              stepNumber={2}
              description={downloadDescription}
            />
          )}

          <ImportSection
            key={selectedType.id}
            stepNumber={showDownloadTemplate ? 3 : 2}
            validExtensions={selectedType.validExtensions}
            acceptedFileTypes={selectedType.acceptedFileTypes}
            hanldeImportFile={handleImportFile}
            successMessage={selectedType.successMessage}
            importButtonLabel={selectedType.importButtonLabel}
            stepTitle={selectedType.stepTitle}
            fileHint={selectedType.fileHint}
          />
        </ContentWrapper>
      </ContainerStyled>
    </>
  );
};

export default Main;
