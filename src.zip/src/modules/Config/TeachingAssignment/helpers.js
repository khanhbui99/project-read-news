export const mappingTeachingAssignment = (item, classesOpt, teachersOpt, examPeriodCategory) => {
  if (!item) return null;

  const { subjects = [], semesters = [], academicYears = [], }= examPeriodCategory;

  const className = classesOpt.find((cls) => cls.id === item.classId)?.className || "";
  const teacherName = teachersOpt.find((_t) => _t.teacherCode === item.teacherCode)?.fullName || "";
  const subjectName = subjects.find((_s) => _s.id === item.subjectId)?.name || "";
  const semesterName = (item.semesterId || []).map((id) => semesters.find((s) => s.id == id)?.name).filter(Boolean).join(", ");
  const schoolYearName = academicYears.find((year) => year.id === item.schoolYearId)?.name || "";

  return {
    ...item,
    className,
    teacherName,
    subjectName,
    semesterName,
    schoolYearName,
  };
}