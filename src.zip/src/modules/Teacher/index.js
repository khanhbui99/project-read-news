// ======== PHÊ DUYỆT CẤP QUẢN LÝ ========
export { default as ApproveLeaveReqTeacher } from "./Leave/ApproveReq";
export { default as BackupLeaveReqTeacher } from "./Leave/BackupReq";
export { default as HistoryLeaveReqTeacher } from "./Leave/HistoryReq";
export { default as ConfirmAndHistoryLeaveReqTeacher } from "./Leave/BroadReq";
export { default as BoardLeaveSummaryTeacher } from "./Leave/BoardSummary";
export { default as OfficeUtilityApproveRequest } from "./OfficeUtility/ApproveReq";
export { default as ConfigTypeOfficeUtilityTeacher } from "./OfficeUtility/ConfigType";
export { default as EmulationCriteriaTeacher } from "./Emulation/Criteria";
export { default as EmulationReportTeacher } from "./Emulation/Report";
export { default as EmulationReport2Teacher } from "./Emulation/Report2";

// ======== CHUNG ========
export { default as MyLeaveReqTeacher } from "./Leave/MyRequest";
export { default as OfficeUtilityMyRequest } from "./OfficeUtility/MyRequest";
export { default as ClassesTeacher } from "./Class";
export { default as ManagementTeachers } from "./GV";
export { default as MyClassTeacher } from "./MyClass";
export { default as StudentGradesMmgt } from "./Scoring";
export { default as DanhSachLopDayTeacher } from "./DanhSachLopDay";
// export { default as StudentGradesManagement} from "./Score/StudentGradesManagement";
export { default as StudentGradesManagement} from "./Scoring";

