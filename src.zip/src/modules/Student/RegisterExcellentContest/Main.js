// import { Box } from "@mui/material";
import { getExamPeriodCategoryAction } from "App/store/actions";
// import LoadingIndicator from "components/common/LoadingIndicator";
import { useEffect, useMemo } from "react";
import { useOneState, useDispatchRedux } from "utils/hooks/useRedux";

import ExamGrid from "./components/ExamGrid";
import HeroSection from "./components/HeroSection";
import MyRegistrations from "./components/MyRegistrations";
import RegisterModal from "./components/RegisterModal";
import SuccessSplash from "./components/SuccessSplash";
import {
  fetchExamsAction,
  registerExamAction,
  cancelRegistrationAction,
  setRegisterModalOpenAction,
  setSuccessSplashOpenAction,
  fetchStudentInfoAction,
  fetchMyRegistrationsAction,
} from "./store/actions";
import { key } from "./store/constants";
import {
  ContainerStyled,
  ContainerInner,
  SectionHeader,
  SectionTitle,
} from "./Styled";

const RegisterExcellentContestMain = () => {
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);
  const fetchStudentInfo = useDispatchRedux(fetchStudentInfoAction);
  const fetchMyRegistrations = useDispatchRedux(fetchMyRegistrationsAction);
  
  // Redux hooks 
  const fetchExams = useDispatchRedux(fetchExamsAction);
  const rqRegisterExam = useDispatchRedux(registerExamAction);
  const rqCancelRegistration = useDispatchRedux(cancelRegistrationAction);
  const rqSetRegisterModalOpen = useDispatchRedux(setRegisterModalOpenAction);
  const rqSetSuccessSplashOpen = useDispatchRedux(setSuccessSplashOpenAction);

  // Redux state
  const exams = useOneState(key, "items") || [];
  const studentInfo = useOneState(key, "studentInfo");
  const registerModal = useOneState(key, "registerModal");
  const successSplash = useOneState(key, "successSplash");

  // Fetch data on mount
  useEffect(() => {
    fetchStudentInfo();
    fetchExamPeriodCategory();
    
    setTimeout(() => { 
      fetchExams();
      fetchMyRegistrations();
    }, 500);
  }, []);

  // Get current exam for modal
  const currentExam = useMemo(() => {
    if (!registerModal?.examId) return null;
    return exams.find((e) => e.id === registerModal.examId);
  }, [exams, registerModal?.examId]);

  const handleRegister = (examId) => {
    rqSetRegisterModalOpen(true, examId);
  };

  const handleCloseModal = () => {
    rqSetRegisterModalOpen(false, null);
  };

  const handleConfirmRegister = (examId) => {
    rqRegisterExam({ examId});
  };


  const handleCancelRegistration = (examId) => {
    if (
      window.confirm(
        "Bạn có chắc muốn hủy đăng ký kỳ thi này không?"
      )
    ) {
      rqCancelRegistration(examId);
    }
  };

  return (
    <ContainerStyled>
      <ContainerInner>
        <HeroSection
          studentInfo={studentInfo}
        />

        <MyRegistrations
          exams={exams}
          onCancel={handleCancelRegistration}
        />

        <SectionHeader style={{ marginTop: 8 }}>
          <SectionTitle>🏆 Kỳ thi đang mở đăng ký</SectionTitle>
        </SectionHeader>

        {/* <ExamTabs
          currentTab={currentTab}
          tabCounts={tabCounts}
          onTabChange={handleTabChange}
        /> */}

        <ExamGrid
          exams={exams}
          studentInfo={studentInfo}
          onRegister={handleRegister}
          onCancel={handleCancelRegistration}
        />
      </ContainerInner>

      <RegisterModal
        open={registerModal?.open || false}
        exam={currentExam}
        studentInfo={studentInfo}
        exams={exams}
        onClose={handleCloseModal}
        onConfirm={handleConfirmRegister}
      />

      <SuccessSplash
        open={successSplash.open}
        examName={currentExam?.name || ""}
        onClose={() => rqSetSuccessSplashOpen(false)}
      />
    </ContainerStyled>
  );
};

export default RegisterExcellentContestMain;
