import * as constants from "./store/constants";

/**
 * Parse exam date string from DD/MM/YYYY to YYYY-MM-DD
 */
export const parseExamDateStr = (ddmmyyyy) => {
  const [d, m, y] = ddmmyyyy.split("/");
  return `${y}-${m}-${d}`;
};

/**
 * Check if two time ranges overlap
 */
export const timesOverlap = (dateA, startA, endA, dateB, startB, endB) => {
  if (dateA !== dateB) return false; // Different dates → no overlap

  // Compare times in HH:MM format
  return startA < endB && endA > startB;
};

/**
 * Get eligibility for an exam
 */
export const getEligibility = (exam, studentInfo, exams) => {
  // Grade-locked (only specific grade)
  if (exam?.onlyGrade && studentInfo?.grade !== exam?.onlyGrade) {
    return {
      eligible: false,
      isOvergrade: false,
      reason: `Kỳ thi chỉ dành cho khối ${exam?.onlyGrade}`,
      conflict: null,
    };
  }

  const avg = studentInfo?.avgScore;
  const stuGrade = studentInfo?.grade;
  const examGrade = exam?.grade;


  // Use minAverageScore and minCrossGradeAverageScore from API
  const minScore = exam?.minAverageScore || exam?.minScore;
  const minCrossGradeScore = exam?.minCrossGradeAverageScore || exam?.minScoreOvergrade;

  if (stuGrade === examGrade) {
    // Same grade - check minAverageScore
    if (avg >= minScore)
      return { eligible: true, isOvergrade: false, reason: "", conflict: null };
    else
      return {
        eligible: false,
        isOvergrade: false,
        // reason: `ĐTB ${avg} chưa đạt ngưỡng ${minScore}`,
        reason: 'Không đủ điều kiện tham dự',
        conflict: null,
      };
  } else {
    // Different grade - check if cross-grade is allowed
    if (!minCrossGradeScore) {
      return {
        eligible: false,
        isOvergrade: false,
        reason: `Kỳ thi không chấp nhận vượt cấp`,
        conflict: null,
      };
    }
    // Check if student meets cross-grade requirement
    if (avg >= minCrossGradeScore)
      return {
        eligible: false,
        isOvergrade: true,
        reason: "",
        conflict: null,
      };
    else
      return {
        eligible: false,
        isOvergrade: false,
        reason: `Vượt cấp yêu cầu ĐTB ≥ ${minCrossGradeScore} (bạn: ${avg})`,
        conflict: null,
      };
  }
};

/**
 * Check if exam should be shown
 */
export const isExamShowable = (exam, studentInfo, exams) => {
  // Always show if already registered
  const { eligible, isOvergrade } = getEligibility(
    exam,
    studentInfo,
    exams
  );
  return eligible || isOvergrade; // Only show if eligible or can overgrade
};

/**
 * Get filtered exams based on current tab
 */
export const getFilteredExams = (
  exams,
  currentTab,
  studentInfo,
) => {
  return exams.filter((e) => {
    if (!isExamShowable(e, studentInfo, exams)) return false;

    if (currentTab === constants.TAB_TYPES.ALL) return true;
    if (currentTab === constants.TAB_TYPES.REGISTERED)
      return e.totalStudent > e.maxStudents;
    if (currentTab === constants.TAB_TYPES.ELIGIBLE)
      return e.totalStudent < e.maxStudents;
    if (currentTab === constants.TAB_TYPES.OVERGRADE) return e.totalStudent > e.maxStudents;
    return true;
  });
};

/**
 * Get tab counts
 */
export const getTabCounts = (exams, studentInfo) => {
  const showable = exams.filter((e) =>
    isExamShowable(e, studentInfo, exams)
  );

  return {
    all: showable.length,
    eligible: showable.filter((e) => {
      const r = getEligibility(e, studentInfo, exams);
      return r.eligible && !r.isOvergrade;
    }).length,
    overgrade: showable.filter((e) =>
      getEligibility(e, studentInfo, exams).isOvergrade
    ).length,
    registered: showable.filter((e) =>
      e.totalStudent > e.maxStudents
    ).length,
  };
};

/**
 * Get exam type config
 */
export const getExamTypeConfig = (type) => {
  const configs = {
    [constants.EXAM_TYPES.HSG]: {
      bannerCls: "banner-hsg",
      iconCls: "eti-hsg",
      icon: "fas fa-medal",
      color: "linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)",
      iconColor: "#7c3aed",
    },
    [constants.EXAM_TYPES.OLYMPIC]: {
      bannerCls: "banner-ol",
      iconCls: "eti-ol",
      icon: "fas fa-star",
      color: "linear-gradient(135deg, #0891b2 0%, #06b6d4 100%)",
      iconColor: "#0891b2",
    },
    [constants.EXAM_TYPES.TRANG_NGUYEN]: {
      bannerCls: "banner-tn",
      iconCls: "eti-tn",
      icon: "fas fa-crown",
      color: "linear-gradient(135deg, #d97706 0%, #f59e0b 100%)",
      iconColor: "#d97706",
    },
    [constants.EXAM_TYPES.TOT_NGHIEP]: {
      bannerCls: "banner-tot",
      iconCls: "eti-tot",
      icon: "fas fa-scroll",
      color: "linear-gradient(135deg, #059669 0%, #10b981 100%)",
      iconColor: "#059669",
    },
  };

  return configs[type] || configs[constants.EXAM_TYPES.HSG];
};

/**
 * Get icon color for exam type (for inline style)
 */
export const getIconColor = (type) => {
  const c = {
    [constants.EXAM_TYPES.HSG]: "color:#7c3aed",
    [constants.EXAM_TYPES.OLYMPIC]: "color:#0891b2",
    [constants.EXAM_TYPES.TRANG_NGUYEN]: "color:#d97706",
    [constants.EXAM_TYPES.TOT_NGHIEP]: "color:#059669",
  };
  return c[type] || "color:#7c3aed";
};

/**
 * Calculate deadline percentage
 */
export const calculateDeadlinePercentage = (deadlineDays, maxDays = 30) => {
  if (deadlineDays < 0) return 100;
  return Math.max(0, Math.min(100, (1 - deadlineDays / maxDays) * 100));
};

/**
 * Get deadline color
 */
export const getDeadlineColor = (deadlineDays) => {
  if (deadlineDays <= 3) return "#e11d48";
  if (deadlineDays <= 7) return "#d97706";
  return "#059669";
};

/**
 * Get slot percentage
 */
export const getSlotPercentage = (registered, maxSlots) => {
  return Math.min(100, Math.round((registered / maxSlots) * 100));
};

/**
 * Get slot color
 */
export const getSlotColor = (percentage) => {
  if (percentage >= 90) return "#e11d48";
  if (percentage >= 70) return "#d97706";
  return "#7c3aed";
};
