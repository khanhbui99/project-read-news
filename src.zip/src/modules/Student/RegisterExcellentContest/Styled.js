import { Box, Paper, Button, Dialog, Backdrop } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

import { EXAM_TYPES } from "./store/constants";

// ──── CONTAINER ────
export const ContainerStyled = styled.div`
  display: flex;
  flex-direction: column;
  gap: 28px;
  // padding: 32px 36px;
  // min-height: calc(100vh - 66px);
  // background: #f0f2ff;
  color: #1e1b4b;

  @media (max-width: 768px) {
    // padding: 22px 20px;
    gap: 20px;
  }
`;

export const ContainerInner = styled.div`
  // max-width: 1080px;
  margin: 0 auto;
  width: 100%;

`;

// ──── HERO SECTION ────
export const HeroSection = styled(Paper)`

  background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%) !important;
  border-radius: 20px;
  padding: 32px 36px;
  margin-bottom: 28px;
  position: relative;
  overflow: hidden;
  box-shadow: 0 16px 56px rgba(79, 70, 229, 0.18);

  &::before {
    content: "";
    position: absolute;
    top: -40px;
    right: -40px;
    width: 240px;
    height: 240px;
    background: rgba(255, 255, 255, 0.06);
    border-radius: 50%;
  }

  &::after {
    content: "";
    position: absolute;
    bottom: -60px;
    right: 120px;
    width: 180px;
    height: 180px;
    background: rgba(255, 255, 255, 0.04);
    border-radius: 50%;
  }

  @media (max-width: 768px) {
    padding: 22px 20px;
  }
`;

export const HeroInner = styled(Box)`
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 28px;
  flex-wrap: wrap;
`;

export const HeroLeft = styled(Box)`
  flex: 1;
  min-width: 0;
`;

export const HeroGreeting = styled.div`
  font-size: 13px;
  font-weight: 700;
  color: rgba(255, 255, 255, 0.7);
  letter-spacing: 0.5px;
  margin-bottom: 4px;
  text-transform: uppercase;
`;

export const HeroName = styled.div`
  font-size: 28px;
  font-weight: 800;
  color: white;
  letter-spacing: -0.5px;
  margin-bottom: 8px;
`;

export const HeroSub = styled.div`
  font-size: 14px;
  color: rgba(255, 255, 255, 0.75);
  line-height: 1.6;
`;

export const HeroStats = styled(Box)`
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
`;

export const HeroStat = styled(Box)`
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  padding: 14px 20px;
  text-align: center;
  min-width: 90px;
`;

export const HeroStatValue = styled.div`
  font-size: 26px;
  font-weight: 700;
  color: white;
  line-height: 1;
`;

export const HeroStatLabel = styled.div`
  font-size: 11px;
  color: rgba(255, 255, 255, 0.7);
  font-weight: 700;
  margin-top: 4px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

export const EligBar = styled(Box)`
  background: rgba(255, 255, 255, 0.12);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 10px;
  padding: 14px 18px;
  display: flex;
  align-items: center;
  gap: 14px;
  margin-top: 16px;
`;

export const EligIcon = styled.div`
  font-size: 24px;
  flex-shrink: 0;
`;

export const EligText = styled.div`
  flex: 1;
`;

export const EligTitle = styled.div`
  font-size: 13px;
  font-weight: 800;
  color: white;
  margin-bottom: 3px;
`;

export const EligSub = styled.div`
  font-size: 12px;
  color: rgba(255, 255, 255, 0.7);
`;

export const EligScore = styled.div`
  font-size: 22px;
  font-weight: 800;
  color: #fde68a;
`;

// ──── MY REGISTRATIONS ────
export const SectionHeader = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 14px;
`;

export const SectionTitle = styled.div`
  font-size: 18px;
  font-weight: 800;
  color: #1e1b4b;
  display: flex;
  align-items: center;
  gap: 8px;
`;

export const SectionBadge = styled.span`
  background: #ede9fe;
  color: #7c3aed;
  font-size: 11px;
  font-weight: 800;
  padding: 2px 9px;
  border-radius: 20px;
  height: auto;
`;

export const MyRegsList = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 32px;
`;

export const MyRegCard = styled.div`
  background: white;
  border: 1.5px solid #e4e8ff;
  border-radius: 16px;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  box-shadow: 0 2px 12px rgba(79, 70, 229, 0.08), 0 1px 3px rgba(0, 0, 0, 0.04);
  transition: all 0.2s;
  animation: fadeSlide 0.3s ease both;

  @keyframes fadeSlide {
    from {
      opacity: 0;
      transform: translateY(8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 28px rgba(79, 70, 229, 0.14);
    border-color: rgba(124, 58, 237, 0.3);
  }
`;

export const RegCardDot = styled.div`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  flex-shrink: 0;
  background: ${({ $color }) => $color || "#f59e0b"};
`;

export const RegCardInfo = styled(Box)`
  flex: 1;
  min-width: 0;
`;

export const RegCardName = styled.div`
  font-size: 14px;
  font-weight: 800;
  color: #1e1b4b;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 3px;
`;

export const RegCardMeta = styled(Box)`
  font-size: 12px;
  color: #6b7280;
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
`;

export const RegCardStatus = styled(Box)`
  flex-shrink: 0;
`;

export const StatusChip = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 800;
`;

// ──── SEARCH ────
export const SearchContainer = styled(Box)`
  margin-bottom: 20px;
  background: white;
  border-radius: 12px;
  padding: 16px;
  display: flex;
  gap: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
`;

export const SearchInputWrapper = styled(Box)`
  position: relative;
  display: flex;
  flex: 2;
  align-items: center;
`;

// ──── EXAM GRID ────
export const ExamsGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 16px;

  @media (max-width: 1450px) {
    grid-template-columns: repeat(auto-fill, minmax(310px, 1fr));
  }
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

export const ExamCard = styled.div`
  background: white;
  border: 1.5px solid #e4e8ff;
  border-radius: 18px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(79, 70, 229, 0.08), 0 1px 3px rgba(0, 0, 0, 0.04);
  transition: all 0.25s;
  display: flex;
  flex-direction: column;
  animation: fadeSlide 0.4s ease both;
  opacity: 0;

  @keyframes fadeSlide {
    from {
      opacity: 0;
      transform: translateY(8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  &.visible {
    animation: fadeSlide 0.4s ease both;
    opacity: 1;
  }

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 16px 56px rgba(79, 70, 229, 0.18);
    border-color: rgba(124, 58, 237, 0.25);
  }

  ${({ $registered }) =>
    $registered &&
    `
    border-color: #059669;
  `}

  ${({ $notEligible }) =>
    $notEligible &&
    `
    opacity: 0.7;
    &:hover {
      transform: none;
      box-shadow: 0 2px 12px rgba(79, 70, 229, 0.08), 0 1px 3px rgba(0, 0, 0, 0.04);
    }
  `}
`;

export const CardHeader = styled.div`
  // height: 100px;
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: flex-end;
  padding: 16px;
  background: ${({ $type }) => {
    switch ($type) {
      case 1:
        return "linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)";
      case 2:
        return "linear-gradient(135deg, #0891b2 0%, #06b6d4 100%)";
      case 3:
        return "linear-gradient(135deg, #d97706 0%, #f59e0b 100%)";
      case 4:
        return "linear-gradient(135deg, #059669 0%, #10b981 100%)";
      default:
        return "linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)";
    }
  }};

  &::before {
    content: "";
    position: absolute;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.08);
    top: -50px;
    right: -30px;
  }

  &::after {
    content: "";
    position: absolute;
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.06);
    bottom: -25px;
    right: 70px;
  }
`;

export const CardHeaderIcon = styled.div`
  width: 52px;
  height: 52px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.22);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: relative;
  z-index: 1;
`;

export const CardHeaderLabels = styled.div`
  // position: absolute;
  // top: 12px;
  // right: 14px;
  // z-index: 1;
  // display: flex;
  // flex-direction: column;
  // align-items: flex-end;
  // gap: 5px;
  position: absolute;
  top: 20px;
  right: 14px;
  z-index: 1;
  display: flex;
  /* flex-direction: column; */
  align-items: flex-end;
  gap: 5px;
  max-width: calc(100% - 100px);
  flex-wrap: wrap;
  justify-content: flex-end;
`;

export const CardHeaderPill = styled.div`
  background: rgba(255, 255, 255, 0.2);
  color: white;
  font-size: 10px;
  font-weight: 800;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  padding: 4px 10px;
  border-radius: 20px;
  white-space: nowrap;
`;

export const ExamCardBody = styled(Box)`
  padding: 16px 20px 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
`;

export const ExamTopRow = styled(Box)`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 10px;
`;

export const ExamTypeIcon = styled(Box)`
  width: 42px;
  height: 42px;
  border-radius: 11px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 19px;
  flex-shrink: 0;
  background: ${({ $type }) => {
    switch ($type) {
      case EXAM_TYPES.HSG:
        return "#ede9fe";
      case EXAM_TYPES.OLYMPIC:
        return "#cffafe";
      case EXAM_TYPES.TRANG_NGUYEN:
        return "#fef3c7";
        case EXAM_TYPES.TOT_NGHIEP:
        return "#d1fae5";
      default:
        return "#ede9fe";
    }
  }};
`;

export const ExamBadgesWrap = styled(Box)`
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  justify-content: flex-end;
`;

export const ExamBadge = styled.span`
  font-size: 10px;
  font-weight: 800;
  padding: 2px 8px;
  border-radius: 20px;
  white-space: nowrap;
  display: inline-block;
`;

// ──── INFO CHIPS ────
export const InfoChipsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 7px;
  margin-bottom: 14px;
`;

export const InfoChip = styled.div`
  background: #f7f8ff;
  border: 1px solid #e4e8ff;
  border-radius: 10px;
  padding: 7px 10px;
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
`;

export const InfoChipIcon = styled.div`
  width: 26px;
  height: 26px;
  border-radius: 7px;
  background: #ede9fe;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
`;

export const InfoChipContent = styled.div`
  flex: 1;
  min-width: 0;
`;

export const InfoChipLabel = styled.div`
  font-size: 9.5px;
  font-weight: 700;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.4px;
  line-height: 1;
  margin-bottom: 3px;
`;

export const InfoChipValue = styled.div`
  font-size: 12px;
  font-weight: 800;
  color: #1e1b4b;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 1.2;
`;

export const ExamName = styled.div`
  font-size: 21px;
  font-weight: 800;
  color: #1e1b4b;
  line-height: 1.3;
  margin-bottom: 12px;
  display: -webkit-box;
  // -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

export const ExamInfoList = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-bottom: 14px;
`;

export const ExamInfoRow = styled(Box)`
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: #6b7280;

  strong {
    color: #4338ca;
    font-weight: 700;
  }
`;

export const EligIndicator = styled(Box)`
  border-radius: 8px;
  padding: 10px 13px;
  margin-bottom: 14px;
  display: flex;
  align-items: center;
  gap: 9px;
  font-size: 12px;
  font-weight: 700;
  background: ${({ $variant }) => {
    switch ($variant) {
      case "ok":
        return "#d1fae5";
      case "warn":
        return "#fef3c7";
      case "no":
        return "#ffe4e6";
      case "og":
        return "#ffedd5";
      case "done":
        return "#d1fae5";
      case "conflict":
        return "#fff7ed";
      default:
        return "#d1fae5";
    }
  }};
  color: ${({ $variant }) => {
    switch ($variant) {
      case "ok":
        return "#059669";
      case "warn":
        return "#d97706";
      case "no":
        return "#e11d48";
      case "og":
        return "#ea580c";
      case "done":
        return "#059669";
      case "conflict":
        return "#c2410c";
      default:
        return "#059669";
    }
  }};
  ${({ $variant }) =>
    $variant === "conflict" &&
    `
    border: 1px solid #fed7aa;
  `}
`;

export const DeadlineBar = styled(Box)`
  margin-bottom: 14px;
`;

export const DeadlineRow = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 5px;
`;

export const DeadlineLabel = styled.div`
  font-size: 11px;
  font-weight: 700;
  color: #9ca3af;
`;

export const DeadlineDays = styled.div`
  font-size: 11px;
  font-weight: 800;
  color: ${({ $color }) => $color || "#059669"};
`;

export const DeadlineTrack = styled(Box)`
  height: 5px;
  background: #e4e8ff;
  border-radius: 3px;
  overflow: hidden;
`;

export const DeadlineFill = styled(Box)`
  height: 100%;
  border-radius: 3px;
  transition: width 0.5s;
  background: ${({ $color }) => $color || "#059669"};
  width: ${({ $width }) => $width || 0}%;
`;

export const SlotBar = styled(Box)`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
`;

export const SlotTrack = styled(Box)`
  flex: 1;
  height: 6px;
  background: #e4e8ff;
  border-radius: 3px;
  overflow: hidden;
`;

export const SlotFill = styled(Box)`
  height: 100%;
  border-radius: 3px;
  background: ${({ $color }) => $color || "#7c3aed"};
  width: ${({ $width }) => $width || 0}%;
`;

export const SlotLabel = styled.div`
  font-size: 11px;
  font-weight: 700;
  color: ${({ $color }) => $color || "#9ca3af"};
  white-space: nowrap;
`;

// ──── DEADLINE CHIP ────
export const DeadlineChip = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  background: ${({ $color }) => `${$color}12`};
  border: 1px solid ${({ $color }) => `${$color}28`};
  border-radius: 10px;
  padding: 9px 13px;
  margin-bottom: 12px;
`;

export const DeadlineChipText = styled.div`
  flex: 1;
  font-size: 12.5px;
  font-weight: 800;
  color: ${({ $color }) => $color};
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
`;

export const DeadlineChipBar = styled.div`
  width: 56px;
  height: 5px;
  background: ${({ $color }) => `${$color}20`};
  border-radius: 3px;
  overflow: hidden;
  flex-shrink: 0;
`;

export const DeadlineChipFill = styled.div`
  height: 100%;
  width: ${({ $width }) => $width || 0}%;
  background: ${({ $color }) => $color};
  border-radius: 3px;
  transition: width 0.5s;
`;

export const ExamFooter = styled(Box)`
  margin-top: auto;
`;

export const RegisterButton = styled.button`
  width: 100%;
  padding: 13px 16px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  font-size: 15px;
  font-weight: 800;
  font-family: inherit;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  letter-spacing: 0.2px;

  ${({ $variant }) => {
    switch ($variant) {
      case "active":
        return `
          background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
          color: white;
          box-shadow: 0 4px 16px rgba(124, 58, 237, 0.4);
          &:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 22px rgba(124, 58, 237, 0.5);
          }
          &:active {
            transform: translateY(0);
          }
        `;
      case "og":
        return `
          background: linear-gradient(135deg, #d97706, #f59e0b);
          color: white;
          box-shadow: 0 4px 14px rgba(217, 119, 6, 0.35);
          &:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(217, 119, 6, 0.45);
          }
        `;
      case "done":
        return `
          background: #d1fae5;
          color: #059669;
          cursor: default;
        `;
      case "no":
        return `
          background: #f3f4f6;
          color: #9ca3af;
          cursor: not-allowed;
        `;
      case "full":
        return `
          background: #ffe4e6;
          color: #e11d48;
          cursor: not-allowed;
        `;
      default:
        return "";
    }
  }}
`;

// ──── TABS ────
export const TabRow = styled(Box)`
  display: flex;
  gap: 6px;
  margin-bottom: 20px;
  flex-wrap: wrap;
`;

export const TabPill = styled(Button)`
  padding: 7px 16px;
  border-radius: 20px;
  border: 1.5px solid #e4e8ff;
  background: white;
  font-size: 13px;
  font-weight: 700;
  color: #6b7280;
  text-transform: none;
  transition: all 0.15s;
  min-width: auto;

  &:hover {
    border-color: #7c3aed;
    color: #7c3aed;
    background: white;
  }

  ${({ $active }) =>
    $active &&
    `
    background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
    color: white;
    border-color: transparent;
    box-shadow: 0 3px 12px rgba(124, 58, 237, 0.3);
    &:hover {
      background: linear-gradient(135deg, #6d28d9 0%, #4338ca 100%);
      color: white;
    }
  `}
`;

export const TabCount = styled.span`
  font-size: 10px;
  font-weight: 800;
  padding: 1px 6px;
  border-radius: 10px;
  background: ${({ $active }) =>
    $active ? "rgba(255,255,255,0.25)" : "#ede9fe"};
  color: ${({ $active }) => ($active ? "white" : "#7c3aed")};
`;

// ──── EMPTY ────
export const EmptyExams = styled(Box)`
  text-align: center;
  padding: 60px 20px;
  grid-column: 1/-1;
`;

export const EmptyIcon = styled.div`
  font-size: 52px;
  margin-bottom: 12px;
  opacity: 0.3;
`;

export const EmptyTitle = styled.div`
  font-size: 16px;
  font-weight: 800;
  color: #6b7280;
  margin-bottom: 5px;
`;

export const EmptySub = styled.div`
  font-size: 13px;
  color: #9ca3af;
`;

// ──── MODAL ────
export const ModalOverlay = styled(Backdrop)`
  z-index: 400;
  background: rgba(30, 27, 75, 0.55);
  backdrop-filter: blur(6px);
`;

export const ModalStyled = styled(Dialog)`
  .MuiDialog-paper {
    border-radius: 20px;
    padding: 0;
    width: 100%;
    max-width: 480px;
    box-shadow: 0 16px 56px rgba(79, 70, 229, 0.18);
    overflow: hidden;
    animation: popIn 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
  }

  @keyframes popIn {
    from {
      transform: scale(0.86);
      opacity: 0;
    }
    to {
      transform: scale(1);
      opacity: 1;
    }
  }
`;

export const ModalHero = styled(Box)`
  padding: 28px 28px 22px;
  position: relative;
  // overflow: hidden;
  display: flex;
  flex-direction: column;
  background: ${({ $bgColor }) =>
    $bgColor || "linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)"};

  &::before {
    content: "";
    position: absolute;
    inset: 0;
    opacity: 0.08;
    background-image: radial-gradient(
      circle at 80% 20%,
      white 1px,
      transparent 1px
    );
    background-size: 24px 24px;
  }
`;

export const ModalHeroIcon = styled(Box)`
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
  margin-bottom: 14px;
  position: relative;
  z-index: 1;
  background: rgba(255, 255, 255, 0.2);
  flex-shrink: 0;
`;

export const ModalHeroTitle = styled.div`
  font-size: 22px;
  font-weight: 800;
  color: white;
  margin-bottom: 4px;
  position: relative;
  z-index: 1;
  line-height: 1.3;
  word-wrap: break-word;
  overflow-wrap: break-word;
  white-space: normal;
`;

export const ModalHeroSub = styled.div`
  font-size: 13px;
  color: rgba(255, 255, 255, 0.75);
  position: relative;
  z-index: 1;
  line-height: 1.5;
  word-wrap: break-word;
  overflow-wrap: break-word;
  white-space: normal;
`;

export const ModalBody = styled(Box)`
  padding: 22px 28px;
  overflow-y: auto;
`;

export const ModalInfoGrid = styled(Box)`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-bottom: 18px;
`;

export const ModalInfoCell = styled(Box)`
  background: ${VPB_THEMES.colors.shade || "#f7f8ff"};
  border-radius: 9px;
  padding: 11px 13px;
`;

export const ModalInfoLabel = styled.div`
  font-size: 10px;
  font-weight: 800;
  color: #9ca3af;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 4px;
`;

export const ModalInfoVal = styled.div`
  font-size: 14px;
  font-weight: 800;
  color: #1e1b4b;
`;

export const OvergradeWarning = styled(Box)`
  background: #fffbeb;
  border: 1.5px solid #fde68a;
  border-radius: 10px;
  padding: 13px 15px;
  margin-bottom: 16px;
  display: flex;
  gap: 10px;
  align-items: flex-start;
`;

export const OvergradeWarningText = styled.div`
  font-size: 13px;
  color: #78350f;
  line-height: 1.6;

  strong {
    color: #d97706;
  }
`;

export const ConfirmCheck = styled(Box)`
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 18px;
  padding: 12px 14px;
  background: #ede9fe;
  border-radius: 9px;
`;

export const ModalFooter = styled(Box)`
  padding: 16px 28px 22px;
  display: flex;
  gap: 10px;
`;

export const CancelModalButton = styled(Button)`
  flex: 1;
  padding: 12px;
  border-radius: 10px;
  border: 1.5px solid ${VPB_THEMES.colors.border || "#e4e8ff"};
  background: white;
  font-size: 14px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.text3 || "#6b7280"};
  text-transform: none;
  cursor: pointer;
  transition: all 0.15s;
  box-shadow: none;

  &:hover {
    background: ${VPB_THEMES.colors.surface2 || "#f7f8ff"};
    box-shadow: none;
  }

  &:active {
    transform: scale(0.98);
  }
`;

export const ConfirmModalButton = styled(Button)`
  flex: 2;
  padding: 12px;
  border-radius: 10px;
  border: none;
  font-size: 14px;
  font-weight: 800;
  color: white !important;
  text-transform: none;
  background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 2px 8px rgba(124, 58, 237, 0.3);

  &:hover {
    transform: translateY(-1px);
    background: linear-gradient(135deg, #6d28d9 0%, #4338ca 100%);
    box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4);
  }

  &:active {
    transform: translateY(0);
  }

  &:disabled {
    opacity: 0.45;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`;

// ──── SUCCESS SPLASH ────
export const SuccessSplash = styled(Backdrop)`
  z-index: 500;
  background: rgba(30, 27, 75, 0.6);
  backdrop-filter: blur(8px);
`;

export const SplashBox = styled(Paper)`
  border-radius: 24px;
  padding: 40px 36px;
  text-align: center;
  max-width: 380px;
  width: 100%;
  box-shadow: 0 16px 56px rgba(79, 70, 229, 0.18);
  position: relative;
  overflow: hidden;
  animation: popIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
`;

export const SplashEmoji = styled.div`
  font-size: 64px;
  line-height: 1;
  margin-bottom: 16px;
  animation: bounce 0.6s ease 0.3s both;

  @keyframes bounce {
    0%,
    100% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(-12px);
    }
  }
`;

export const SplashTitle = styled.div`
  font-size: 24px;
  font-weight: 800;
  color: #1e1b4b;
  margin-bottom: 8px;
`;

export const SplashSub = styled.div`
  font-size: 14px;
  color: #6b7280;
  line-height: 1.6;
  margin-bottom: 24px;
`;

export const SplashButton = styled(Button)`
  width: 100%;
  padding: 13px;
  border-radius: 12px;
  border: none;
  background: linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%);
  color: white !important;
  font-size: 15px;
  font-weight: 800;
  box-shadow: 0 4px 16px rgba(124, 58, 237, 0.4);
  text-transform: none;

  &:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, #6d28d9 0%, #4338ca 100%);
  }
`;

export const ConfettiWrap = styled(Box)`
  position: absolute;
  inset: 0;
  pointer-events: none;
  overflow: hidden;
`;

export const ConfettiParticle = styled.div`
  position: absolute;
  width: ${({ $size }) => $size || 8}px;
  height: ${({ $size }) => $size || 8}px;
  border-radius: 2px;
  background: ${({ $color }) => $color || "#7c3aed"};
  left: ${({ $left }) => $left || 0}%;
  top: ${({ $top }) => $top || 0}%;
  animation: confettiFall ${({ $duration }) => $duration || 1.2}s ease-out
    ${({ $delay }) => $delay || 0}s both;

  @keyframes confettiFall {
    0% {
      transform: translateY(-20px) rotate(0deg);
      opacity: 1;
    }
    100% {
      transform: translateY(300px) rotate(720deg);
      opacity: 0;
    }
  }
`;
