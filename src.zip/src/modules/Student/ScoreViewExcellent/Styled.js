import styled from "styled-components";

export const InfoStudentStyled = styled.div`
  background: linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%);
  border-radius: 20px;
  padding: 28px 32px;
  position: relative;
  overflow: hidden;
  box-shadow: var(--shadow-lg);
  width: 100%;
  display: flex;
  gap: 28px;
  align-items: center;

  @media (max-width: 900px) {
    flex-wrap: wrap;
    padding: 22px 20px;
    gap: 18px;
  }

  @media (max-width: 600px) {
    flex-direction: column;
    align-items: flex-start;
    border-radius: 16px;
    padding: 18px 16px;
    gap: 14px;
  }
`;

export const DotInfoStudent = styled.div`
  position: absolute;
  inset: 0;
  pointer-events: none;
  background-image:
    radial-gradient(circle, rgba(255, 255, 255, 0.25) 1px, transparent 1px),
    radial-gradient(circle, rgba(255, 255, 255, 0.15) 1px, transparent 1px);
  background-size:
    40px 40px,
    23px 23px;
  background-position:
    0 0,
    12px 12px;
`;

export const IconCup = styled.div`
  font-size: 64px;
  line-height: 1;
  filter: drop-shadow(0 4px 16px rgba(251, 191, 36, 0.6));
  flex-shrink: 0;

  @media (max-width: 600px) {
    font-size: 48px;
  }
`;

export const OverviewStyled = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px;

  @media (max-width: 600px) {
    grid-template-columns: 1fr;
  }
`;

export const FilterRow = styled.div`
  display: flex;
  gap: 8px;
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  border-bottom: 1px solid #e4e8ff;
  padding: 12px 20px;

  @media (max-width: 600px) {
    padding: 12px 12px;
  }

  /* Scrollbar: cố gắng mỏng nhất + tuỳ OS/browser */
  scrollbar-width: thin; /* Firefox */
  scrollbar-color: #c7d2fe transparent;

  &::-webkit-scrollbar {
    height: 1px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #c7d2fe;
    border-radius: 999px;
  }
`;

// ── DASHBOARD WIDGETS ──
export const WidgetGrid = styled.div`
  display: grid;
  gap: 14px;
  width: 400px;
  height: max-content;
  position: sticky;
  top: 0;
  margin: 0;

  @media (max-width: 1400px) {
    width: 300px;
  }

  @media (max-width: 768px) {
    max-width: 100%;
    width: 100%;
    position: relative;
    top: unset;
  }
`;

export const WidgetCard = styled.div`
  background: #ffffff;
  border-radius: 16px;
  border: 1.5px solid #e4e8ff;
  box-shadow:
    0 10px 30px rgba(79, 70, 229, 0.08),
    0 2px 10px rgba(0, 0, 0, 0.04);
  overflow: hidden;
  height: max-content;
`;

export const WidgetHeader = styled.div`
  padding: 14px 18px;
  border-bottom: 1px solid #eef2ff;
  background: linear-gradient(180deg, #ffffff 0%, #fbfbff 100%);

  @media (max-width: 600px) {
    padding: 12px 14px;
  }
`;

export const WidgetTitle = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 800;
  font-size: 16px;
  color: #111827;

  svg {
    width: 18px;
    height: 18px;
    color: #7c3aed;
  }
`;

export const WidgetBody = styled.div`
  padding: 14px 18px;

  @media (max-width: 600px) {
    padding: 12px 14px;
  }
`;

export const SubjectRow = styled.div`
  display: grid;
  grid-template-columns: 64px minmax(0, 1fr) 44px;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
`;

export const SubjectName = styled.div`
  font-weight: 800;
  color: #4f46e5;
`;

export const SubjectBarTrack = styled.div`
  height: 10px;
  border-radius: 999px;
  background: #eef2ff;
  overflow: hidden;
`;

export const SubjectBarFill = styled.div`
  height: 100%;
  border-radius: 999px;
`;

export const SubjectScore = styled.div`
  font-weight: 900;
  text-align: right;
  color: #111827;
`;

export const TrendBars = styled.div`
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 12px;
  align-items: end;
`;

export const TrendBar = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;

  .value {
    font-size: 12px;
    font-weight: 800;
    color: #6b7280;
  }

  .barTrack {
    width: 100%;
    height: 90px;
    border-radius: 10px;
    background: #eef2ff;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: flex-end;
  }

  .barFill {
    width: 100%;
    border-radius: 10px;
  }

  .label {
    font-size: 11px;
    font-weight: 700;
    color: #9ca3af;
  }
`;

export const TrendHint = styled.div`
  margin-top: 10px;
  text-align: center;
  font-size: 12px;
  color: #9ca3af;
  font-weight: 600;
`;

export const UpcomingList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const UpcomingItem = styled.div`
  display: grid;
  gap: 8px;
  align-items: center;
  padding: 12px 12px;
  border-radius: 14px;
  background: #f8fafc;
  border: 1px solid #eef2ff;
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 6px;
    background: linear-gradient(180deg, #7c3aed 0%, #4f46e5 100%);
  }

  @media (max-width: 420px) {
    gap: 8px;
  }
`;

export const UpcomingDate = styled.div`
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
    "Liberation Mono", "Courier New", monospace;
  font-weight: 900;
  color: #6b7280;
  padding-left: 8px;
`;

export const UpcomingInfo = styled.div`
  min-width: 0;
  padding-left: 6px;
`;

export const UpcomingTitle = styled.div`
  font-weight: 900;
  color: #111827;
  line-height: 1.25;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
`;

export const UpcomingStatus = styled.div`
  margin-top: 6px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 800;
  white-space: nowrap;
  width: max-content;

  ${({ $type }) => {
    if ($type === "success") {
      return `
        background: #dcfce7;
        color: #166534;
      `;
    }
    if ($type === "warning") {
      return `
        background: #fef3c7;
        color: #92400e;
      `;
    }
    return `
      background: #eef2ff;
      color: #3730a3;
    `;
  }}
`;

export const ListExcellentRegisterStyled = styled.div`
  background: white;
  border-radius: 16px;
  min-height: 60vh;
  flex: 1;
  border: 1.5px solid #e4e8ff;
  box-shadow:
    0 2px 12px rgba(79, 70, 229, 0.08),
    0 1px 3px rgba(0, 0, 0, 0.04);
  overflow: hidden;

  @media (max-width: 600px) {
    border-radius: 14px;
    min-height: 500px;
  }
`;

export const DotListExellent = styled.div`
  width: 14px;
  height: 14px;
  border-radius: 50%;
  border: 2.5px solid white;
  box-shadow: 0 0 0 2px currentColor;
  flex-shrink: 0;
  color: #f59e0b;
  background: #f59e0b;
  margin-top: 5px !important;
  position: relative;

  &::before {
    content: "";
    height: calc(100% - 56px);
    width: 2px;
    position: absolute;
    top: 40px;
    background: #e4e8ff;
    left: 21px;
  }
`;

export const ProcessScoreExellent = styled.div`
  height: 6px;
  background: #e4e8ff;
  border-radius: 3px;
  position: relative;
  margin-top: 14px;

  &::before {
    content: "";
    height: 100%;
    width: ${({ $score }) => ($score / 10) * 100}%;
    position: absolute;
    top: 0;
    background: ${({ $score }) => {
      if ($score > 8.5) return "#059669";
      if ($score > 7) return "#4f46e5";
      return "#d97706";
    }};
    left: 0;
    border-radius: 3px;
  }
`;

export const ScoreExellent = styled.div`
  gap: 8px;
  display: flex;
  height: max-content;
  align-items: flex-end;
`;

// ── MODAL VIEW EXCELLENT STYLES ──
export const ModalHeader = styled.div`
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  padding: 28px 32px;
  border-radius: 16px 16px 0 0;
  display: flex;
  align-items: center;
  gap: 20px;
  position: relative;

  @media (max-width: 600px) {
    padding: 20px 16px;
    gap: 16px;
  }
`;

export const ModalIcon = styled.div`
  width: 56px;
  height: 56px;
  background: rgba(255, 255, 255, 0.25);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  flex-shrink: 0;
  backdrop-filter: blur(10px);
`;

export const ModalTitleWrapper = styled.div`
  color: white;
  flex: 1;

  h3 {
    margin: 0;
    font-size: 18px;
    font-weight: 600;
    line-height: 1.3;
  }

  p {
    margin: 4px 0 0 0;
    font-size: 13px;
    opacity: 0.9;
  }
`;

export const CloseButton = styled.button`
  position: absolute;
  right: 16px;
  top: 16px;
  min-width: auto;
  width: 32px;
  height: 32px;
  padding: 0;
  color: white;
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: background 0.2s ease;

  &:hover {
    background: rgba(255, 255, 255, 0.1);
  }
`;

export const ScoreSection = styled.div`
  background: ${({ $success }) => ($success ? "#f0fdf4" : "#f0fafd")};
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
  border: none;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
  display: flex;
  align-items: center;
  gap: 24px;

  @media (max-width: 600px) {
    padding: 16px;
    gap: 16px;
  }
`;

export const ScoreLabel = styled.div`
  font-size: 13px;
  font-weight: 600;
  color: #6b7280;
  letter-spacing: 0.02em;
`;

export const ScoreDisplay = styled.div`
  display: flex;
  align-items: baseline;
  gap: 4px;

  .score-number {
    font-size: 48px;
    font-weight: 700;
    color: #059669;
    line-height: 1;
    letter-spacing: -0.04em;
  }

  .score-divider {
    font-size: 20px;
    color: #d1d5db;
    font-weight: 300;
  }

  .score-max {
    font-size: 20px;
    font-weight: 600;
    color: #6b7280;
    letter-spacing: -0.02em;
  }
`;

export const AwardInfo = styled.div`
  flex: 1;
`;

export const AwardTitle = styled.div`
  font-size: 18px;
  font-weight: 700;
  color: #059669;
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;

  svg {
    width: 24px;
    height: 24px;
  }
`;

export const AwardRank = styled.div`
  font-size: 14px;
  color: #6b7280;
  margin-bottom: 8px;
`;

export const CongratulationBadge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: ${({ $success }) => ($success ? "#dcfce7" : "#fce1dc")};
  color: ${({ $success }) => ($success ? "#059669" : "#961305")};
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;

  svg {
    width: 16px;
    height: 16px;
  }
`;

export const DetailsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 16px;
  margin-bottom: 24px;

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
  }
`;

export const DetailItem = styled.div`
  padding: 16px;
  border-radius: 8px;
  background: #f9fafb;
  border: 1px solid #e5e7eb;

  @media (max-width: 600px) {
    padding: 12px;
  }
`;

export const DetailLabel = styled.div`
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  color: #9ca3af;
  margin-bottom: 4px;
  letter-spacing: 0.5px;
`;

export const DetailValue = styled.div`
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
`;

export const ShareButton = styled.button`
  width: 100%;
  padding: 14px 20px;
  background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
  color: white;
  font-weight: 600;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  text-transform: none;
  font-size: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  transition: all 0.2s ease;

  &:hover {
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
  }

  &:active {
    transform: scale(0.98);
  }

  svg {
    width: 20px;
    height: 20px;
  }
`;

export const ModalContent = styled.div`
  padding: 28px;
  background: white;
  border-radius: 0 0 16px 16px;

  @media (max-width: 600px) {
    padding: 16px;
  }
`;
