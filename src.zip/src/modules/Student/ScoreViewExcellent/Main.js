import { Stack } from "@mui/material";
import {
  getExamPeriodCategoryAction,
} from "App/store/actions";
import { useEffect } from "react";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import DashboardWidgets from "./components/DashboardWidgets";
import InfoStudent from "./components/InfoStudent";
import ListExcellentRegister from "./components/ListExcellentRegister";
import Overview from "./components/Overview";
import {
  fetchMyRegistrationsAction,
  fetchStudentInfoAction,
} from "./store/actions";
import { key } from "./store/constants";

const Main = () => {
  const fetchMyRegistrations = useDispatchRedux(fetchMyRegistrationsAction);
  const fetchStudentInfo = useDispatchRedux(fetchStudentInfoAction);
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  const summary = useOneState(key, "summary", []);

  useEffect(() => {
    fetchStudentInfo();
    fetchExamPeriodCategory();
    fetchMyRegistrations();
  }, []);

  return (
    <Stack spacing={2}>
      <InfoStudent summary={summary} />
      <Overview summary={summary} />
      <Stack direction="row" sx={{ flexWrap: "wrap", gap: 2 }}>
        <ListExcellentRegister />
        <DashboardWidgets />
      </Stack>
      
    </Stack>
  );
};

export default Main;
