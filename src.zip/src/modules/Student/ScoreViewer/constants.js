// Score grade thresholds
export const SCORE_THRESHOLDS = {
  EXCELLENT: 8.5,
  GOOD: 7.0,
  AVERAGE: 5.5,
  POOR: 0,
};

// Academic rank labels
export const ACADEMIC_RANKS = {
  EXCELLENT: "Xuất sắc",
  GOOD: "Giỏi",
  AVERAGE: "Khá",
  POOR: "Trung bình",
  FAIL: "Yếu",
};

// Score type mapping
export const getScoreType = (score) => {
  if (!score || score === "-") return "default";
  const numScore = parseFloat(score);
  if (numScore >= SCORE_THRESHOLDS.EXCELLENT) return "excellent";
  if (numScore >= SCORE_THRESHOLDS.GOOD) return "good";
  if (numScore >= SCORE_THRESHOLDS.AVERAGE) return "average";
  return "poor";
};

// Get academic rank from GPA
export const getAcademicRank = (gpa) => {
  if (gpa >= 9.0) return ACADEMIC_RANKS.EXCELLENT;
  if (gpa >= 8.0) return ACADEMIC_RANKS.GOOD;
  if (gpa >= 6.5) return ACADEMIC_RANKS.AVERAGE;
  if (gpa >= 5.0) return ACADEMIC_RANKS.POOR;
  return ACADEMIC_RANKS.FAIL;
};

// Get academic level from GPA
export const getAcademicLevel = (gpa) => {
  if (gpa >= 8.0) return "Giỏi";
  if (gpa >= 6.5) return "Khá";
  if (gpa >= 5.0) return "Trung bình";
  return "Yếu";
};

// Default score columns
export const DEFAULT_SCORE_COLUMNS = [
  { key: "midterm", label: "Giữa kỳ" },
  { key: "final", label: "Cuối kỳ" },
];

// Semester options
export const SEMESTER_OPTIONS = [
  { value: "1", label: "Học kỳ 1" },
  { value: "2", label: "Học kỳ 2" },
];

