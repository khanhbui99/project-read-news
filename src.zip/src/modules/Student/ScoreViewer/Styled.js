import { Box } from "@mui/material";
import { Text, Title } from "components/Styled";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled.div`
  display: flex;
  flex-direction: column;
  gap: 24px;
  padding: 24px;

  @media (max-width: 768px) {
    gap: 16px;
    padding: 16px;
  }

  @media (max-width: 480px) {
    gap: 12px;
    padding: 12px;
  }
`;

export const InfoCard = styled(Box)`
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.white} 0%,
    ${VPB_THEMES.colors.gray[100]} 50%,
    ${VPB_THEMES.colors.white} 100%
  );
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 4px;
    height: 100%;
    background: linear-gradient(
      180deg,
      ${VPB_THEMES.colors.blue} 0%,
      ${VPB_THEMES.colors.lightBlue} 100%
    );
  }

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
    border-color: ${VPB_THEMES.colors.gray[300]};
  }
`;

export const InfoCardTitle = styled(Title)`
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 8px;

  &::before {
    content: "";
    width: 4px;
    height: 20px;
    background: ${VPB_THEMES.colors.blue};
    border-radius: 2px;
  }
`;

export const InfoCardGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;

  @media (max-width: 768px) {
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
  }

  @media (max-width: 480px) {
    grid-template-columns: 1fr;
  }
`;

export const InfoCardItem = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 20px;
  background: ${VPB_THEMES.colors.white};
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.table.borderMedium};
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;

  &::after {
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    width: 60px;
    height: 60px;
    background: ${({ $color }) =>
      $color ? `${$color}15` : `${VPB_THEMES.colors.blue}15`};
    border-radius: 50%;
    transform: translate(30%, -30%);
  }

  &:hover {
    border-color: ${({ $color }) => $color || VPB_THEMES.colors.blue};
    box-shadow: 0 4px 12px
      ${({ $color }) =>
        $color ? `${$color}25` : `${VPB_THEMES.colors.blue}25`};
    transform: translateY(-2px);
  }
`;

export const InfoCardItemIcon = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: ${({ $color }) =>
    $color ? `${$color}15` : `${VPB_THEMES.colors.blue}15`};
  color: ${({ $color }) => $color || VPB_THEMES.colors.blue};
  flex-shrink: 0;
  margin-bottom: 8px;

  svg {
    font-size: 24px;
  }
`;

export const InfoCardItemLabel = styled(Text)`
  margin-bottom: 4px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: ${VPB_THEMES.colors.secondaryText};
`;

export const InfoCardItemValue = styled(Title)`
  line-height: 1.4;
  color: ${({ $color }) => $color || VPB_THEMES.colors.darkBlue};
`;

export const ScoreContainer = styled(Box)`
  background: ${VPB_THEMES.colors.white};
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  position: relative;
  overflow: hidden;
`;

export const FilterBar = styled.div`
  margin-bottom: 24px;
  padding: 16px 20px;
  background: ${VPB_THEMES.colors.shade || "#F2F4F8"};
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  display: flex;
  align-items: flex-end;
  gap: 16px;

  @media (max-width: 768px) {
    display: grid;
    flex-wrap: wrap;
  }
`;

export const FilterGroup = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;

  @media (max-width: 768px) {
    width: 100%;
    justify-content: space-between;
  }
`;

export const FilterLabel = styled(Text)`
  font-weight: 600;
  color: ${VPB_THEMES.colors.darkBlue};
  white-space: nowrap;
`;

export const ScoreTableWrapper = styled.div`
  overflow-x: auto;
  width: 100%;
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
`;

export const ScoreTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  min-width: 900px;
  background: ${VPB_THEMES.colors.white};
`;

export const ScoreTableHeader = styled.thead`
  background: ${VPB_THEMES.colors.table.headerBg || "#F2F4F8"};
  position: sticky;
  top: 0;
  z-index: 10;
`;

export const ScoreTableHeaderCell = styled.th`
  padding: 16px;
  text-align: center;
  font-weight: 700;
  color: ${VPB_THEMES.colors.darkBlue};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  background: ${VPB_THEMES.colors.table.headerBg || "#F2F4F8"};
  position: relative;
  white-space: nowrap;

  &:first-child {
    text-align: left;
    position: sticky;
    left: 0;
    background: ${VPB_THEMES.colors.table.headerBg || "#F2F4F8"};
    z-index: 11;
    min-width: 200px;
  }
`;

export const ScoreTableBody = styled.tbody``;

export const ScoreTableRow = styled.tr`
  border-bottom: 1px solid ${VPB_THEMES.colors.table.borderLight};
  transition: background-color 0.2s;

  &:hover {
    background-color: ${VPB_THEMES.colors.gray[100]};
  }

  &:last-child {
    border-bottom: none;
  }
`;

export const ScoreTableCell = styled.td`
  padding: 16px;
  text-align: center;
  vertical-align: middle;
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  color: ${VPB_THEMES.colors.darkBlue};

  &:first-child {
    text-align: left;
    position: sticky;
    left: 0;
    background: ${VPB_THEMES.colors.white};
    z-index: 9;
    font-weight: 600;
    min-width: 200px;
  }

  ${ScoreTableRow}:hover &:first-child {
    background: ${VPB_THEMES.colors.gray[100]};
  }
`;

export const ScoreBadge = styled.span`
  display: inline-block;
  padding: 6px 12px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 14px;
  background: ${({ $type }) => {
    switch ($type) {
      case "excellent":
        return `${VPB_THEMES.colors.green}20`;
      case "good":
        return `${VPB_THEMES.colors.blue}20`;
      case "average":
        return `${VPB_THEMES.colors.yellow}20`;
      case "poor":
        return `${VPB_THEMES.colors.red}20`;
      default:
        return `${VPB_THEMES.colors.gray[200]}`;
    }
  }};
  color: ${({ $type }) => {
    switch ($type) {
      case "excellent":
        return VPB_THEMES.colors.green;
      case "good":
        return VPB_THEMES.colors.blue;
      case "average":
        return VPB_THEMES.colors.yellow;
      case "poor":
        return VPB_THEMES.colors.red;
      default:
        return VPB_THEMES.colors.darkBlue;
    }
  }};
`;

export const SubjectName = styled.div`
  font-weight: 600;
  color: ${VPB_THEMES.colors.darkBlue};
  margin-bottom: 4px;
`;

export const SubjectCode = styled.div`
  font-size: 12px;
  color: ${VPB_THEMES.colors.secondaryText};
`;

export const EmptyState = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 60px 20px;
  text-align: center;
  color: ${VPB_THEMES.colors.secondaryText};
`;

export const EmptyStateIcon = styled(Box)`
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: ${VPB_THEMES.colors.gray[100]};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;

  svg {
    font-size: 40px;
    color: ${VPB_THEMES.colors.gray[300]};
  }
`;
