import {
  getDetailStudentAction,
  getExamPeriodCategoryAction,
} from "App/store/actions";
import { useEffect } from "react";
import { useOneState, useDispatchRedux } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import FilterBar from "./components/FilterBar";
import Header from "./components/Header";
import InfoCard from "./components/InfoCard";
import ScoreTable from "./components/ScoreTable";
import { key } from "./store/constants";
import { ContainerStyled, ScoreContainer } from "./Styled";

const ScoreViewerMain = () => {
  const fetchDetailStudent = useDispatchRedux(getDetailStudentAction);
  const fetchExamPeriodCategory = useDispatchRedux(getExamPeriodCategoryAction);

  const myScore = useOneState(key, "myScore", []);
  const summaryData = useOneState(key, "summaryData", {});
  const detailStudent = useOneState(injectKey.GLOBAL, "detailStudent", {});
  const examPeriodCategory = useOneState(
    injectKey.GLOBAL,
    "examPeriodCategory",
    {},
  );

  useEffect(() => {
    fetchDetailStudent();
    fetchExamPeriodCategory();
  }, []);

  return (
    <ContainerStyled>
      <Header />

      <InfoCard summaryData={summaryData} />

      <ScoreContainer>
        <FilterBar
          detailStudent={detailStudent}
          semesterOpt={examPeriodCategory?.semesters}
          academicYearOpt={examPeriodCategory?.academicYears}
        />

        <ScoreTable myScore={myScore} />
      </ScoreContainer>
    </ContainerStyled>
  );
};

export default ScoreViewerMain;
