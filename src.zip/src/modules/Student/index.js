// export { default as TimeTableStudent } from "./TimeTable";
export { default as TimeTableStudent } from "../Timeable/Student";
export { default as ScoreViewerStudent } from "./ScoreViewer";
export { default as ExamRoomSchedStudent } from "./ExamRoomSched";
export { default as RegisterExcellentContestStudent } from "./RegisterExcellentContest";
export { default as ScoreViewExcellentStudent } from "./ScoreViewExcellent";
export { default as ScoreAppealExcellentStudent } from "./AppealExcellentScore";
