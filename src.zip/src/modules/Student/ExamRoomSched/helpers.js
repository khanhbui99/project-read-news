import dayjs from "dayjs";

/**
 * Tính end time từ startTime và durationMinutes
 * @param {string} startTime - Thời gian bắt đầu (format: "HH:mm:ss" hoặc "HH:mm")
 * @param {number} durationMinutes - Thời lượng thi (phút)
 * @returns {string} - Thời gian kết thúc (format: "HH:mm")
 */
export const calculateEndTime = (startTime, durationMinutes) => {
  // Xử lý format "HH:mm:ss" hoặc "HH:mm"
  const timeParts = startTime.split(":");
  const hours = parseInt(timeParts[0] || 0, 10);
  const minutes = parseInt(timeParts[1] || 0, 10);
  const start = dayjs().hour(hours).minute(minutes).second(0);
  const end = start.add(durationMinutes || 0, "minute");
  return end.format("HH:mm");
};

/**
 * Format startTime từ "HH:mm:ss" về "HH:mm"
 * @param {string} startTime - Thời gian bắt đầu (format: "HH:mm:ss" hoặc "HH:mm")
 * @returns {string} - Thời gian đã format (format: "HH:mm")
 */
export const formatStartTime = (startTime) => {
  if (!startTime) return "00:00";
  const timeParts = startTime.split(":");
  return `${timeParts[0] || "00"}:${timeParts[1] || "00"}`;
};

/**
 * Chuyển đổi exam schedule data sang format events của FullCalendar
 * @param {Array} examScheduleData - Mảng dữ liệu lịch thi từ API
 * @param {Function} getEventColor - Function trả về màu cho event
 * @returns {Array} - Mảng events cho FullCalendar
 */
export const convertExamToCalendarEvents = (examScheduleData = [], getEventColor) => {
  if (!Array.isArray(examScheduleData) || examScheduleData.length === 0) {
    return [];
  }

  return examScheduleData
    .map((exam) => {
      if (!exam) return null;

      // Format startTime từ "HH:mm:ss" về "HH:mm"
      const formattedStartTime = formatStartTime(exam.startTime);
      const endTime = calculateEndTime(exam.startTime || "00:00:00", exam.durationMinutes || 0);

      // Tạo datetime string cho FullCalendar (format: YYYY-MM-DDTHH:mm:ss)
      const startDateTime = `${exam.examDate}T${formattedStartTime}:00`;
      const endDateTime = `${exam.examDate}T${endTime}:00`;

      // Tạo title với thời gian và môn học
      const roomName = exam.roomName || "";
      const title = `${formattedStartTime} - ${exam.subjectName || ""}${roomName ? ` (${roomName})` : ""}`;

      return {
        id: String(exam.examId || exam.id || Math.random()),
        title: title,
        start: startDateTime,
        end: endDateTime,
        backgroundColor: getEventColor(),
        borderColor: getEventColor(),
        extendedProps: {
          exam: exam,
        },
      };
    })
    .filter(Boolean);
};

