import { Card, Box, Button, Chip } from "@mui/material";
import { Text, Title } from "components/Styled";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

const width = screen.width;

export const ContainerStyled = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 24px;

  @media (max-width: 768px) {
    gap: 16px;
  }

  @media (max-width: 480px) {
    gap: 12px;
  }
`;

export const TabsContainer = styled(Box)`
  display: flex;
  gap: 4px;
  border-bottom: 2px solid #e1e8ed;
  margin-bottom: 24px;
`;

export const TabButton = styled(Button)`
  padding: 14px 28px;
  border: none;
  background: transparent;
  cursor: pointer;
  font-size: 15px;
  font-weight: 600;
  color: ${(props) => (props.$active ? "#0084ff" : "#7f8c8d")};
  transition: all 0.3s;
  border-bottom: 3px solid transparent;
  margin-bottom: -2px;
  text-transform: none;
  min-width: auto;
  border-radius: 0;

  &:hover {
    color: #0084ff;
    background: transparent;
  }

  ${(props) =>
    props.$active &&
    `
    color: #0084ff;
    border-bottom-color: #0084ff;
  `}
`;

export const TabContent = styled(Box)`
  display: ${(props) => (props.$active ? "block" : "none")};
`;

export const CalendarContainer = styled(Card)`
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  padding: 24px;
  margin-top: 24px;

  /* FullCalendar styling */
  .fc {
    font-family: inherit;
  }

  .fc-header-toolbar {
    margin-bottom: 1.5em;
  }

  .fc-button {
    background-color: #f5f7fa;
    border: none;
    color: #2c3e50;
    font-weight: 600;
    text-transform: none;
    border-radius: 6px;
    padding: 8px 16px;
    transition: all 0.3s;

    &:hover {
      background-color: #0084ff;
      color: white;
    }

    &:focus {
      box-shadow: none;
    }

    &.fc-button-active {
      background-color: #0084ff;
      color: white;
    }
  }

  .fc-today-button {
    background-color: #0084ff;
    color: white;
    border: none;

    &:hover {
      background-color: #0066cc;
    }
  }

  .fc-toolbar-title {
    font-size: 24px;
    font-weight: 600;
    color: #2c3e50;
  }

  .fc-col-header-cell {
    background-color: #f5f7fa;
    padding: 12px;
    font-weight: 600;
    color: #2c3e50;
  }

  .fc-daygrid-day {
    border-color: #e1e8ed;
  }

  .fc-day-today {
    background-color: #e3f2fd !important;
  }

  .fc-event {
    border-radius: 4px;
    border: none;
    padding: 4px 8px;
    cursor: pointer;
    font-weight: 500;

    &:hover {
      opacity: 0.9;
      transform: translateY(-1px);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
  }

  .fc-event-title {
    font-weight: 500;
  }

  .fc-daygrid-event {
    margin: 2px 4px;
  }

  .fc-daygrid-day-frame {
    min-height: 100px;
  }
`;

export const CalendarHeaderBox = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
  flex-wrap: wrap;
  gap: 16px;
`;

export const CalendarMonth = styled.div`
  font-size: 24px;
  font-weight: 600;
  color: #2c3e50;
`;

export const CalendarNav = styled(Box)`
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
`;

export const CalendarNavButton = styled(Button)`
  padding: 8px 16px;
  background: #f5f7fa;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.3s;
  font-weight: 600;
  text-transform: none;
  color: #2c3e50;
  min-width: auto;

  &:hover {
    background: #0084ff;
    color: white;
  }
`;

export const CalendarGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 8px;
`;

export const CalendarDayHeader = styled(Box)`
  text-align: center;
  font-weight: 600;
  padding: 12px;
  background: #f5f7fa;
  border-radius: 6px;
  font-size: 14px;
  color: #2c3e50;
`;

export const CalendarDay = styled(Box)`
  min-height: 120px;
  border: 2px solid #e1e8ed;
  border-radius: 8px;
  padding: 8px;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
  display: flex;
  flex-direction: column;
  background: white;

  &:hover {
    border-color: #0084ff;
    background: #f0f7ff;
  }

  ${(props) =>
    props.$isToday &&
    `
    background: #e3f2fd;
    border-color: #0084ff;
  `}

  ${(props) =>
    props.$isOtherMonth &&
    `
    opacity: 0.3;
    background: #fafafa;
  `}
`;

export const CalendarDayNumber = styled.div`
  font-weight: 600;
  margin-bottom: 8px;
  font-size: 14px;
  color: ${(props) => (props.$isToday ? "#0084ff" : "#2c3e50")};
`;

export const CalendarDayEvents = styled(Box)`
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

export const CalendarEventItem = styled(Box)`
  padding: 6px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  background: ${(props) => props.$bgColor || "#0084ff"};
  color: white;
  cursor: pointer;
  transition: all 0.2s;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;

  &:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }
`;

export const EventsList = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 16px;
  margin-top: 24px;
`;

export const EventCard = styled(Card)`
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  border-left: 4px solid ${(props) => props.$borderColor || "#0084ff"};
  transition: all 0.3s;
  cursor: pointer;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
`;

export const EventHeader = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: start;
  margin-bottom: 12px;
  flex-wrap: wrap;
  gap: 12px;
`;

export const EventTitle = styled.div`
  font-weight: 600;
  font-size: 18px;
  margin-bottom: 8px;
  color: #2c3e50;
`;

export const EventDateText = styled.div`
  font-size: 13px;
  color: #7f8c8d;
  margin-top: 4px;
`;

export const EventBadgeStyled = styled(Chip)`
  height: auto;
  font-weight: 600;
  font-size: 12px;
  padding: 4px 12px;
`;

export const EventMeta = styled(Box)`
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
  font-size: 14px;
  color: #7f8c8d;
  margin-top: 12px;
`;

export const EventMetaItem = styled(Box)`
  display: flex;
  align-items: center;
  gap: 6px;
`;

export const EventDescription = styled(Box)`
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #e1e8ed;
  font-size: 14px;
  line-height: 1.6;
  color: #2c3e50;
`;

export const EmptyState = styled(Box)`
  text-align: center;
  padding: 60px 20px;
  color: #7f8c8d;
`;

export const EmptyStateIcon = styled.div`
  font-size: 64px;
  margin-bottom: 16px;
  opacity: 0.5;
`;

export const EmptyStateText = styled.div`
  font-size: 16px;
  font-weight: 500;
`;

// Modal styled components
export const ModalContentWrapper = styled(Box)`
  padding: 4px 0;
  width: ${width / 2}px;
  max-width: 540px;

  @media (max-width: 600px) {
    width: 100%;
    max-width: 100%;
  }
`;

export const ModalHeaderSection = styled(Box)`
  padding: 24px;
  margin: -24px -24px 24px -24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.modal.summaryBg} 0%,
    ${VPB_THEMES.colors.modal.summaryBgEnd} 100%
  );
  border-bottom: 1px solid ${VPB_THEMES.colors.modal.summaryBorder};
`;

export const ModalHeaderContent = styled(Box)`
  display: flex;
  align-items: center;
  gap: 16px;
`;

export const ModalHeaderIcon = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  height: 56px;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.iconBlue};
  box-shadow: 0 2px 8px rgba(0, 132, 255, 0.15);
  font-size: 28px;
`;

export const ModalHeaderText = styled(Box)`
  flex: 1;
`;

export const ModalHeaderSubtitle = styled(Text)`
  font-size: 13px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.modal.infoLabel};
  margin-top: 4px;
`;

export const ModalSection = styled(Box)`
  margin-bottom: 32px;
  padding-bottom: 24px;
  border-bottom: 1px solid ${VPB_THEMES.colors.gray[200]};

  &:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
  }
`;

export const ModalSectionTitle = styled(Text)`
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.modal.sectionTitle};
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
`;

export const ModalSubjectTitle = styled(Title)`
  font-size: 24px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.modal.subjectTitle};
  margin-bottom: 0;
  line-height: 1.4;
`;

export const ModalInfoGrid = styled(Box)`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
  margin-top: 16px;
`;

export const ModalInfoRow = styled(Box)`
  display: flex;
  align-items: flex-start;
  gap: 16px;
  padding: 16px;
  background: ${VPB_THEMES.colors.modal.roomCardBg};
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  transition: all 0.2s;

  &:hover {
    background: ${VPB_THEMES.colors.modal.roomCardHover};
    border-color: ${VPB_THEMES.colors.iconBlue};
    box-shadow: 0 2px 8px rgba(0, 132, 255, 0.1);
  }
`;

export const ModalInfoIcon = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border-radius: 12px;
  background: ${(props) => props.$bgColor || VPB_THEMES.colors.iconBgBlue};
  color: ${(props) => props.$iconColor || VPB_THEMES.colors.iconBlue};
  flex-shrink: 0;
  font-size: 24px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
`;

export const ModalInfoContent = styled(Box)`
  flex: 1;
`;

export const ModalInfoLabel = styled(Text)`
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.modal.infoLabel};
  margin-bottom: 8px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
`;

export const ModalInfoValue = styled(Text)`
  font-size: 16px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.modal.infoValue};
  line-height: 1.5;
`;

export const ModalRoomList = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 12px;
`;

export const ModalRoomCard = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  background: ${VPB_THEMES.colors.modal.roomCardBg};
  border-radius: 14px;
  border: 2px solid ${VPB_THEMES.colors.iconBlue};
  transition: all 0.3s;
  box-shadow: 0 2px 8px rgba(0, 132, 255, 0.1);

  &:hover {
    background: ${VPB_THEMES.colors.modal.roomCardHover};
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 132, 255, 0.2);
  }
`;

export const ModalRoomInfo = styled(Box)`
  display: flex;
  align-items: center;
  gap: 12px;
`;

export const ModalRoomName = styled(Text)`
  font-size: 18px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.modal.subjectTitle};
`;

export const ModalRoomBadge = styled(Chip)`
  height: 36px;
  font-size: 13px;
  font-weight: 700;
  background: ${VPB_THEMES.colors.iconBlue};
  color: ${VPB_THEMES.colors.white};
  border: none;
  padding: 0 16px;
  box-shadow: 0 2px 4px rgba(0, 132, 255, 0.2);
`;

export const ModalSummaryBox = styled(Box)`
  margin-top: 16px;
  padding: 16px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.modal.summaryBg} 0%,
    ${VPB_THEMES.colors.modal.summaryBgEnd} 100%
  );
  border-radius: 10px;
  border: 1px solid ${VPB_THEMES.colors.modal.summaryBorder};
`;

export const ModalSummaryText = styled(Text)`
  font-size: 14px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.iconBlue};
  text-align: center;
`;
