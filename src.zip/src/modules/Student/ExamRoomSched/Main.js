import AppCalendar from "components/common/AppCalendar";
import AppHeader from "components/common/AppHeader";
import { useEffect, useMemo, useState } from "react";
import { VPB_THEMES } from "utils/configs";
import { useDispatchRedux, useOneState } from "utils/hooks/useRedux";

import ExamDetailModal from "./components/ExamDetailModal";
import { convertExamToCalendarEvents } from "./helpers";
import {
  fetchExamScheduleAction,
  resetStoreExamRoomSchedAction,
} from "./store/actions";
import { key } from "./store/constants";
import { ContainerStyled } from "./Styled";

const MOBILE_BREAKPOINT = 768;

const ExamRoomSchedMain = () => {
  const [selectedExam, setSelectedExam] = useState(null);
  const [isMobile, setIsMobile] = useState(
    () => window.innerWidth <= MOBILE_BREAKPOINT
  );

  const fetchExamSchedule = useDispatchRedux(fetchExamScheduleAction);
  const rqResetStore = useDispatchRedux(resetStoreExamRoomSchedAction);

  const examScheduleData = useOneState(key, "examSchedule") || [];

  // Màu sắc cho events
  const getEventColor = () => VPB_THEMES.colors.iconBlue;

  // Chuyển đổi exam schedule data sang format events của FullCalendar
  const calendarEvents = useMemo(() => {
    return convertExamToCalendarEvents(examScheduleData, getEventColor);
  }, [examScheduleData]);

  // Responsive headerToolbar cho mobile
  const headerToolbar = useMemo(() => {
    if (isMobile) {
      return {
        left: "prev,next",
        center: "title",
        right: "today",
      };
    }
    return {
      left: "prev,next today",
      center: "title",
      right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek",
    };
  }, [isMobile]);

  // Xử lý khi calendar thay đổi date range (chỉ khi prev/next month)
  // const handleDatesSet = () => {
  //   fetchExamSchedule({
  //     studentId: 1,
  //   });
  // };

  // Xử lý click vào event
  const handleEventClick = (clickInfo) => {
    const exam = clickInfo.event.extendedProps.exam;
    if (exam) {
      setSelectedExam(exam);
    }
  };

  // Detect mobile và update state
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= MOBILE_BREAKPOINT);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Fetch data khi component mount
  useEffect(() => {
    fetchExamSchedule();
  }, []);

  // Cleanup khi unmount
  useEffect(() => {
    return () => {
      rqResetStore();
    };
  }, []);

  return (
    <ContainerStyled>
      <AppHeader componentName="ExamRoomSchedStudent" isHiddenBtn />

      <AppCalendar
        events={calendarEvents}
        onEventClick={handleEventClick}
        // onDatesSet={handleDatesSet}
        headerToolbar={headerToolbar}
        initialView={isMobile ? "listWeek" : "dayGridMonth"}
      />

      <ExamDetailModal
        open={!!selectedExam}
        exam={selectedExam}
        onClose={() => setSelectedExam(null)}
      />
    </ContainerStyled>
  );
};

export default ExamRoomSchedMain;
