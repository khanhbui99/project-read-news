import AppHeader from "components/common/AppHeader";
import PropTypes from "prop-types";
import { useEffect } from "react";
import React from "react";
import { useDispatchRedux } from "utils/hooks/useRedux";

import TableExcellentStudentContest from "./components/List/Table";
import {
  queryExcellentStudentContestAction,
  resetStoreExcellentStudentContestAction,
} from "./store/actions";

const ListExcellentStudentContest = () => {
  const fetchAllExcellentStudentContest = useDispatchRedux(
    queryExcellentStudentContestAction,
  );
  const resetStoreExcellentStudentContest = useDispatchRedux(
    resetStoreExcellentStudentContestAction,
  );

  useEffect(() => {
    fetchAllExcellentStudentContest();

    return () => {
      resetStoreExcellentStudentContest();
    };
  }, []);

  return (
    <React.Fragment>
      <AppHeader isHiddenBtn componentName="ScoreAppealExcellentStudent" />

      <TableExcellentStudentContest />
    </React.Fragment>
  );
};

ListExcellentStudentContest.propTypes = {
  historyPathCreate: PropTypes.string,
  historyPathEdit: PropTypes.string,
};

export default ListExcellentStudentContest;
