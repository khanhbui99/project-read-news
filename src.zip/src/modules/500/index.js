import PropTypes from "prop-types";
import loadable from "utils/loadable";

const Provider = ({ children }) => {
  return <>{children}</>;
};

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

const Error500 = loadable(() => import("./Main"), {
  fallback: null,
  provider: Provider,
});

export default Error500;
