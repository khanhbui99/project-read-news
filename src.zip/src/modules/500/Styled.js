import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";
export { BoxShadow, Text, Title } from "components/Styled";

export const PageWrapper = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const Container = styled.div`
  max-width: 800px;
  width: 100%;
  text-align: center;
  position: relative;
  z-index: 1;
`;

export const ContentCard = styled.div`
  background: ${VPB_THEMES.colors.white};
  border-radius: 24px;
  padding: 48px 32px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  position: relative;

  @media (max-width: 768px) {
    padding: 32px 24px;
    border-radius: 16px;
  }
`;

export const IconWrapper = styled.div`
  margin-bottom: 32px;
  text-align: center;

  svg {
    font-size: 80px;
    color: ${VPB_THEMES.colors.primaryBlue};
    filter: drop-shadow(0 4px 12px rgba(0, 119, 190, 0.3));
    transition: all 0.3s ease;

    &:hover {
      transform: scale(1.05);
      filter: drop-shadow(0 6px 16px rgba(0, 119, 190, 0.4));
    }
  }

  @media (max-width: 768px) {
    margin-bottom: 24px;

    svg {
      font-size: 60px;
    }
  }
`;

export const StatusBadge = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 12px;
  background: ${VPB_THEMES.colors.iconBgBlue};
  color: ${VPB_THEMES.colors.primaryBlue};
  padding: 12px 24px;
  border-radius: 24px;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 24px;
  border: 1px solid rgba(0, 119, 190, 0.2);

  svg {
    font-size: 20px;
  }
`;

export const FeatureGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
  margin-top: 32px;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 16px;
    margin-top: 24px;
  }
`;

export const FeatureItem = styled.div`
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  border-radius: 12px;
  padding: 20px 16px;
  transition: all 0.3s ease;
  cursor: pointer;
  text-align: center;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    border-color: ${VPB_THEMES.colors.secondaryBlue};

    svg {
      transform: scale(1.05);
      color: ${VPB_THEMES.colors.secondaryBlue};
    }
  }

  svg {
    font-size: 28px;
    color: ${VPB_THEMES.colors.iconBlue};
    margin-bottom: 12px;
    transition: all 0.3s ease;
  }

  @media (max-width: 768px) {
    padding: 16px 12px;

    svg {
      font-size: 24px;
    }
  }
`;
