import AnalyticsIcon from "@mui/icons-material/Analytics";
import AssessmentIcon from "@mui/icons-material/Assessment";
import BuildIcon from "@mui/icons-material/Build";
import EngineeringIcon from "@mui/icons-material/Engineering";
import ScienceIcon from "@mui/icons-material/Science";
import SupportIcon from "@mui/icons-material/Support";
import TimelineIcon from "@mui/icons-material/Timeline";

import {
  PageWrapper,
  Container,
  ContentCard,
  IconWrapper,
  StatusBadge,
  FeatureGrid,
  FeatureItem,
  Text,
  Title
} from "./Styled";

const Main = () => {
  const features = [
    {
      icon: <TimelineIcon />,
      title: "Phân tích dữ liệu",
      description: "Đang phát triển tính năng phân tích nâng cao",
      color: "#0077be"
    },
    {
      icon: <AnalyticsIcon />,
      title: "Báo cáo thông minh",
      description: "Tích hợp các tính năng để tạo báo cáo tự động",
      color: "#00a8e8"
    },
    {
      icon: <AssessmentIcon />,
      title: "Đánh giá hiệu quả",
      description: "Hệ thống đánh giá toàn diện đang được xây dựng",
      color: "#48cae4"
    },
    {
      icon: <EngineeringIcon />,
      title: "Công nghệ tiên tiến",
      description: "Áp dụng công nghệ mới nhất cho trải nghiệm tốt hơn",
      color: "#023e8a"
    },
    {
      icon: <ScienceIcon />,
      title: "Nghiên cứu & Phát triển",
      description: "Đội ngũ R&D đang nghiên cứu các giải pháp đột phá",
      color: "#00AD53"
    },
    {
      icon: <SupportIcon />,
      title: "Hỗ trợ chuyên nghiệp",
      description: "Đội ngũ hỗ trợ sẵn sàng tư vấn và giải đáp thắc mắc",
      color: "#ff9800"
    }
  ];

  return (
    <PageWrapper>
      <Container>
        <ContentCard>
          <IconWrapper>
            <BuildIcon />
          </IconWrapper>

          <StatusBadge>
            <BuildIcon />
            Tính năng đang phát triển
          </StatusBadge>

          <Title $size={32} $weight={700} $color="textDark" $align="center" $line="130%">
            Trang này đang được xây dựng
          </Title>

          <Text $size={16} $color="textLight" $align="center" $line="150%" style={{ marginBottom: 32 }}>
            Chúng tôi đang làm việc chăm chỉ để mang đến cho bạn trải nghiệm tốt nhất.
            Tính năng này sẽ sớm được ra mắt với nhiều cải tiến mới.
          </Text>

          <FeatureGrid>
            {features.map((feature, index) => (
              <FeatureItem key={index}>
                <div style={{ color: feature.color }}>
                  {feature.icon}
                </div>
                <Text $size={14} $weight={600} $color="textDark" $align="center" style={{ marginBottom: 8 }}>
                  {feature.title}
                </Text>
                <Text $size={12} $color="textLight" $align="center" $line="140%">
                  {feature.description}
                </Text>
              </FeatureItem>
            ))}
          </FeatureGrid>

          <Text $size={14} $color="textLight" $align="center" style={{ marginTop: 32 }}>
            Vui lòng quay lại sau hoặc liên hệ bộ phận hỗ trợ nếu cần giúp đỡ.
          </Text>
        </ContentCard>
      </Container>
    </PageWrapper>
  );
};

export default Main;
