import { createRoutine } from "redux-saga-routines";

import * as Const from "./constants";

export function toggleSidebarAction() {
  return {
    type: Const.TOGGLE_SIDEBAR_ACTION,
  };
}

export function toggleMobileSidebarAction() {
  return {
    type: Const.TOGGLE_MOBILE_SIDEBAR_ACTION,
  };
}

export function closeMobileSidebarAction() {
  return {
    type: Const.CLOSE_MOBILE_SIDEBAR_ACTION,
  };
}

export function logoutAction() {
  return {
    type: Const.LOGOUT_ACTION,
  };
}

// MESSAGE
export const cleanErrorMessage = () => ({
  type: Const.CLEAN_ERROR_MESSAGE_ACTION,
});

export const setMessageByFieldAction = (field, value) => ({
  type: Const.SET_MESSAGE_BY_FIELD_ACTION,
  payload: { field, value },
});

export const clearMessageByFieldAction = (field) => ({
  type: Const.CLEAR_MESSAGE_BY_FIELD_ACTION,
  payload: { field },
});

export function setLoadingSwitchRole(payload) {
  return {
    type: Const.SET_LOADING_SWITCH_ROLE,
    payload,
  };
}

export function setLoadingAction(payload) {
  return {
    type: Const.SET_LOADING_ACTION,
    payload,
  };
}

export function toggleMenuAction(value) {
  return {
    type: Const.TOGGLE_MENU_ACTION,
    payload: value,
  };
}
export function toggleMenuParentAction(value) {
  return {
    type: Const.TOGGLE_MENU_PARENT_ACTION,
    payload: value,
  };
}

export function setPageTitleAction(value) {
  return {
    type: Const.SET_PAGE_TITLE_ACTION,
    payload: value,
  };
}

// Modal Notification
export const setModalNotificationAction = (payload) => ({
  type: Const.SET_MODAL_NOTIFICATION_ACTION,
  payload,
});

export const closeModalNotificationAction = () => ({
  type: Const.CLOSE_MODAL_NOTIFICATION_ACTION,
});

// Modal Share
export const setModalShareAction = (payload) => ({
  type: Const.SET_MODAL_SHARE_ACTION,
  payload,
});

export const closeModalShareAction = () => ({
  type: Const.CLOSE_MODAL_SHARE_ACTION,
});

// ---------------- action saga global ---------------- //
export const loginAction = createRoutine(Const.LOGIN_ACTION);

export const getPathByComponentNameAction = createRoutine(
  Const.GET_PATH_BY_COMPONENT
);

export const switchRoleAction = createRoutine(Const.SWITCH_ROLE_ACTION);

export const getMenuAction = createRoutine(Const.GET_MENU_ACTION);

export const registerFcmToken = createRoutine(Const.REGISTER_FMC_TOKEN);

export const getAllRolesAction = createRoutine(
  Const.GET_ALL_ROLES_ACTION
);  

export const getAllDepartmentsAction = createRoutine(
  Const.GET_ALL_DEPARTMENTS_ACTION
);

export const getAllTopicAction = createRoutine(Const.GET_ALL_TOPIC_ACTION);

export const getAllSubjectAction = createRoutine(Const.GET_ALL_SUBJECT_ACTION);

export const getAllOrgChartAction = createRoutine(Const.GET_ALL_ORG_CHART_ACTION);

export const getAllExamTemplatesAction = createRoutine(Const.GET_ALL_EXAM_TEMPLATES_ACTION);

export const getExamTemplateDetailAction = createRoutine(Const.GET_EXAM_TEMPLATE_DETAIL_ACTION);

export const getAllQuestionsAction = createRoutine(Const.GET_ALL_QUESTIONS_ACTION);

export const getAllBankQuestionsAction = createRoutine(Const.GET_ALL_BANK_QUESTIONS_ACTION);

export const getAllUsersAction = createRoutine(Const.GET_ALL_USERS_ACTION);

export const getAllDistrictsAction = createRoutine(Const.GET_ALL_DISTRICTS_ACTION);

export const getAllAcademicYearsAction = createRoutine(Const.GET_ALL_ACADEMIC_YEARS_ACTION);

export const getAllOfficeUtilityTypesAction = createRoutine(Const.GET_ALL_OFFICE_UTILITY_TYPES_ACTION);

export const getAllTaskCategoryAction = createRoutine(Const.GET_ALL_TASK_CATEGORY_ACTION);

export const getAllTeachersAction = createRoutine(Const.GET_ALL_TEACHERS_ACTION);

export const getAllClassesAction = createRoutine(Const.GET_ALL_CLASSES_ACTION);

export const lockStatusQIAction = createRoutine(Const.LOCK_STATUS_QI_ACTION);
export const getDetailStudentAction = createRoutine(Const.GET_DETAIL_STUDENT_ACTION);

export const awardScoreRangeAction = createRoutine(Const.AWARD_SCORE_RANGES_ACTION);

export const getExamPeriodCategoryAction = createRoutine(
  Const.GET_EXAM_PERIOD_CATEGORY_ACTION
);


// Import/Export Question
export const importQuestionAction = createRoutine(Const.IMPORT_QUESTIONS_ACTION);

export const downloadTemplateQuestionAction = createRoutine(Const.DOWNLOAD_TEMPLATE_QUESTION_ACTION);

// Share Resource
export const shareResourceAction = createRoutine(Const.SHARE_RESOURCE_ACTION);

export const allJsonAction = createRoutine(Const.ALL_JSON_CONFIG_ACTION);

export const updateByCodeAction = createRoutine(Const.UPDATE_BY_CODE_ACTION);