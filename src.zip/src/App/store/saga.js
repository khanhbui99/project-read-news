import { jwtDecode } from "jwt-decode";
import size from "lodash/size";
import { all, delay, put, select, takeLatest } from "redux-saga/effects";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import {
  ACCOUNT_CODE,
  GENERATION_MODE,
  IL_LIST_ROLE,
  REFRESH_TOKEN_NAME,
  responseCode,
  TOKEN_NAME,
  USER_INFO_NAME,
  IL_USER_SELECTED_ORGCHART,
  KEY,
  awardLevelOpt,
} from "utils/constants";
import { getInfoUser } from "utils/helpers";
import history from "utils/history";
import injectKey from "utils/injectKey";
import { get, post } from "utils/request";
import API from "utils/services/service.constant.js";

import {
  setLoadingAction,
  setMessageByFieldAction,
  closeModalShareAction,
  allJsonAction,
  updateByCodeAction,
} from "./actions";
import {
  getMenuAction,
  loginAction,
  setLoadingSwitchRole,
  switchRoleAction,
  getAllTopicAction,
  getAllRolesAction,
  getAllSubjectAction,
  getAllDepartmentsAction,
  getAllExamTemplatesAction,
  getExamTemplateDetailAction,
  getAllQuestionsAction,
  getAllOrgChartAction,
  getAllBankQuestionsAction,
  getAllUsersAction,
  getAllDistrictsAction,
  getAllAcademicYearsAction,
  getAllOfficeUtilityTypesAction,
  getAllTaskCategoryAction,
  getAllTeachersAction,
  getAllClassesAction,
  getExamPeriodCategoryAction,
  importQuestionAction,
  downloadTemplateQuestionAction,
  shareResourceAction,
  getDetailStudentAction,
  lockStatusQIAction,
  awardScoreRangeAction,
} from "./actions";
import { sortAwardScoreRanges } from "modules/GiamThi/helpers";

function buildConcurrentRoleList(accountConcurrentInfos = []) {
  return accountConcurrentInfos.reduce((acc, e) => {
    e.chartConcurrentInfo.forEach((chart) => {
      acc.push({
        accountCode: e.accountCode,
        email: e.email,
        userName: e.userName,
        roleName: chart.roleName,
        chartName: chart.chartName,
        chartId: chart.chartId,
      });
    });
    return acc;
  }, []);
}

export function* loginSaga({ payload }) {
  try {
    yield put(loginAction.request());

    const requestData = {
      url: urlApi.orgChart.account.login,
      data: {
        email: payload.email,
        password: payload.password,
      },
    };

    const { data: res = {} } = yield ApiReq.post(requestData);

    const { data = {}, meta = {} } = res;
    const val = `Bearer ${data.token}`;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        const concurrentRoleList = buildConcurrentRoleList(
          data.accountConcurrentInfos,
        );

        const teachers = yield select(
          (state) => state[injectKey.GLOBAL][KEY.TEACHER],
        );

        const decodedToken = jwtDecode(val);
        const infoUser = getInfoUser(teachers, data.name);
        // console.log('infoUser: ', infoUser);
        localStorage.setItem(TOKEN_NAME, val);
        localStorage.setItem(ACCOUNT_CODE, data.accountCode);
        localStorage.setItem(IL_LIST_ROLE, data.listRole);
        localStorage.setItem(
          USER_INFO_NAME,
          JSON.stringify({
            ...data,
            id: decodedToken.id,
            teacherCode: infoUser?.teacher_code,
            position: infoUser?.position,
            accountConcurrentInfos: concurrentRoleList,
          }),
        );
        localStorage.setItem(REFRESH_TOKEN_NAME, data.refreshToken);

        if (size(data.orgCharts)) {
          localStorage.setItem(
            IL_USER_SELECTED_ORGCHART,
            data.orgCharts[0].orgChartId,
          );
        }

        yield put(loginAction.success());
        break;
      }
      default:
        yield put(loginAction.failure(meta));
    }
  } catch (err) {
    console.log("err: ", err);
    yield put(loginAction.failure(err));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export function* getMenuSaga() {
  yield put(getMenuAction.request());
  const requestData = {
    url: urlApi.orgChart.menuItem.listMenu,
    // params: {
    //   roleName: localStorage.getItem(IL_LIST_ROLE),
    // },
  };
  try {
    const { data: res = {} } = yield get(requestData);
    const { data, meta = {} } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield put(getMenuAction.success(data));
        break;
      default:
        yield put(getMenuAction.failure(meta));
    }
  } catch (err) {
    yield put(getMenuAction.failure(err));
  }
}

export function* switchRoleSaga({ payload }) {
  yield put(switchRoleAction.request());
  const requestData = {
    url: API.auth.switchRole,
    data: {
      email: payload.email,
    },
  };
  try {
    const { data: res = {} } = yield post(requestData);
    const { data, meta = {} } = res;
    const val = `Bearer ${data.token}`;

    switch (meta.code) {
      case responseCode["IL-200"]: {
        const concurrentRoleList = buildConcurrentRoleList(
          data.accountConcurrentInfos,
        );

        localStorage.setItem(TOKEN_NAME, val);
        localStorage.setItem(ACCOUNT_CODE, data.accountCode);
        localStorage.setItem(IL_LIST_ROLE, data.listRole);
        localStorage.setItem(
          USER_INFO_NAME,
          JSON.stringify({
            ...data,
            accountConcurrentInfos: concurrentRoleList,
          }),
        );
        localStorage.setItem(REFRESH_TOKEN_NAME, data.refreshToken);
        if (size(data.orgCharts)) {
          localStorage.setItem(
            IL_USER_SELECTED_ORGCHART,
            (data.orgCharts || []).find(
              (e) => Number(e.orgChartId) === Number(payload.chartId),
            ).orgChartId,
          );
        }

        yield put(switchRoleAction.success());
        yield delay(300);
        history.push({
          pathname: "/",
        });

        yield delay(150);
        yield put(setLoadingSwitchRole(false));
        break;
      }
      default:
        yield put(switchRoleAction.failure(meta));
    }
  } catch (err) {
    yield put(switchRoleAction.failure(err));
  }
}

export function* getAllRolesSaga() {
  try {
    yield put(getAllRolesAction.request());
    const requestData = {
      url: urlApi.orgChart.authorities.listAll,
    };

    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;
    yield put(getAllRolesAction.success({ roles: data }));
  } catch (err) {
    yield put(getAllRolesAction.failure(err));
  }
}

export function* getAllDepartmentsSaga() {
  try {
    yield put(getAllDepartmentsAction.request());
    const requestData = {
      url: urlApi.orgChart.department.listAll,
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;
    yield put(getAllDepartmentsAction.success(data));
  } catch (err) {
    yield put(getAllDepartmentsAction.failure(err));
  }
}

export function* getAllSubjectSaga() {
  try {
    yield put(getAllSubjectAction.request());
    const requestData = {
      url: urlApi.managementService.subject.list,
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;
    yield put(getAllSubjectAction.success(data));
  } catch (err) {
    yield put(getAllSubjectAction.failure(err));
  }
}

export function* getAllTopicSaga() {
  try {
    yield put(getAllTopicAction.request());
    const requestData = {
      url: urlApi.managementService.topic.list,
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;
    yield put(getAllTopicAction.success(data));
  } catch (err) {
    yield put(getAllTopicAction.failure(err));
  }
}

export function* getAllExamTemplatesSaga() {
  try {
    yield put(getAllExamTemplatesAction.request());
    const requestData = {
      url: urlApi.managementService.examTemplate.list,
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;

    // Map generationModeName và titleFormat vào mỗi item
    const mappedData = data.map((item) => {
      const generationMode = GENERATION_MODE.find(
        (mode) => mode.value === item.generationMode,
      );
      const generationModeName = generationMode?.label || "";
      const titleFormat = generationModeName
        ? `${item.title} - ${generationModeName}`
        : item.title;

      return {
        ...item,
        generationModeName,
        titleFormat,
      };
    });

    yield put(getAllExamTemplatesAction.success(mappedData));
  } catch (err) {
    yield put(getAllExamTemplatesAction.failure(err));
  }
}

export function* getExamTemplateDetailSaga({ payload }) {
  try {
    yield put(getExamTemplateDetailAction.request());
    const requestData = {
      url: urlApi.managementService.examTemplate.detail(payload),
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = {} } = res;

    // Map generationModeName vào data
    const generationMode = GENERATION_MODE.find(
      (mode) => mode.value === data.generationMode,
    );
    const mappedData = {
      ...data,
      generationModeName: generationMode?.label || "",
    };

    yield put(getExamTemplateDetailAction.success(mappedData));
  } catch (err) {
    yield put(getExamTemplateDetailAction.failure(err));
  }
}

export function* getAllQuestionsSaga() {
  try {
    yield put(getAllQuestionsAction.request());
    const requestData = {
      url: urlApi.managementService.question.list,
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;

    // Lấy topicOpt từ global store
    const topicOpt = yield select(
      (state) => state[injectKey.GLOBAL]?.topicOpt || [],
    );

    // Map topicName vào mỗi question dựa trên topicId
    const mappedData = data.map((question) => {
      const topic = topicOpt.find((t) => t.id === question.topicId);
      return {
        ...question,
        topicName: topic?.name || "",
      };
    });

    yield put(getAllQuestionsAction.success(mappedData));
  } catch (err) {
    yield put(getAllQuestionsAction.failure(err));
  }
}

export function* allOrgChartActionSaga() {
  try {
    yield put(getAllOrgChartAction.request());
    const requestData = {
      url: urlApi.orgChart.chart.listAll,
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = {} } = res;
    yield put(getAllOrgChartAction.success(data));
  } catch (err) {
    yield put(getAllOrgChartAction.failure(err));
  }
}

export function* getAllBankQuestionsSaga({ payload }) {
  try {
    yield put(getAllBankQuestionsAction.request());
    const requestData = {
      url: urlApi.managementService.bankQuestion.list,
      params: payload?.subjectId ? { subjectId: payload.subjectId } : {},
    };
    const { data: res = {} } = yield ApiReq.get(requestData);
    const { data = [] } = res;
    yield put(getAllBankQuestionsAction.success(data));
  } catch (err) {
    yield put(getAllBankQuestionsAction.failure(err));
  }
}

export function* getAllUsersSaga({ payload }) {
  try {
    yield put(getAllUsersAction.request());
    const request = {
      url: urlApi.orgChart.account.list,
      params: { page: 0, size: 1000, ...payload },
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [] } = res;

    // Transform to format: { id, name }
    const formattedUsers = data.map((user) => ({
      ...user,
      name: `${user.name} - ${user.userName}`,
    }));

    yield put(getAllUsersAction.success(formattedUsers));
  } catch (err) {
    yield put(getAllUsersAction.failure(err));
  }
}

export function* getAllDistrictsSaga() {
  try {
    yield put(getAllDistrictsAction.request());
    const request = {
      url: urlApi.core.districts.listAll,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [] } = res;
    yield put(getAllDistrictsAction.success(data));
  } catch (err) {
    yield put(getAllDistrictsAction.failure(err));
  }
}

export function* getAllAcademicYearsSaga() {
  try {
    // Check nếu đã có data trong state thì không gọi API
    const academicYearOpt = yield select(
      (state) => state[injectKey.GLOBAL]?.academicYearOpt || [],
    );

    if (academicYearOpt.length > 0) {
      // Đã có data, không cần gọi API
      return;
    }

    yield put(getAllAcademicYearsAction.request());
    const request = {
      url: urlApi.managementService.academicYear.findAll,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [] } = res;
    yield put(getAllAcademicYearsAction.success(data));
  } catch (err) {
    yield put(getAllAcademicYearsAction.failure(err));
  }
}

export function* getAllOfficeUtilityTypesSaga() {
  try {
    yield put(getAllOfficeUtilityTypesAction.request());
    const request = {
      url: urlApi.orgChart.officeUtilityType.list,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    if (meta?.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message);
    }

    yield put(getAllOfficeUtilityTypesAction.success(data));
  } catch (err) {
    yield put(getAllOfficeUtilityTypesAction.failure(err));
  }
}

export function* getAllTaskCategorySaga() {
  try {
    const taskCategoryOpt = yield select(
      (state) => state[injectKey.GLOBAL]?.taskCategoryOpt || [],
    );

    if (taskCategoryOpt.length > 0) return;

    yield put(getAllTaskCategoryAction.request());
    const request = {
      url: urlApi.teacherService.taskCategory.list,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    if (
      meta?.code &&
      meta?.code !== responseCode["IL-200"] &&
      meta?.code !== "LMS-200"
    ) {
      throw new Error(meta?.message);
    }

    // Xử lý response - có thể là array trực tiếp hoặc trong data
    const items = Array.isArray(res) ? res : Array.isArray(data) ? data : [];
    yield put(getAllTaskCategoryAction.success(items));
  } catch (err) {
    yield put(getAllTaskCategoryAction.failure(err));
  }
}

export function* getAllTeachersSaga() {
  try {
    const teachersOpt = yield select(
      (state) => state[injectKey.GLOBAL]?.teachersOpt || [],
    );

    if (teachersOpt.length > 0) return;

    yield put(getAllTeachersAction.request());
    const request = {
      url: urlApi.core.teachers.listAll,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    if (
      meta?.code &&
      meta?.code !== responseCode["IL-200"] &&
      meta?.code !== "LMS-200"
    ) {
      throw new Error(meta?.message);
    }

    // Xử lý response - có thể là array trực tiếp hoặc trong data
    const items = Array.isArray(res) ? res : Array.isArray(data) ? data : [];
    yield put(getAllTeachersAction.success(items));
  } catch (err) {
    yield put(getAllTeachersAction.failure(err));
  }
}

export function* getAllClassesSaga() {
  try {
    const classesOpt = yield select(
      (state) => state[injectKey.GLOBAL]?.classesOpt || [],
    );

    if (classesOpt.length > 0) return;

    yield put(getAllClassesAction.request());
    const request = {
      url: "/management-service/v2/api/classes",
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    if (
      meta?.code &&
      meta?.code !== responseCode["IL-200"] &&
      meta?.code !== "LMS-200"
    ) {
      throw new Error(meta?.message);
    }

    // Xử lý response - có thể là array trực tiếp hoặc trong data
    const items = Array.isArray(res) ? res : Array.isArray(data) ? data : [];
    yield put(getAllClassesAction.success(items));
  } catch (err) {
    yield put(getAllClassesAction.failure(err));
  }
}

export function* downloadTemplateQuestionSaga({ payload }) {
  try {
    yield put(setLoadingAction(true));
    yield put(downloadTemplateQuestionAction.request());

    const { subjectId } = payload;

    if (!subjectId) {
      yield put(
        setMessageByFieldAction("error", {
          message: "Vui lòng chọn môn học",
        }),
      );
      yield put(downloadTemplateQuestionAction.failure({}));
      return;
    }

    const request = {
      url: urlApi.managementService.excel.downloadTemplate(subjectId),
      method: "GET",
    };

    yield ApiReq.download({
      url: request.url,
      method: "GET",
      folderName: `Template_CauHoi_MonHoc_${subjectId}.xlsx`,
    });

    yield put(downloadTemplateQuestionAction.success({}));
    yield put(
      setMessageByFieldAction("success", {
        message: "Tải template thành công",
      }),
    );
  } catch (err) {
    yield put(downloadTemplateQuestionAction.failure(err));
    yield put(setMessageByFieldAction("error", err));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export function* importQuestionSaga({ payload }) {
  try {
    yield put(setLoadingAction(true));
    yield put(importQuestionAction.request());

    const { file, subjectId, bankQuestionId } = payload;

    if (!subjectId || !bankQuestionId) {
      yield put(
        setMessageByFieldAction("error", {
          message: "Vui lòng chọn môn học và ngân hàng câu hỏi",
        }),
      );
      yield put(importQuestionAction.failure({}));
      return;
    }

    if (!file) {
      yield put(
        setMessageByFieldAction("error", {
          message: "Vui lòng chọn file để import",
        }),
      );
      yield put(importQuestionAction.failure({}));
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    const request = {
      url: urlApi.managementService.excel.importTemplate(
        subjectId,
        bankQuestionId,
      ),
      data: formData,
      multipart: true,
    };

    const { data: res = {} } = yield ApiReq.post(request);
    const { meta = {}, data } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield put(importQuestionAction.success(data));
        yield put(
          setMessageByFieldAction("success", {
            message: "Import câu hỏi thành công",
          }),
        );
        break;
      default:
        yield put(importQuestionAction.failure(meta));
        yield put(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield put(importQuestionAction.failure(err));
    yield put(setMessageByFieldAction("error", err));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export function* shareResourceSaga({ payload }) {
  try {
    yield put(setLoadingAction(true));
    yield put(shareResourceAction.request());

    const { resourceType, resourceId, shares } = payload;

    if (!resourceType || !resourceId || !shares || shares.length === 0) {
      yield put(
        setMessageByFieldAction("error", {
          message: "Vui lòng điền đầy đủ thông tin",
        }),
      );
      yield put(shareResourceAction.failure({}));
      return;
    }

    const request = {
      url: urlApi.managementService.share.share,
      data: {
        resourceType,
        resourceId,
        shares,
      },
    };

    const { data: res = {} } = yield ApiReq.post(request);
    const { meta = {}, data } = res;

    switch (meta.code) {
      case responseCode["IL-200"]:
        yield put(shareResourceAction.success(data));
        yield put(
          setMessageByFieldAction("success", {
            message: "Chia sẻ thành công",
          }),
        );
        yield put(closeModalShareAction());
        break;
      default:
        yield put(shareResourceAction.failure(meta));
        yield put(setMessageByFieldAction("error", meta));
    }
  } catch (err) {
    yield put(shareResourceAction.failure(err));
    yield put(setMessageByFieldAction("error", err));
  } finally {
    yield put(setLoadingAction(false));
  }
}

export function* allJsonSaga() {
  try {
    // yield put(setLoadingAction(true));
    yield put(allJsonAction.request());

    const request = {
      url: "lms/api-json/all",
    };

    const { data: res = {} } = yield ApiReq.get(request);

    if (!Array.isArray(res)) throw new Error("Không lấy được dữ liệu!");

    const dataRes = {
      [KEY.AUTH]: [],
      [KEY.CLASS_TEACHER_SUBJECT]: [],
      [KEY.COMPETITION_TEACHER_CATEGORY]: [],
      [KEY.COMPETITION_TEACHER_REASON]: [],
      [KEY.COMPETITION_TEACHER_SCORE]: [],
      [KEY.MAP_LOAI_MON]: [],
    };

    yield put(allJsonAction.success(dataRes));
  } catch (err) {
    yield put(allJsonAction.failure(err));
    // yield put(setMessageByFieldAction("error", err));
  } finally {
    // yield put(setLoadingAction(false));
  }
}

export function* updateByCodeSaga({ payload }) {
  try {
    yield put(setLoadingAction(true));
    yield put(updateByCodeAction.request());

    const request = {
      url: "lms/api-json/save",
      data: {
        action: "UPDATE",
        code: payload.code,
        type: "test",
        data: payload.data,
      },
      notAuth: true,
    };

    const { data: res = {} } = yield ApiReq.post(request);

    yield put(
      updateByCodeAction.success({
        code: payload.code,
        data: payload.data,
      }),
    );

    payload.cb?.();
    yield put(setMessageByFieldAction("success", "Cập nhật thành công"));
  } catch (err) {
    yield put(setMessageByFieldAction("error", "Cập nhật thất bại"));
  } finally {
    // yield put(setLoadingAction(false));
  }
}

export function* getExamPeriodCategorySaga() {
  try {
    const examPeriodCategory = yield select(
      (state) => state[injectKey.GLOBAL]?.examPeriodCategory,
    ) || {};
    if (Object.keys(examPeriodCategory).length > 0) return;

    yield put(getExamPeriodCategoryAction.request());
    const request = {
      url: urlApi.managementService.examPeriod.categoryDependency,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    if (meta?.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message);
    }

    if (data?.academicYears?.length) {
      data.academicYears = data?.academicYears.sort((a, b) => b?.id - a?.id);
    }

    if (data?.semesters?.length) {
      data.semesters = data.semesters.map((_s) => ({
        ..._s,
        semesterName: `Học kỳ ${_s?.name}`,
      }));
    }

    yield put(getExamPeriodCategoryAction.success(data));
  } catch (err) {
    yield put(getExamPeriodCategoryAction.failure(err));
  }
}

export function* detailStudentSaga() {
  try {
    const detailStudent = yield select(
      (state) => state[injectKey.GLOBAL]?.detailStudent,
    ) || {};
    if (Object.keys(detailStudent).length > 0) return;

    yield put(getDetailStudentAction.request());

    const request = {
      url: urlApi.managementService.student.detail,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    if (meta?.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message);
    }

    yield put(getDetailStudentAction.success(data));
  } catch (err) {
    yield put(getDetailStudentAction.failure(err));
  }
}

export function* lockStatusQISaga() {
  try {
    yield put(lockStatusQIAction.request());

    const request = {
      url: urlApi.managementService.score.statusQI,
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = {}, meta = {} } = res;

    if (meta?.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message);
    }

    yield put(lockStatusQIAction.success(data?.locked));
  } catch (err) {
    yield put(lockStatusQIAction.failure(err));
  }
}

export function* awardScoreRangeSaga({ payload }) {
  try {
    yield put(setLoadingAction(true));
    yield put(awardScoreRangeAction.request());

    const request = {
      url: urlApi.managementService.excellentStudentContest.awardScoreRanges(
        payload,
      ),
    };
    const { data: res = {} } = yield ApiReq.get(request);
    const { data = [], meta = {} } = res;

    if (meta?.code !== responseCode["IL-200"]) {
      throw new Error(meta?.message);
    }

    const ranges = sortAwardScoreRanges(data);

    yield put(awardScoreRangeAction.success(ranges));
  } catch (err) {
    yield put(awardScoreRangeAction.failure(err));
  } finally {
    yield put(setLoadingAction(false));
  }
}


export default function* watchAll() {
  yield all([
    takeLatest(loginAction.TRIGGER, loginSaga),
    takeLatest(getMenuAction.TRIGGER, getMenuSaga),
    takeLatest(switchRoleAction.TRIGGER, switchRoleSaga),
    takeLatest(getAllRolesAction.TRIGGER, getAllRolesSaga),
    takeLatest(getAllTopicAction.TRIGGER, getAllTopicSaga),
    takeLatest(getAllSubjectAction.TRIGGER, getAllSubjectSaga),
    takeLatest(getAllDepartmentsAction.TRIGGER, getAllDepartmentsSaga),
    takeLatest(getAllQuestionsAction.TRIGGER, getAllQuestionsSaga),
    takeLatest(getAllExamTemplatesAction.TRIGGER, getAllExamTemplatesSaga),
    takeLatest(getExamTemplateDetailAction.TRIGGER, getExamTemplateDetailSaga),
    takeLatest(getAllOrgChartAction.TRIGGER, allOrgChartActionSaga),
    takeLatest(getAllBankQuestionsAction.TRIGGER, getAllBankQuestionsSaga),
    takeLatest(getAllUsersAction.TRIGGER, getAllUsersSaga),
    takeLatest(getAllDistrictsAction.TRIGGER, getAllDistrictsSaga),
    takeLatest(getAllAcademicYearsAction.TRIGGER, getAllAcademicYearsSaga),
    takeLatest(
      getAllOfficeUtilityTypesAction.TRIGGER,
      getAllOfficeUtilityTypesSaga,
    ),
    takeLatest(importQuestionAction.TRIGGER, importQuestionSaga),
    takeLatest(
      downloadTemplateQuestionAction.TRIGGER,
      downloadTemplateQuestionSaga,
    ),
    takeLatest(shareResourceAction.TRIGGER, shareResourceSaga),
    takeLatest(getAllTaskCategoryAction.TRIGGER, getAllTaskCategorySaga),
    takeLatest(getAllTeachersAction.TRIGGER, getAllTeachersSaga),
    takeLatest(getAllClassesAction.TRIGGER, getAllClassesSaga),
    takeLatest(getExamPeriodCategoryAction.TRIGGER, getExamPeriodCategorySaga),
    takeLatest(allJsonAction.TRIGGER, allJsonSaga),
    takeLatest(updateByCodeAction.TRIGGER, updateByCodeSaga),
    takeLatest(getDetailStudentAction.TRIGGER, detailStudentSaga),
    takeLatest(lockStatusQIAction.TRIGGER, lockStatusQISaga),
    takeLatest(awardScoreRangeAction.TRIGGER, awardScoreRangeSaga),
  ]);
}
