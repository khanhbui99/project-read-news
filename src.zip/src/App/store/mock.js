export const mockLoginApi = payload =>
  new Promise(resolve => {
    setTimeout(() => {
      if (payload.email === 'admin@g' && payload.password === '123')
        resolve({
          data: {
            data: {
              token:
                'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIyZWY2MjQzNy02ZTA2LTQ2OTgtOTYyYS1jNGJiMmRjOTQxYmYiLCJpZCI6NCwiZW1haWwiOiJhZG1pbl92cGJhbmtAZ21haWwuY29tIiwiaWF0IjoxNjg2NzE2MDg4LCJleHAiOjE2ODY3MTk2ODh9.i8cTsdZjoHKe0RHVQ_QsoC8sWNPfbC2wq578fAZqvulgazCKcZr5acvjm_pjPjFAFist3uEiKr76dszG4BFDT1RVHVqyMlWB33eJ9TIV4pmn3mKhK4XMb1HUdaY6GJjyAKZbA83jk1OYhbLp-y7Wov5q1jxGLKCz-lJi16_-Xi2f00DRWzHx3CS2PrKkPv1hY_vLBTe3yegyUqbGGYmflkJjtWfKjobv1AsfvUi9L1kxNXYS3LSXoPV6qs6KApJFsRNC-hAwC8ypbjoglG4oCeQyeXtZN6NMTZC9c1t-7YRJKYrRbsfwYtmqI8TQKhbR0TtsS6Yt2hDXIINOxItRl8pTNoKeM5is__8wPwyPI6Okn4T-IeC7rMgp6mu4P1WCfiX5n9zT17qYGzc5TvHgePk7haRHcQEcPwmBP9VqMjuB6tEdZlDZ5LPK1zQRoKsPcjh9YCfVQE5ucZ1sPyHl16YDaupDt6sJEGio4mrf4M2428Fg89OwCcgLrg5uAvm5B1_ntI5m0hg7GchNG3yLaOvx1Te3uNm0w5PKtogWeVSriOwypGwkf5CcOu92zRzd5Vi6pzvO470xlog8HmtTSQp8zHiM6Acr1BcY3r_3tYjPIcy4LDr_2GvhUo9C8g9YBHhF8HfbApfO05NbwM9aH2J0qToKwQUUoIf8UvSbyCM',
              expired_at: 1686719688,
            },
            meta: {
              code: 'IL-200',
            },
          },
        });
      else
        resolve({
          meta: {
            code: 'IL-4003',
            message: 'Wrong password',
          },
        });
    }, 2000);
  });
