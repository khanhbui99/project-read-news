import { produce } from "immer";
import isObjectLd from "lodash/isObject";
import {
  IL_MENU_TYPE,
  IL_MENU_TYPE_PARENT,
  KEY,
  USER_INFO_NAME,
} from "utils/constants";
import { isAuthenticated, logout } from "utils/helpers";
import localStorageService from "utils/services/service.localStorage";

import { compareToHidden, compareToOrder } from "../helpers";
import {
  getMenuAction,
  loginAction,
  switchRoleAction,
  getAllTopicAction,
  getAllRolesAction,
  getAllSubjectAction,
  getAllDepartmentsAction,
  getAllExamTemplatesAction,
  getExamTemplateDetailAction,
  getAllQuestionsAction,
  getAllOrgChartAction,
  getAllBankQuestionsAction,
  getAllUsersAction,
  getAllDistrictsAction,
  getAllAcademicYearsAction,
  getAllOfficeUtilityTypesAction,
  getAllTaskCategoryAction,
  getAllTeachersAction,
  getAllClassesAction,
  getExamPeriodCategoryAction,
  getDetailStudentAction,
  lockStatusQIAction,
  awardScoreRangeAction,
} from "./actions";
import * as globalConst from "./constants";

export const initialState = {
  errorMessage: "",
  isLoggingIn: false,
  isMiniSidebar: false,
  isMobileSidebarOpen: false,
  isLoggedIn: isAuthenticated(),

  isLoadedMenu: false,
  isLoadingMenu: true,
  isLoading: false,

  lockedQI: true,
  pageTitle: "",

  menuTopBar: [],
  salesProduct: [],
  selectionListOps: [],
  menuTypeParent: localStorage.getItem(IL_MENU_TYPE_PARENT),
  menuType: localStorage.getItem(IL_MENU_TYPE),
  userInfo: JSON.parse(localStorage.getItem(USER_INFO_NAME) || "{}"),
  isSwitching: false,
  userProfileURL: "/profile",
  isCheckButtonFilterApprove: false,

  detailStudent: {},
  examPeriodCategory: {},

  // option
  roleOpt: [],
  topicOpt: [],
  subjectOpt: [],
  bankQuestionOpt: [],
  orgChartOpt: [],
  questionsOpt: [],
  departmentOpt: [],
  examTemplatesOpt: [],
  examTemplateDetail: {},
  userOpt: [],
  districtOpt: [],
  academicYearOpt: [],
  officeUtilityTypeOpt: [],
  taskCategoryOpt: [],
  teachersOpt: [],
  classesOpt: [],
  configRank: [],


  // Massage
  message: {
    error: "",
    success: "",
  },

  // Modal Notification
  modalNotification: {
    title: "",
    message: "",
    isOpen: false,
    isError: false,
  },

  // Modal Share
  modalShare: {
    isOpen: false,
    resourceId: null,
  },

  // 30/01
  [KEY.AUTH]: [],
  [KEY.TEACHER]: [],
  [KEY.LEAVE_REQUEST]: [],
  [KEY.CONFIG_APPROVED]: [],
  [KEY.CLASS_TEACHER_SUBJECT]: [],
  [KEY.COMPETITION_TEACHER_CATEGORY]: [],
  [KEY.COMPETITION_TEACHER_REASON]: [],
  [KEY.COMPETITION_TEACHER_SCORE]: [],
  [KEY.COMPETITION_CLASS_CATEGORY]: [],
  [KEY.COMPETITION_CLASS_REASON]: [],
  [KEY.COMPETITION_CLASS_SCORE]: [],
  [KEY.MAP_LOAI_MON]: [],
  [KEY.SCORE_STUDENT]: [],
  [KEY.SCORE_STUDENT_HK_2]: [],
};

const appReducer = (state = initialState, { payload = {}, type }) =>
  produce(state, (dr) => {
    const draft = dr;
    switch (type) {
      // ------------ Redux ------------ //
      case globalConst.TOGGLE_SIDEBAR_ACTION: {
        draft.isMiniSidebar = !state.isMiniSidebar;
        break;
      }

      case globalConst.TOGGLE_MOBILE_SIDEBAR_ACTION: {
        draft.isMobileSidebarOpen = !state.isMobileSidebarOpen;
        break;
      }

      case globalConst.CLOSE_MOBILE_SIDEBAR_ACTION: {
        draft.isMobileSidebarOpen = false;
        break;
      }

      case globalConst.LOGOUT_ACTION: {
        logout();
        draft.isLoggedIn = isAuthenticated();
        break;
      }

      case globalConst.SET_LOADING_SWITCH_ROLE:
        draft.isSwitching = payload;
        break;

      case globalConst.SET_LOADING_ACTION:
        draft.isLoading = payload;
        break;

      case globalConst.CLEAN_ERROR_MESSAGE_ACTION:
        draft.errorMessage = "";
        break;

      case globalConst.CLEAR_MESSAGE_BY_FIELD_ACTION:
        draft.message[payload.field] = "";
        break;

      case globalConst.TOGGLE_MENU_ACTION: {
        draft.menuType = payload;
        localStorage.setItem(IL_MENU_TYPE, payload);
        break;
      }

      case globalConst.TOGGLE_MENU_PARENT_ACTION: {
        draft.menuTypeParent = payload;
        localStorage.setItem(IL_MENU_TYPE_PARENT, payload);
        break;
      }

      case globalConst.SET_PAGE_TITLE_ACTION: {
        draft.pageTitle = payload;
        break;
      }

      case globalConst.SET_MESSAGE_BY_FIELD_ACTION: {
        const { field, value } = payload;
        const message = isObjectLd(value)
          ? value?.message || JSON.stringify(value)
          : value;

        draft.message[field] = message;
        break;
      }

      case globalConst.SET_MODAL_NOTIFICATION_ACTION: {
        draft.modalNotification = {
          ...draft.modalNotification,
          ...payload,
          isOpen: true,
        };
        break;
      }

      case globalConst.CLOSE_MODAL_NOTIFICATION_ACTION: {
        draft.modalNotification = {
          title: "",
          message: "",
          isOpen: false,
          isError: false,
        };
        break;
      }

      // Modal Share
      case globalConst.SET_MODAL_SHARE_ACTION: {
        draft.modalShare = {
          ...draft.modalShare,
          ...payload,
          isOpen: true,
        };
        break;
      }

      case globalConst.CLOSE_MODAL_SHARE_ACTION: {
        draft.modalShare = {
          isOpen: false,
          resourceId: null,
        };
        break;
      }

      // ---------- Redux And Saga ------- //
      case loginAction.REQUEST:
        draft.isLoading = true;
        draft.isLoggingIn = true;
        break;
      case loginAction.SUCCESS:
        draft.isLoggingIn = false;
        draft.isLoading = false;
        draft.isLoggedIn = isAuthenticated();
        draft.userInfo = JSON.parse(
          localStorage.getItem(USER_INFO_NAME) || "{}",
        );
        break;
      case loginAction.FAILURE:
        draft.isLoggingIn = false;
        draft.isLoading = false;
        draft.errorMessage = payload.message || "";
        break;

      // menu
      case getMenuAction.REQUEST:
        draft.isLoadingMenu = true;
        draft.isLoadedMenu = false;
        break;
      case getMenuAction.SUCCESS: {
        const menuActive = Object.entries(payload.router)
          .map(([key, value]) => [
            key,
            [...value].sort(compareToOrder).sort(compareToHidden),
          ])
          .reduce((acc, [key, value]) => ({ ...acc, ...{ [key]: value } }), {});

        // update local
        localStorageService.menu.set(menuActive);
        draft.isLoadingMenu = false;
        draft.isLoadedMenu = true;
        draft.menuTopBar = payload.menuTab;

        draft.menuRouter = menuActive;
        break;
      }
      case getMenuAction.FAILURE:
        draft.isLoadingMenu = false;
        draft.errorMessage = payload.message || "";
        break;

      // switch role
      case switchRoleAction.REQUEST:
        draft.isSwitching = true;
        break;
      case switchRoleAction.SUCCESS: {
        draft.isLoggedIn = isAuthenticated();
        draft.userInfo = JSON.parse(
          localStorage.getItem(USER_INFO_NAME) || "{}",
        );
        break;
      }
      case switchRoleAction.FAILURE: {
        draft.isSwitching = false;
        draft.errorMessage = payload.message || "";
        break;
      }

      // role all
      case getAllRolesAction.REQUEST: {
        draft.roleOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllRolesAction.SUCCESS: {
        draft.roleOpt = payload.roles;
        draft.isLoading = false;
        break;
      }
      case getAllRolesAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // department all
      case getAllDepartmentsAction.REQUEST: {
        draft.departmentOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllDepartmentsAction.SUCCESS: {
        draft.departmentOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllDepartmentsAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // subject all
      case getAllSubjectAction.REQUEST: {
        draft.subjectOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllSubjectAction.SUCCESS: {
        draft.subjectOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllSubjectAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // topic all
      case getAllTopicAction.REQUEST: {
        draft.topicOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllTopicAction.SUCCESS: {
        draft.topicOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllTopicAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // bank question all
      case getAllBankQuestionsAction.REQUEST: {
        draft.bankQuestionOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllBankQuestionsAction.SUCCESS: {
        draft.bankQuestionOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllBankQuestionsAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // users all
      case getAllUsersAction.REQUEST: {
        draft.userOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllUsersAction.SUCCESS: {
        draft.userOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllUsersAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // exam templates all
      case getAllExamTemplatesAction.REQUEST: {
        draft.examTemplatesOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllExamTemplatesAction.SUCCESS: {
        draft.examTemplatesOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllExamTemplatesAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // exam template detail
      case getExamTemplateDetailAction.REQUEST: {
        draft.examTemplateDetail = initialState.examTemplateDetail;
        draft.isLoading = true;
        break;
      }
      case getExamTemplateDetailAction.SUCCESS: {
        draft.examTemplateDetail = payload;
        draft.isLoading = false;
        break;
      }
      case getExamTemplateDetailAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // exam templates all
      case getAllQuestionsAction.REQUEST: {
        draft.questionsOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllQuestionsAction.SUCCESS: {
        draft.questionsOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllQuestionsAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // org chart
      case getAllOrgChartAction.REQUEST: {
        draft.orgChartOpt = initialState.orgChartOpt;
        draft.isLoading = true;
        break;
      }
      case getAllOrgChartAction.SUCCESS: {
        draft.orgChartOpt = payload;
        draft.isLoading = false;
        break;
      }
      case getAllOrgChartAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // districts all
      case getAllDistrictsAction.REQUEST: {
        draft.districtOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllDistrictsAction.SUCCESS: {
        draft.districtOpt = payload || [];
        draft.isLoading = false;
        break;
      }
      case getAllDistrictsAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // academic years all
      case getAllAcademicYearsAction.REQUEST: {
        draft.academicYearOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllAcademicYearsAction.SUCCESS: {
        draft.academicYearOpt = payload || [];
        draft.isLoading = false;
        break;
      }
      case getAllAcademicYearsAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // office utility types all
      case getAllOfficeUtilityTypesAction.REQUEST: {
        draft.officeUtilityTypeOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllOfficeUtilityTypesAction.SUCCESS: {
        draft.officeUtilityTypeOpt = payload || [];
        draft.isLoading = false;
        break;
      }
      case getAllOfficeUtilityTypesAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // task category all
      case getAllTaskCategoryAction.REQUEST: {
        draft.taskCategoryOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllTaskCategoryAction.SUCCESS: {
        draft.taskCategoryOpt = payload || [];
        draft.isLoading = false;
        break;
      }
      case getAllTaskCategoryAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // teachers all
      case getAllTeachersAction.REQUEST: {
        // draft.teachersOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllTeachersAction.SUCCESS: {
        draft.teachersOpt = payload || [];
        draft.isLoading = false;
        break;
      }
      case getAllTeachersAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // teachers all
      case getAllClassesAction.REQUEST: {
        draft.classesOpt = [];
        draft.isLoading = true;
        break;
      }
      case getAllClassesAction.SUCCESS: {
        draft.classesOpt = payload || [];
        draft.isLoading = false;
        break;
      }
      case getAllClassesAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      case lockStatusQIAction.SUCCESS: {
        draft.lockedQI = payload;
        break;
      }

      // exam period category dependency
      case getExamPeriodCategoryAction.REQUEST: {
        draft.examPeriodCategory = {};
        draft.isLoading = true;
        break;
      }
      case getExamPeriodCategoryAction.SUCCESS: {
        draft.examPeriodCategory = payload || {};
        draft.isLoading = false;
        break;
      }
      case getExamPeriodCategoryAction.FAILURE: {
        draft.errorMessage = payload.message || "";
        draft.isLoading = false;
        break;
      }

      // detail student
      case getDetailStudentAction.REQUEST: {
        draft.detailStudent = {};
        draft.isLoading = true;
        break;
      }
      case getDetailStudentAction.SUCCESS: {
        draft.detailStudent = payload || {};
        draft.isLoading = false;
        break;
      }
      case getDetailStudentAction.FAILURE: {
        draft.isLoading = false;
        break;
      }

      // award score range
      case awardScoreRangeAction.REQUEST: {
        draft.configRank = [];
        break;
      }
      case awardScoreRangeAction.SUCCESS: {
        draft.configRank = payload || [];
        break;
      }
      case awardScoreRangeAction.FAILURE: {
        break;
      }
      default:
        break;
    }
  });

export default appReducer;
