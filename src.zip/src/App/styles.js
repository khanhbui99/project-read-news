import { createGlobalStyle } from "styled-components";

import { VPB_THEMES } from "../utils/configs";
import { rem } from "../utils/constants";

const GlobalStyle = createGlobalStyle`
  html {
    scroll-behavior: smooth;
  }

  html,
  body {
    width: 100%;
    height: 100%;
    color: #2B343D;
    line-height: 1.5;
    font-size: ${rem.tablet}px;
    font-family: 'SVN_Gilroy', sans-serif;
  }

  @media screen and (min-width: 1281px) {  
    html,
    body {
      font-size: ${rem.hd}px;
    }
  }

  @media screen and (min-width: 1367px) {  
    html,
    body {
      font-size: ${rem.fhd}px;
    }
  }

  #app {
    min-height: 100%;
    min-width: 100%;
    font-family: 'SVN_Gilroy' !important;
  }

  .non-touch {
    pointer-events: none;
  }

  a {
    &:hover {
      text-decoration: none;
    }
  }

  a, button {
    color: ${VPB_THEMES.colors.green};
    &:focus, &:active {
      outline: 0;
    }
  }

  .textUnderline {
    text-decoration: underline;
  }

  img {
    max-width: 100%;
  }

  .pointer {
    cursor: pointer;
  }

  .cover-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
  }

  .cover-bg {
    background-size: cover;
    background-repeat: no-repeat;
    background-position: 50% 50%;
  }

  .text-center {
    text-align: center;
  }

  .MuiPopover-paper {
    border-radius: 8px !important;
  }

  .w-full {
    width: 100%;
  }

  .w-form {
    width: 80%;
    margin-bottom: 16px;
  }

  .h-full {
    height: 100%;
  }

  .grid-1 {
    display: grid;
    grid-template-columns: repeat(1, minmax(0, 1fr));
  }

  .grid-2 {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .grid-3 {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
  
  .grid-4 {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  
  .grid-5 {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
  } 

  .grid-6 {
    display: grid;
    grid-template-columns: repeat(6, minmax(0, 1fr));
  }

  .grid-7 {
    display: grid;
    grid-template-columns: repeat(7, minmax(0, 1fr));
  }

  .col-span-2 {
    grid-column: span 2 / span 2;
  }

  .col-span-3 {
    grid-column: span 3 / span 3;
  }  
  
  .col-span-4 {
    grid-column: span 4 / span 4;
  }
  
  .col-span-5 {
    grid-column: span 5 / span 5;
  }

  .col-span-6 {
    grid-column: span 6 / span 6;
  }

  .col-span-7 {
    grid-column: span 7 / span 7;
  }

  .col-span-8 {
    grid-column: span 8 / span 8;
  }
  
  .line-clamp {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
  }

  .gap-8 {
    gap: 8px;
  }

  .gap-16 {
    gap: 16px;
  }

  .gap-24 {
    gap: 24px;
  }
  
  .pt-24 {
    padding-top: 24px;
  }

  .m-0 {
    margin: 0;
  }
  
  .mt-16 {
    margin-top: 16px !important;
  }

  .mt-24 {
    margin-top: 24px !important;
  }

  .mt-8 {
    margin-top: 8px !important;
  }

  .fw6 {
    font-weight: 600;
  }

  .mb-0 {
    margin-bottom: 0;
  }

  .mb-16 {
    margin-bottom: 16px;
  }

  .mb-24 {
    margin-bottom: 24px;
  }

  .mb-32 {
    margin-bottom: 32px;
  }

  .mb-40 {
    margin-bottom: 40px;
  }

  .pl-0{
    padding-left: 0;
  }

  .flex {
    display: flex;
  }

  .flex-wrap {
    flex-wrap: wrap;
  }

  .justify-center {
    justify-content: center;
  }

  .justify-between {
    justify-content: space-between;
  }

  .items-center {
    align-items: center;
  }

  .items-start {
    align-items: flex-start;
  }

  .align-end {
    align-items: end;
  }

  .string {
    color: ${VPB_THEMES.colors.string};
  }
  
  .boolean {
    color: ${VPB_THEMES.colors.boolean};
  }
  
  .object {
    color: ${VPB_THEMES.colors.object};
  }
  
  .null {
    color: ${VPB_THEMES.colors.null};
  }
  
  .xml {
    color: ${VPB_THEMES.colors.xml};
  }
  
  & ::-webkit-scrollbar {
    width: 10px;
    height: 10px;
  }

  &::-webkit-scrollbar-thumb {
    background: #dddddd;
    border-radius: 10px;
  }

  &::-webkit-scrollbar-thumb:hover {
    background: #c1c1c1;
  }

  .copy-icon {
    svg {
      vertical-align: middle !important;
    }
  }

  .relative{
    position: relative;
  }

  .color-red {
    color: ${VPB_THEMES.colors.red}
  }

  .choice {
    .ck.ck-editor__main {
      .ck-editor__editable {
        min-height: auto ;
      }
    }
  }
`;

export default GlobalStyle;
