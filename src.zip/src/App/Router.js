import LoadingIndicator from "components/common/LoadingIndicator";
import Pages, { UnAuthPages } from "containers";
import NotFound from "containers/Common/404";
import AdminLayout from "layouts/AdminLayout";
import NormalLayout from "layouts/NormalLayout";
import { isArray } from "lodash";
import get from "lodash/get";
import size from "lodash/size";
import uniqBy from "lodash/uniqBy";
import PropTypes from "prop-types";
import { memo, useCallback, useEffect, useMemo, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Redirect,
  Route,
  Switch,
  matchPath,
  useLocation,
} from "react-router-dom";
import {
  IL_MENU_TYPE,
  adminPrefix,
  authPrefix,
  sysPrefix,
} from "utils/constants";
import { useSearchQuery } from "utils/helpers";
import { useInjectReducer } from "utils/injectReducer";
import { useInjectSaga } from "utils/injectSaga";

import { getAdminPaths, getDefaultMenu } from "./helpers";
import {
  OtherRouteConfig,
  ProfileRouter,
  UnAuthRouteConfig,
} from "./menuConfig";
import {
  getMenuAction,
  toggleMenuAction,
  toggleMenuParentAction,
} from "./store/actions";
import { MENU_TYPE } from "./store/constants";
import reducer from "./store/reducer";
import saga from "./store/saga";

const CustomRoute = memo(({ config = [], type }) => {
  const renderRoute = ({ id, url, component, child }) => {
    if (child?.length) {
      return child.flatMap((item) => renderRoute(item));
    }

    const pages = type === authPrefix ? UnAuthPages : { ...Pages, NotFound };
    const basePath =
      type === adminPrefix()
        ? adminPrefix()
        : type === sysPrefix
          ? sysPrefix
          : authPrefix;

    return (
      <Route
        key={id}
        path={`${basePath}${url}`}
        component={pages[component]}
        exact
      />
    );
  };

  return config.flatMap((route) => renderRoute(route));
});

CustomRoute.displayName = "CustomRoute";
CustomRoute.propTypes = {
  config: PropTypes.array,
  type: PropTypes.string,
};

export default function Router() {
  const dispatch = useDispatch();
  useInjectReducer({ key: "global", reducer });
  useInjectSaga({ key: "global", saga });

  const { pathname } = useLocation();
  const { currentPath } = useSearchQuery();
  const { menuType, isLoggedIn, menuRouter, menuTopBar, isLoadedMenu } =
    useSelector((state) => state.global);
  const defaultMenu = useRef(currentPath);

  useEffect(() => {
    if (!isLoggedIn) return;
    dispatch(getMenuAction(true));
  }, [dispatch, isLoggedIn]);

  const handleInitialMenuSetup = useCallback(() => {
    const hasMenuData = size(menuTopBar);
    if (!hasMenuData) return;

    const hasMenuType = menuTopBar.some(
      (item) =>
        item.value === menuType ||
        item.children?.some((child) => child.value === menuType)
    );

    if (hasMenuType && localStorage.getItem(IL_MENU_TYPE)) {
      return;
    }

    const [firstMenu] = menuTopBar;
    if (!firstMenu) return;

    dispatch(toggleMenuParentAction(firstMenu.value));
    if (firstMenu.children?.length) {
      dispatch(toggleMenuAction(firstMenu.children[0].value));
    }
  }, [dispatch, menuTopBar, menuType]);

  useEffect(() => {
    handleInitialMenuSetup();
  }, [handleInitialMenuSetup]);

  const adminMenu = useMemo(() => {
    const menuCommon = get(menuRouter, MENU_TYPE.common, []);
    const menuTypeData = isArray(menuRouter?.[menuType])
      ? menuRouter[menuType]
      : [];

    const router =
      size(menuRouter) && menuType
        ? [...menuTypeData, ...menuCommon, ProfileRouter]
        : [];

    if (router.length) {
      const paths = getAdminPaths(router);

      router.push({
        url: `*`,
        id: "notFound",
        hidden: true,
        component: paths.some((item) =>
          matchPath(pathname, {
            path: item,
          })
        )
          ? ""
          : "NotFound",
      });
    }
    defaultMenu.current = getDefaultMenu(router);
    return uniqBy(router, "id");
  }, [menuType, menuRouter, pathname]);

  const previousPath = useMemo(() => {
    const isNotAuthRoute = !UnAuthRouteConfig.some(({ path }) =>
      matchPath(pathname, { path, exact: true })
    );
    if (isNotAuthRoute) {
      return `${authPrefix}/login?currentPath=${pathname}`;
    }
    return `${authPrefix}/login`;
  }, [pathname]);

  const shouldRenderAdmin = isLoadedMenu && isLoggedIn;
  const shouldRenderAuth = !isLoggedIn;
  const shouldShowLoader = !isLoadedMenu && isLoggedIn;

  return (
    <>
      {shouldRenderAdmin && (
        <Switch>
          <Route
                  path={`/view-file`}
                  component={Pages.ViewFile}
                />
          <Route path={`${adminPrefix()}/:path?`}>
            <AdminLayout>
              <Switch>
                <CustomRoute type={adminPrefix()} config={adminMenu} />
                
              </Switch>
            </AdminLayout>
          </Route>
          <Route path={`${sysPrefix}/:path?`}>
            <NormalLayout>
              <Switch>
                <CustomRoute type={sysPrefix} config={OtherRouteConfig} />
                
              </Switch>
            </NormalLayout>
          </Route>
          {!!adminMenu.length && (
            <Route
              path="*"
              component={() => <Redirect to={defaultMenu.current} />}
            />
          )}
        </Switch>
      )}

      {shouldRenderAuth && (
        <Switch>
          <Route path={`${authPrefix}/:path?`}>
            <NormalLayout>
              <Switch>
                <CustomRoute type={authPrefix} config={UnAuthRouteConfig} />
              </Switch>
            </NormalLayout>
          </Route>
          <Route path="*" component={() => <Redirect to={previousPath} />} />
        </Switch>
      )}

      {shouldShowLoader && <LoadingIndicator />}
    </>
  );
}
