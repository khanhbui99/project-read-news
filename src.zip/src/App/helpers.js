import get from "lodash/get";
import size from "lodash/size";
import { adminPrefix } from "utils/constants";

// follow 1->n
export const compareToOrder = (a, b) => {
  if (a.orders < b.orders) return -1;

  if (a.orders > b.orders) return 1;

  return 0;
};

// folow false -> true
export const compareToHidden = (a, b) => Number(a.hidden) - Number(b.hidden);

export const getAdminPaths = (menus) => {
  const paths = [];
  const extractPaths = (menuItems) => {
    menuItems.forEach((item) => {
      if (item.url && !item.isDivider) {
        paths.push(`${adminPrefix()}${item.url}`);
      }
      if (item.child && item.child.length) {
        extractPaths(item.child);
      }
    });
  };
  extractPaths(menus);
  paths.push(`${adminPrefix()}/profile`);
  return paths;
};

export const getDefaultMenu = (menus) => {
  const menuFilter = menus ? menus.filter((item) => !item.isDivider) : [];
  const defaultMenu = size(get(menuFilter[0], "child"))
    ? get(menuFilter[0], "child")[0]
    : menuFilter[0];
  return `${adminPrefix()}${get(defaultMenu, "url")}`;
};
