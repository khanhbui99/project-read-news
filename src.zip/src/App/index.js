import ScrollToTop from "components/ScrollToTop";
import ScrollToTopButton from "components/ScrollToTopButton";
import SnackbarNotifier from "components/SnackbarNotifier";
import React, { useEffect } from "react";
// import { useSelector } from 'react-redux';

import { useDispatchRedux } from "utils/hooks/useRedux";

import Router from "./Router";
import GlobalStyle from "./styles";
import LoadingPage from "../components/LoadingPage";
import { allJsonAction, getAllTeachersAction } from "./store/actions";

export default function App() {
  // const fetchAllTeachers = useDispatchRedux(getAllTeachersAction);
  const fetchAllJson = useDispatchRedux(allJsonAction);

  useEffect(() => {
    // fetchAllTeachers();
    // fetchAllJson();
  }, []);

  return (
    <React.Fragment>
      <SnackbarNotifier />
      <GlobalStyle />
      <ScrollToTop />
      <ScrollToTopButton />
      <LoadingPage />
      <Router />
    </React.Fragment>
  );
}
