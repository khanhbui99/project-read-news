const OtherRouteConfig = [
  {
    id: Math.random(),
    url: `/change-password`,
    component: "ChangePasswordPage",
  },
  {
    id: Math.random(),
    url: `/faq`,
    component: "Dashboard",
  },
  {
    id: Math.random(),
    url: `/chat`,
    component: "ChatPage",
  },
];

const UnAuthRouteConfig = [
  {
    id: Math.random(),
    url: `/login`,
    component: "AuthLogin",
  },
  {
    id: Math.random(),
    url: `/signup`,
    component: "AuthLogin",
  },
];

const ProfileRouter = {
  url: "/profile",
  id: '/profile',
  hidden: true,
  component: "MyProfile",
};

export { ProfileRouter, OtherRouteConfig, UnAuthRouteConfig };
