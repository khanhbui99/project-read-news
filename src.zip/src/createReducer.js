/**
 * Combine all reducers in this file and export the combined reducers.
 */

import globalReducer from 'App/store/reducer';
import { connectRouter } from 'connected-react-router';
import { combineReducers } from 'redux';
import history from 'utils/history';

/**
 * Merges the main reducer with the router state and dynamically injected reducers
 */
export default function createReducer(injectedReducers = {}) {
  const rootReducer = combineReducers({
    global: globalReducer,
    router: connectRouter(history),
    ...injectedReducers,
  });

  return rootReducer;
}
