import { Avatar } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

const Title = styled.h3`
  margin: 0;
  padding: 0;
  font-size: ${({ $size = 18 }) => $size}px;
  text-align: ${({ $align = "left" }) => $align};
  font-weight: ${({ $weight = 600 }) => $weight};
  line-height: ${({ $line = "150%" }) => $line};
  text-transform: ${({ $transform = "none" }) => $transform};
  color: ${({ $color }) => $color || VPB_THEMES.colors.darkBlue};
`;

const Text = styled.p`
  margin: 0;
  padding: 0;
  font-size: ${({ $size = 14 }) => $size}px;
  text-align: ${({ $align = "left" }) => $align};
  font-weight: ${({ $weight = 500 }) => $weight};
  line-height: ${({ $line = "140%" }) => $line};
  color: ${({ $color }) =>
    $color
      ? VPB_THEMES.colors[$color]
        ? VPB_THEMES.colors[$color]
        : $color
      : VPB_THEMES.colors.darkBlue};
`;

const Link = styled(Text)`
  text-decoration: underline;
  cursor: pointer;
  color: ${({ $color }) => $color || VPB_THEMES.colors.green};
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

const BoxShadow = styled.div`
  border-radius: ${({ $borderRadius = 8 }) => $borderRadius}px;
  padding: ${({ $padding = 24 }) => $padding}px;
  background: ${({ $background = "#ffffff" }) => $background};
  border: ${({ $border = "1px solid rgba(102, 126, 234, 0.2)" }) => $border};
  box-shadow: ${({ $boxShadow = "0px 2px 16px rgba(0, 0, 0, 0.1)" }) =>
    $boxShadow};
  display: ${({ $display = "flex" }) => $display};
  flex-direction: ${({ $direction = "column" }) => $direction};
  gap: ${({ $gap = "0" }) => $gap}px;
`;

const AvatarName = styled(Avatar)`
  width: ${({ $size = 36 }) => $size}px;
  height: ${({ $size = 36 }) => $size}px;
  bgcolor: ${({ $bgcolor = VPB_THEMES.colors.blue } ) => $bgcolor};
  font-size: ${({ $fontSize = 13 }) => $fontSize}px;
  font-weight: ${({ $fontWeight = 600 }) => $fontWeight};
`;

export { Text, Title, Link, Form, BoxShadow, AvatarName };
