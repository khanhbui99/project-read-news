import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

const StatusStyled = styled.span`
  margin: auto;
  padding: 5px 10px;
  font-size: 12px;
  line-height: 18px;
  width: max-content;
  border-radius: 20px;
  text-transform: capitalize;
  background-color: ${({ $isActive }) =>
    $isActive ? VPB_THEMES.colors.table.headerBg : VPB_THEMES.colors.red};
`;

export default StatusStyled;
