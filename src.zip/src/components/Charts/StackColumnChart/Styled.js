import styled from "styled-components";

export const ChartWrapper = styled.div`
  width: 100%;
  overflow-x: ${(props) => (props.$verticalScroll ? "hidden" : "auto")};
  overflow-y: ${(props) => (props.$verticalScroll ? "auto" : "hidden")};
  max-height: ${(props) =>
    props.$verticalScroll ? props.$maxHeight || "360px" : "none"};
  position: relative;
  -webkit-overflow-scrolling: touch;

  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }

  &::-webkit-scrollbar-track {
    background: #f1f5f9;
    border-radius: 3px;
  }

  &::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 3px;
  }

  &:hover::-webkit-scrollbar-thumb {
    background: #94a3b8;
  }
`;

export const ChartContainer = styled.div`
  min-width: ${(props) => props.$minWidth || "100%"};
  width: ${(props) => props.$width || "auto"};
  min-height: ${(props) => props.$minHeight || "450px"};
  position: relative;

  @media (max-width: 768px) {
    min-height: ${(props) => props.$minHeight || "450px"};
  }
`;
