import { Box, Skeleton } from "@mui/material";
import PropTypes from "prop-types";

/**
 * Skeleton loading cho chart
 * 
 * @param {number} height - Chiều cao của skeleton (mặc định: 400px)
 * @param {number} bars - Số lượng cột skeleton (mặc định: 8)
 */
const ChartSkeleton = ({ height = 400, bars = 8 }) => {
  const barHeights = Array.from({ length: bars }, () => Math.random() * 0.6 + 0.3);

  return (
    <Box
      sx={{
        width: "100%",
        height: `${height}px`,
        display: "flex",
        flexDirection: "column",
        gap: 2,
        padding: 2,
      }}
    >
      {/* X-axis labels skeleton */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-end",
          height: "100%",
          gap: 1,
        }}
      >
        {barHeights.map((heightRatio, index) => (
          <Box
            key={index}
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 1,
              flex: 1,
            }}
          >
            <Skeleton
              variant="rectangular"
              width="100%"
              height={`${heightRatio * 100}%`}
              sx={{
                borderRadius: "4px 4px 0 0",
                maxHeight: "80%",
              }}
            />
            <Skeleton variant="text" width="60%" height={20} />
          </Box>
        ))}
      </Box>

      {/* Legend skeleton */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: 2,
          marginTop: "auto",
        }}
      >
        {Array.from({ length: 3 }).map((_, index) => (
          <Box key={index} sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Skeleton variant="rectangular" width={16} height={16} />
            <Skeleton variant="text" width={60} height={20} />
          </Box>
        ))}
      </Box>
    </Box>
  );
};

ChartSkeleton.propTypes = {
  height: PropTypes.number,
  bars: PropTypes.number,
};

export default ChartSkeleton;

