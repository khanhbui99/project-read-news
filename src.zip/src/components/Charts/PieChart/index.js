import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import PropTypes from "prop-types";
import { useMemo } from "react";
import { VPB_THEMES } from "utils/configs";

/**
 * Component biểu đồ tròn (pie chart) có thể tái sử dụng
 *
 * @param {Array} data - Mảng dữ liệu để hiển thị. Format: [{name: string, y: number, color?: string}, ...]
 *                       hoặc object với các field: {public: number, private: number, autonomous: number, ...}
 * @param {string} seriesName - Tên series (mặc định: "Loại hình")
 * @param {string} tooltipFormat - Format cho tooltip (mặc định: "{point.name}: {point.y}<br/>Tỷ lệ: {point.percentage:.1f}%")
 * @param {string} dataLabelFormat - Format cho data label (mặc định: "{point.name}<br/>{point.y}<br/>({point.percentage:.1f}%)")
 * @param {string} tooltipUnit - Đơn vị hiển thị trong tooltip (mặc định: "")
 * @param {Function} onPointClick - Callback khi click vào slice
 * @param {Object} chartConfig - Cấu hình bổ sung cho chart (responsive, legend, etc.)
 */
const PieChart = ({
  data = [],
  seriesName = "Loại hình",
  tooltipFormat = null,
  dataLabelFormat = null,
  tooltipUnit = "",
  onPointClick = null,
  chartConfig = {},
}) => {
  const chartOptions = useMemo(() => {
    // Xử lý data - hỗ trợ cả array và object
    let pieData = [];
    let hasColors = false;

    if (Array.isArray(data)) {
      // Nếu là array, sử dụng trực tiếp
      pieData = data;
      hasColors = pieData.some((item) => item.color);
    } else if (typeof data === "object" && data !== null) {
      // Nếu là object, convert sang array format
      // Ví dụ: {public: 45, private: 25, autonomous: 15}
      // -> [{name: "Công lập", y: 45}, {name: "Tư thục", y: 25}, {name: "Tự chủ", y: 15}]
      pieData = Object.entries(data)
        .filter(([_, value]) => typeof value === "number" && value >= 0)
        .map(([key, value]) => ({
          name: key.charAt(0).toUpperCase() + key.slice(1),
          y: value,
        }));
    }

    // Đảm bảo có dữ liệu
    if (!Array.isArray(pieData) || pieData.length === 0) {
      return {
        chart: {
          type: "pie",
          backgroundColor: "transparent",
          style: {
            fontFamily: "SVN_Gilroy, sans-serif",
          },
        },
        title: { text: null },
        credits: { enabled: false },
        series: [],
      };
    }

    // Kiểm tra xem tất cả giá trị có đều bằng 0 không
    const totalSum = pieData.reduce(
      (sum, item) => sum + (Number(item.y) || 0),
      0
    );
    const allZero = totalSum === 0 && pieData.length > 0;

    // Merge với chartConfig từ props
    const defaultConfig = {
      chart: {
        type: "pie",
        backgroundColor: "transparent",
        style: {
          fontFamily: "SVN_Gilroy, sans-serif",
        },
        animation: false,
      },
      title: {
        text: null,
      },
      subtitle: allZero
        ? {
            text: "Tất cả giá trị đều bằng 0",
            style: {
              fontSize: "14px",
              fontWeight: 500,
              color: "#8a9ba8",
              fontFamily: "SVN_Gilroy, sans-serif",
            },
            verticalAlign: "middle",
            y: 25,
            floating: true,
          }
        : { text: null },
      credits: { enabled: false },
      tooltip: {
        backgroundColor: "rgba(255, 255, 255, 0.95)",
        borderColor: VPB_THEMES.colors.green,
        borderRadius: 8,
        borderWidth: 2,
        style: {
          fontSize: "13px",
          fontFamily: "SVN_Gilroy, sans-serif",
        },
        pointFormat:
          tooltipFormat ||
          `<b>{point.name}</b>: {point.y}${
            tooltipUnit ? ` ${tooltipUnit}` : ""
          }<br/>Tỷ lệ: <b>{point.percentage:.1f}%</b>`,
        useHTML: true,
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: onPointClick ? "pointer" : "default",
          minPointSize: allZero ? 10 : undefined, // Đảm bảo các slice có giá trị 0 vẫn hiển thị
          dataLabels: {
            enabled: !allZero, // Tắt data labels khi tất cả bằng 0
            format:
              dataLabelFormat ||
              `<b>{point.name}</b><br/>{point.y}${
                tooltipUnit ? ` ${tooltipUnit}` : ""
              }<br/>({point.percentage:.1f}%)`,
            style: {
              fontSize: "12px",
              fontWeight: 600,
              color: "#0b263d",
              textOutline: "none",
            },
            distance: 20,
          },
          showInLegend: true,
          borderWidth: 2,
          borderColor: "#ffffff",
          point: {
            events: {
              click: function () {
                if (onPointClick) {
                  onPointClick(this.name, this.y, this.percentage);
                }
              },
            },
          },
        },
      },
      legend: {
        align: "right",
        verticalAlign: "middle",
        layout: "vertical",
        itemStyle: {
          fontSize: "13px",
          fontWeight: 600,
          color: "#0b263d",
        },
        itemHoverStyle: {
          color: VPB_THEMES.colors.green,
        },
        labelFormatter: function () {
          // Hiển thị tên trong legend ngay cả khi giá trị bằng 0
          return this.name;
        },
      },
      series: [
        {
          name: seriesName,
          // Chỉ dùng colorByPoint nếu data không có màu sẵn
          colorByPoint: !hasColors,
          data: pieData,
          showInLegend: true, // Đảm bảo tất cả items hiển thị trong legend
          ignoreHiddenPoint: false, // Đảm bảo các điểm có giá trị 0 vẫn hiển thị trong legend
        },
      ],
      responsive: {
        rules: [
          {
            condition: { maxWidth: 1024 },
            chartOptions: {
              legend: {
                align: "center",
                verticalAlign: "bottom",
                layout: "horizontal",
                itemStyle: { fontSize: "12px" },
              },
              plotOptions: {
                pie: {
                  dataLabels: {
                    style: { fontSize: "11px" },
                    distance: 15,
                  },
                },
              },
            },
          },
          {
            condition: { maxWidth: 768 },
            chartOptions: {
              legend: {
                align: "center",
                verticalAlign: "bottom",
                layout: "horizontal",
                itemStyle: { fontSize: "11px" },
              },
              plotOptions: {
                pie: {
                  dataLabels: {
                    style: { fontSize: "10px" },
                    distance: 10,
                  },
                },
              },
            },
          },
          {
            condition: { maxWidth: 480 },
            chartOptions: {
              legend: {
                align: "center",
                verticalAlign: "bottom",
                layout: "horizontal",
                itemStyle: { fontSize: "10px" },
              },
              plotOptions: {
                pie: {
                  dataLabels: {
                    style: { fontSize: "9px" },
                    distance: 8,
                  },
                },
              },
            },
          },
        ],
      },
    };

    // Deep merge với chartConfig từ props
    const mergeConfig = (defaultObj, customObj) => {
      const result = { ...defaultObj };
      for (const key in customObj) {
        if (
          typeof customObj[key] === "object" &&
          !Array.isArray(customObj[key]) &&
          customObj[key] !== null
        ) {
          result[key] = mergeConfig(defaultObj[key] || {}, customObj[key]);
        } else {
          result[key] = customObj[key];
        }
      }
      return result;
    };

    return mergeConfig(defaultConfig, chartConfig);
  }, [
    data,
    seriesName,
    tooltipFormat,
    dataLabelFormat,
    tooltipUnit,
    onPointClick,
    chartConfig,
  ]);

  return (
    <HighchartsReact
      highcharts={Highcharts}
      options={chartOptions}
      containerProps={{ style: { width: "100%", height: "100%" } }}
    />
  );
};

PieChart.propTypes = {
  data: PropTypes.oneOfType([
    PropTypes.arrayOf(
      PropTypes.shape({
        name: PropTypes.string.isRequired,
        y: PropTypes.number.isRequired,
        color: PropTypes.string,
      })
    ),
    PropTypes.object, // Object với các field như {public: number, private: number, ...}
  ]).isRequired,
  seriesName: PropTypes.string,
  tooltipFormat: PropTypes.string,
  dataLabelFormat: PropTypes.string,
  tooltipUnit: PropTypes.string,
  onPointClick: PropTypes.func,
  chartConfig: PropTypes.object,
};

export default PieChart;
