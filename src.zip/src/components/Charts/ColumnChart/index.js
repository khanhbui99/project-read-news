import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import PropTypes from "prop-types";
import { useMemo } from "react";
import { VPB_THEMES } from "utils/configs";

import { ChartWrapper, ChartContainer } from "./Styled";

/**
 * Component biểu đồ cột (grouped, không stacked) có thể tái sử dụng
 * 
 * @param {Array} data - Mảng dữ liệu để hiển thị
 * @param {Array} series - Mảng cấu hình các series (mỗi series có: name, dataKey, color)
 * @param {string} categorieField - Key để lấy categories từ data (mặc định: 'ward' hoặc 'name')
 * @param {string} yAxisTitle - Tiêu đề trục Y (mặc định: 'Số lượng')
 * @param {Function} onPointClick - Callback khi click vào cột
 * @param {Object} chartConfig - Cấu hình bổ sung cho chart (responsive, tooltip, etc.)
 */
const ColumnChart = ({
  data = [],
  series = [],
  categorieField = null,
  yAxisTitle = "Số lượng",
  onPointClick = null,
  chartConfig = {},
}) => {
  const chartOptions = useMemo(() => {
    // Đảm bảo data là array và có format đúng
    if (!Array.isArray(data) || data.length === 0 || !Array.isArray(series) || series.length === 0) {
      return {
        chart: {
          type: "column",
          backgroundColor: "transparent",
          style: {
            fontFamily: "SVN_Gilroy, sans-serif",
          },
        },
        title: { text: null },
        credits: { enabled: false },
        series: [],
      };
    }

    // Xác định key để lấy categories
    const categoryKey = categorieField || (data[0]?.ward ? "ward" : "name");
    const categories = data.map((item) => item[categoryKey] || "");

    // Tạo data cho từng series
    const seriesData = series.map((serie) => {
      // Hỗ trợ cả dataKey (string) và dataExtractor (function)
      const extractData = typeof serie.dataKey === "function" 
        ? serie.dataKey 
        : (item) => Number(item[serie.dataKey]) || 0;
      
      return {
        name: serie.name,
        data: data.map(extractData),
        showInLegend: serie.showInLegend !== false,
        color: serie.color || VPB_THEMES.colors.blue || "#2563EB",
      };
    });

    // Tính toán độ rộng cột dựa trên số lượng categories
    const categoryCount = categories.length;
    const isBar = chartConfig?.chart?.type === "bar";
    const minWidth = categoryCount > 50 ? 20 : categoryCount > 30 ? 40 : 80;
    const maxWidth = categoryCount > 50 ? 50 : categoryCount > 30 ? 80 : 100;
    const COLUMN_SCROLL_MIN = 8;
    const chartWidth =
      !isBar && categoryCount > COLUMN_SCROLL_MIN
        ? Math.max(categoryCount * (maxWidth + 10), categoryCount * 72, 640)
        : null;

    // Merge với chartConfig từ props
    const defaultConfig = {
      chart: {
        type: "column",
        backgroundColor: "transparent",
        style: {
          fontFamily: "SVN_Gilroy, sans-serif",
        },
        animation: false,
        boostThreshold: 100,
        width: chartWidth,
      },
      title: { text: null },
      credits: { enabled: false },
      xAxis: {
        categories: categories,
        labels: {
          style: {
            fontSize: "13px",
            fontWeight: 600,
            color: "#0b263d",
          },
          rotation: categories.length <= 2 ? 0 : categories.length > 8 ? -45 : 0,
          autoRotation: categories.length > 2 ? [-45, -90] : [0],
          autoRotationLimit: categories.length > 2 ? 80 : undefined,
        },
        scrollbar: {
          enabled: false,
        },
      },
      yAxis: {
        min: 0,
        title: {
          text: yAxisTitle,
          style: {
            fontSize: "14px",
            fontWeight: 600,
            color: "#526779",
          },
        },
        labels: {
          style: {
            fontSize: "12px",
            color: "#526779",
          },
        },
        gridLineColor: "#e8eef3",
      },
      legend: {
        enabled: seriesData.length > 1,
        align: "center",
        verticalAlign: "bottom",
        itemStyle: {
          fontSize: "13px",
          fontWeight: 600,
          color: "#0b263d",
        },
        itemHoverStyle: {
          color: VPB_THEMES.colors.green,
        },
      },
      tooltip: {
        shared: true,
        backgroundColor: "rgba(255, 255, 255, 0.95)",
        borderColor: VPB_THEMES.colors.green,
        borderRadius: 8,
        borderWidth: 2,
        style: {
          fontSize: "13px",
          fontFamily: "SVN_Gilroy, sans-serif",
        },
        headerFormat: '<span style="font-size: 13px; font-weight: 700;">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0; font-weight: 600;"><b>{point.y}</b></td></tr>',
        footerFormat: "</table>",
        useHTML: true,
      },
      plotOptions: {
        // Bar không nhận option của plotOptions.column → đặt ở series cho mọi type
        series: {
          cursor: onPointClick ? "pointer" : "default",
          point: {
            events: {
              click: function () {
                if (onPointClick) {
                  onPointClick(this.category, {
                    seriesName: this.series?.name,
                    value: this.y,
                    index: this.index,
                  });
                }
              },
            },
          },
        },
        column: {
          // Không có stacking - grouped columns
          dataLabels: {
            enabled: true,
            style: {
              fontSize: "11px",
              fontWeight: 600,
              textOutline: "none",
              color: "#333",
            },
            formatter: function () {
              return this.y > 0 ? this.y : "";
            },
          },
          borderRadius: 6,
          borderWidth: 0,
          minPointWidth: minWidth,
          maxPointWidth: maxWidth,
          groupPadding: categoryCount > 50 ? 0.02 : categoryCount > 30 ? 0.05 : 0.1,
          pointPadding: categoryCount > 50 ? 0.02 : categoryCount > 30 ? 0.05 : 0.1,
          point: {
            events: {
              click: function () {
                if (onPointClick) {
                  onPointClick(this.category, {
                    seriesName: this.series?.name,
                    value: this.y,
                    index: this.index,
                  });
                }
              },
            },
          },
          cursor: onPointClick ? "pointer" : "default",
        },
      },
      series: seriesData,
      responsive: {
        rules: [
          {
            condition: { maxWidth: 1024 },
            chartOptions: {
              legend: {
                layout: "horizontal",
                align: "center",
                verticalAlign: "bottom",
                itemStyle: { fontSize: "12px" },
              },
              xAxis: {
                labels: {
                  style: { fontSize: "12px" },
                  rotation: -45,
                },
              },
            },
          },
          {
            condition: { maxWidth: 768 },
            chartOptions: {
              legend: {
                layout: "horizontal",
                align: "center",
                verticalAlign: "bottom",
                itemStyle: { fontSize: "11px" },
              },
              xAxis: {
                labels: {
                  style: { fontSize: "11px" },
                  rotation: -45,
                },
              },
              yAxis: {
                title: { text: null },
              },
              plotOptions: {
                column: {
                  dataLabels: {
                    style: { fontSize: "10px" },
                  },
                },
              },
            },
          },
          {
            condition: { maxWidth: 480 },
            chartOptions: {
              legend: {
                layout: "horizontal",
                align: "center",
                verticalAlign: "bottom",
                itemStyle: { fontSize: "10px" },
              },
              xAxis: {
                labels: {
                  style: { fontSize: "10px" },
                  rotation: -45,
                },
              },
              plotOptions: {
                column: {
                  dataLabels: {
                    style: { fontSize: "9px" },
                  },
                },
              },
            },
          },
        ],
      },
    };

    // Deep merge với chartConfig từ props
    const mergeConfig = (defaultObj, customObj) => {
      const result = { ...defaultObj };
      for (const key in customObj) {
        if (typeof customObj[key] === "object" && !Array.isArray(customObj[key]) && customObj[key] !== null) {
          result[key] = mergeConfig(defaultObj[key] || {}, customObj[key]);
        } else {
          result[key] = customObj[key];
        }
      }
      return result;
    };

    const merged = mergeConfig(defaultConfig, chartConfig);
    const isHorizontal = merged.chart?.type === "bar";
    const BAR_SCROLL_MIN = 6;
    const BAR_ROW_HEIGHT = 40;
    const BAR_CHART_PADDING = 80;

    if (isHorizontal) {
      const contentHeight = Math.max(
        Number(merged.chart?.height) || 320,
        categoryCount * BAR_ROW_HEIGHT + BAR_CHART_PADDING,
      );
      merged.chart = {
        ...merged.chart,
        height: contentHeight,
      };
      delete merged.chart.width;
      if (merged.xAxis) {
        merged.xAxis = {
          ...merged.xAxis,
          scrollbar: { enabled: false },
        };
      }
      merged.__scrollMeta = {
        verticalScroll: categoryCount > BAR_SCROLL_MIN,
        maxHeight: "360px",
        containerWidth: "100%",
      };
    } else {
      const maxW = categoryCount > 50 ? 50 : categoryCount > 30 ? 80 : 100;
      const needsHScroll = categoryCount > COLUMN_SCROLL_MIN;
      const width = needsHScroll
        ? Math.max(categoryCount * (maxW + 10), categoryCount * 72, 640)
        : null;
      if (width && !chartConfig?.chart?.width) {
        merged.chart = { ...merged.chart, width };
      }
      if (merged.chart?.width == null) {
        const { width: _w, ...chartRest } = merged.chart || {};
        merged.chart = chartRest;
      }
      merged.__scrollMeta = {
        verticalScroll: false,
        maxHeight: undefined,
        containerWidth: merged.chart?.width
          ? `${merged.chart.width}px`
          : "100%",
      };
    }

    return merged;
  }, [data, series, categorieField, yAxisTitle, onPointClick, chartConfig]);

  const scrollMeta = chartOptions?.__scrollMeta || {
    verticalScroll: false,
    containerWidth: "100%",
  };

  const renderOptions = useMemo(() => {
    if (!chartOptions?.__scrollMeta) return chartOptions;
    const { __scrollMeta, ...rest } = chartOptions;
    return rest;
  }, [chartOptions]);

  return (
    <ChartWrapper
      $verticalScroll={scrollMeta.verticalScroll}
      $maxHeight={scrollMeta.maxHeight}
    >
      <ChartContainer
        $width={scrollMeta.containerWidth}
        $minWidth={scrollMeta.containerWidth}
      >
        <HighchartsReact
          highcharts={Highcharts}
          options={renderOptions}
          containerProps={{ style: { width: "100%", height: "100%" } }}
        />
      </ChartContainer>
    </ChartWrapper>
  );
};

ColumnChart.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object).isRequired,
  series: PropTypes.arrayOf(
    PropTypes.shape({
      name: PropTypes.string.isRequired,
      dataKey: PropTypes.oneOfType([PropTypes.string, PropTypes.func]).isRequired,
      color: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object, // linearGradient object
      ]),
      showInLegend: PropTypes.bool,
    })
  ).isRequired,
  categorieField: PropTypes.string,
  yAxisTitle: PropTypes.string,
  onPointClick: PropTypes.func,
  chartConfig: PropTypes.object,
};

export default ColumnChart;

