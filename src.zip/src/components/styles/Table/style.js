import { TableCell } from '@mui/material';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

const TableStyle = styled.div`
  padding: 1px;
  position: relative;
  margin-bottom: 34px;

  &:before {
    inset: 0;
    content: '';
    z-index: -1;
    border-radius: 8px;
    position: absolute;
  }

  .table {
    box-shadow: none;
    min-height: ${p => (p.open ? '440px' : 'auto')};

    @media screen and (min-width: 1281px) {
      min-height: ${p => (p.open ? '470px' : 'auto')};
    }

    @media screen and (min-width: 1367px) {
      min-height: ${p => (p.open ? '500px' : 'auto')};
    }

    &::-webkit-scrollbar-track {
      background: #ffffff;
      border-bottom-left-radius: 7px;
      border-bottom-right-radius: 7px;
    }

    &__header {
      font-family: 'SVN_Gilroy', sans-serif;
    }

    .MuiTableCell-root {
      border: none;
      padding-top: 0;
      padding-right: 0;
      font-weight: 500;
      padding-bottom: 0;
      font-family: 'SVN_Gilroy', sans-serif;
      font-size: ${pxToRem(13)};
      padding-top: ${pxToRem(6)};
      padding-left: ${pxToRem(12)};
      padding-bottom: ${pxToRem(6)};

      &:last-child {
        padding-right: ${pxToRem(12)};
      }

      &.table__header-title {
        font-family: SVN_Gilroy;
        font-size: 14px;
        font-weight: 500;
        line-height: 15.4px;
        text-align: left;
        text-underline-position: from-font;
        text-decoration-skip-ink: none;
        color: rgba(18, 22, 25, 1);

        text-wrap: nowrap;
        /* padding-top: 8.5px;
        padding-bottom: 8.5px; */
        font-size: ${pxToRem(14)};
      }
    }
  }

  .loading {
    inset: 0;
    top: 54px;
    display: flex;
    border-radius: 8px;
    position: absolute;
    align-items: center;
    justify-content: center;
    background-color: rgb(255, 255, 255, 0.3);
  }
`;

export default TableStyle;

export const TableCellContent = styled.div`
  display: flex;
  min-height: 36px;
  align-items: center;
  font-weight: 400;
  ${p => (p.align === 'right' ? 'justify-content: right;' : '')}
  &.header {
    font-weight: 500;
  }
`;

export const TableCellEmpty = styled(TableCell)`
  padding-top: ${({ $pt = 204 }) => $pt}px !important;
  padding-bottom: ${({ $pb = 204 }) => $pb}px !important;
  font-size: ${pxToRem(16)} !important;
  color: ${VPB_THEMES.colors.gray[300]} !important;
`;
