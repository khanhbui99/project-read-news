import DotIcon from 'assets/icons/common/dot.svg';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs';

export const DetailProfileWraper = styled.div`
  position: relative;
  p {
    margin-top: 0px;
    margin-bottom: 8px;
  }
  .MuiGrid-root {
    &.profile {
      width: 100%;
      padding-top: 0px !important;
      position: absolute;
      right: 0px;
      top: 0px;
    }
  }
`;

export const Header = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-bottom: 16px;
  .alert {
    background: rgba(255, 251, 240, 1);
    padding: 8px 16px;
    border-radius: 8px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    img {
      margin-right: 8px;
    }
  }
`;

export const TopicContent = styled.div`
  color: ${VPB_THEMES.colors.darkBlue};
  font-family: 'SVN_Gilroy', sans-serif;
  font-size: 16px;
  line-height: 24px;
  font-style: normal;
  font-weight: 600;
  line-height: 150%;
  margin-bottom: 10px;
`;

export const GroupRow = styled.div`
  padding: 16px;
  background: rgba(249, 249, 249, 1);
  border-radius: 8px;
  margin-bottom: 24px;
  .groupCol {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    @media (max-width: 1280px) {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }
  &.rowInsideBox {
    margin-bottom: 0px;
    padding: 0px 16px;
  }
`;

export const TextData = styled.p`
  color: var(--500, #181b1d);
  font-family: 'SVN_Gilroy', sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: 150%;
  :before {
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: #181b1d;
    display: inline-block;
    margin: 0 10px 3px 0;
  }
  span {
    color: var(--500, #181b1d);
    font-family: 'SVN_Gilroy', sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 150%; /* 21px */
  }
`;

export const TextUnderlined = styled.p`
  color: ${VPB_THEMES.colors.darkBlue};
  font-family: 'SVN_Gilroy', sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: 21px;
  /* text-decoration-line: underline; */
  margin-bottom: 8px;
`;

export const GroupText = styled.div`
  margin-bottom: 10px;
`;

export const GroupDocument = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 8px 16px;
  background: rgba(246, 249, 251, 1);
  border: 1px solid rgba(242, 244, 248, 1);
  border-radius: 100px;
  margin-bottom: 16px;
  .nameImage {
    color: ${VPB_THEMES.colors.neutral};
    font-family: 'SVN_Gilroy', sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 150%;
    margin-bottom: 0px;
  }
`;

export const TextChild = styled.p`
  color: var(--500, #181b1d);
  font-family: 'SVN_Gilroy', sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: 150%;
  :before {
    content: '';
    background: url(${DotIcon});
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: #acacac;
    display: inline-block;
    margin: 0 10px 3px 0;
  }
  span {
    color: var(--500, #181b1d);
    font-family: 'SVN_Gilroy', sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 700;
    line-height: 150%; /* 21px */
  }
`;
