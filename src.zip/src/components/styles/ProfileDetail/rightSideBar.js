import styled from 'styled-components';

export const ProfileWraper = styled.div`
  width: 100%;
  height: fit-content;
  border-radius: 8px;
  background: var(--100, #f9f9f9);
  .profile-content {
    padding: 24px 16px;
    display: flex;
    flex-direction: column;
    gap: 24px;
  }
  .text-header {
    font-size: 15px;
  }
  .text-value {
    font-family: SVN-Gilroy;
    font-size: 14px;
    font-weight: 600;
    line-height: 21px;
  }
  .history-link {
    cursor: pointer;
    font-weight: 500;
    line-height: 21px;
    text-decoration-line: underline;
    text-decoration-style: solid;
    color: rgba(93, 112, 128, 1);
  }
`;

export const Header = styled.div`
  background: rgba(93, 112, 128, 1);
  padding: 16px;
  border-radius: 8px 8px 0px 0px;
  display: flex;
  gap: 16px;
`;

export const Avatar = styled.div`
  padding: 5px;
  background: rgba(234, 238, 249, 0.1);
  border-radius: 50px;
  img {
    width: 44px;
    height: 44px;
  }
`;

export const UserHeaderInfo = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  .row {
    display: flex;
    align-items: center;
    gap: 8px;
  }
`;

export const TextHeader = styled.div`
  color: var(--white, #fff);
  font-family: 'SVN_Gilroy', sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  &.fullName {
    font-size: 16px;
    font-weight: 600;
    line-height: 16.8px;
  }
  &.phone {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 4px 10px;
    border-radius: 50px;
    background: rgba(129, 146, 163, 1);
  }
`;

export const Topic = styled.div`
  font-family: SVN-Gilroy;
  font-size: 16px;
  font-weight: 600;
  line-height: 24px;
  margin-bottom: 10px;
`;

export const History = styled.div`
  display: flex;
  align-items: center;
  padding: 14.5px 16px;
  background: rgba(242, 244, 248, 1);
  justify-content: space-between;
`;
