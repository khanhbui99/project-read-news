import styled from 'styled-components';
import { MINI_SIDEBAR_WITH, SIDEBAR_WITH } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

const PaginationStyle = styled.div`
  left: ${p => (p.isMiniSidebar ? MINI_SIDEBAR_WITH : SIDEBAR_WITH)}px;
  right: 0;
  bottom: 0;
  z-index: 1;
  display: flex;
  position: fixed;
  justify-content: center;
  background-color: #ffffff;
  padding: ${pxToRem(24)} 0;

  .MuiPaginationItem-root {
    line-height: 1.5;
  }
`;

PaginationStyle.shouldForwardProp = (prop) => !["isMiniSidebar"].includes(prop);
export default PaginationStyle;
