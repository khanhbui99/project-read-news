import Button from 'components/common/AppButton';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

export const HeaderStyle = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: ${pxToRem(16)} !important;
  justify-content: space-between;

  h2 {
    margin: 0;
    font-weight: 600;
    line-height: 36px;
    font-size: ${pxToRem(36)};
  }

  h3 {
    margin: 0;
    font-weight: 600;
    line-height: 24px;
    font-size: ${pxToRem(24)};
  }

  .btns {
    gap: 16px;
    display: flex;
  }
`;

export const HeaderButtonStyle = styled(Button)`
  padding-left: 16px;
  padding-right: 16px;
`;

export const CodeProfile = styled.div`
  color: var(--500, #181b1d);
  font-family: 'SVN_Gilroy', sans-serif;
  font-size: 36px;
  line-height: 36px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
  margin: 0px 0px 16px;
`;

export const SummaryStyle = styled.h3`
  margin-top: 0;
  font-weight: 600;
  font-size: ${pxToRem(20)};
  margin-bottom: ${pxToRem(24)};

  > span {
    color: ${VPB_THEMES.colors.green};
  }
`;