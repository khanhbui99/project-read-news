import styled from 'styled-components';

const FilterStyle = styled.form`
  display: grid;
  gap: 8px;
  margin-bottom: 16px;
  grid-template-columns: repeat(${({ cols = 19 }) => cols}, minmax(0, 1fr));
`;

export default FilterStyle;
