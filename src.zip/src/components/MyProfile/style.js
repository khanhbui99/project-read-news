import styled from 'styled-components';
import { PROFILE_HEIGHT, PROFILE_PADDING_TOP } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

const ProfileStyle = styled.div`
  display: flex;
  padding: ${PROFILE_PADDING_TOP}px 8px 0 8px;
  justify-content: ${p => (p.isMiniSidebar ? 'center' : 'space-between')};
  gap: 10px;
  min-width: 205px;
`;

const ProfileLeftStyle = styled.div`
  display: flex;
  align-items: center;

  h4,
  p {
    margin: 0;
  }

  p {
    font-weight: 500;
    font-size: ${pxToRem(12)};
  }

  img {
    width: ${PROFILE_HEIGHT}px;
    height: ${PROFILE_HEIGHT}px;
    margin-right: ${p => (p.isMiniSidebar ? 0 : 8)}px;
  }
`;

ProfileStyle.shouldForwardProp = (prop) => !["isMiniSidebar"].includes(prop);
ProfileLeftStyle.shouldForwardProp = (prop) => !["isMiniSidebar"].includes(prop);

export { ProfileLeftStyle }
export default ProfileStyle;

