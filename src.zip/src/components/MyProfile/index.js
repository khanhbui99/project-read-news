import { IconButton } from "@mui/material";
import { logoutAction } from "App/store/actions";
import SidebarIcons from "assets/icons/sidebar";
import SidebarImg from "assets/images/sidebar";
import React, { useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";

import ProfileStyle, { ProfileLeftStyle } from "./style";
import Tooltip from "../common/Tooltip";
import { shortcutName } from "utils/helpers";

const MyProfile = ({ disableCollapsed = false, style, open }) => {
  const dispatch = useDispatch();
  const { isMiniSidebar, userInfo } = useSelector((state) => state.global);

  const name = useMemo(() => userInfo.name, [userInfo.name]);
  const isCollapsed = useMemo(
    () => isMiniSidebar && !disableCollapsed,
    [isMiniSidebar, disableCollapsed],
  );

  const listRole = useMemo(
    () => userInfo.listRole || "admin",
    [userInfo.listRole],
  );

  const handlerLogout = () => {
    // TODO: send to logout API
    dispatch(logoutAction());
  };

  const urlAvatar = useMemo(() => {
    switch (String(userInfo?.listRole).toLowerCase()) {
      case "hiệu trưởng":
        return SidebarImg.ht;
      // case "phó hiệu trưởng":
      //   return SidebarImg.pht;
      default:
        return null;
    }
  }, [userInfo?.listRole]);

  return (
    <ProfileStyle isMiniSidebar={isCollapsed} style={style}>
      <ProfileLeftStyle isMiniSidebar={isCollapsed}>
        {urlAvatar ? <img src={urlAvatar} alt="avatar" /> : shortcutName(name)}
        {isCollapsed ? null : (
          <div>
            <h4>
              <Tooltip
                arrow
                placement="right"
                title={!disableCollapsed ? name : ""}
              >
                <span style={{ width: "fit-content" }} className="line-clamp">
                  {name}
                </span>
              </Tooltip>
            </h4>
            <p>
              <Tooltip
                arrow
                placement="right"
                title={!disableCollapsed ? listRole : ""}
              >
                <span style={{ width: "fit-content" }} className="line-clamp">
                  {listRole}
                </span>
              </Tooltip>
            </p>
          </div>
        )}
      </ProfileLeftStyle>
      <img
        alt="arrow"
        src={SidebarIcons.arrowDown}
        style={{
          transform: `rotate(${open ? 180 : 0}deg)`,
          transition: "transform 0.5s",
        }}
      />
      {isMiniSidebar || disableCollapsed ? null : (
        <Tooltip arrow title="Logout">
          <IconButton onClick={handlerLogout}>
            <img src={SidebarIcons.logout} alt="logout" />
          </IconButton>
        </Tooltip>
      )}
    </ProfileStyle>
  );
};

export default MyProfile;
