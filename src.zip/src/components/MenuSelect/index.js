import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { toggleMenuAction } from 'App/store/actions';
import get from 'lodash/get';
import { useMemo } from 'react';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useHistory } from 'react-router-dom';

export default function MenuSelect() {
  const dispatch = useDispatch();
  const history = useHistory();
  const { menuType, menuTypeParent, menuTopBar = [] } = useSelector(
    state => state.global,
  );

  const toggleMenuType = (event, newValue) => {
    dispatch(toggleMenuAction(newValue));
    history.push('/');
  };

  const menuList = useMemo(
    () => menuTopBar.find(item => item.value === menuTypeParent),
    [menuTypeParent, menuTopBar],
  );

  return (
    <Box sx={{ width: '80%', margin: '0px 0px 21px' }}>
      <Box>
        <Tabs
          value={menuType}
          onChange={toggleMenuType}
          aria-label="menu tab child"
          sx={{ height: 40 }}
          variant="scrollable"
          scrollButtons="auto"
        >
          {get(menuList, 'children', []).map(item => (
            <Tab
              key={item.value}
              label={item.label}
              value={item.value}
              className="tab-header"
              sx={{ height: 40 }}
            />
          ))}
        </Tabs>
      </Box>
    </Box>
  );
}
