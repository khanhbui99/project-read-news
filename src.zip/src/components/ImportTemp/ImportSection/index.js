import { CloudUpload as CloudUploadIcon } from "@mui/icons-material";
import { Description as DescriptionIcon } from "@mui/icons-material";
import { DeleteOutline as DeleteOutlineIcon } from "@mui/icons-material";
import { Box, Divider, IconButton, Stack } from "@mui/material";
import AppButton from "components/common/AppButton";
import { BoxShadow, Text, Title } from "components/Styled";
import PropTypes from "prop-types";
import { useEffect, useRef } from "react";
import { VPB_THEMES } from "utils/configs";
import { handleScrollToBottom } from "utils/helpers";
import { useFileUpload } from "utils/hooks/useFileUpload";
import { useOneState } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

import {
  SectionTitleStyled,
  DropZoneStyled,
  DropZoneContentStyled,
  FileItemStyled,
} from "../Styled";

const PRIMARY_COLOR = VPB_THEMES.colors.green;

const ImportSection = ({
  validExtensions,
  acceptedFileTypes,
  hanldeImportFile,
  externalAction,
  successMessage = "Import báo cáo thành công",
  importButtonLabel = "Gửi Báo Cáo",
  stepTitle = "Import Báo Cáo",
  stepNumber = 2,
  fileHint = "💡 Định dạng hỗ trợ: Excel (.xlsx, .xls), Word (.docx, .doc)",
}) => {
  const {
    refFileInput,
    files,
    dragOver,
    handleFileInput,
    handleDrop,
    removeFile,
    handleDragOver,
    handleDragLeave,
  } = useFileUpload({
    validExtensions,
    multiple: false, // Chỉ cho phép 1 file
  });

  const message = useOneState(injectKey.GLOBAL, "message");
  const previousSuccessRef = useRef("");

  const handleFileInputClick = () => {
    refFileInput.current?.click();
  };

  const handleImport = () => {
    if (files.length === 0) {
      return;
    }

    hanldeImportFile({
      file: files[0],
    });
  };

  useEffect(() => {
    if (files.length > 0) {
      handleScrollToBottom();
    }
  }, [files.length]);

  useEffect(() => {
    const currentSuccess = message?.success || "";
    const successText =
      typeof currentSuccess === "string"
        ? currentSuccess
        : currentSuccess?.message || "";
    if (
      successText &&
      successText !== previousSuccessRef.current &&
      successText.includes(successMessage)
    ) {
      // Clear file after successful import
      if (files.length > 0) {
        removeFile(0);
      }
      previousSuccessRef.current = currentSuccess;
    }
  }, [message?.success, files.length, removeFile, successMessage]);

  return (
    <BoxShadow
      $borderRadius="16"
      style={{ marginBottom: 24 }}
      className="partWrapper"
    >
      <SectionTitleStyled>
        <Text className="step-number">{stepNumber}</Text>
        <Title>{stepTitle}</Title>
      </SectionTitleStyled>

      <DropZoneStyled
        elevation={0}
        className={dragOver ? "dragover" : ""}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleFileInputClick}
      >
        <input
          ref={refFileInput}
          type="file"
          accept={acceptedFileTypes}
          onChange={handleFileInput}
          style={{ display: "none" }}
        />
        <DropZoneContentStyled>
          <CloudUploadIcon />
          <div>
            <h3>Kéo thả file vào đây</h3>
            <p>hoặc bấm để chọn file từ máy tính</p>
          </div>
        </DropZoneContentStyled>
      </DropZoneStyled>

      <Box
        sx={{
          mt: 2,
          mb: 3,
          px: { xs: 1, sm: 0 },
        }}
      >
        <Text
          $size={13}
          $color="neutral"
          $align="center"
          sx={{
            fontSize: { xs: "0.75rem", sm: "0.8125rem" },
          }}
        >
          {fileHint}
        </Text>
      </Box>

      {files.length > 0 && (
        <>
          <Divider sx={{ mb: 2 }} />
          <FileItemStyled>
            <DescriptionIcon
              sx={{
                color: PRIMARY_COLOR,
                fontSize: { xs: "1.5rem", sm: "1.8rem" },
              }}
            />
            <Box sx={{ flex: 1 }}>
              <Text $weight={600} $size={16}>
                {files[0].name}
              </Text>
              <Text $color="neutral" $size={14}>
                {(files[0].size / 1024).toFixed(2)} KB
              </Text>
            </Box>
            <IconButton
              edge="end"
              onClick={() => removeFile(0)}
              size="small"
              sx={{
                color: "#ff4757",
                transition: "all 0.2s",
                "&:hover": {
                  backgroundColor: "rgba(255, 71, 87, 0.1)",
                },
              }}
            >
              <DeleteOutlineIcon />
            </IconButton>
          </FileItemStyled>

          <Stack direction="row" justifyContent="flex-end" sx={{ mt: 3 }}>
            {externalAction ? externalAction({removeFile: () => removeFile(0)}): null}
            <AppButton
              onClick={handleImport}
              className="btn"
              sx={{
                height: 44,
                borderRadius: 8,
                padding: "1rem 2rem",
              }}
            >
              {importButtonLabel}
            </AppButton>
          </Stack>
        </>
      )}
    </BoxShadow>
  );
};

ImportSection.propTypes = {
  validExtensions: PropTypes.array.isRequired,
  acceptedFileTypes: PropTypes.string.isRequired,
  hanldeImportFile: PropTypes.func.isRequired,
  externalAction: PropTypes.func,
  successMessage: PropTypes.string,
  importButtonLabel: PropTypes.string,
  stepTitle: PropTypes.string,
  stepNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  fileHint: PropTypes.string,
};
export default ImportSection;
