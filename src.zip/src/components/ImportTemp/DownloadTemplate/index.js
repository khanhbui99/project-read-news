import {
  Download as DownloadIcon,
  FileDownload as FileDownloadIcon,
} from "@mui/icons-material";
import { Box } from "@mui/material";
import AppButton from "components/common/AppButton";
import { BoxShadow, Text, Title } from "components/Styled";
import PropTypes from "prop-types";

import {
  DownloadSectionStyled,
  DownloadIconBox,
  SectionTitleStyled,
} from "../Styled";

const DownloadTemplate = ({
  handleDownloadTemp,
  stepNumber = 1,
  title = "Tải Template",
  description = "Tải file mẫu để xem cấu trúc dữ liệu và cách nhập báo cáo đúng",
}) => {
  const handleDownload = () => {
    handleDownloadTemp();
  };

  return (
    <BoxShadow
      $borderRadius="16"
      style={{ marginBottom: 24 }}
      className="partWrapper"
    >
      <SectionTitleStyled>
        <Text className="step-number">{stepNumber}</Text>
        <Title>{title}</Title>
      </SectionTitleStyled>

      <DownloadSectionStyled elevation={0}>
        <DownloadIconBox>
          <FileDownloadIcon />
        </DownloadIconBox>
        <Box
          sx={{
            flex: 1,
            minWidth: 0,
            "@media (max-width: 768px)": {
              width: "100%",
            },
          }}
        >
          <Title>Tải file mẫu</Title>
          <Text $color="neutral">{description}</Text>
        </Box>

        <AppButton
          onClick={handleDownload}
          className="btn"
          startIcon={<DownloadIcon />}
          sx={{
            height: 44,
            borderRadius: 8,
            padding: "1rem 2rem",
          }}
        >
          Tải Template
        </AppButton>
      </DownloadSectionStyled>
    </BoxShadow>
  );
};

DownloadTemplate.propTypes = {
  handleDownloadTemp: PropTypes.func.isRequired,
  stepNumber: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  title: PropTypes.string,
  description: PropTypes.string,
};

export default DownloadTemplate;
