import { Box, Paper } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ContainerStyled = styled(Box)`
  padding: 2rem;
  min-height: 100vh;
  border-radius: 24px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.gray[100]} 0%,
    #e8eef3 100%
  );

  @media (max-width: 768px) {
    padding: 0;
    border-radius: 16px;
    background: none;

    .btn {
      width: 100%;
    }

    .partWrapper {
      padding: 16px;
    }
  }
`;

export const ContentWrapper = styled(Box)`
  max-width: 1000px;
  margin: 0 auto;

  @media (max-width: 1200px) {
    max-width: 100%;
    padding: 0 1rem;
  }

  @media (max-width: 768px) {
    padding: 0;
  }
`;

export const SectionTitleStyled = styled(Box)`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;

  .step-number {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: linear-gradient(
      135deg,
      ${VPB_THEMES.colors.green} 0%,
      ${VPB_THEMES.colors.blue} 100%
    );
    color: white;
    font-weight: 700;
    font-size: 0.9rem;
  }

  @media (max-width: 768px) {
    gap: 0.75rem;
    margin-bottom: 1.5rem;

    .step-number {
      width: 28px;
      height: 28px;
      font-size: 0.8rem;
    }
  }
`;

export const DownloadSectionStyled = styled(Paper)`
  display: flex;
  align-items: center;
  gap: 2rem;
  padding: 2rem;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  border-radius: 12px !important;
  margin-bottom: 2rem;
  border: 2px solid #c8f0d4;
  transition: all 0.3s ease;

  &:hover {
    border-color: ${VPB_THEMES.colors.green};
    box-shadow: 0 12px 32px rgba(0, 173, 83, 0.15);
  }

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 1.5rem;
    padding: 1.5rem;
    text-align: center;
  }
`;

export const DownloadIconBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  height: 80px;
  border-radius: 12px;
  background: white;
  box-shadow: 0 4px 16px rgba(0, 173, 83, 0.2);
  flex-shrink: 0;

  svg {
    font-size: 2.5rem;
    color: ${VPB_THEMES.colors.green};
  }

  @media (max-width: 768px) {
    width: 70px;
    height: 70px;

    svg {
      font-size: 2rem;
    }
  }
`;

export const DropZoneStyled = styled(Paper)`
  border: 3px dashed ${VPB_THEMES.colors.green};
  border-radius: 16px;
  padding: 4rem 2rem;
  text-align: center;
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(
      circle at 30% 70%,
      rgba(0, 173, 83, 0.05) 0%,
      transparent 50%
    );
    pointer-events: none;
  }

  &:hover {
    background: linear-gradient(135deg, #f0f9f5 0%, #e8f5f0 100%);
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 16px 48px rgba(0, 173, 83, 0.2);
  }

  &.dragover {
    background: linear-gradient(135deg, #e8f5f0 0%, #e0f2eb 100%);
    border-color: ${VPB_THEMES.colors.blue};
    box-shadow: 0 20px 60px rgba(0, 173, 83, 0.3);
    transform: scale(1.01);
  }

  @media (max-width: 768px) {
    padding: 3rem 1.5rem;
    border-width: 2px;
  }
`;

export const DropZoneContentStyled = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  position: relative;
  z-index: 1;

  svg {
    font-size: 5rem;
    color: ${VPB_THEMES.colors.green};
    opacity: 0.8;
    animation: float 3s ease-in-out infinite;
  }

  @keyframes float {
    0%,
    100% {
      transform: translateY(0px);
    }
    50% {
      transform: translateY(-10px);
    }
  }

  h3 {
    color: #1a1a1a;
    margin: 0;
    font-size: 1.3rem;
    font-weight: 700;
  }

  p {
    color: #666;
    margin: 0;
    font-size: 1rem;
  }

  @media (max-width: 768px) {
    gap: 1rem;

    svg {
      font-size: 4rem;
    }

    h3 {
      font-size: 1.1rem;
    }

    p {
      font-size: 0.9rem;
    }
  }
`;

export const FileItemStyled = styled(Box)`
  background: linear-gradient(135deg, #f8fef9 0%, #f0f9f5 100%);
  border-radius: 12px;
  margin-bottom: 1rem;
  padding: 1.25rem;
  border-left: 5px solid ${VPB_THEMES.colors.green};
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 1rem;

  &:hover {
    box-shadow: 0 8px 24px rgba(0, 173, 83, 0.15);
    transform: translateX(8px);
  }

  @media (max-width: 768px) {
    padding: 1rem;
    border-left-width: 4px;
  }
`;
