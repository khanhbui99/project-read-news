import Box from "@mui/material/Box";
import { IcEmpty } from "assets/icons";
import AppImage from "components/common/AppImage";
import { Text } from "components/Styled";
import PropTypes from "prop-types";
import { VPB_THEMES } from "utils/configs";

const Empty = ({
  mt = 3,
  description = "Không tìm thấy hồ sơ nào!",
  descProps = {},
  imgProps = {},
}) => {
  return (
    <Box display="grid" alignItems="center" justifyContent="center" mt={mt}>
      <AppImage
        width={160}
        height={160}
        src={IcEmpty}
        styleWrap={{ margin: "auto" }}
        {...imgProps}
      />

      <Text
        $size={16}
        $weight={500}
        $color={VPB_THEMES.colors.darkBlue}
        {...descProps}
      >
        {description}
      </Text>
    </Box>
  );
};

Empty.propTypes = {
  mt: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
  imgProps: PropTypes.object,
  descProps: PropTypes.object,
  description: PropTypes.string,
};

export default Empty;
