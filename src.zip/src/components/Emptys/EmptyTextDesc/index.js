import AppButton from "components/common/AppButton";
import { Title } from "components/Styled";
import { Text } from "components/Styled";
import PropTypes from "prop-types";
import { useMemo } from "react";
import styled from "styled-components";
import { findMenuByComponentName } from "utils/helpers";
import history from "utils/history";

const EmptyState = styled.div`
  border-radius: 24px;
  padding: 48px;
  background: linear-gradient(135deg, #f2fcff, #e0c3fc);
  text-align: center;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.5);
`;

const EmptyTextDesc = ({ componentAdd, btnName, title, description }) => {
  const addPath = useMemo(() => {
    return findMenuByComponentName(componentAdd)?.url || "";
  }, [componentAdd]);

  const handleCreate = () => {
    history.push({ pathname: addPath });
  };

  return (
    <EmptyState>
      <Title $size={22} $align="center">
        {title}
      </Title>
      <Text $align="center" style={{ margin: "12px 0 24px" }}>
        {description}
      </Text>
      <AppButton btnType="secondary" onClick={handleCreate}>
        {btnName || "Bắt đầu tạo"}
      </AppButton>
    </EmptyState>
  );
};

EmptyTextDesc.propTypes = {
  componentAdd: PropTypes.string.isRequired,
  btnName: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
};

export default EmptyTextDesc;
