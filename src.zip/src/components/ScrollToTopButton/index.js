import { IconButton } from "@mui/material";
import Icons from "assets/icons/common";
import { memo, useEffect, useState } from "react";

import ScrollToTopButtonStyle from "./style";

const ScrollToTopButton = () => {
  const [isVisiable, setIsVisiable] = useState(false);

  const handleScrollTop = () => {
    window.scrollTo(0, 0);
  };

  useEffect(() => {
    window.addEventListener("scroll", () => {
      if (window.pageYOffset > 250 && !isVisiable) {
        setIsVisiable(true);
      } else if (window.pageYOffset <= 250 && isVisiable) {
        setIsVisiable(false);
      }
    });

    return () => window.removeEventListener("scroll", () => {}, true);
  }, [isVisiable]);

  return isVisiable ? (
    <ScrollToTopButtonStyle>
      <IconButton onClick={handleScrollTop}>
        <img width="100%" src={Icons.scollTop} alt="icon" />
      </IconButton>
    </ScrollToTopButtonStyle>
  ) : null;
};

export default memo(ScrollToTopButton);
