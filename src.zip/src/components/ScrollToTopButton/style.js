import styled from 'styled-components';

const ScrollToTopButtonStyle = styled.div`
  z-index: 99;
  right: 32px;
  width: 50px;
  height: 50px;
  bottom: 19px;
  position: fixed;
`;

export default ScrollToTopButtonStyle;
