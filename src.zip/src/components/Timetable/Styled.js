import { Box } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const ScheduleContainer = styled(Box)`
  background: ${VPB_THEMES.colors.white};
  border-radius: 16px;
  padding: 24px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  position: relative;
  overflow: hidden;

  @media (max-width: 768px) {
    padding: 16px;
    border-radius: 12px;
  }

  @media (max-width: 480px) {
    padding: 12px;
    border-radius: 8px;
  }
`;

export const WeekSelector = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  margin-bottom: 24px;
  padding: 20px;
  background: ${VPB_THEMES.colors.shade || "#F2F4F8"};
  border-radius: 12px;
  border: 1px solid ${VPB_THEMES.colors.gray[200]};
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);

  @media (max-width: 768px) {
    padding: 16px;
    gap: 12px;
    margin-bottom: 16px;
    justify-content: space-between;
  }

  @media (max-width: 480px) {
    padding: 12px;
    gap: 8px;
    margin-bottom: 12px;
  }
`;

export const WeekButton = styled.button`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  border: 1px solid ${VPB_THEMES.colors.gray[300]};
  border-radius: 10px;
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.darkBlue};
  cursor: pointer;
  transition: all 0.3s;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);

  &:hover {
    background: ${VPB_THEMES.colors.blue};
    color: ${VPB_THEMES.colors.white};
    border-color: ${VPB_THEMES.colors.blue};
    transform: translateY(-2px) scale(1.05);
    box-shadow: 0 6px 12px rgba(29, 66, 137, 0.25);
  }

  &:active {
    transform: translateY(0) scale(1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  @media (max-width: 480px) {
    width: 36px;
    height: 36px;
    border-radius: 8px;
  }
`;

export const WeekLabel = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  padding: 12px 20px;
  border-radius: 10px;
  transition: all 0.3s;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.gray[200]};

  &:hover {
    background: ${VPB_THEMES.colors.shade || "#F2F4F8"};
    border-color: ${VPB_THEMES.colors.gray[300]};
    transform: scale(1.02);
  }

  @media (max-width: 768px) {
    padding: 10px 16px;
  }

  @media (max-width: 480px) {
    padding: 8px 12px;
  }
`;

export const ScheduleTableWrapper = styled.div`
  overflow-x: auto;
  width: 100%;
  -webkit-overflow-scrolling: touch;
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};

  @media (max-width: 768px) {
    margin: 0 -12px;
    padding: 0;
    border-radius: 0;
    border-left: none;
    border-right: none;
  }

  @media (max-width: 480px) {
    margin: 0 -8px;
  }
`;

export const ScheduleTable = styled.table`
  width: 100%;
  min-width: 980px;
  border-collapse: separate;
  border-spacing: 0;

  @media (max-width: 768px) {
    min-width: 860px;
    font-size: 14px;
  }

  @media (max-width: 480px) {
    min-width: 780px;
    font-size: 12px;
  }
`;

export const ScheduleTableHeader = styled.thead`
  background: ${VPB_THEMES.colors.table.headerBg || "#F2F4F8"};
`;

export const ScheduleTableBody = styled.tbody``;

export const ScheduleTableRow = styled.tr`
  transition: background-color 0.2s;

  &:hover {
    background-color: ${VPB_THEMES.colors.gray[100]};
  }
`;

const SESSION_STICKY_WIDTH = 76;
const PERIOD_STICKY_WIDTH = 88;

export const TimeCell = styled.td.withConfig({
  shouldForwardProp: (prop) =>
    !["$isMorning", "$sticky", "$stickyLeft", "$isLastSticky"].includes(prop),
})`
  padding: 16px 8px;
  text-align: center;
  background: ${VPB_THEMES.colors.shade || "#F2F4F8"};
  font-weight: 600;
  color: ${VPB_THEMES.colors.darkBlue};
  width: ${({ $stickyLeft }) =>
    $stickyLeft === 0 ? `${SESSION_STICKY_WIDTH}px` : `${PERIOD_STICKY_WIDTH}px`};
  min-width: ${({ $stickyLeft }) =>
    $stickyLeft === 0 ? `${SESSION_STICKY_WIDTH}px` : `${PERIOD_STICKY_WIDTH}px`};
  max-width: ${({ $stickyLeft }) =>
    $stickyLeft === 0 ? `${SESSION_STICKY_WIDTH}px` : `${PERIOD_STICKY_WIDTH}px`};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  position: ${({ $sticky }) => ($sticky ? "sticky" : "relative")};
  left: ${({ $sticky, $stickyLeft }) =>
    $sticky ? `${$stickyLeft || 0}px` : "auto"};
  z-index: ${({ $sticky }) => ($sticky ? 3 : 1)};
  box-shadow: ${({ $isLastSticky }) =>
    $isLastSticky ? "4px 0 10px rgba(15, 23, 42, 0.08)" : "none"};

  small {
    display: block;
    margin-top: 4px;
    font-weight: 600;
    color: ${VPB_THEMES.colors.secondaryText};
    font-size: 12px;
  }

  @media (max-width: 768px) {
    padding: 12px 6px;
    font-size: 13px;

    small {
      font-size: 11px;
    }
  }

  @media (max-width: 480px) {
    padding: 8px 4px;
    font-size: 11px;

    small {
      font-size: 10px;
    }
  }
`;

export const ScheduleTableCell = styled.td.withConfig({
  shouldForwardProp: (prop) => prop !== "$isActive",
})`
  padding: 8px;
  vertical-align: top;
  min-width: 140px;
  width: 140px;
  min-height: 100px;
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  background: ${({ $isActive }) =>
    $isActive
      ? `linear-gradient(135deg, ${VPB_THEMES.colors.primaryBlue}25 0%, ${VPB_THEMES.colors.lightBlue}25 100%)`
      : VPB_THEMES.colors.white};
  position: relative;
  transition: background 0.3s ease;
  box-shadow: ${({ $isActive }) =>
    $isActive ? `0 0 0 2px ${VPB_THEMES.colors.primaryBlue}40 inset` : "none"};

  @media (max-width: 768px) {
    padding: 6px;
    min-width: 128px;
    width: 128px;
    min-height: 80px;
  }

  @media (max-width: 480px) {
    padding: 4px;
    min-width: 116px;
    width: 116px;
    min-height: 60px;
  }
`;

export const ScheduleTableHeaderCell = styled.th.withConfig({
  shouldForwardProp: (prop) =>
    !["$isActive", "$sticky", "$stickyLeft", "$isLastSticky"].includes(prop),
})`
  padding: 16px;
  text-align: center;
  font-weight: 700;
  color: ${({ $isActive }) =>
    $isActive ? VPB_THEMES.colors.primaryBlue : VPB_THEMES.colors.darkBlue};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  background: ${({ $isActive, $sticky }) => {
    if ($sticky) return VPB_THEMES.colors.gray[200] || "#E8EDF3";
    if ($isActive) {
      return `linear-gradient(135deg, ${VPB_THEMES.colors.primaryBlue}30 0%, ${VPB_THEMES.colors.lightBlue}30 100%)`;
    }
    return VPB_THEMES.colors.table.headerBg || "#F2F4F8";
  }};
  position: ${({ $sticky }) => ($sticky ? "sticky" : "relative")};
  left: ${({ $sticky, $stickyLeft }) =>
    $sticky ? `${$stickyLeft || 0}px` : "auto"};
  z-index: ${({ $sticky }) => ($sticky ? 4 : 2)};
  top: 0;
  min-width: ${({ $sticky }) =>
    $sticky ? `${SESSION_STICKY_WIDTH + PERIOD_STICKY_WIDTH}px` : "140px"};
  width: ${({ $sticky }) =>
    $sticky ? `${SESSION_STICKY_WIDTH + PERIOD_STICKY_WIDTH}px` : "140px"};
  box-shadow: ${({ $isLastSticky, $isActive }) => {
    if ($isLastSticky) return "4px 0 10px rgba(15, 23, 42, 0.08)";
    if ($isActive) return `0 2px 8px ${VPB_THEMES.colors.primaryBlue}40`;
    return "none";
  }};
  transition: all 0.3s ease;

  @media (max-width: 768px) {
    padding: 12px 8px;
    font-size: 13px;
  }

  @media (max-width: 480px) {
    padding: 8px 4px;
    font-size: 11px;
  }
`;

export const LessonItem = styled.div`
  background: ${({ gradient }) =>
    gradient || `linear-gradient(135deg, ${VPB_THEMES.colors.lessonDefault.start} 0%, ${VPB_THEMES.colors.lessonDefault.end} 100%)`};
  border-radius: 8px;
  padding: 12px;
  color: #37474f;
  cursor: pointer;
  transition: all 0.2s;
  min-height: 80px;
  display: flex;
  flex-direction: column;
  gap: 6px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  border: 1px solid rgba(0, 0, 0, 0.05);
  width: 160px;
  box-sizing: border-box;

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.12);
    border-color: rgba(0, 0, 0, 0.1);
  }

  @media (max-width: 768px) {
    padding: 10px;
    min-height: 70px;
    gap: 4px;
    border-radius: 6px;
  }

  @media (max-width: 480px) {
    padding: 8px;
    min-height: 60px;
    gap: 3px;
    border-radius: 4px;
  }
`;

export const LessonSubject = styled.div`
  font-weight: 700;
  font-size: 14px;
  margin-bottom: 4px;

  @media (max-width: 768px) {
    font-size: 13px;
    margin-bottom: 2px;
  }

  @media (max-width: 480px) {
    font-size: 11px;
    margin-bottom: 2px;
  }
`;

export const LessonInfo = styled.div`
  font-size: 12px;
  color: #546e7a;
  display: flex;
  align-items: flex-start;
  gap: 4px;

  span {
    font-size: 14px;
    flex-shrink: 0;
    line-height: 1.35;
  }

  @media (max-width: 768px) {
    font-size: 11px;
    gap: 3px;

    span {
      font-size: 12px;
    }
  }

  @media (max-width: 480px) {
    font-size: 10px;
    gap: 2px;

    span {
      font-size: 11px;
    }
  }
`;

export const LessonTeachers = styled.div`
  flex: 1;
  min-width: 0;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  overflow: hidden;
  text-overflow: ellipsis;
  word-break: break-word;
  line-height: 1.4;
  max-height: calc(1.4em * 2);
`;

export const ScheduleEmptyWrap = styled.div`
  padding: 24px 16px 32px;
  display: flex;
  justify-content: center;
`;

export const LessonModalPaper = styled.div`
  overflow: hidden;
  border-radius: 20px;
  background: ${VPB_THEMES.colors.white};
`;

export const LessonModalHero = styled.div`
  position: relative;
  padding: 22px 24px 20px;
  background: linear-gradient(
    145deg,
    ${VPB_THEMES.colors.f0f9ff} 0%,
    #e0f2fe 45%,
    ${VPB_THEMES.colors.white} 100%
  );
  border-bottom: 1px solid rgba(2, 132, 199, 0.1);
`;

export const LessonModalClose = styled.button`
  position: absolute;
  top: 12px;
  right: 12px;
  width: 36px;
  height: 36px;
  border: none;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.85);
  color: ${VPB_THEMES.colors.textLight};
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s ease;
  box-shadow: 0 1px 4px rgba(15, 23, 42, 0.06);

  &:hover {
    background: ${VPB_THEMES.colors.white};
    color: ${VPB_THEMES.colors.primaryBlue};
    transform: scale(1.04);
  }
`;

export const LessonModalEyebrow = styled.div`
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.02em;
  color: ${VPB_THEMES.colors.primaryBlue};
  margin-bottom: 8px;
`;

export const LessonModalSubject = styled.h2`
  margin: 0 0 14px;
  padding-right: 40px;
  font-size: 22px;
  font-weight: 800;
  line-height: 1.3;
  color: ${VPB_THEMES.colors.textDark};
  word-break: break-word;
`;

export const LessonModalChipRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
`;

export const LessonModalChip = styled.span`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  color: ${({ $tone }) => {
    if ($tone === "mint") return "#0f766e";
    if ($tone === "amber") return "#b45309";
    return VPB_THEMES.colors.primaryBlue;
  }};
  background: ${({ $tone }) => {
    if ($tone === "mint") return "#ecfdf5";
    if ($tone === "amber") return "#fffbeb";
    return "#e0f2fe";
  }};
`;

export const LessonModalBody = styled.div`
  padding: 18px 24px 8px;
  display: flex;
  flex-direction: column;
  gap: 14px;
`;

export const LessonModalSection = styled.section`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const LessonModalSectionTitle = styled.div`
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textLight};
`;

export const LessonModalInfoGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;

  @media (max-width: 480px) {
    grid-template-columns: 1fr;
  }
`;

export const LessonModalInfoCard = styled.div`
  padding: 12px 14px;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.lightBg};
  border: 1px solid rgba(148, 163, 184, 0.18);
`;

export const LessonModalInfoLabel = styled.div`
  font-size: 11px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
  margin-bottom: 4px;
`;

export const LessonModalInfoValue = styled.div`
  font-size: 14px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  word-break: break-word;
  line-height: 1.4;
`;

export const LessonModalTeacherList = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;

  @media (max-width: 520px) {
    grid-template-columns: 1fr;
  }
`;

export const LessonModalTeacherCard = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border-radius: 14px;
  background: linear-gradient(
    135deg,
    ${VPB_THEMES.colors.f0f9ff} 0%,
    ${VPB_THEMES.colors.white} 70%
  );
  border: 1px solid rgba(2, 132, 199, 0.12);
`;

export const LessonModalAvatar = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 12px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.primaryBlue};
  background: #e0f2fe;
`;

export const LessonModalTeacherMeta = styled.div`
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
`;

export const LessonModalTeacherName = styled.div`
  font-size: 14px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  word-break: break-word;
`;

export const LessonModalTeacherSub = styled.div`
  font-size: 12px;
  font-weight: 500;
  color: ${VPB_THEMES.colors.textLight};
`;

export const LessonModalNote = styled.div`
  padding: 12px 14px;
  border-radius: 14px;
  background: #fffbeb;
  border: 1px solid rgba(245, 158, 11, 0.2);
  font-size: 13px;
  font-weight: 500;
  line-height: 1.5;
  color: #92400e;
`;

export const LessonModalFooter = styled.div`
  padding: 8px 24px 20px;
  display: flex;
  justify-content: center;
`;
