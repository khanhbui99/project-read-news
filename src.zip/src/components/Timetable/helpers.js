import dayjs from "dayjs";
import { VPB_THEMES } from "utils/configs";

dayjs.locale("vi");

export const PERIOD_TIME_HINTS = [
  "07:40–08:25",
  "08:30–09:15",
  "09:30–10:15",
  "10:20–11:05",
  "11:10–11:55",
  "14:00–14:45",
  "14:50–15:35",
  "15:50–16:35",
];

export const getPeriodTime = (period, session) => {
  const p = Number(period);
  if (!Number.isFinite(p) || p < 1) return "";

  const raw = String(session || "").toLowerCase();
  const isAfternoon =
    raw === "afternoon" || raw.includes("chiều") || raw.includes("chieu");
  const globalPeriod = isAfternoon && p <= 5 ? p + 5 : p;

  return PERIOD_TIME_HINTS[globalPeriod - 1] || "";
};

// Ngày trong tuần
export const daysOfWeek = [
  { key: "monday", label: "Thứ 2", offset: 0 },
  { key: "tuesday", label: "Thứ 3", offset: 1 },
  { key: "wednesday", label: "Thứ 4", offset: 2 },
  { key: "thursday", label: "Thứ 5", offset: 3 },
  { key: "friday", label: "Thứ 6", offset: 4 },
  { key: "saturday", label: "Thứ 7", offset: 5 },
];

/**
 * Tính toán Thứ 2 của tuần
 * @param {dayjs.Dayjs} date - Ngày cần tính
 * @param {number} weekOffset - Số tuần offset (0 = tuần hiện tại, -1 = tuần trước, 1 = tuần sau)
 * @returns {dayjs.Dayjs} - Thứ 2 của tuần
 */
const getMondayOfWeek = (date, weekOffset = 0) => {
  const d = dayjs(date).add(weekOffset * 7, "day");
  const day = d.day(); // 0 = Chủ nhật, 1 = Thứ 2, ..., 6 = Thứ 7

  if (day === 0) {
    return d.add(1, "day");
  }

  return d.subtract(day - 1, "day");
};

// Tính toán tuần hiện tại
export const getWeekDates = (weekOffset = 0) => {
  const today = dayjs();
  const monday = getMondayOfWeek(today, weekOffset);

  return daysOfWeek.map((day, index) => {
    const date = monday.add(index, "day");
    return {
      ...day,
      date,
      dateText: date.format("DD/MM"),
    };
  });
};

// Lấy gradient theo loại môn học
export const getTypeGradient = (type) => {
  switch (type) {
    case "sport":
      return `linear-gradient(135deg, ${VPB_THEMES.colors.lessonSport.start} 0%, ${VPB_THEMES.colors.lessonSport.end} 100%)`;
    case "art":
      return `linear-gradient(135deg, ${VPB_THEMES.colors.lessonArt.start} 0%, ${VPB_THEMES.colors.lessonArt.end} 100%)`;
    case "special":
      return `linear-gradient(135deg, ${VPB_THEMES.colors.lessonSpecial.start} 0%, ${VPB_THEMES.colors.lessonSpecial.end} 100%)`;
    default:
      return `linear-gradient(135deg, ${VPB_THEMES.colors.lessonDefault.start} 0%, ${VPB_THEMES.colors.lessonDefault.end} 100%)`;
  }
};

/**
 * Kiểm tra xem một ngày có phải là ngày hiện tại không
 * @param {dayjs.Dayjs} date - Ngày cần kiểm tra
 * @returns {boolean}
 */
export const isToday = (date) => {
  if (!date) return false;
  const today = dayjs();
  return date.isSame(today, "day");
};

/**
 * Convert mảng phẳng từ API thành cấu trúc nested object
 * Input: [{ day, period, session, subject, teacher, type }, ...]
 * Output: { day: { period: { morning: {...}, afternoon: {...} } } }
 */
export const convertScheduleDataToNested = (flatArray = []) => {
  if (!Array.isArray(flatArray) || flatArray.length === 0) {
    return {};
  }

  const nested = {};

  flatArray.forEach((item) => {
    const { day, period, session, subject, teacher, type, room } = item;

    if (!nested[day]) {
      nested[day] = {};
    }
    if (!nested[day][period]) {
      nested[day][period] = {
        morning: null,
        afternoon: null,
      };
    }

    if (session === "morning" || session === "afternoon") {
      nested[day][period][session] = {
        subject,
        teacher,
        type,
        room,
      };
    }
  });

  return nested;
};

/** weekday API: 2=Thứ 2 ... 7=Thứ 7 → offset 0..5 */
const weekdayToDayOffset = (weekday) => {
  const day = Number(weekday);
  if (!Number.isFinite(day)) return null;
  const dayOffset = day - 2;
  return dayOffset >= 0 && dayOffset <= 5 ? dayOffset : null;
};

const mapSessionType = (session) => {
  const raw = String(session || "")
    .trim()
    .toUpperCase();
  if (raw === "SANG" || raw === "MORNING") return "morning";
  if (raw === "CHIEU" || raw === "AFTERNOON") return "afternoon";
  return null;
};

/** Chuẩn hóa teachers API → mảng object */
export const normalizeTeachersList = (teachers) => {
  if (!teachers && teachers !== 0) return [];

  if (!Array.isArray(teachers)) {
    if (typeof teachers === "string" && teachers.trim()) {
      return teachers
        .split(/[,;/|]+|\s+và\s+/i)
        .map((name) => name.trim())
        .filter(Boolean)
        .map((teacherName) => ({ teacherName }));
    }
    if (typeof teachers === "object") {
      return normalizeTeachersList([teachers]);
    }
    return [];
  }

  return teachers
    .map((t) => {
      if (typeof t === "string") {
        const name = t.trim();
        return name ? { teacherName: name } : null;
      }
      if (!t || typeof t !== "object") return null;
      const teacherName = (
        t.teacherName ||
        t.externalLabel ||
        t.fullName ||
        t.name ||
        t.teacher?.fullName ||
        t.teacher?.name ||
        ""
      ).trim();
      if (!teacherName) return null;
      return {
        teacherId: t.teacherId ?? t.id ?? t.teacher?.id ?? null,
        teacherCode: t.teacherCode || t.code || t.teacher?.code || "",
        teacherName,
        externalLabel: t.externalLabel || null,
      };
    })
    .filter(Boolean);
};

export const getTeacherDisplayNames = (teachers) =>
  normalizeTeachersList(teachers).map((t) => t.teacherName);

const formatTeacherNames = (teachers) =>
  getTeacherDisplayNames(teachers).join(", ");

/** Gộp danh sách GV, bỏ trùng theo id hoặc tên */
export const mergeTeachersList = (...lists) => {
  const merged = [];
  const seen = new Set();

  lists.flatMap((list) => normalizeTeachersList(list)).forEach((teacher) => {
    const key = String(
      teacher.teacherId || teacher.teacherName.toLowerCase(),
    );
    if (seen.has(key)) return;
    seen.add(key);
    merged.push(teacher);
  });

  return merged;
};

const resolveSubjectType = (subjectName = "") => {
  const name = String(subjectName || "");
  if (name.includes("GDTC") || name.includes("Thể dục")) {
    return "sport";
  }
  if (name.includes("Nghệ thuật") || /\b(AN|MT)\b/i.test(name)) {
    return "art";
  }
  if (
    name.includes("CLB") ||
    name.includes("CLBVH") ||
    name.includes("CLBTC")
  ) {
    return "special";
  }
  return "normal";
};

const ensurePeriodCell = (nested, dayOffset, period) => {
  if (!nested[dayOffset]) nested[dayOffset] = {};
  if (!nested[dayOffset][period]) {
    nested[dayOffset][period] = {
      morning: null,
      afternoon: null,
    };
  }
};

/**
 * Format mới: { classId, className, homeroomTeacherName, slots: [...] }
 * slot: { weekday, period, session: SANG|CHIEU, contentText, note, teachers: [{ teacherName }] }
 */
export const convertSlotsTimetableToNested = (apiData = {}) => {
  const slots = Array.isArray(apiData)
    ? apiData
    : Array.isArray(apiData?.slots)
      ? apiData.slots
      : [];

  if (!slots.length) return {};

  const nested = {};

  slots.forEach((slot) => {
    if (!slot || typeof slot !== "object") return;

    const dayOffset = weekdayToDayOffset(slot.weekday);
    const sessionType = mapSessionType(slot.session);
    const period = Number(slot.period);
    const subject =
      slot.contentText ||
      slot.subjectName ||
      slot.subject ||
      "";

    if (dayOffset === null || !sessionType || !period || !subject) return;

    ensurePeriodCell(nested, dayOffset, period);

    const existing = nested[dayOffset][period][sessionType];
    const teachers = mergeTeachersList(existing?.teachers, slot.teachers);
    const classNames = [
      ...(existing?.className
        ? String(existing.className)
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean)
        : []),
      ...(slot.className ? [String(slot.className).trim()] : []),
    ].filter(Boolean);
    const uniqueClassNames = [...new Set(classNames)];

    nested[dayOffset][period][sessionType] = {
      subject: existing?.subject || subject,
      teachers,
      teacher: formatTeacherNames(teachers),
      type: resolveSubjectType(existing?.subject || subject),
      room: slot.roomName || slot.room || existing?.room || null,
      note: slot.note || existing?.note || null,
      className: uniqueClassNames.join(", ") || null,
      session: sessionType,
      period,
      weekday: Number(slot.weekday) || existing?.weekday || null,
    };
  });

  return nested;
};

/**
 * Convert dữ liệu TKB về format component
 * Hỗ trợ:
 * 1) { slots: [{ weekday, period, session, contentText, teachers }] }
 * 2) legacy { SANG: [{ period, days: { "2": {...} } }], CHIEU: [...] }
 * Output: { [dayOffset]: { [period]: { morning, afternoon } } }
 */
export const convertApiTimetableToNested = (apiData = {}) => {
  if (!apiData || typeof apiData !== "object") {
    return {};
  }

  if (Array.isArray(apiData) || Array.isArray(apiData.slots)) {
    return convertSlotsTimetableToNested(apiData);
  }

  const nested = {};
  const SANG = apiData.SANG || [];
  const CHIEU = apiData.CHIEU || [];

  const processSession = (sessionData, sessionType) => {
    if (!Array.isArray(sessionData)) return;

    sessionData.forEach((periodData) => {
      const { period, days = {} } = periodData;

      Object.keys(days).forEach((dayString) => {
        const dayOffset = weekdayToDayOffset(dayString);
        if (dayOffset === null) return;

        const dayData = days[dayString];
        ensurePeriodCell(nested, dayOffset, period);

        if (dayData && dayData.hasData !== false && dayData.subjectName) {
          const subjectName = dayData.subjectName || "";
          const existing = nested[dayOffset][period][sessionType];
          const teachers = mergeTeachersList(
            existing?.teachers,
            dayData.teachers,
          );

          nested[dayOffset][period][sessionType] = {
            subject: existing?.subject || subjectName,
            teachers,
            teacher: formatTeacherNames(teachers),
            type: resolveSubjectType(existing?.subject || subjectName),
            room: dayData.roomName || existing?.room || null,
            note: dayData.note || existing?.note || null,
            session: sessionType,
            period,
            weekday: Number(dayString) || existing?.weekday || null,
          };
        }
      });
    });
  };

  processSession(SANG, "morning");
  processSession(CHIEU, "afternoon");

  return nested;
};

/** Lấy thông tin GV từ response TKB (public/tkb/me) */
export const mapTeacherInfoFromTimetable = (apiData = {}, fallback = {}) => {
  if (!apiData || typeof apiData !== "object" || Array.isArray(apiData)) {
    return fallback || {};
  }

  return {
    ...(fallback || {}),
    teacherId: apiData.teacherId ?? fallback?.teacherId ?? null,
    teacherName: apiData.teacherName || fallback?.teacherName || "",
  };
};

/** Lấy thông tin lớp từ response TKB (kèm slots) */
export const mapClassInfoFromTimetable = (apiData = {}, fallback = {}) => {
  if (!apiData || typeof apiData !== "object" || Array.isArray(apiData)) {
    return fallback || {};
  }

  return {
    ...(fallback || {}),
    classId: apiData.classId ?? fallback?.classId ?? null,
    className: apiData.className || fallback?.className || "",
    homeroomTeacherName:
      apiData.homeroomTeacherName || fallback?.homeroomTeacherName || "",
    schoolYearName: fallback?.schoolYearName || apiData.schoolYearName || "",
    totalStudents: fallback?.totalStudents ?? apiData.totalStudents ?? "",
  };
};

/**
 * Tính số tiết tối đa từ dữ liệu thời khóa biểu đã convert
 * @param {Object} scheduleData - Dữ liệu thời khóa biểu đã convert { [dayOffset]: { [period]: {...} } }
 * @returns {Object} - { maxMorningPeriods: number, maxAfternoonPeriods: number }
 */
export const getMaxPeriods = (scheduleData = {}) => {
  let maxMorningPeriods = 0;
  let maxAfternoonPeriods = 0;

  Object.values(scheduleData).forEach((dayData) => {
    if (!dayData || typeof dayData !== "object") return;

    Object.keys(dayData).forEach((periodStr) => {
      const period = parseInt(periodStr);
      const periodData = dayData[period];

      if (periodData) {
        if (periodData.morning && period > maxMorningPeriods) {
          maxMorningPeriods = period;
        }
        if (periodData.afternoon && period > maxAfternoonPeriods) {
          maxAfternoonPeriods = period;
        }
      }
    });
  });

  return {
    maxMorningPeriods,
    maxAfternoonPeriods,
  };
};
