import Empty from "components/Emptys/EmptyIconText";
import PropTypes from "prop-types";
import { useMemo, useState } from "react";

import ScheduleTableBody from "./components/ScheduleTable/Body";
import ScheduleTableHeader from "./components/ScheduleTable/Header";
import WeekSelector from "./components/WeekSelector";
import { getWeekDates, isToday, getMaxPeriods } from "./helpers";
import {
  ScheduleContainer,
  ScheduleTableWrapper,
  ScheduleTable,
  ScheduleEmptyWrap,
} from "./Styled";

const buildPeriodList = (count) => {
  const periods = [];
  for (let i = 1; i <= count; i++) {
    periods.push({ period: i });
  }
  return periods;
};

const TimetableBoard = ({
  scheduleData = {},
  fetched = false,
  emptyDescription = "Không có dữ liệu thời khóa biểu",
  showWeekSelector = true,
  currentWeek: controlledWeek,
  onWeekChange,
}) => {
  const [internalWeek, setInternalWeek] = useState(0);
  const isControlled = controlledWeek !== undefined && controlledWeek !== null;
  const currentWeek = isControlled ? controlledWeek : internalWeek;

  const setWeek = (nextWeek) => {
    if (!isControlled) {
      setInternalWeek(nextWeek);
    }
    if (onWeekChange) {
      onWeekChange(nextWeek);
    }
  };

  const weekDates = useMemo(() => getWeekDates(currentWeek), [currentWeek]);

  const { maxMorningPeriods, maxAfternoonPeriods } = useMemo(
    () => getMaxPeriods(scheduleData),
    [scheduleData],
  );

  const hasSchedule = maxMorningPeriods > 0 || maxAfternoonPeriods > 0;

  const morningLessons = useMemo(
    () => buildPeriodList(maxMorningPeriods),
    [maxMorningPeriods],
  );

  const afternoonLessons = useMemo(
    () => buildPeriodList(maxAfternoonPeriods),
    [maxAfternoonPeriods],
  );

  const weekRange = useMemo(() => {
    const start = weekDates[0].date;
    const end = weekDates[weekDates.length - 1].date;
    return `${start.format("DD/MM/YYYY")} - ${end.format("DD/MM/YYYY")}`;
  }, [weekDates]);

  const todayOffset = useMemo(() => {
    const todayIndex = weekDates.findIndex((day) => isToday(day.date));
    return todayIndex >= 0 ? weekDates[todayIndex].offset : null;
  }, [weekDates]);

  const handlePreviousWeek = () => {
    setWeek(currentWeek - 1);
  };

  const handleNextWeek = () => {
    setWeek(currentWeek + 1);
  };

  const handleCurrentWeek = () => {
    setWeek(0);
  };

  return (
    <ScheduleContainer>
      {showWeekSelector && (
        <WeekSelector
          currentWeek={currentWeek}
          weekRange={weekRange}
          onPreviousWeek={handlePreviousWeek}
          onNextWeek={handleNextWeek}
          onCurrentWeek={handleCurrentWeek}
        />
      )}

      {fetched && !hasSchedule ? (
        <ScheduleEmptyWrap>
          <Empty description={emptyDescription} />
        </ScheduleEmptyWrap>
      ) : (
        <ScheduleTableWrapper>
          <ScheduleTable>
            <ScheduleTableHeader
              weekDates={weekDates}
              todayOffset={todayOffset}
            />
            <ScheduleTableBody
              morningLessons={morningLessons}
              afternoonLessons={afternoonLessons}
              weekDates={weekDates}
              scheduleData={scheduleData}
              todayOffset={todayOffset}
            />
          </ScheduleTable>
        </ScheduleTableWrapper>
      )}
    </ScheduleContainer>
  );
};

TimetableBoard.propTypes = {
  scheduleData: PropTypes.object,
  fetched: PropTypes.bool,
  emptyDescription: PropTypes.string,
  showWeekSelector: PropTypes.bool,
  currentWeek: PropTypes.number,
  onWeekChange: PropTypes.func,
};

export default TimetableBoard;
