import Checkbox from '@mui/material/Checkbox';
import debounce from 'lodash/debounce';
import PropTypes from 'prop-types';
import { memo, useState, useCallback, useEffect } from 'react';

import AppCheckedItemContainer from './Styled'

const AppCheckedItem = ({ 
  checked,
  label = '', 
  disabled = false, 
  onChecked = () => {}, 
  ...props 
}) => {
  const [isChecked, setChecked] = useState(checked);

  useEffect(()=>{
    if(checked !== isChecked) setChecked(checked)
  }, [checked])

  const handleChange = (event) => {
    const newChecked = event.target.checked;
    setChecked(newChecked);

    debouncedOnChecked(newChecked);
  };

  // Debounced function to update the backend or list after a delay
  const debouncedOnChecked = useCallback(
    debounce((newChecked) =>  onChecked(newChecked), 200),
    [onChecked]
  );

  return (
    <AppCheckedItemContainer
      disabled={disabled}
      label={label}
      {...props}
      control={
        <Checkbox
          checked={isChecked}
          onChange={handleChange}
          aria-checked={isChecked}
        />
      }
    />
  );
};

// PropTypes validation
AppCheckedItem.propTypes = {
  disabled: PropTypes.bool,
  label: PropTypes.string,
  checked: PropTypes.bool.isRequired,
  onChecked: PropTypes.func.isRequired,
};

export default memo(AppCheckedItem);
