import FormControlLabel from '@mui/material/FormControlLabel';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs'

const AppCheckedItemContainer = styled(FormControlLabel)`
  gap: 16px;
  height: 40px;
  margin: 0 !important;
  width: max-content;
  padding: 0;
  border-top: unset;
  padding: 0 16px;

  .MuiTypography-body1{
    font-family: 'SVN_Gilroy';
    font-size: 14px;
    font-weight: 500;
    color: ${VPB_THEMES.colors.btnColor};
  }
  .MuiCheckbox-root{
    padding: 4px;
  }
`;

export default AppCheckedItemContainer;
