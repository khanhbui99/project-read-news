import { DateTimePicker } from '@mui/x-date-pickers';
import React, { memo } from 'react';

import AppTextField from '../AppTextField';

const AppDatePickerField = ({
  rq,
  name,
  errorMessage,
  onBlur = () => {},
  onChange = () => {},
  ...props
}) => (
  <DateTimePicker
    name={name}
    renderInput={({ error, InputProps, ...params }) => (
      <AppTextField
        {...params}
        rq={rq}
        errorMessage={errorMessage}
        endAdornment={InputProps.endAdornment}
        onBlur={() => onBlur({ target: { name } })}
      />
    )}
    onChange={value => onChange({ target: { name, value } })}
    {...props}
  />
);

export default memo(AppDatePickerField);
