import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs'

import OutlineInput from '../OutlineInput';

export const SelectedStyle = styled.div`
  gap: 4px;
  display: flex;
  flex-wrap: wrap;
`;

export const ChipLabelStyle = styled.div`
  gap: 3px;
  display: flex;
  align-items: center;
`;

export const ChipCloseStyle = styled.span`
  color: #fff;
  width: 14px;
  height: 14px;
  cursor: pointer;
  border-radius: 14px;
  align-items: center;
  display: inline-flex;
  justify-content: center;
  transition: background-color 0.2s;
  background-color: rgb(0, 0, 0, 0.175);

  &:hover {
    background-color: rgb(0, 0, 0, 0.3);
  }
`;

const TextFieldStyle = styled(OutlineInput)`
  & .MuiInputBase-root {
    border-radius: 8px !important;

    fieldset {
      border-color: ${VPB_THEMES.colors.gray.fieldset};
      border-width: 1px !important;
    }
  }

  & .MuiInputBase-input {
    padding-top: 10.5px !important;
    padding-bottom: 10.5px !important;
  }

  & .MuiFormLabel-root {
    font-size: 1.075rem;
    transform: translate(14px, ${p => (p.size === 'small' ? 10 : 14)}px)
      scale(1);

    &.Mui-focused,
    &.MuiFormLabel-filled {
      transform: translate(14px, -9px) scale(0.75);
    }
  }

  & legend span {
    font-size: 0.8125rem;
  }
`;

export default TextFieldStyle;
