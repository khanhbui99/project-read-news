import CloseIcon from "@mui/icons-material/Close";
import {
  Checkbox,
  Chip,
  FormControlLabel,
  ListSubheader,
  Select,
} from "@mui/material";
import FormControl from "@mui/material/FormControl";
import MenuItem from "@mui/material/MenuItem";
import cloneDeep from "lodash/cloneDeep";
import isArray from "lodash/isArray";
import without from "lodash/without";
import React, { memo, useMemo, useState } from "react";

import { VPB_THEMES } from "../../../utils/configs";
import AppInputField from "../AppInputField";
import ErrorMessage from "../ErrorMessage";
import InputLabel from "../InputLabel";
import TextFieldStyle, {
  ChipCloseStyle,
  ChipLabelStyle,
  SelectedStyle,
} from "./style";

const AppMultipleSelectField = ({
  rq,
  label,
  field = "",
  errorMessage,
  enabledSearch,
  size = "small",
  enabledSelectAll,
  labelField = "",
  startAdornment,
  options = [],
  value = [],
  className,
  isLabelTop,
  onChange = () => {},
  ...props
}) => {
  const [search, setSearch] = useState("");
  const key = useMemo(() => field || "value", [field]);
  const labelKey = useMemo(() => labelField || "label", [labelField]);

  const searchOpt = useMemo(() => {
    return (options || []).filter((o) => {
      return `${o[labelKey]}`.toLowerCase().includes(search.toLowerCase());
    });
  }, [options, search, labelKey]);

  const internalValue = useMemo(() => (isArray(value) ? value : []), [value]);

  const handleDelete = (val) => {
    const clone = isArray(value) ? cloneDeep(value) : [];
    onChange({
      target: {
        name: props.name,
        value: without(clone, val),
      },
    });
  };

  const handleCheckAll = () => {
    if (internalValue.length < options.length) {
      onChange({
        target: {
          name: props.name,
          value: options.map((o) => o[key]),
        },
      });

      return;
    }

    onChange({
      target: {
        name: props.name,
        value: [],
      },
    });
  };

  const getLabel = () => (
    <>
      {label}{" "}
      {rq ? (
        <span
          style={{
            verticalAlign: "middle",
            color: VPB_THEMES.colors.red,
          }}
        >
          *
        </span>
      ) : null}
    </>
  );

  return (
    <FormControl
      fullWidth
      variant="standard"
      className={className}
      disabled={props.disabled}
    >
      {!isLabelTop && (
        <InputLabel
          size={size}
          startAdornment={startAdornment}
          shrink
          htmlFor="bootstrap-input"
        >
          {getLabel()}
        </InputLabel>
      )}

      {isLabelTop && (
        <label
          style={{
            fontSize: 12,
            marginBottom: 5,
            lineHeight: "17px",
            fontFamily: "SVN_Gilroy",
            color: VPB_THEMES.colors.secondaryText,
          }}
        >
          {getLabel()}
        </label>
      )}

      <Select
        id="bootstrap-input"
        multiple
        input={
          <TextFieldStyle
            size={size}
            label={isLabelTop ? null : getLabel()}
            value={internalValue}
            error={!!errorMessage}
            startAdornment={startAdornment}
            {...props}
          />
        }
        renderValue={(selected) => (
          <SelectedStyle>
            {(selected || []).map((val, idx) => (
              <Chip
                key={`${val}-${idx}`}
                sx={{
                  height: "unset",
                  ".MuiChip-label": {
                    paddingLeft: "8px",
                    paddingRight: props.disabled ? "8px" : "3px",
                  },
                }}
                label={
                  <ChipLabelStyle>
                    {
                      (options.find((o) => `${o[key]}` === `${val}`) || {})[
                        labelKey
                      ]
                    }
                    {!props.disabled ? (
                      <ChipCloseStyle
                        onClick={() => handleDelete(val)}
                        onMouseDown={(event) => event.stopPropagation()}
                      >
                        <CloseIcon style={{ width: 10, height: 10 }} />
                      </ChipCloseStyle>
                    ) : null}
                  </ChipLabelStyle>
                }
              />
            ))}
          </SelectedStyle>
        )}
        onChange={(e) => {
          const v = e.target.value.filter((t) => !!t);
          onChange({ ...e, target: { ...e.target, value: v } });
        }}
        {...props}
      >
        {enabledSelectAll ? (
          <ListSubheader>
            <FormControlLabel
              label="Select all"
              control={
                <Checkbox checked={internalValue.length === options.length} />
              }
              onChange={handleCheckAll}
            />
          </ListSubheader>
        ) : null}
        {enabledSearch ? (
          <li
            role="application"
            style={{ padding: "4px 16px 8px 16px" }}
            onKeyDown={(e) => {
              e.stopPropagation();
            }}
            onKeyUp={(e) => {
              e.stopPropagation();
            }}
          >
            <AppInputField
              delay={300}
              label="Search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </li>
        ) : null}
        {searchOpt.map((o, idx) => (
          <MenuItem key={`${o[key]}-${idx}`} value={o[key]}>
            {o[labelKey]}
          </MenuItem>
        ))}
      </Select>
      <ErrorMessage errorMessage={errorMessage} />
    </FormControl>
  );
};

export default memo(AppMultipleSelectField);
