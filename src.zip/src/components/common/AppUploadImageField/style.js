import styled, { keyframes } from 'styled-components';
import { VPB_THEMES } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

import Button from '../AppButton';

const scale = keyframes`
0% { transform: scale(1) }
1% {transform: scale(1.4)}
2% {transform: scale(1)}
3% {transform: scale(1.3)}
4% {transform: scale(1)}
`;

export const PreviewImageStyle = styled.div`
  overflow: hidden;
  border-radius: 15px;
  background-color: rgb(0, 0, 0, 0.05);
  border: 1px dotted ${VPB_THEMES.colors.gray[300]};
  width: ${p => (p.width ? `${p.width}px` : '100%')};
`;

export const NoteStyle = styled.p`
  line-height: 1.1;
  margin: 6px 0 0 0;
  font-size: ${pxToRem(12)};
`;

export const AnimateButtonStyle = styled(Button)`
  animation-delay: 0.3s;
  animation-duration: 15s;
  animation-iteration-count: infinite;
  animation-name: ${p => (p.disabled ? '' : scale)};
`;
