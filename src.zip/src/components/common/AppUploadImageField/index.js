import CloudUploadOutlinedIcon from "@mui/icons-material/CloudUploadOutlined";
import { InputAdornment } from "@mui/material";
import BenefitIcons from "assets/icons/product.benefit";
import { useSnackbar } from "notistack";
import React, { memo, useEffect, useRef, useState } from "react";
import urlApi from "services/api.url";
import { isSvgUrl } from "utils/helpers";
import { post } from "utils/request";

import AppTextField from "../AppTextField";
import Svg from "../Svg";
import Tooltip from "../Tooltip";
import { AnimateButtonStyle, NoteStyle, PreviewImageStyle } from "./style";

const acceptExtension = ["gif", "png", "jpeg", "jpg", "svg"];
const maxFileCapacity = 1024 * 1024 * 2; // 2MB

const AppUploadImageField = ({
  value,
  width,
  imgSize,
  disabled,
  className,
  folderName,
  ratio = 507 / 320,
  extensions = acceptExtension,
  maxCapacity = maxFileCapacity,
  url = urlApi.managementService.s3.uploadResource,
  onChange = () => {},
  isShowPreview = true,
  ...props
}) => {
  const previewRef = useRef();
  const { enqueueSnackbar } = useSnackbar();
  const [preview, setPreview] = useState("");
  const [selectedFile, setSelectedFile] = useState();
  const [previewHeight, setPreviewHeight] = useState("unset");

  const onSelectFile = (e) => {
    const path = e.target.value;
    const extension = path.substring(path.lastIndexOf(".") + 1).toLowerCase();

    if (!e.target.files || e.target.files.length === 0) {
      setSelectedFile(undefined);
      return;
    }

    if (!extensions.includes(extension)) {
      enqueueSnackbar(
        `System support only ${extensions.join(", ")} extension`,
        {
          variant: "error",
        }
      );
      return;
    }

    if (e.target.files[0].size > maxCapacity) {
      enqueueSnackbar(`Size must be smaller than 2MB`, {
        variant: "error",
      });
      return;
    }

    setSelectedFile(e.target.files[0]);
  };

  const handleSave = async () => {
    const payload = new FormData();
    payload.append("file", selectedFile);
    payload.append("docType", folderName);

    const requestData = {
      url,
      data: payload,
      multipart: true,
    };

    try {
      const { data: res = {} } = await post(requestData);

      const { data = "" } = res;

      setSelectedFile("");
      onChange({ target: { name: props.name, value: data || "//" } });
      enqueueSnackbar("upload success!", {
        variant: "success",
      });
    } catch (err) {
      enqueueSnackbar(err.message || "upload fail!", {
        variant: "error",
      });
    }
  };

  const handleChange = (e) => {
    setSelectedFile("");
    onChange(e);
  };

  const renderIcon = (src) =>
    isSvgUrl(src) ? (
      <Svg url={src} />
    ) : (
      <img className="w-full" src={src} alt="preview" />
    );

  useEffect(() => {
    if (value) setPreview(value);
  }, [value]);

  useEffect(() => {
    if (!selectedFile) {
      return;
    }

    const objectUrl = URL.createObjectURL(selectedFile);
    setPreview(objectUrl);
    onChange({ target: { name: props.name, value: "" } });

    return () => URL.revokeObjectURL(objectUrl);
  }, [selectedFile]);

  useEffect(() => {
    if (!previewRef.current) return;

    setPreviewHeight((previewRef.current.clientWidth + 2) / ratio);
  }, [previewRef.current]);

  return (
    <div className={className}>
      <div className={`flex gap-16 ${isShowPreview ? "mb-24" : ""}`}>
        <AppTextField
          {...props}
          value={value}
          disabled={disabled}
          className="col-span-3 w-full"
          endAdornment={
            <InputAdornment position="end" sx={{ minWidth: "18px" }}>
              <label
                className="pointer"
                style={{ lineHeight: 1 }}
                htmlFor={`upload-${props.name}`}
              >
                <Tooltip
                  arrow
                  title="Choose image"
                  disableHoverListener={disabled}
                >
                  <img
                    alt="camera"
                    disabled={disabled}
                    className="line-clamp"
                    src={BenefitIcons.camera}
                  />
                </Tooltip>
                <input
                  hidden
                  type="file"
                  accept="image/*"
                  disabled={disabled}
                  key={Math.random()}
                  id={`upload-${props.name}`}
                  onChange={onSelectFile}
                />
              </label>
            </InputAdornment>
          }
          onChange={handleChange}
        />
        <AnimateButtonStyle
          key={preview}
          type="button"
          tooltip="Upload"
          disabled={!selectedFile}
          style={{ minWidth: 50 }}
          onClick={handleSave}
        >
          <CloudUploadOutlinedIcon />
        </AnimateButtonStyle>
      </div>
      {isShowPreview && (
        <>
          <PreviewImageStyle
            width={width}
            ref={previewRef}
            style={{
              height: previewHeight,
            }}
          >
            {preview ? renderIcon(preview) : null}
          </PreviewImageStyle>
          <NoteStyle className="xml">Kích thước: {imgSize}</NoteStyle>
          <NoteStyle className="string">
            Dung lượng: {"<="} {maxCapacity / (1024 * 1024)}MB
          </NoteStyle>
          <NoteStyle className="string">
            Định dạng: {extensions.join(", ")}
          </NoteStyle>
        </>
      )}
    </div>
  );
};

export default memo(AppUploadImageField);
