import PropTypes from 'prop-types';
import React from 'react';

import LoadingStyle from './LoadingStyle';

function LoadingPage({ loading, ...props }) {
  return (
    <>
      {loading && (
        <LoadingStyle>
          <div className='loadingWrapper'>
            <div className="loadingIcon" />
          </div>
        </LoadingStyle>
      )}
    </>
  );
}

LoadingPage.propTypes = {
  loading: PropTypes.bool,
  className: PropTypes.string,
};

export default LoadingPage;
