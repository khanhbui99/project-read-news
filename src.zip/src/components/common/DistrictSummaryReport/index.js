import BarChartIcon from "@mui/icons-material/BarChart";
import FilterListIcon from "@mui/icons-material/FilterList";
import { Box } from "@mui/material";
import ChartSkeleton from "components/Charts/ChartSkeleton";
import StackColumnChart from "components/Charts/StackColumnChart";
import AppButton from "components/common/AppButton";
import EmptyIconText from "components/Emptys/EmptyIconText";
import { BoxShadow } from "components/Styled";
import PropTypes from "prop-types";
import { useEffect, useMemo, useState } from "react";

import FilterModal from "./components/FilterModal";
import useDistrictSummary from "./hooks/useDistrictSummary";
import {
  ChartContainerStyled,
  ChartHeaderStyled,
  ChartContentStyled,
} from "./Styled";

/**
 * Component báo cáo tổng hợp theo quận/huyện - có thể tái sử dụng
 *
 * @param {string} categoryName - Category code để gọi API (ví dụ: "CLASSROOM", "STUDENT_QUALITY", "CLASSROOM,STUDENT_QUALITY")
 * @param {string} title - Tiêu đề chart (mặc định: "Tổng hợp theo quận/huyện")
 * @param {string} description - Mô tả chart (mặc định: "Thống kê tổng hợp dữ liệu theo từng quận/huyện")
 * @param {string} yAxisTitle - Tiêu đề trục Y (mặc định: "Số liệu")
 * @param {Function} onPointClick - Callback khi click vào điểm trên chart
 * @param {Object} chartConfig - Cấu hình bổ sung cho chart
 * @param {Function} transformData - Function để transform data từ API (optional)
 */
const DistrictSummaryReport = ({
  categoryName,
  title = "Tổng hợp theo quận/huyện",
  description = "Thống kê tổng hợp dữ liệu theo từng quận/huyện",
  yAxisTitle = "Số liệu",
  onPointClick = null,
  chartConfig = {},
  transformData = null,
  metricField = [],
}) => {
  const {
    data: districtSummary,
    loading,
    error,
  } = useDistrictSummary(categoryName);

  // State cho filter modal
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Lấy năm hiện tại
  // const currentYear = useMemo(() => {
  //   const currentDate = new Date();
  //   const currentYearNum = currentDate.getFullYear();
  //   const nextYearNum = currentYearNum + 1;
  //   return `${currentYearNum}-${nextYearNum}`;
  // }, []);

  // State cho filters - mặc định
  const [filters, setFilters] = useState({
    // year: currentYear, // Năm hiện tại
    schoolTypes: [], // Sẽ được set sau khi có filterOptions
    districts: [], // Sẽ được set sau khi có filterOptions
  });

  // Tạo map từ metricField để dễ lookup
  const metricFieldMap = useMemo(() => {
    if (!metricField || !Array.isArray(metricField) || metricField.length === 0) {
      return new Map();
    }
    const map = new Map();
    metricField.forEach((field) => {
      if (field.value) {
        map.set(field.value, {
          label: field.label || field.value,
          color: field.color || "#2563EB",
        });
      }
    });
    return map;
  }, [metricField]);

  // Extract filter options từ data
  const filterOptions = useMemo(() => {
    if (!districtSummary || typeof districtSummary !== "object") {
      return { districts: [], years: [], schoolTypes: [] };
    }

    const districts = [];
    // const years = new Set();
    const schoolTypes = new Set();

    Object.keys(districtSummary).forEach((districtCode) => {
      const districtsArray = districtSummary[districtCode];
      if (Array.isArray(districtsArray)) {
        districtsArray.forEach((district) => {
          // Thêm district vào danh sách
          if (
            district.districtCode &&
            !districts.find((d) => d.districtCode === district.districtCode)
          ) {
            districts.push({
              districtCode: district.districtCode,
              districtName: district.districtName || district.name,
            });
          }

          // Thêm year
          // if (district.year) {
          //   years.add(district.year);
          // }

          // Thêm schoolType
          if (district.schoolType) {
            schoolTypes.add(district.schoolType);
          }
        });
      }
    });

    // Sắp xếp districts theo tên
    districts.sort((a, b) => {
      const nameA = a.districtName || "";
      const nameB = b.districtName || "";
      return nameA.localeCompare(nameB);
    });

    return {
      districts: districts, // Lấy tất cả districts
      years: [], // Array.from(years).sort(),
      schoolTypes: Array.from(schoolTypes),
    };
  }, [districtSummary]);

  // Set default filters khi có filterOptions
  useEffect(() => {
    if (filterOptions.schoolTypes && filterOptions.schoolTypes.length > 0) {
      setFilters((prev) => {
        // Chỉ set nếu chưa có giá trị
        if (prev.schoolTypes.length === 0) {
          return {
            ...prev,
            schoolTypes: filterOptions.schoolTypes, // Tất cả loại trường
          };
        }
        return prev;
      });
    }

    if (filterOptions.districts && filterOptions.districts.length > 0) {
      setFilters((prev) => {
        // Chỉ set nếu chưa có giá trị
        if (prev.districts.length === 0) {
          // Lấy 5 districts đầu tiên
          const defaultDistricts = filterOptions.districts.slice(0, 5);
          return {
            ...prev,
            districts: defaultDistricts,
          };
        }
        return prev;
      });
    }

    // Set năm học nếu có trong options
    // if (filterOptions.years && filterOptions.years.length > 0) {
    //   setFilters((prev) => {
    //     // Chỉ set nếu chưa có giá trị hoặc giá trị không hợp lệ
    //     if (!prev.year || !filterOptions.years.includes(prev.year)) {
    //       // Tìm năm hiện tại trong options, nếu không có thì lấy năm đầu tiên
    //       const yearIndex = filterOptions.years.indexOf(currentYear);
    //       return {
    //         ...prev,
    //         year: yearIndex >= 0 ? currentYear : filterOptions.years[0] || "",
    //       };
    //     }
    //     return prev;
    //   });
    // }
  }, [filterOptions]);

  const chartData = useMemo(() => {
    // Nếu có transformData function, sử dụng nó
    if (transformData && typeof transformData === "function") {
      return transformData(districtSummary);
    }

    // Transform mặc định cho format mới
    // Format từ hook: { "10003": [{ districtName, metrics: [...] }] }
    // Hook đã trả về res[category] nên districtSummary là categoryData
    if (
      !districtSummary ||
      typeof districtSummary !== "object" ||
      Object.keys(districtSummary).length === 0
    ) {
      return { data: [], series: [] };
    }

    // Thu thập tất cả districts từ tất cả districtCodes và áp dụng filter
    const districtsMap = new Map();
    Object.keys(districtSummary).forEach((districtCode) => {
      const districts = districtSummary[districtCode];
      if (Array.isArray(districts) && districts.length > 0) {
        districts.forEach((district) => {
          // Áp dụng filter - chỉ filter nếu có giá trị
          // Filter theo year
          // if (
          //   filters.year &&
          //   filters.year.trim() !== "" &&
          //   district.year !== filters.year
          // ) {
          //   return;
          // }
          // Filter theo schoolTypes
          if (
            filters.schoolTypes &&
            filters.schoolTypes.length > 0 &&
            district.schoolType &&
            !filters.schoolTypes.includes(district.schoolType)
          ) {
            return;
          }
          // Filter theo districts
          if (filters.districts && filters.districts.length > 0) {
            const districtCode = district.districtCode;
            const isMatched = filters.districts.some((d) => {
              const filterCode = d.districtCode || d.code || d.value || d;
              return filterCode === districtCode;
            });
            if (!isMatched) {
              return;
            }
          }

          // Nếu districtCode đã tồn tại, merge metrics (cộng giá trị)
          if (district && district.districtCode) {
            const existing = districtsMap.get(district.districtCode);
            if (existing) {
              // Merge metrics: cộng giá trị của cùng metricCode
              const existingMetrics = existing.metrics || [];
              const newMetrics = district.metrics || [];
              const mergedMetricsMap = new Map();

              // Thêm existing metrics
              existingMetrics.forEach((m) => {
                mergedMetricsMap.set(m.metricCode, parseFloat(m.value || 0));
              });

              // Cộng thêm new metrics
              newMetrics.forEach((m) => {
                const currentValue = mergedMetricsMap.get(m.metricCode) || 0;
                mergedMetricsMap.set(
                  m.metricCode,
                  currentValue + parseFloat(m.value || 0)
                );
              });

              // Convert back to array
              const mergedMetrics = Array.from(mergedMetricsMap.entries()).map(
                ([metricCode, value]) => ({
                  metricCode,
                  value: value.toString(),
                })
              );

              districtsMap.set(district.districtCode, {
                ...existing,
                metrics: mergedMetrics,
              });
            } else {
              districtsMap.set(district.districtCode, district);
            }
          }
        });
      }
    });

    let allDistricts = Array.from(districtsMap.values());

    if (allDistricts.length === 0) {
      return { data: [], series: [] };
    }

    // Sắp xếp theo districtCode để đảm bảo thứ tự nhất quán
    allDistricts.sort((a, b) => {
      const codeA = a?.districtCode || "";
      const codeB = b?.districtCode || "";
      return codeA.localeCompare(codeB);
    });

    // Giới hạn chỉ hiển thị 5 districts đầu tiên trên chart
    // (Nếu không có filter districts nào được chọn)
    if (!filters.districts || filters.districts.length === 0) {
      allDistricts = allDistricts.slice(0, 5);
    }

    // Lấy tất cả metric codes từ item đầu tiên
    const firstItem = allDistricts[0];
    const metrics = firstItem?.metrics || [];
    const allMetricCodes = metrics.map((m) => m.metricCode);

    if (allMetricCodes.length === 0) {
      return { data: [], series: [] };
    }

    // Chỉ lấy các metric codes có trong metricField
    const metricCodes = allMetricCodes.filter((code) =>
      metricFieldMap.has(code)
    );

    if (metricCodes.length === 0) {
      return { data: [], series: [] };
    }

    // Helper function để lấy label cho metric
    const getMetricLabel = (metricCode) => {
      const field = metricFieldMap.get(metricCode);
      return field ? field.label : metricCode;
    };

    // Helper function để lấy màu cho metric
    const getMetricColor = (metricCode) => {
      // Lấy từ metricField
      const field = metricFieldMap.get(metricCode);
      if (field && field.color) {
        return field.color;
      }
      // Fallback
      return "#2563EB";
    };

    // Tạo data array cho StackColumnChart
    // Mỗi district là một object với các metric values
    const chartDataArray = allDistricts.map((district) => {
      const dataItem = {
        districtName: district.districtName || district.name || "N/A",
      };

      metricCodes.forEach((metricCode) => {
        const metric = district?.metrics?.find(
          (m) => m.metricCode === metricCode
        );
        dataItem[metricCode] = parseFloat(metric?.value || 0);
      });

      return dataItem;
    });

    // Tạo series config cho StackColumnChart
    // Mỗi metric là một series để tạo cột chồng
    // Chỉ thêm series nếu chưa tồn tại (tránh duplicate)
    const seriesConfig = [];
    const existingDataKeys = new Set();

    metricCodes.forEach((metricCode) => {
      // Kiểm tra xem dataKey đã tồn tại chưa
      if (!existingDataKeys.has(metricCode)) {
        seriesConfig.push({
          name: getMetricLabel(metricCode),
          dataKey: metricCode,
          color: getMetricColor(metricCode),
        });
        existingDataKeys.add(metricCode);
      }
    });

    return { data: chartDataArray, series: seriesConfig };
  }, [districtSummary, transformData, categoryName, filters, metricField, metricFieldMap]);

  return (
    <ChartContainerStyled>
      <BoxShadow
        $padding={24}
        $borderRadius={8}
        $background="#fff"
        $boxShadow="0 4px 16px rgba(0, 0, 0, 0.08)"
      >
        <ChartHeaderStyled>
          <Box
            sx={{
              display: "flex",
              width: "100%",
              alignItems: "flex-start",
              gap: { xs: 1, sm: 2 },
              marginBottom: 2,
            }}
          >
            <BarChartIcon
              sx={{
                fontSize: { xs: 24, sm: 28, md: 32 },
                color: "#2563EB",
                flexShrink: 0,
              }}
            />
            <Box sx={{ flex: 1 }}>
              <h3
                style={{
                  margin: 0,
                  fontSize: "clamp(1.1rem, 2vw, 1.5rem)",
                  fontWeight: 700,
                  lineHeight: 1.3,
                }}
              >
                {title}
              </h3>
              <p
                style={{
                  margin: "0.5rem 0 0 0",
                  color: "#526779",
                  fontSize: "clamp(0.8rem, 1.5vw, 0.9rem)",
                  lineHeight: 1.5,
                }}
              >
                {description}
              </p>
            </Box>
            <AppButton
              outline
              startIcon={<FilterListIcon />}
              onClick={() => setIsFilterOpen(true)}
              type="button"
            >
              Bộ lọc
            </AppButton>
          </Box>
        </ChartHeaderStyled>

        {/* Filter Modal */}
        <FilterModal
          open={isFilterOpen}
          onClose={() => setIsFilterOpen(false)}
          onSubmit={(newFilters) => {
            setFilters(newFilters);
          }}
          districts={filterOptions.districts}
          years={[]}
          // years={filterOptions.years}
          schoolTypes={filterOptions.schoolTypes}
          filters={filters}
        />
        <ChartContentStyled>
          {loading ? (
            <ChartSkeleton
              height={450}
              bars={chartData.categories?.length || 8}
            />
          ) : error ? (
            <EmptyIconText
              description="Có lỗi xảy ra khi tải dữ liệu!"
              descProps={{ style: { textAlign: "center" } }}
            />
          ) : chartData.data?.length > 0 && chartData.series?.length > 0 ? (
            <StackColumnChart
              data={chartData.data}
              series={chartData.series}
              categorieField="districtName"
              yAxisTitle={yAxisTitle}
              onPointClick={onPointClick}
              chartConfig={chartConfig}
            />
          ) : (
            <EmptyIconText
              description="Chưa có dữ liệu!"
              descProps={{ style: { textAlign: "center" } }}
            />
          )}
        </ChartContentStyled>
      </BoxShadow>
    </ChartContainerStyled>
  );
};

DistrictSummaryReport.propTypes = {
  categoryName: PropTypes.string.isRequired,
  title: PropTypes.string,
  description: PropTypes.string,
  yAxisTitle: PropTypes.string,
  onPointClick: PropTypes.func,
  chartConfig: PropTypes.object,
  transformData: PropTypes.func,
  metricField: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string,
      color: PropTypes.string,
    })
  ),
};

export default DistrictSummaryReport;
