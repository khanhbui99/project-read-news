import { Box } from "@mui/material";
import styled from "styled-components";

export const ChartContainerStyled = styled(Box)`
  width: 100%;
  margin-bottom: 0;
  overflow: hidden;

  @media (max-width: 768px) {
    margin-bottom: 0;
  }
`;

export const ChartHeaderStyled = styled(Box)`
  width: 100%;
`;

export const ChartContentStyled = styled(Box)`
  width: 100%;
  min-height: 450px;
  position: relative;

  @media (max-width: 768px) {
    min-height: 450px;
  }
`;

