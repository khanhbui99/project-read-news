import { OutlinedInput as Base } from '@mui/material';
import PropTypes from 'prop-types';

const OutlineInput = ({ notBorder, sx, value, InputProps, ...props }) => {
  const safeValue = value === null ? '' : value;

  // Filter out InputProps to prevent it from being passed to DOM
  // OutlinedInput uses startAdornment/endAdornment directly, not InputProps
  const { startAdornment, endAdornment, ...restInputProps } = InputProps || {};

  return (
    <Base
      value={safeValue}
      startAdornment={startAdornment}
      endAdornment={endAdornment}
      inputProps={Object.keys(restInputProps).length > 0 ? restInputProps : undefined}
      sx={{
        '&': {
          borderRadius: '8px',
        },
        '&.MuiInputBase-adornedStart': {
          paddingLeft: '12px',
        },
        '& .MuiIconButton-edgeEnd': {
          marginRight: '-4px',
        },
        '& .MuiOutlinedInput-input': {
          fontWeight: 500,
          fontSize: '14px',
          paddingTop: '14px',
          paddingBottom: '14px',
        },
        '&.MuiInputBase-sizeSmall .MuiOutlinedInput-input:not(textarea)': {
          paddingTop: '10px',
          paddingBottom: '10px',
        },
        '&.MuiInputBase-sizeSmall textarea.MuiOutlinedInput-input': {
          paddingTop: '1.5px',
          paddingBottom: '1.5px',
        },
        '& .MuiOutlinedInput-notchedOutline': {
          padding: '0 8px',
          ...(notBorder ? { border: 'none' } : {}),
        },
        ...sx,
      }}
      {...props}
    />
  );
};

OutlineInput.propTypes = {
  notBorder: PropTypes.bool,
  sx: PropTypes.object,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default OutlineInput;
