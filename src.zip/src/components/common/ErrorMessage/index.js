import React from 'react';
import { VPB_THEMES } from 'utils/configs';

const ErrorMessage = ({ errorMessage, style }) =>
  errorMessage ? (
    <span
      style={{
        left: 0,
        top: 'calc(100% + 4px)',
        fontWeight: 300,
        lineHeight: 1.2,
        fontSize: '12px',
        padding: '0 12px',
        position: 'absolute',
        color: VPB_THEMES.colors.red,
        ...style,
      }}
    >
      {errorMessage}
    </span>
  ) : null;

export default ErrorMessage;
