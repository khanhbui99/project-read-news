import CodeIcon from '@mui/icons-material/Code';
import CopyAllIcon from '@mui/icons-material/CopyAll';
import DataObjectIcon from '@mui/icons-material/DataObject';
import DoneOutlinedIcon from '@mui/icons-material/DoneOutlined';
import { IconButton } from '@mui/material';
import React, { useState } from 'react';
import { VPB_THEMES } from 'utils/configs';

import Tooltip from '../Tooltip';
import DataStyle from './style';

const CopyIcon = ({ copied }) => (
  <Tooltip arrow placement="top" title={copied ? 'copied' : 'copy'}>
    {copied ? (
      <DoneOutlinedIcon className="copy-btn boolean" />
    ) : (
      <CopyAllIcon className="pointer copy-btn boolean" />
    )}
  </Tooltip>
);

const FormatData = ({ data, handleViewDetail = () => {} }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(data);
  };

  if (data === true || data === false) {
    return (
      <DataStyle
        className="boolean"
        onClick={() => {
          handleCopy();
          setCopied(true);
        }}
        onMouseLeave={() => setCopied(false)}
      >
        {`${data}`} <CopyIcon copied={copied} />
      </DataStyle>
    );
  }

  if (data === null || data === 'null') {
    return (
      <DataStyle
        className="null"
        onClick={() => {
          handleCopy();
          setCopied(true);
        }}
        onMouseLeave={() => setCopied(false)}
      >
        {`${data}`} <CopyIcon copied={copied} />
      </DataStyle>
    );
  }

  if (typeof data === 'number' || Number(data) || Number(data) === 0) {
    return (
      <DataStyle
        onClick={() => {
          handleCopy();
          setCopied(true);
        }}
        onMouseLeave={() => setCopied(false)}
      >
        {data} <CopyIcon copied={copied} />
      </DataStyle>
    );
  }

  try {
    let obj = JSON.parse(data);
    if (typeof obj === 'string') obj = JSON.parse(obj);
    return (
      <Tooltip arrow title="View more...">
        <IconButton
          style={{ color: VPB_THEMES.colors.object }}
          onClick={() => handleViewDetail(obj)}
        >
          <DataObjectIcon />
        </IconButton>
      </Tooltip>
    );
  } catch {
    if (data.indexOf('<?xml') !== -1) {
      return (
        <Tooltip arrow title="View more...">
          <IconButton
            style={{ color: VPB_THEMES.colors.xml }}
            onClick={() => handleViewDetail(data)}
          >
            <CodeIcon />
          </IconButton>
        </Tooltip>
      );
    }

    if (data.length > 20) {
      return (
        <DataStyle
          className="flex"
          onClick={() => {
            handleCopy();
            setCopied(true);
          }}
          onMouseLeave={() => setCopied(false)}
        >
          <Tooltip arrow title={data}>
            <div className="line-clamp">{data}</div>
          </Tooltip>
          <CopyIcon copied={copied} />
        </DataStyle>
      );
    }

    if (typeof data === 'object') {
      return (
        <Tooltip arrow title="View more...">
          <IconButton
            style={{ color: VPB_THEMES.colors.object }}
            onClick={() => handleViewDetail(data)}
          >
            <DataObjectIcon />
          </IconButton>
        </Tooltip>
      );
    }

    return (
      <DataStyle
        onClick={() => {
          handleCopy();
          setCopied(true);
        }}
        onMouseLeave={() => setCopied(false)}
      >
        {data} <CopyIcon copied={copied} />
      </DataStyle>
    );
  }
};

export default FormatData;
