import styled from "styled-components";

const DataStyle = styled.div`
  max-width: 300px;
  .copy-btn {
    opacity: 0;
    height: 18px;
    pointer-events: none;
  }

  &:hover {
    .copy-btn {
      opacity: 1;
      pointer-events: auto;
    }
  }
`;

export default DataStyle;
