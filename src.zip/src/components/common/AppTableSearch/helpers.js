import { toAccentVietnamese } from "utils/helpers";

/**
 * Cache cho normalized strings để tránh normalize lại nhiều lần
 * Key: original string, Value: normalized string
 */
const normalizedCache = new Map();

/**
 * Cache size limit để tránh memory leak
 */
const MAX_CACHE_SIZE = 100000;

/**
 * Normalize string với caching
 * @param {string} str - String cần normalize
 * @returns {string} - Normalized string
 */
export const normalizeWithCache = (str) => {
  if (!str) return "";
  
  const strKey = String(str);
  
  // Check cache first
  if (normalizedCache.has(strKey)) {
    return normalizedCache.get(strKey);
  }
  
  // Normalize và cache
  const normalized = toAccentVietnamese(strKey);
  
  // Limit cache size - remove oldest entries if needed
  if (normalizedCache.size >= MAX_CACHE_SIZE) {
    const firstKey = normalizedCache.keys().next().value;
    normalizedCache.delete(firstKey);
  }
  
  normalizedCache.set(strKey, normalized);
  return normalized;
};

/**
 * Pre-normalize toàn bộ data một lần khi load
 * Tạo normalized index cho các field thường filter
 * @param {Array} data - Raw data array
 * @param {Array} filterableFields - Danh sách field có thể filter
 * @returns {Array} - Data với normalized fields
 */
export const preNormalizeData = (data, filterableFields = []) => {
  if (!Array.isArray(data) || data.length === 0) {
    return data;
  }
  
  return data.map((row) => {
    const normalizedRow = { ...row };
    
    // Normalize các field có thể filter
    filterableFields.forEach((field) => {
      const value = row[field];
      if (value != null) {
        normalizedRow[`_${field}_normalized`] = normalizeWithCache(String(value));
      }
    });
    
    return normalizedRow;
  });
};

/**
 * So sánh Vietnamese với normalized cache
 * @param {string} text - Text cần so sánh
 * @param {string} keySearch - Key search đã normalized
 * @returns {boolean}
 */
export const compareVietnameseOptimized = (text, keySearch) => {
  if (!text || !keySearch) return false;
  
  const normalizedText = normalizeWithCache(String(text));
  return normalizedText.includes(keySearch);
};

/**
 * Clear cache khi không cần thiết
 */
export const clearNormalizedCache = () => {
  normalizedCache.clear();
};

/**
 * Generator function để xử lý data theo chunks với yield
 * Cho phép browser render giữa các chunks
 * @param {Array} dataArray - Data cần xử lý
 * @param {Function} processor - Function xử lý mỗi item
 * @param {number} chunkSize - Kích thước mỗi chunk
 * @yields {Array} - Kết quả của chunk hiện tại
 */
export async function* processInChunks(dataArray, processor, chunkSize = 5000) {
  const dataLength = dataArray.length;
  
  for (let chunkStart = 0; chunkStart < dataLength; chunkStart += chunkSize) {
    const chunkEnd = Math.min(chunkStart + chunkSize, dataLength);
    const chunk = dataArray.slice(chunkStart, chunkEnd);
    
    const chunkResults = [];
    for (let i = 0; i < chunk.length; i++) {
      const result = processor(chunk[i], chunkStart + i);
      if (result !== null && result !== undefined) {
        chunkResults.push(result);
      }
    }
    
    // Yield để browser có thể render
    yield chunkResults;
    
    // Yield control back to browser
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
}

/**
 * Filter data với early termination khi đạt maxResults
 * @param {Array} dataArray - Data cần filter
 * @param {Array} processedFilters - Filters đã pre-process
 * @param {number} maxResults - Số lượng kết quả tối đa
 * @returns {Array} - Filtered results
 */
export const filterDataWithLimit = (dataArray, processedFilters, maxResults = 10000) => {
  if (processedFilters.length === 0) {
    return dataArray;
  }
  
  const results = [];
  const dataLength = dataArray.length;
  
  for (let i = 0; i < dataLength && results.length < maxResults; i++) {
    const row = dataArray[i];
    let matches = true;
    
    // Early exit nếu đã đạt maxResults
    if (results.length >= maxResults) {
      break;
    }
    
    // Check từng filter
    for (let j = 0; j < processedFilters.length && matches; j++) {
      const { field, normalizedKey } = processedFilters[j];
      
      // Sử dụng normalized field nếu có
      const normalizedField = `_${field}_normalized`;
      const rowValue = row[normalizedField] || row[field];
      
      if (rowValue == null) {
        matches = false;
        break;
      }
      
      // So sánh với normalized value
      const rowValueStr = String(rowValue);
      if (normalizedField in row) {
        // Đã có normalized, so sánh trực tiếp
        if (!rowValueStr.includes(normalizedKey)) {
          matches = false;
          break;
        }
      } else {
        // Chưa có normalized, normalize và so sánh
        if (!compareVietnameseOptimized(rowValueStr, normalizedKey)) {
          matches = false;
          break;
        }
      }
    }
    
    if (matches) {
      results.push(row);
    }
  }
  
  return results;
};

