import Paper from "@mui/material/Paper";
import TableContainer from "@mui/material/TableContainer";
import cloneDeep from "lodash/cloneDeep";
import debounce from "lodash/debounce";
import size from "lodash/size";
import { useSnackbar } from "notistack";
import PropTypes from "prop-types";
import { useState, useMemo, useCallback, useEffect, memo, useRef } from "react";
import { MODE_FILTER } from "utils/constants";

import Filter from "./components/Filter";
import Pagination from "./components/Pagination";
import TableBody from "./components/TableBody";
import TableHeader from "./components/TableHeader";
import { defaultPagination } from "./constants";
import {
  preNormalizeData,
  filterDataWithLimit,
  normalizeWithCache,
  clearNormalizedCache,
} from "./helpers";
import { TableStyle, VirtualizedTable, SearchContainer } from "./styles";

const EMPTY_INITIAL_FILTERS = {};

function AppTableSearch({
  columns = [],
  data = [],
  id = "id",
  // Search
  searchDebounceMs = 300,
  // Cell action
  extendElement,
  isDisableFilter,
  hiddenEdit = false,
  hiddenDelete = false,
  hiddenDetail = true,
  onActive = () => {},
  onDelete = () => {},
  onEdit = () => {},
  onDetail = () => {},
  renderCustomFilter,
  onCellClick = () => {},
  rowHeight = 45,
  isLoading,
  initialFilters = EMPTY_INITIAL_FILTERS,
  // Performance
  maxSearchResults = 10000,
}) {
  const { enqueueSnackbar } = useSnackbar();
  const refFormik = useRef();
  const [cols, setColumns] = useState(columns);
  const [filteredData, setFilteredData] = useState(data);
  const [pagination, setPagination] = useState(defaultPagination);
  const [isSearching, setIsSearching] = useState(false);
  
  // Cache cho normalized data và filterable fields
  const normalizedDataRef = useRef(null);
  const filterableFieldsRef = useRef([]);
  const previousDataRef = useRef(null);

  const columnsDisplay = useMemo(() => cols.filter((c) => c.checked), [cols]);

  // Convert columns with filter: true to filter fields format
  const filterFields = useMemo(() => {
    return columnsDisplay
      .filter((col) => col.filter === true)
      .map((col) => ({
        name: col.field,
        label: col.name,
        mode: col.filterMode || MODE_FILTER.INPUT,
        placeholder: `Tìm theo ${col.name}`,
        options: col.filterOptions || [],
        field: col.field,
        ...col.filterProps,
      }));
  }, [columnsDisplay]);

  // Initialize form values
  const initFormValues = useMemo(() => {
    return filterFields.reduce((acc, field) => {
      if (initialFilters[field.name] !== undefined && initialFilters[field.name] !== null) {
        acc[field.name] = initialFilters[field.name];
        return acc;
      }
      if (typeof field.defaultValue === "boolean") {
        acc[field.name] = field.defaultValue;
      } else {
        acc[field.name] = field.defaultValue || "";
      }
      return acc;
    }, {});
  }, [filterFields, initialFilters]);

  // Pre-normalize data khi data thay đổi (chỉ normalize khi cần)
  useEffect(() => {
    if (!data || data.length === 0) {
      normalizedDataRef.current = [];
      previousDataRef.current = data;
      setFilteredData([]);
      return;
    }
    
    // Lấy danh sách filterable fields
    const filterableFields = columnsDisplay
      .filter((col) => col.filter === true)
      .map((col) => col.field);
    
    // Kiểm tra xem data có thay đổi không (so sánh reference và nội dung)
    const dataChanged = 
      previousDataRef.current !== data ||
      previousDataRef.current?.length !== data.length;
    
    // Kiểm tra xem có item nào thay đổi không bằng cách so sánh id và một số field quan trọng
    let itemsChanged = false;
    if (!dataChanged && previousDataRef.current && normalizedDataRef.current) {
      // So sánh từng item để phát hiện thay đổi
      for (let i = 0; i < Math.min(data.length, previousDataRef.current.length); i++) {
        const currentItem = data[i];
        const previousItem = previousDataRef.current[i];
        
        // So sánh id và tạo hash đơn giản từ các field quan trọng
        if (currentItem[id] !== previousItem[id]) {
          itemsChanged = true;
          break;
        }
        
        // So sánh một số field có thể thay đổi (như status, updatedAt, etc.)
        const currentHash = JSON.stringify({
          status: currentItem.status,
          updatedAt: currentItem.updatedAt,
          ...filterableFields.reduce((acc, field) => {
            acc[field] = currentItem[field];
            return acc;
          }, {}),
        });
        const previousHash = JSON.stringify({
          status: previousItem.status,
          updatedAt: previousItem.updatedAt,
          ...filterableFields.reduce((acc, field) => {
            acc[field] = previousItem[field];
            return acc;
          }, {}),
        });
        
        if (currentHash !== previousHash) {
          itemsChanged = true;
          break;
        }
      }
    }
    
    filterableFieldsRef.current = filterableFields;
    
    // Pre-normalize data một lần
    // Chỉ normalize khi data thay đổi, items thay đổi, hoặc filterable fields thay đổi
    const shouldRenormalize = 
      !normalizedDataRef.current ||
      dataChanged ||
      itemsChanged ||
      normalizedDataRef.current.length !== data.length ||
      JSON.stringify(filterableFieldsRef.current) !== JSON.stringify(filterableFields);
    
    if (shouldRenormalize) {
      // Lưu reference của data hiện tại để so sánh lần sau
      previousDataRef.current = data;
      // Với dataset lớn (> 100k), normalize trong background
      // Với dataset nhỏ, normalize ngay
      if (data.length > 100000) {
        setIsSearching(true);
        
        // Normalize trong background với chunks
        const normalizeAsync = async () => {
          try {
            const CHUNK_SIZE = 50000;
            const normalized = [];
            
            for (let i = 0; i < data.length; i += CHUNK_SIZE) {
              const chunk = data.slice(i, i + CHUNK_SIZE);
              const normalizedChunk = preNormalizeData(chunk, filterableFields);
              normalized.push(...normalizedChunk);
              
              // Yield control để browser render
              await new Promise((resolve) => setTimeout(resolve, 0));
            }
            
            normalizedDataRef.current = normalized;
            setFilteredData(normalized);
            setIsSearching(false);
          } catch (error) {
            console.error("Error normalizing data:", error);
            // Fallback to original data
            normalizedDataRef.current = data;
            setFilteredData(data);
            setIsSearching(false);
          }
        };
        
        normalizeAsync();
      } else {
        // Dataset nhỏ, normalize ngay
        const normalized = preNormalizeData(data, filterableFields);
        normalizedDataRef.current = normalized;
        setFilteredData(normalized);
      }
      // Lưu reference của data hiện tại để so sánh lần sau
      previousDataRef.current = data;
    } else {
      // Ngay cả khi không re-normalize, vẫn cần cập nhật previousDataRef
      // để phát hiện thay đổi trong lần sau
      previousDataRef.current = data;
      setFilteredData(normalizedDataRef.current || data);
    }
  }, [data, columnsDisplay, id]);
  
  // Cleanup cache khi unmount
  useEffect(() => {
    return () => {
      clearNormalizedCache();
    };
  }, []);

  // Optimized column filter với normalized data và early termination
  const applyColumnFilters = useCallback((dataArray, filterValues) => {
    const filterKeys = Object.keys(filterValues || {});
    if (filterKeys.length === 0) {
      return dataArray;
    }

    // Pre-process filter values và normalize một lần
    const processedFilters = filterKeys
      .map((field) => {
        let filterValue = filterValues[field];
        let targetField = field;

        // Handle dynamic search (object format)
        if (filterValue && typeof filterValue === "object") {
          targetField = Object.keys(filterValue)[0];
          filterValue = filterValue[targetField];
        }

        filterValue = String(filterValue || "").trim();
        if (!filterValue) return null;
        
        // Normalize filter value một lần
        const normalizedKey = normalizeWithCache(filterValue);
        
        return {
          field: targetField,
          value: filterValue,
          normalizedKey,
        };
      })
      .filter((f) => f && f.value); // Remove empty filters

    if (processedFilters.length === 0) {
      return dataArray;
    }

    // Sử dụng optimized filter với early termination
    return filterDataWithLimit(dataArray, processedFilters, maxSearchResults);
  }, [maxSearchResults]);

  // Store filter values for debouncing
  const [filterValues, setFilterValues] = useState(initFormValues);
  const [debouncedFilterValues, setDebouncedFilterValues] = useState(initFormValues);
  
  // Sử dụng lodash debounce trực tiếp với useMemo để tạo lại khi delay thay đổi
  const debouncedSetFilterValues = useMemo(
    () => debounce((vals) => setDebouncedFilterValues(vals), searchDebounceMs),
    [searchDebounceMs]
  );

  useEffect(() => {
    debouncedSetFilterValues(filterValues);
    return () => {
      debouncedSetFilterValues.cancel();
    };
  }, [filterValues, debouncedSetFilterValues]);

  // Handle filter form submit
  const handleFilterSubmit = useCallback((values) => {
    const vals = cloneDeep(values);
    Object.keys(values).forEach((k) => {
      if (typeof values[k] === "string") vals[k] = values[k].trim();
    });
    setFilterValues(vals);
  }, []);

  // Optimized combined filter and search với async processing
  useEffect(() => {
    // Skip if no normalized data
    const dataToFilter = normalizedDataRef.current || data;
    
    if (!dataToFilter || dataToFilter.length === 0) {
      setFilteredData([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    let cancelled = false;

    // Async processing với chunks để không block UI
    const processSearchAsync = async () => {
      if (cancelled) return;

      try {
        // Apply column filters với normalized data
        let result = applyColumnFilters(dataToFilter, debouncedFilterValues);

        if (!cancelled) {
          setFilteredData(result);
          setPagination((prev) => ({ ...prev, page: 1 }));
          setIsSearching(false);

          if (result.length >= maxSearchResults) {
            enqueueSnackbar(
              `Kết quả tìm kiếm bị giới hạn ở ${maxSearchResults} bản ghi đầu tiên`,
              {
                variant: "info",
                autoHideDuration: 3000,
              }
            );
          }
        }
      } catch (error) {
        console.error("Filter/Search error:", error);
        if (!cancelled) {
          enqueueSnackbar("Có lỗi xảy ra khi tìm kiếm, vui lòng thử lại", {
            variant: "error",
          });
          setIsSearching(false);
        }
      }
    };

    // Sử dụng requestIdleCallback nếu có, fallback về setTimeout
    let timeoutId;
    let idleId;

    if (typeof requestIdleCallback !== "undefined") {
      idleId = requestIdleCallback(
        () => {
          processSearchAsync();
        },
        { timeout: 1000 }
      );
    } else {
      timeoutId = setTimeout(() => {
        processSearchAsync();
      }, 0);
    }

    return () => {
      cancelled = true;
      if (idleId) {
        cancelIdleCallback(idleId);
      }
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, [
    debouncedFilterValues,
    data,
    applyColumnFilters,
    maxSearchResults,
    enqueueSnackbar,
  ]);

  // Get paginated data
  const paginatedData = useMemo(() => {
    const { page, pageSize } = pagination;
    const startIndex = (page - 1) * pageSize;
    return filteredData.slice(startIndex, startIndex + pageSize);
  }, [pagination, filteredData]);

  // Get total count for display
  const totalCount = useMemo(() => size(filteredData), [filteredData]);

  return (
    <>
      <TableStyle>
        {/* Filter and Search Container */}
        <SearchContainer>
          {!isDisableFilter && filterFields.length > 0 && (
            <Filter
              innerRef={refFormik}
              filterFields={filterFields}
              initFormValues={initFormValues}
              onSubmit={handleFilterSubmit}
              isLoading={isSearching}
              renderCustomFilter={renderCustomFilter}
            />
          )}
        </SearchContainer>

        {/* Table */}
        <TableContainer
          component={Paper}
          className="table"
          style={{ maxHeight: rowHeight * 13, minHeight: rowHeight * 10 }}
        >
          <VirtualizedTable stickyHeader>
            <TableHeader
              columns={cols}
              isDisableFilter={isDisableFilter}
              onColumnChange={setColumns}
            />
            <TableBody
              id={id}
              data={paginatedData}
              columns={columnsDisplay}
              isEmpty={!size(filteredData)}
              isLoading={isLoading || isSearching}
              hiddenEdit={hiddenEdit}
              hiddenDelete={hiddenDelete}
              hiddenDetail={hiddenDetail}
              onActive={onActive}
              onDelete={onDelete}
              onEdit={onEdit}
              onDetail={onDetail}
              onCellClick={onCellClick}
              extendElement={extendElement}
            />
          </VirtualizedTable>
        </TableContainer>

        {/* Pagination */}
        <Pagination
          pagination={pagination}
          onPaginationChange={setPagination}
          total={totalCount}
        />
      </TableStyle>
    </>
  );
}

AppTableSearch.propTypes = {
  columns: PropTypes.array,
  data: PropTypes.array,
  id: PropTypes.string,
  searchPlaceholder: PropTypes.string,
  searchDebounceMs: PropTypes.number,
  extendElement: PropTypes.func,
  isDisableFilter: PropTypes.bool,
  hiddenEdit: PropTypes.bool,
  hiddenDelete: PropTypes.bool,
  hiddenDetail: PropTypes.bool,
  onActive: PropTypes.func,
  onDelete: PropTypes.func,
  onEdit: PropTypes.func,
  onDetail: PropTypes.func,
  renderCustomFilter: PropTypes.func,
  onCellClick: PropTypes.func,
  rowHeight: PropTypes.number,
  isLoading: PropTypes.bool,
  initialFilters: PropTypes.object,
  maxSearchResults: PropTypes.number,
};

export default memo(AppTableSearch);
