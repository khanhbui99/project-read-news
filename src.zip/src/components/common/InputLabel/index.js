import { InputLabel as Base } from '@mui/material';
import React from 'react';

const InputLabel = ({ size, children, startAdornment }) => (
  <Base
    sx={{
      '&': {
        fontWeight: 500,
        fontSize: '1.075rem',
        transform: startAdornment
          ? `translate(14px, -9px) scale(.75)`
          : `translate(14px, ${size === 'small' ? 10 : 14}px) scale(1)`,
      },
      '&.Mui-focused, &.MuiFormLabel-filled': {
        transform: 'translate(14px, -9px) scale(.75)',
      },
    }}
  >
    {children}
  </Base>
);

export default InputLabel;
