import { FormControl, Tooltip } from '@mui/material';
import React, { memo, useEffect, useRef, useState } from 'react';
import { numberWithCommas } from 'utils/helpers';

import { VPB_THEMES } from '../../../utils/configs';
import ErrorMessage from '../ErrorMessage';
import InputLabel from '../InputLabel';
import TextFieldStyle from './style';

const AppTextField = ({
  rq,
  label,
  fullWidth,
  isLabelTop,
  delay = 100,
  errorMessage,
  size = 'small',
  placeholder = 'Nhập',
  startAdornment,
  value = '',
  className,
  titleTooltip,
  commas,
  onBlur = () => {},
  onChange = () => {},
  ...props
}) => {
  const timeout = useRef(null);
  const [internalValue, setInternalValue] = useState(value);

  const getLabel = () => (
    <>
      {label}{' '}
      {rq ? (
        <span
          style={{
            verticalAlign: 'middle',
            color: VPB_THEMES.colors.red
          }}
        >
          *
        </span>
      ) : null}
    </>
  );

  const handleChange = e => {
    const event = e;
    setInternalValue(e.target.value);

    if (timeout.current) clearTimeout(timeout.current);

    if (delay) {
      timeout.current = setTimeout(() => {
        if (commas) event.target.value = e.target.value.replaceAll(',', '');
        onChange(event);
      }, delay);
    }

    onChange(event);
  };

  const handleBlur = e => {
    const event = e;
    if (commas) event.target.value = e.target.value.replaceAll(',', '');
    onBlur(event);
  };

  useEffect(() => {
    if (!commas) setInternalValue(value);
    else setInternalValue(numberWithCommas(value));
  }, [value]);

  return (
      <Tooltip title={props?.disabled && titleTooltip || null}>

    <FormControl fullWidth={fullWidth} variant="outlined" className={className}>
      {isLabelTop ? (
        <label
          style={{
            fontSize: 13,
            marginBottom: 5,
            fontWeight: 600,
            lineHeight: "17px",
            fontFamily: "SVN_Gilroy",
            color: VPB_THEMES.colors.secondaryText,
          }}
        >
          {getLabel()}
        </label>
      ):(
        <InputLabel size={size} startAdornment={startAdornment}>
          {getLabel()}
        </InputLabel>
      )}
        <TextFieldStyle
          size={size}
          label={isLabelTop ? null :getLabel()}
          value={internalValue}
          error={!!errorMessage}
          placeholder={placeholder}
          startAdornment={startAdornment}
          onBlur={handleBlur}
          $isError={errorMessage}
          onChange={handleChange}
          {...props}
        />
      
      <ErrorMessage errorMessage={errorMessage} />
    </FormControl>
      </Tooltip>
  );
};

export default memo(AppTextField);
