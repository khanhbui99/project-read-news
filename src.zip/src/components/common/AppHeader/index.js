import Stack from "@mui/material/Stack";
import BranchIcons from "assets/icons/user.branch";
import { Title } from "components/Styled";
import { HeaderButtonStyle } from "components/styles/Header/style";
import PropTypes from "prop-types";
import { useMemo } from "react";
import { findMenuByComponentName } from "utils/helpers";
import history from "utils/history";

const AppHeader = ({
  btnName = "",
  pageTitle = "",
  componentName = "",
  componentNameAdd = "",
  isHiddenBtn = false,
  externalBtn = null,
  handleBtnClick,
}) => {
  const title = useMemo(() => {
    if (pageTitle) return pageTitle;

    if (!componentName) return "";
    return findMenuByComponentName(componentName)?.name || "";
  }, [pageTitle, componentName]);

  const addPath = useMemo(() => {
    if (!componentNameAdd) return "";
    return findMenuByComponentName(componentNameAdd)?.url || "";
  }, [componentNameAdd]);

  const handleInternalClick = () => {
    if (handleBtnClick) return handleBtnClick();
    return history.push({ pathname: addPath });
  };

  return (
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
    >
      <Title $size={36}>{title}</Title>

      {externalBtn
        ? externalBtn
        : !isHiddenBtn && (
            <div className="btns">
              <HeaderButtonStyle
                outline
                startIcon={<img src={BranchIcons.add} alt="export" />}
                onClick={handleInternalClick}
              >
                {btnName || "Tạo mới"}
              </HeaderButtonStyle>
            </div>
          )}
    </Stack>
  );
};

AppHeader.propTypes = {
  componentName: PropTypes.string,
  componentNameAdd: PropTypes.string,
  isHiddenBtn: PropTypes.bool,
  handleBtnClick: PropTypes.func,
  externalBtn: PropTypes.node,
  btnName: PropTypes.string,
  pageTitle: PropTypes.string,
};

export default AppHeader;
