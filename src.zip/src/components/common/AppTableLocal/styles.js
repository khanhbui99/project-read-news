import { FormControlLabel, Menu, TableCell, Table } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";
import { pxToRem } from "utils/helpers";

export const TableStyle = styled.div`
  padding: 1px;
  position: relative;
  margin-bottom: 34px;

  .table {
    overflow-y: auto;
    box-shadow: none;
    min-height: ${(p) => (p.open ? "440px" : "auto")};

    @media screen and (min-width: 1281px) {
      min-height: ${(p) => (p.open ? "470px" : "auto")};
    }

    @media screen and (min-width: 1367px) {
      min-height: ${(p) => (p.open ? "500px" : "auto")};
    }

    &::-webkit-scrollbar-track {
      background: #ffffff;
      border-bottom-left-radius: 7px;
      border-bottom-right-radius: 7px;
    }

    &__header {
      font-family: "SVN_Gilroy", sans-serif;
    }

    .cell-sticky {
      position: sticky;
      right: 1px;
      &.body-cell {
        background: white;
      }
    }

    .MuiTableCell-root {
      border: none;
      padding-top: 0;
      padding-right: 0;
      font-weight: 500;
      padding-bottom: 0;
      font-family: "SVN_Gilroy", sans-serif;
      font-size: ${pxToRem(13)};
      padding-top: ${pxToRem(6)};
      padding-left: ${pxToRem(12)};
      padding-bottom: ${pxToRem(6)};

      &:last-child {
        padding-right: ${pxToRem(12)};
      }

      &.table__header-title {
        font-family: SVN-Gilroy;
        font-size: 14px;
        font-weight: 500;
        line-height: 15.4px;
        text-align: left;
        text-underline-position: from-font;
        text-decoration-skip-ink: none;
        color: rgba(18, 22, 25, 1);

        text-wrap: nowrap;
        /* padding-top: 8.5px;
        padding-bottom: 8.5px; */
        font-size: ${pxToRem(14)};
      }
    }

    .MuiTableCell-body {
      border-bottom: 1px solid;
      border-color: rgba(242, 244, 248, 1);
    }
  }

  .table-local-row-header {
    position: relative;
  }
  .table-local-cell-header {
    padding-top: 1px !important;
    padding-right: 0px !important;
    padding-bottom: 1px !important;
    font-family: SVN-Gilroy;
    font-weight: 500;
    line-height: 15.4px;
    text-align: left;
    text-underline-position: from-font;
    text-decoration-skip-ink: none;
    color: rgb(18, 22, 25);
    text-wrap: nowrap;
    font-size: 1rem;
    &.header-filter {
      :first-child {
        margin-bottom: 5px;
      }
    }
  }
  .header-action {
    /* background-color: white; */
  }
  .MuiInputBase-root {
    height: 36px !important;
  }
`;

export const VirtualizedTable = styled(Table)({
  tableLayout: "fixed",
  width: "100%",
  "& .MuiTableCell-root": {
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    borderBottom: "1px solid rgba(224, 224, 224, 1)",
  },
});

export const TableCellActionStyle = styled.div`
  display: flex;
  align-items: center;

  svg {
    transform: scale(1.1);
    color: ${VPB_THEMES.colors.gray[300]};

    &.rotate {
      transform: scale(1.1) rotate(45deg);
    }
  }
`;

export const TableCellContent = styled.div`
  display: flex;
  min-height: 30px;
  align-items: center;
  font-weight: 400;
  ${(p) => (p.align === "right" ? "justify-content: right;" : "")}
  word-wrap: wrap;
  &.header {
    font-weight: 500;
  }
  .text {
    word-wrap: wrap;
    width: 95%;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
`;

export const TableCellEmpty = styled(TableCell)`
  // padding-top: 204px !important;
  // padding-bottom: 204px !important;
  height: 50vh !important;
  font-size: ${pxToRem(16)} !important;
  color: ${VPB_THEMES.colors.gray[300]} !important;
`;

// table header cell action
export const TableCellActionContainer = styled.div`
  .action {
    height: 47px;
    display: flex;
    align-items: center;
    justify-content: space-evenly;
    padding: 1px ${pxToRem(12)};
    background-color: ${VPB_THEMES.colors.white};
  }
`;

export const FormControlLabelStyle = styled(FormControlLabel)`
  color: #000;
  display: flex !important;
  text-align: left !important;
  color: ${VPB_THEMES.colors.darkBlue};
  .title {
    font-size: 18px;
    font-weight: 500;
  }
`;

export const MenuStyle = styled(Menu)`
  .columnsList {
    max-height: 300px;
    overflow-y: auto;
  }
  .MuiPaper-root {
    min-width: 224px;
    padding: 0px 16px;
    margin-top: 15px;
    filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))";
  }
`;

export const PaginationContainerStyle = styled.form`
  display: flex;
  justify-content: space-between;
  margin: 16px 0px 24px;
  .column {
    display: flex;
    align-items: center;
    gap: 10px;
    .MuiInputBase-root {
      height: 26px !important;
    }
  }
`;
