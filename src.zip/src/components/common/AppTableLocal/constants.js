export const ROWS_PER_PAGE = [
  {
    label: 10,
    value: 10,
  },
  {
    label: 20,
    value: 20,
  },
  {
    label: 50,
    value: 50,
  },
];

export const defaultPagination = {
  page: 1,
  pageSize: ROWS_PER_PAGE[0].value,
};
