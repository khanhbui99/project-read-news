import Paper from "@mui/material/Paper";
import TableContainer from "@mui/material/TableContainer";
import cloneDeep from "lodash/cloneDeep";
import size from "lodash/size";
import { useSnackbar } from "notistack";
import PropTypes from "prop-types";
import { memo, useEffect, useState, useMemo } from "react";
import { compareVietnamese } from "utils/helpers";

import Pagination from "./components/Pagination";
import TableBody from "./components/TableBody";
import TableHeader from "./components/TableHeader";
import { defaultPagination } from "./constants";
import { TableStyle, VirtualizedTable } from "./styles";

function AppTableLocal({
  columns = [],
  data = [],
  id = "id",
  minWidth = "max-content",
  //cell action
  extendElement,
  isDisableFilter,
  hiddenEdit = false,
  hiddenDelete = false,
  hiddenDetail = true,
  onActive = () => {},
  onDelete = () => {},
  onEdit = () => {},
  onDetail = () => {},
  renderCustomFilter,
  onCellClick = () => {},
  rowHeight = 45,
  isLoading,
}) {
  const { enqueueSnackbar } = useSnackbar();
  const [cols, setColumns] = useState(columns);
  const [filteredData, setFilteredData] = useState(data);
  const [pagination, setPagination] = useState(defaultPagination);
  const [filters, setFilters] = useState({});

  const columnsDisplay = useMemo(() => cols.filter((c) => c.checked), [cols]);

  useEffect(() => {
    setFilteredData(data);
  }, [data]);

  // Lọc dữ liệu theo cột
  const filterData = (values) => {
    try {
      let filteredData = cloneDeep(data).filter((row) => {
        return Object.keys(values).every((key) => {
          const filterValue = values[key].trim();
          if (!filterValue) return true;
          return compareVietnamese(row[key], filterValue);
        });
      });
      setFilteredData(filteredData);
      setPagination({ ...pagination, page: 1 });
    } catch (error) {
      enqueueSnackbar("Có lỗi xảy ra, vui lòng thử lại", {
        variant: "error",
      });
    }
  };

  useEffect(() => {
    filterData(filters);
  }, [filters]);

  // Lấy dữ liệu theo trang hiện tại
  const paginatedData = useMemo(() => {
    const { page, pageSize } = pagination;
    const startIndex = (page - 1) * pageSize;
    return filteredData.slice(startIndex, startIndex + pageSize);
  }, [pagination, filteredData]);

  return (
    <>
      <TableStyle>
        <TableContainer
          component={Paper}
          className="table"
          style={{ maxHeight: rowHeight * 13, minHeight: rowHeight * 10 }}
        >
          <VirtualizedTable stickyHeader>
            {/*header */}
            <TableHeader
              columns={cols}
              renderCustomFilter={renderCustomFilter}
              isDisableFilter={isDisableFilter}
              onColumnChange={setColumns}
              onSubmitFilter={setFilters}
            />
            {/* table body */}
            <TableBody
              id={id}
              minWidth={minWidth}
              data={paginatedData}
              columns={columnsDisplay}
              isEmpty={!size(filteredData)}
              isLoading={isLoading}
              // cell action config
              extendElement={extendElement}
              hiddenEdit={hiddenEdit}
              hiddenDelete={hiddenDelete}
              hiddenDetail={hiddenDetail}
              onEdit={onEdit}
              onDelete={onDelete}
              onDetail={onDetail}
              // more config
              onActive={onActive}
              onCellClick={onCellClick}
            />
          </VirtualizedTable>
        </TableContainer>
        <Pagination
          pagination={pagination}
          onPaginationChange={setPagination}
          total={size(filteredData)}
        />
      </TableStyle>
    </>
  );
}

AppTableLocal.propTypes = {
  columns: PropTypes.array,
  data: PropTypes.array,
  id: PropTypes.string,
  minWidth: PropTypes.string,
  //cell action
  extendElement: PropTypes.func,
  isDisableFilter: PropTypes.bool,
  hiddenEdit: PropTypes.bool,
  hiddenDelete: PropTypes.bool,
  hiddenDetail: PropTypes.bool,
  onActive: PropTypes.func,
  onDelete: PropTypes.func,
  onEdit: PropTypes.func,
  onDetail: PropTypes.func,
  renderCustomFilter: PropTypes.func,
  onCellClick: PropTypes.func,
  rowHeight: PropTypes.number,
  isLoading: PropTypes.bool,
};

export default memo(AppTableLocal);
