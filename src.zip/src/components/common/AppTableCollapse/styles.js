import styled from "styled-components";

export const PaginationContainerStyle = styled.form`
  display: flex;
  justify-content: space-between;
  margin: 16px 0px 24px;
  .column {
    display: flex;
    align-items: center;
    gap: 10px;
    .MuiInputBase-root {
      height: 26px !important;
    }
  }
`;

