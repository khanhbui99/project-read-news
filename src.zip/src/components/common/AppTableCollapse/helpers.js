
export const formatStatus = (status, isActive) => {
  if (typeof status === "string" && status.trim()) return status;
  if (typeof status === "number") return status;
  if (typeof status === "boolean") return status ? "Kích hoạt" : "Nháp";
  if (typeof isActive === "boolean") return isActive ? "Kích hoạt" : "Khoá";
  return "Không xác định";
};

export const getChildItems = (row = {}) => {
  const candidate =
    row?.items ??
    row?.questions ??
    row?.questionItems ??
    row?.answers ??
    row?.children ??
    row?.questionList ??
    row?.options ??
    [];

  return Array.isArray(candidate) ? candidate : [];
};

export const getRowKey = (row, index) => {
  return String(row?.id ?? row?.questionId ?? row?.code ?? index);
};

export const getChildKey = (child, index) => {
  return String(child?.id ?? child?.questionId ?? index);
};

