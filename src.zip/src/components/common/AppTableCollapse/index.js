import { Box, Paper, Table as MuiTable, TableContainer } from "@mui/material";
import PropTypes from "prop-types";
import { useCallback, useEffect, useMemo, useState } from "react";

import Pagination from "./components/Pagination";
import TableBody from "./components/TableBody";
import TableHeader from "./components/TableHeader";
import { defaultPagination, INITIAL_SLICE } from "./constants";
import { getRowKey } from "./helpers";

const AppTableCollapse = ({
  data = [],
  columns = [],
  rowsPerPage,
  onEdit = () => {},
  onDetail = () => {},
  onDelete = () => {},
  searchValue = "",
  onAddQuestion = () => {},
  handleEditChildItem = () => {},
  handleDeleteChildItem = () => {},
}) => {
  const [openMap, setOpenMap] = useState({});
  const [visibleCountMap, setVisibleCountMap] = useState({});
  const [selectedItems, setSelectedItems] = useState(new Set());
  const [pagination, setPagination] = useState({
    page: 1,
    pageSize: rowsPerPage || defaultPagination.pageSize,
  });
  const [filteredData, setFilteredData] = useState(data);

  useEffect(() => {
    setFilteredData(data);
    setOpenMap({});
    setVisibleCountMap({});
    setPagination({
      page: 1,
      pageSize: rowsPerPage || defaultPagination.pageSize,
    });
    setSelectedItems(new Set());
  }, [data, rowsPerPage]);

  const handleToggleRow = useCallback((rowKey, totalChildren, row) => {
    setOpenMap((prev) => {
      const isCurrentlyOpen = prev[rowKey];
      // Nếu đang mở thì đóng lại, nếu đang đóng thì mở và đóng tất cả các row khác
      if (isCurrentlyOpen) {
        return {
          ...prev,
          [rowKey]: false,
        };
      } else {
        // Đóng tất cả các row khác và chỉ mở row hiện tại
        onDetail && onDetail(row, rowKey);
        const newOpenMap = {};
        newOpenMap[rowKey] = true;
        return newOpenMap;
      }
    });

    setVisibleCountMap((prev) => {
      const isCurrentlyOpen = prev[rowKey];
      if (isCurrentlyOpen) {
        // Nếu đang đóng lại, giữ nguyên visibleCount để có thể mở lại nhanh
        return prev;
      }
      // Nếu đang mở, reset tất cả và set cho row hiện tại
      const newMap = {};
      newMap[rowKey] = totalChildren
        ? Math.min(totalChildren, INITIAL_SLICE)
        : 0;
      return newMap;
    });
  }, []);

  const handleScrollChildren = useCallback((rowKey, totalChildren, event) => {
    if (!totalChildren) return;

    const target = event.currentTarget;
    const isBottomReached =
      target.scrollTop + target.clientHeight >= target.scrollHeight - 8;

    if (!isBottomReached) return;

    setVisibleCountMap((prev) => {
      const current = prev[rowKey] ?? INITIAL_SLICE;
      if (current >= totalChildren) return prev;

      return {
        ...prev,
        [rowKey]: Math.min(current + INITIAL_SLICE, totalChildren),
      };
    });
  }, []);

  const getVisibleCount = useCallback(
    (rowKey, childItemsLength) => {
      return (
        visibleCountMap[rowKey] ||
        (childItemsLength ? Math.min(childItemsLength, INITIAL_SLICE) : 0)
      );
    },
    [visibleCountMap]
  );

  // Filter data locally based on searchValue
  useEffect(() => {
    if (!searchValue || !searchValue.trim()) {
      setFilteredData(data);
      return;
    }

    const searchLower = searchValue.toLowerCase().trim();
    const filtered = data.filter((row) => {
      // Search in all columns that have render function or field
      return columns.some((column) => {
        const value = column.render
          ? String(column.render(row)).toLowerCase()
          : String(row[column.field] || "").toLowerCase();
        return value.includes(searchLower);
      });
    });
    setFilteredData(filtered);
    // Reset to page 1 when filtering
    setPagination((prev) => ({ ...prev, page: 1 }));
  }, [searchValue, data, columns]);

  const handlePaginationChange = useCallback((newPagination) => {
    setPagination(newPagination);
  }, []);

  const paginatedData = useMemo(() => {
    const { page, pageSize } = pagination;
    if (!pageSize || pageSize <= 0) return filteredData;
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    return filteredData.slice(startIndex, endIndex);
  }, [filteredData, pagination]);

  const handleSelectRow = useCallback((rowKey) => {
    setSelectedItems((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(rowKey)) {
        newSet.delete(rowKey);
      } else {
        newSet.add(rowKey);
      }
      return newSet;
    });
  }, []);

  const handleSelectAll = useCallback(() => {
    const allRowKeys = paginatedData.map((row, index) => getRowKey(row, index));
    const allSelected = allRowKeys.every((key) => selectedItems.has(key));

    setSelectedItems((prev) => {
      const newSet = new Set(prev);
      if (allSelected) {
        allRowKeys.forEach((key) => newSet.delete(key));
      } else {
        allRowKeys.forEach((key) => newSet.add(key));
      }
      return newSet;
    });
  }, [paginatedData, selectedItems]);

  const isAllSelected = useMemo(() => {
    if (paginatedData.length === 0) return false;
    return paginatedData.every((row, index) =>
      selectedItems.has(getRowKey(row, index))
    );
  }, [paginatedData, selectedItems]);

  const isIndeterminate = useMemo(() => {
    if (paginatedData.length === 0) return false;
    const selectedCount = paginatedData.filter((row, index) =>
      selectedItems.has(getRowKey(row, index))
    ).length;
    return selectedCount > 0 && selectedCount < paginatedData.length;
  }, [paginatedData, selectedItems]);

  return (
    <Box position="relative">
      <TableContainer component={Paper} variant="outlined">
        <MuiTable>
          <TableHeader
            columns={columns}
            isAllSelected={isAllSelected}
            isIndeterminate={isIndeterminate}
            onSelectAll={handleSelectAll}
            hasData={paginatedData.length > 0}
          />
          <TableBody
            data={paginatedData}
            columns={columns}
            openMap={openMap}
            selectedItems={selectedItems}
            getVisibleCount={getVisibleCount}
            onToggle={handleToggleRow}
            onScroll={handleScrollChildren}
            onSelect={handleSelectRow}
            onEdit={onEdit}
            onDelete={onDelete}
            onAddQuestion={onAddQuestion}
            handleEditChildItem={handleEditChildItem}
            handleDeleteChildItem={handleDeleteChildItem}
          />
        </MuiTable>
      </TableContainer>
      <Pagination
        pagination={pagination}
        onPaginationChange={handlePaginationChange}
        total={filteredData.length}
      />
    </Box>
  );
};

AppTableCollapse.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
  columns: PropTypes.arrayOf(
    PropTypes.shape({
      field: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      render: PropTypes.func,
    })
  ),
  rowsPerPage: PropTypes.number,
  onEdit: PropTypes.func,
  onDelete: PropTypes.func,
  searchValue: PropTypes.string,
};

AppTableCollapse.defaultProps = {
  data: [],
  columns: [],
  rowsPerPage: undefined,
  onEdit: () => {},
  onDelete: () => {},
  searchValue: "",
};

export default AppTableCollapse;
