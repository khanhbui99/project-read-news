import { TimePicker } from '@mui/x-date-pickers';
import PropTypes from 'prop-types';
import React, { memo } from 'react';

import AppTextField from '../AppTextField';

const AppTimePickerField = ({
  rq,
  name,
  label,
  errorMessage,
  isLabelTop,
  fullWidth,
  onBlur = () => {},
  onChange = () => {},
  ...props
}) => (
  <TimePicker
    ampm={false}
    renderInput={({ InputProps, ...params }) => (
      <AppTextField
        {...params}
        rq={rq}
        label={label}
        isLabelTop={isLabelTop}
        fullWidth={fullWidth}
        errorMessage={errorMessage}
        endAdornment={InputProps.endAdornment}
        onBlur={() => onBlur({ target: { name } })}
      />
    )}
    onChange={value => onChange({ target: { name, value } })}
    {...props}
  />
);

AppTimePickerField.propTypes = {
  rq: PropTypes.bool,
  name: PropTypes.string,
  label: PropTypes.string,
  errorMessage: PropTypes.string,
  isLabelTop: PropTypes.bool,
  fullWidth: PropTypes.bool,
  onBlur: PropTypes.func,
  onChange: PropTypes.func,
};

export default memo(AppTimePickerField);
