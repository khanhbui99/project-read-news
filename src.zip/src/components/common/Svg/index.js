 
import React, { useEffect, useState } from 'react';
import { get } from 'utils/request';

import SvgStyle from './style';

const Svg = ({ url, ...props }) => {
  const [src, setSrc] = useState('');

  useEffect(() => {
    if (url !== '.svg')
      get({
        url,
        notAuth: true,
      })
        .then(({ data }) => setSrc(data))
        .catch(() => setSrc(''));
  }, [url]);

  return <SvgStyle {...props} dangerouslySetInnerHTML={{ __html: src }} />;
};

export default Svg;
