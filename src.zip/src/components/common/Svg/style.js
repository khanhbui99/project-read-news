import styled from 'styled-components';

const SvgStyle = styled.span`
  svg {
    width: ${p => (p.width ? `${p.width}px` : '100%')};
    height: ${p => (p.height ? `${p.height}px` : '100%')};
  }
`;

export default SvgStyle;
