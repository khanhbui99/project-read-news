export const validateForm = (values, data) => {
  const errors = {};
  data.forEach((field) => {
    if (field.validation) {
      const error = field.validation(values[field.name], values);
      if (error) {
        errors[field.name] = error;
      }
    }
  });
  return errors;
};

export const initDefaultValueForm = (data = []) => {
  return Array.isArray(data)
    ? data.reduce((acc, _f) => {
        if (typeof _f.defaultValue === "boolean") {
          acc[_f.name] = _f.defaultValue;
        } else {
          acc[_f.name] = _f.defaultValue || "";
        }
        return acc;
      }, {})
    : {};
};
