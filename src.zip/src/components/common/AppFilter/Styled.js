import styled from 'styled-components';

const AppFilterWrapper = styled.div`
  width: 100%;

  form {
    display: grid;
    gap: 8px;
    margin-bottom: 16px;
    align-items: flex-end;
    grid-template-columns: repeat(19, minmax(0, 1fr));
  }
`;

export default AppFilterWrapper;