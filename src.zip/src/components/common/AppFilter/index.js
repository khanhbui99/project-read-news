/* eslint-disable react/display-name */
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
 
import BranchIcons from "assets/icons/user.branch";
import AppButton from "components/common/AppButton";
import AppDatePickerField from "components/common/AppDatePickerField";
import AppDynamicTextField from "components/common/AppDynamicTextField";
import AppInputField from "components/common/AppInputField";
import AppSelectSearchField from "components/common/AppSelectSearchField";
import dayjs from "dayjs";
import { Formik, Field, Form } from "formik";
import cloneDeep from "lodash/cloneDeep";
import getLd from "lodash/get";
import isFunction from "lodash/isFunction";
import {
  memo,
  useMemo,
  useCallback,
  forwardRef,
  useRef,
  useEffect,
  useImperativeHandle,
} from "react";
import { useHistory, useLocation } from "react-router-dom";
import { MODE_FILTER } from "utils/constants";
import { useSearchQuery } from "utils/helpers";

import { validateForm, initDefaultValueForm } from "./helpers";
import AppFilterWrapper from "./Styled";

const AppFilter = forwardRef(
  ({ data = [], loading, btnSearch, onSearch }, ref) => {
    const refFormik = useRef();
    const history = useHistory();
    const params = useSearchQuery();

    const { pathname } = useLocation();

    const filterParams = Object.fromEntries(
      // chuyển nhưng giá trị trên param đang là boolean string về đúng giá trị boolean 'true' => true
      Object.entries(params).map(([key, value]) => {
        if (value === "true") return [key, true];
        if (value === "false") return [key, false];
        return [key, value];
      })
    );

    const initFormValues = useMemo(() => {
      const defaultValues = initDefaultValueForm(data);

      try {
        return {
          ...defaultValues,
          // ...params,
          ...filterParams,
          dynamicSearch: JSON.parse(getLd(params, "dynamicSearch", {})),
        };
      } catch (error) {
        return { ...defaultValues, ...params };
      }
    }, [data, params]);

    // init validate form
    const validation = useCallback(
      (values) => validateForm(values, data),
      [data]
    );

    // render field follow mode
    const renderField = (field) => {
      const _f = { ...field };
      const type = String(getLd(_f, "mode"));
      delete _f.mode;
      // delete _f.watch;
      delete _f.validation;

      switch (type) {
        case MODE_FILTER.DATE_PICKER: {
          return (
            <Field
              key={_f.name}
              name={_f.name}
              render={() => (
                <AppDatePickerField
                  {..._f}
                  key={_f.value || _f.name}
                  value={dayjs(_f.value)}
                />
              )}
            />
          );
        }
        case MODE_FILTER.DYNAMIC_SEARCH_TEXT: {
          delete _f.valueDynamicForm;
          delete _f.defaultValue;

          return (
            <Field
              key={_f.name}
              name={_f.name}
              render={() => <AppDynamicTextField {..._f} />}
            />
          );
        }
        case MODE_FILTER.SELECT_SEARCH: {
          delete _f.valueDynamicForm;
          delete _f.handleChange;

          return (
            <Field
              key={_f.name}
              name={_f.name}
              render={() => <AppSelectSearchField {..._f} />}
            />
          );
        }
        case MODE_FILTER.INPUT: {
          delete _f.valueDynamicForm;

          return (
            <Field
              key={_f.name}
              name={_f.name}
              render={() => <AppInputField {..._f} />}
            />
          );
        }
        case MODE_FILTER.CUSTOM: {
          delete _f.valueDynamicForm;
          // Nếu có prop render thì gọi render, truyền props cần thiết
          if (typeof _f.render === "function") {
            return (
              <Field
                key={_f.name}
                name={_f.name}
                render={({ field, form }) => _f.render({ ...field, form })}
              />
            );
          }
          return null;
        }
        default:
          return null;
      }
    };

    // data ref form
    useImperativeHandle(ref, () => ({
      resetForm: () => {
        refFormik.current && refFormik.current.resetForm();
      },
      setFieldValue: (fieldName, value) => {
        refFormik.current && refFormik.current.setFieldValue(fieldName, value);
      },
      setFieldTouched: (fieldName, touched) => {
        refFormik.current &&
          refFormik.current.setFieldTouched(fieldName, touched);
      },
      submitForm: () => {
        refFormik.current && refFormik.current.submitForm();
      },
      values: getLd(refFormik.current, "values", {}),
    }));

    // call when initFormValues change
    useEffect(() => onSearch(initFormValues), [initFormValues]);

    return (
      <AppFilterWrapper ref={ref}>
        <Formik
          innerRef={refFormik}
          initialValues={initFormValues}
          validate={validation}
          onSubmit={(values) => {
            const vals = cloneDeep(values);
            Object.keys(values).forEach((k) => {
              if (typeof values[k] === "string") vals[k] = values[k].trim();
            });

            history.push({
              pathname,
              search: `?${new URLSearchParams({
                ...vals,
                page: 1,
                cache: Date.now(),
                dynamicSearch: JSON.stringify(vals.dynamicSearch),
              })}`,
            });
          }}
        >
          {({ values, errors, touched, handleChange, handleBlur }) => (
            <Form>
              {data.map((field) => {
                const errorMessage = touched[field.name]
                  ? errors[field.name]
                  : undefined;
                return renderField({
                  ...field,
                  isLabelTop: true,
                  errorMessage,
                  value: values[field.name],
                  valueDynamicForm: values,
                  onBlur: (e) => {
                    handleBlur(e);
                    if (isFunction(field.handleBlur)) field.handleBlur(e);
                    return;
                  },
                  onChange: (e) => {
                    handleChange(e);
                    if (isFunction(field.handleChange)) field.handleChange(e);
                    return;
                  },
                });
              })}

              {btnSearch || (
                <AppButton
                  type="submit"
                  className="col-span-1 search-button"
                  loadding={loading}
                  startIcon={<img src={BranchIcons.search} alt="search" />}
                />
              )}
            </Form>
          )}
        </Formik>
      </AppFilterWrapper>
    );
  }
);

export default memo(AppFilter);
