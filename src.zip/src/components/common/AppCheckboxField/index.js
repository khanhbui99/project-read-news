import { Checkbox, createTheme, ThemeProvider } from '@mui/material';
import React, { memo } from 'react';
import { MuiTheme, VPB_THEMES } from 'utils/configs';

const ReverseTheme = createTheme({
  palette: {
    primary: {
      main: '#fff',
      contrastText: VPB_THEMES.colors.green,
    },
    secondary: {
      main: VPB_THEMES.colors.blue,
    },
  },
  components: {
    MuiCheckbox: {
      styleOverrides: {
        root: {
          color: '#fff',
          borderRadius: 8,
        },
      },
    },
  },
});

const AppCheckboxField = ({ theme = 'forward', style, ...props }) => (
  <ThemeProvider theme={theme === 'reverse' ? ReverseTheme : MuiTheme}>
    <Checkbox style={{ ...style }} {...props} />
  </ThemeProvider>
);

export default memo(AppCheckboxField);
