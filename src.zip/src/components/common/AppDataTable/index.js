import {
  Pagination,
  Skeleton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from "@mui/material";
import AppSelectSearchField from "components/common/AppSelectSearchField";
import EmptyIconText from "components/Emptys/EmptyIconText";
import PropTypes from "prop-types";
import { useMemo } from "react";

import {
  EmptyWrap,
  PageSizeBox,
  PaginationBar,
  PaginationInfo,
  PaginationRight,
  TableCard,
  TableScroll,
  TableWrap,
} from "./Styled";

const DEFAULT_PAGE_SIZE_OPTIONS = [10, 20, 50];

function AppDataTable({
  columns = [],
  rows = [],
  loading = false,
  page = 0,
  size = 10,
  total,
  clientPaging = true,
  pageSizeOptions = DEFAULT_PAGE_SIZE_OPTIONS,
  emptyText = "Chưa có dữ liệu.",
  getRowKey = (row, index) => row?.id ?? index,
  onPageChange,
  onPageSizeChange,
  onRowClick,
}) {
  const totalRows = total ?? rows.length;

  const pagedRows = useMemo(() => {
    if (!clientPaging) return rows;
    const start = page * size;
    return rows.slice(start, start + size);
  }, [rows, page, size, clientPaging]);

  const pageCount = Math.max(1, Math.ceil((totalRows || 0) / size));
  const from = totalRows ? page * size + 1 : 0;
  const to = Math.min((page + 1) * size, totalRows);

  const sizeOptions = pageSizeOptions.map((value) => ({
    value,
    label: String(value),
  }));

  if (loading) {
    return (
      <TableCard>
        <div style={{ padding: 16 }}>
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} height={48} sx={{ mb: 1, borderRadius: 1 }} />
          ))}
        </div>
      </TableCard>
    );
  }

  const isEmpty = !pagedRows.length;

  return (
    <TableWrap>
      <TableCard>
        <TableScroll>
          <Table stickyHeader size="small">
            <TableHead>
              <TableRow>
                {columns.map((col) => (
                  <TableCell
                    key={col.field}
                    align={col.align || "left"}
                    className={
                      col.sticky || col.field === "actions"
                        ? "sticky-action"
                        : undefined
                    }
                    style={{ minWidth: col.width }}
                  >
                    {col.name}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {isEmpty ? (
                <TableRow>
                  <TableCell
                    colSpan={Math.max(columns.length, 1)}
                    style={{ borderBottom: "none", padding: 0 }}
                  >
                    <EmptyWrap>
                      <EmptyIconText description={emptyText} mt={0} />
                    </EmptyWrap>
                  </TableCell>
                </TableRow>
              ) : (
                pagedRows.map((row, index) => (
                  <TableRow
                    key={getRowKey(row, index)}
                    hover
                    onClick={() => onRowClick?.(row)}
                  >
                    {columns.map((col) => {
                      const isSticky = col.sticky || col.field === "actions";

                      if (col.field === "stt") {
                        return (
                          <TableCell key={col.field} align={col.align || "left"}>
                            {page * size + index + 1}
                          </TableCell>
                        );
                      }

                      const rawValue = row[col.field];
                      const value = col.render
                        ? col.render(rawValue, row, index)
                        : rawValue == null || rawValue === ""
                          ? "—"
                          : rawValue;

                      return (
                        <TableCell
                          key={col.field}
                          align={col.align || "left"}
                          className={isSticky ? "sticky-action" : undefined}
                          onClick={
                            isSticky
                              ? (e) => e.stopPropagation()
                              : undefined
                          }
                        >
                          {value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </TableScroll>
      </TableCard>

      <PaginationBar>
        <PaginationInfo>
          Hiển thị {from} - {to} trong tổng số {totalRows} bản ghi
        </PaginationInfo>
        <PaginationRight>
          <PageSizeBox>
            <AppSelectSearchField
              fullWidth
              name="pageSize"
              options={sizeOptions}
              value={size}
              field="value"
              labelField="label"
              onChange={(e) => onPageSizeChange?.(Number(e.target.value))}
            />
          </PageSizeBox>
          <Pagination
            color="primary"
            shape="rounded"
            page={page + 1}
            count={pageCount}
            onChange={(_, nextPage) => onPageChange?.(nextPage - 1)}
          />
        </PaginationRight>
      </PaginationBar>
    </TableWrap>
  );
}

AppDataTable.propTypes = {
  columns: PropTypes.array,
  rows: PropTypes.array,
  loading: PropTypes.bool,
  page: PropTypes.number,
  size: PropTypes.number,
  total: PropTypes.number,
  clientPaging: PropTypes.bool,
  pageSizeOptions: PropTypes.arrayOf(PropTypes.number),
  emptyText: PropTypes.string,
  getRowKey: PropTypes.func,
  onPageChange: PropTypes.func,
  onPageSizeChange: PropTypes.func,
  onRowClick: PropTypes.func,
};

export default AppDataTable;
