import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const TableWrap = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1;
  min-height: 0;
  gap: 12px;
`;

export const TableCard = styled.div`
  flex: 1;
  min-height: 0;
  border-radius: 12px;
  background: ${VPB_THEMES.colors.white};
  border: 1px solid ${VPB_THEMES.colors.table.borderLight};
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

export const EmptyWrap = styled.div`
  flex: 1;
  min-height: 360px;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
`;

export const TableScroll = styled.div`
  flex: 1;
  min-height: 0;
  overflow: auto;

  .MuiTableCell-head {
    background: ${VPB_THEMES.colors.table.headerBg};
    font-weight: 600;
    font-size: 13px;
    color: ${VPB_THEMES.colors.textDark};
    white-space: nowrap;
    border-bottom: 1px solid ${VPB_THEMES.colors.table.borderLight};
  }

  .MuiTableRow-root:hover {
    background: ${VPB_THEMES.colors.lightBg};
  }

  .MuiTableCell-root {
    font-family: SVN_Gilroy, sans-serif;
    font-size: 13px;
    color: ${VPB_THEMES.colors.textDark};
    border-bottom: 1px solid ${VPB_THEMES.colors.table.border};
    padding-top: 12px;
    padding-bottom: 12px;
  }

  .sticky-action {
    position: sticky;
    right: 0;
    z-index: 2;
    background: ${VPB_THEMES.colors.white};
    border-left: 1px solid ${VPB_THEMES.colors.table.borderLight};
  }

  .MuiTableCell-head.sticky-action {
    z-index: 4;
    background: ${VPB_THEMES.colors.table.headerBg};
  }

  .MuiTableRow-root:hover .sticky-action,
  .MuiTableRow-root.Mui-selected .sticky-action {
    background: ${VPB_THEMES.colors.lightBg};
  }
`;

export const PaginationBar = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  padding: 4px 2px 0;
`;

export const PaginationInfo = styled.div`
  font-size: 13px;
  color: ${VPB_THEMES.colors.textLight};
`;

export const PaginationRight = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
`;

export const PageSizeBox = styled.div`
  min-width: 110px;

  .MuiFormControl-root {
    width: 100%;
  }

  .MuiOutlinedInput-root {
    height: 36px;
    border-radius: 8px;
  }
`;
