import TooltipStyle from './style';

const Tooltip = TooltipStyle;

export default Tooltip;
