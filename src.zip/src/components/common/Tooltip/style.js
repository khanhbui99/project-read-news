import { Tooltip, tooltipClasses } from '@mui/material';
import React from 'react';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs';

const TooltipStyle = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(() => ({
  [`& .${tooltipClasses.tooltip}`]: {
    fontSize: '12px',
    maxWidth: '480px',
    marginTop: '5px !important',
    backgroundColor: VPB_THEMES.colors.gray[400],
  },
  [`& .${tooltipClasses.arrow}`]: {
    color: VPB_THEMES.colors.gray[400],
  },
}));

export default TooltipStyle;
