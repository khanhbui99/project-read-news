import { DesktopDatePicker } from "@mui/x-date-pickers";
import sizeLd from "lodash/size";
import PropTypes from "prop-types";
import { useMemo, useEffect, useState, memo } from "react";

import AppTextField from "../AppTextField";

const AppDatePickerField = ({
  rq,
  name,
  label,
  errorMessage,
  titleTooltip = null,
  isLabelTop,
  fullWidth,
  watch = {}, // use dynamic form
  valueDynamicForm = {}, // use dynamic form

  onBlur = () => {},
  onChange = () => {},
  ...props
}) => {
  const [attribute, setAttribute] = useState({});

  // use dynamic form
  const keyWatch = useMemo(() => {
    if (watch && sizeLd(watch) && valueDynamicForm) {
      return Object.keys(watch) || [];
    }
    return [];
  }, [watch, valueDynamicForm]);

  useEffect(() => {
    if (watch && sizeLd(watch) && valueDynamicForm && keyWatch.length > 0) {
      const obj = keyWatch.reduce((acc, key) => {
        if (watch[key]) {
          const attr = watch[key](valueDynamicForm[key]);
          acc = { ...acc, ...attr };
        }
        return acc;
      }, {});

      if (sizeLd(obj)) {
        setAttribute(obj);
      }
    }
  }, [keyWatch, watch, valueDynamicForm]);
  // END use dynamic form

  return (
    <DesktopDatePicker
      name={name}
      renderInput={({ InputProps, ...params }) => (
        <AppTextField
          {...params}
          rq={rq}
          label={label}
          isLabelTop={isLabelTop}
          fullWidth={fullWidth}
          titleTooltip={titleTooltip}
          errorMessage={errorMessage}
          endAdornment={InputProps.endAdornment}
          onBlur={() => onBlur({ target: { name } })}
        />
      )}
      onChange={(value) => onChange({ target: { name, value } })}
      {...props}
      {...attribute}
    />
  );
};

AppDatePickerField.propTypes = {
  rq: PropTypes.bool,
  name: PropTypes.string,
  label: PropTypes.string,
  errorMessage: PropTypes.string,
  isLabelTop: PropTypes.bool,
  fullWidth: PropTypes.bool,
  watch: PropTypes.any, // use dynamic form
  valueDynamicForm: PropTypes.any, // use dynamic form

  onBlur: PropTypes.func,
  onChange: PropTypes.func,
};
export default memo(AppDatePickerField);
