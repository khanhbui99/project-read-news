import { Dialog } from "@mui/material";
import styled from "styled-components";

export const DialogStyle = styled(Dialog)`
  .dialogContainer {
    outline: none;
    overflow-y: auto;
    max-height: 100vh;
    position: relative;
    .content {
      padding: 0px 16px;
    }
  }
`;

export const DialogHeaderStyle = styled.div`
  min-height: 27px;
  padding: 16px;
  background: white;
  z-index: 10;
  position: sticky;
  top: 0;
  margin-bottom: 16px;
  .top {
    position: relative;
  }
  .title {
    font-family: SVN_Gilroy;
    font-weight: 600;
    font-size: 18px;
    line-height: 27px;
    letter-spacing: 0%;
    color: Dark Blue;
  }
  .close-icon {
    padding: 3px;
    top: 0px;
    z-index: 1;
    right: 0px;
    cursor: pointer;
    position: absolute;
    color: #0b263d;
  }
  .image {
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    gap: 16px;
  }
`;

export const DialogFooterStyle = styled.div`
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
`;
