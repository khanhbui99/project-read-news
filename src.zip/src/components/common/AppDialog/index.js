import React, { memo, useMemo } from "react";

import { DialogStyle } from "./styles";

const mapAlign = {
  left: "flex-start",
  center: "center",
  right: "flex-end",
};

function AppDialog({
  open,
  align = "center",
  onClose = () => {},
  children,
  PaperProps = {},
  ...props
}) {
  const AlignPaperStyle = useMemo(() => {
    if (align !== "center") {
      return {
        minWidth: "40%",
        maxHeight: "100%",
        maxWidth: "100%",
        height: "100%",
        borderRadius: 0,
        margin: 0,
      };
    }
    return {};
  }, [align]);

  const dialogStyles = useMemo(
    () => ({
      display: "flex",
      justifyContent: mapAlign[align],
    }),
    [align]
  );

  const paperStyles = useMemo(
    () => ({
      ...AlignPaperStyle,
      ...PaperProps.style,
    }),
    [AlignPaperStyle, PaperProps.style]
  );

  return (
    <DialogStyle
      open={open}
      onClose={onClose}
      sx={dialogStyles}
      maxWidth={align !== "center" ? false : undefined}
      PaperProps={{
        ...PaperProps,
        style: paperStyles,
      }}
      {...props}
    >
      <div className="dialogContainer">{children}</div>
    </DialogStyle>
  );
}

export default memo(AppDialog);
