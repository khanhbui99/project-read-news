import ClearIcon from '@mui/icons-material/Clear';
import { InputAdornment } from '@mui/material';
import React, { memo } from 'react';

import Button from '../AppButton';
import AppTextField from '../AppTextField';
import { ButtonContainerStyle, FieldContainerStyle } from './style';

const AppMultipleTextField = ({
  name,
  label,
  className,
  value = [],
  errorMessage = [],
  onChange = () => {},
  ...props
}) => {
  const handleAdd = () => {
    onChange({ target: { name, value: [...value, ''] } });
  };

  const handleClear = i => {
    const val = value.filter((v, index) => i !== index);
    if (val.length) onChange({ target: { name, value: val } });
  };

  return (
    <div className={className}>
      <div className="flex gap-16">
        <FieldContainerStyle className="flex gap-24 w-full">
          {(value || []).map((v, i) => (
            <AppTextField
              value={v}
              fullWidth
              key={`${name}[${i}]`}
              name={`${name}[${i}]`}
              label={`${label}[${i + 1}]`}
              errorMessage={errorMessage[i]}
              endAdornment={
                value.length > 1 ? (
                  <InputAdornment
                    position="end"
                    className="pointer"
                    onClick={() => handleClear(i)}
                  >
                    <ClearIcon />
                  </InputAdornment>
                ) : null
              }
              onChange={onChange}
              {...props}
            />
          ))}
        </FieldContainerStyle>

        <ButtonContainerStyle>
          <Button wFull type="button" onClick={handleAdd}>
            add
          </Button>
        </ButtonContainerStyle>
      </div>
    </div>
  );
};

export default memo(AppMultipleTextField);
