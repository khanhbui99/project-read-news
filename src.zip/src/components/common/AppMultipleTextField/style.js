import styled from 'styled-components';

export const FieldContainerStyle = styled.div`
  flex-direction: column;
`;

export const ButtonContainerStyle = styled.div`
  width: 80px;
  display: flex;
  align-items: end;
`;
