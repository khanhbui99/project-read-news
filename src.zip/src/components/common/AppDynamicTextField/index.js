import get from 'lodash/get';
import React, { memo, useEffect, useState } from 'react';

import AppSelectField from '../AppSelectField';
import AppTextField from '../AppTextField';

const AppDynamicTextField = ({
  name,
  value = {},
  options = [],
  disabledSelect,
  onBlur = () => {},
  onChange = () => {},
  ...props
}) => {
  const [internalValue, setInternalValue] = useState({});
  const [selectedId, setSelectedId] = useState('');

  useEffect(() => {
    if (value && typeof value === 'object') {
      setInternalValue(value);
      Object.keys(value).forEach(key => {
        setSelectedId(key);
      });
    }
  }, [value]);

  return (
    <AppTextField
      {...props}
      value={internalValue[selectedId] || ''}
      sx={{
        '&.MuiInputBase-sizeSmall .MuiOutlinedInput-input': {
          paddingTop: '10px',
          paddingBottom: '10px',
        },
      }}
      onBlur={e => {
        onBlur({
          target: {
            name,
            value: { [selectedId]: get(e, 'target.value', '').trim() },
          },
        });
      }}
      onChange={e => {
        onChange({
          target: {
            name,
            value: { [selectedId]: get(e, 'target.value', '').trim() },
          },
        });
      }}
      startAdornment={
        <AppSelectField
          notBorder
          options={options}
          value={selectedId}
          width="max-content"
          minWidth="max-content"
          disabled={disabledSelect}
          sx={{
            '&.MuiInputBase-sizeSmall .MuiOutlinedInput-input': {
              paddingLeft: 0,
            },
          }}
          onBlur={e => {
            onBlur({
              target: {
                name,
                value: {
                  [get(e, 'target.value', '')]: internalValue[selectedId] || '',
                },
              },
            });
          }}
          onChange={e => {
            onChange({
              target: {
                name,
                value: {
                  [get(e, 'target.value', '')]: internalValue[selectedId] || '',
                },
              },
            });
          }}
        />
      }
    />
  );
};

export default memo(AppDynamicTextField);
