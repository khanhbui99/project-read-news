import React from 'react';

const Divider = ({ style }) => (
  <div
    style={{
      height: 8,
      background: '#f5f5f5',
      gridColumn: 'span 2 / span 2',
      ...style,
    }}
  />
);

export default Divider;
