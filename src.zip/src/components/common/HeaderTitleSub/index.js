import InfoIcon from "@mui/icons-material/Info";
import { Box, Stack } from "@mui/material";
import { Title, Text } from "components/Styled";
import PropTypes from "prop-types";
import { VPB_THEMES } from "utils/configs";

const HeaderTitleSub = ({ title = "", subtitle = "", color = "eff6ff", icon }) => {
  return (
    <Stack direction="row" gap={1.25}>
      <Box style={{ height: 36, width: 36, backgroundColor: VPB_THEMES.colors[color], borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
        {icon || <InfoIcon style={{ color: VPB_THEMES.colors.darkBlue }} />}
      </Box>
      
      <Stack>
        <Title $size={16} $weight={700} $line="20px">
          {title}
        </Title>
        <Text size={13} $color={VPB_THEMES.colors.secondaryText}>{subtitle}</Text>
      </Stack>
    </Stack>
  )
}

HeaderTitleSub.propTypes = {
  title: PropTypes.string,
  icon: PropTypes.node,
  color: PropTypes.string,
  subtitle: PropTypes.string,
}

export default HeaderTitleSub;