import Empty from "assets/icons/common/empty.svg";
import PropTypes from "prop-types";

import { EmptyContainer } from "./styles";

function EmptyComponent({ title = "Thông tin trống" }) {
  return (
    <EmptyContainer>
      <img src={Empty} />
      <span>{title}</span>
    </EmptyContainer>
  );
}

EmptyComponent.propTypes = {
  title: PropTypes.string,
};
export default EmptyComponent;
