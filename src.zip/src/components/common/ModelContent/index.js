import { IconButton } from "@mui/material";
import Icons from "assets/icons/common";
import React from "react";

export const ModalHeader = ({
  image,
  children,
  hiddenClose = false,
  handleClose = () => {},
}) => (
  <>
    {!hiddenClose ? (
      <IconButton className="close-icon" onClick={handleClose}>
        <img alt="close" src={Icons.closeCircle} />
      </IconButton>
    ) : null}

    {image ? <img className="mb-16" src={image} alt="avt" /> : null}
    {children}
  </>
);
