import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

export const ModalContentStyle = styled.div`
  top: 50%;
  left: 50%;
  outline: none;
  overflow-y: auto;
  max-height: 100vh;
  position: relative;
  padding: 36px 16px;
  transform: translate(-50%, -50%);

  .content {
    display: flex;
    margin: 0 auto;
    max-width: 584px;
    position: relative;
    border-radius: 12px;
    align-items: center;
    flex-direction: column;
    background-color: #ffffff;
    padding: 24px 24px 40px 24px;
    box-shadow: 0px 2px 16px rgba(0, 0, 0, 0.1);
  }

  .close-icon {
    top: 2px;
    z-index: 1;
    right: 2px;
    cursor: pointer;
    position: absolute;
  }

  .title {
    margin-top: 0;
    font-weight: 600;
    line-height: 150%;
    text-align: center;
    font-size: ${pxToRem(32)};
    margin-bottom: ${pxToRem(37)};
    color: ${VPB_THEMES.colors.gray[500]};
  }

  form {
    display: flex;
    align-items: center;
    flex-direction: column;
  }

  .footer {
    gap: 24px;
    display: flex;
  }
`;

export const ModalRightContentStyle = styled('div')`
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  height: 100vh;
  min-width: 720px;
  max-width: 100vw;
  position: absolute;
  padding: 16px;

  .content {
    padding: 16px;
    min-height: 100%;
    position: relative;
    border-radius: 12px;
    background-color: #ffffff;
    border: 1px solid #cccccc;
  }

  .close-icon {
    top: 2px;
    z-index: 1;
    right: 2px;
    cursor: pointer;
    position: absolute;
  }
`;

export const ModalFormStyle = styled.div`
  gap: 24px;
  margin-bottom: ${pxToRem(40)};
`;
