import { Autocomplete } from '@mui/material';
import styled from 'styled-components';

const AutocompleteStyle = styled(Autocomplete)`
  & .MuiAutocomplete-inputRoot.MuiOutlinedInput-root {
    border-radius: 8px;
    padding-top: 8.2px !important;
    padding-bottom: 8.2px !important;
  }

  & .MuiFormLabel-root {
    font-size: 1.075rem;
    transform: translate(14px, ${p => (p.size === 'small' ? 10 : 14)}px)
      scale(1);

    &.Mui-focused,
    &.MuiFormLabel-filled {
      transform: translate(14px, -9px) scale(0.75);
    }
  }

  & legend span {
    font-size: 0.8125rem;
  }

  fieldset {
    border-width: 1px !important;
  }
`;

export default AutocompleteStyle;
