import { Box, Tooltip } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import { memo, useMemo } from "react";

import { VPB_THEMES } from "../../../utils/configs";
import ErrorMessage from "../ErrorMessage";
import AutocompleteStyle from "./style";
const AppSelectSearchField = ({
  rq,
  label,
  minWidth,
  errorMessage,
  size = "small",
  field = "value",
  labelField = "label",
  width = "100%",
  options = [],
  className,
  value,
  isLabelTop,
  placeholder,
  onBlur = () => {},
  onChange = () => {},
  disableClearable = true,
  multiple,
  focused,
  renderOptionCustom,
  tooltip,
  enabledSearch, // Filter out this prop to prevent it from being passed to DOM
  ...props
}) => {
  const internalValue = useMemo(
    () => {
      if (multiple) {
        // Khi multiple, value là array các IDs, cần map thành array các objects
        if (!Array.isArray(value)) return [];
        return value
          .map((val) => options.find((o) => `${o[field]}` === `${val}`))
          .filter((o) => o != null);
      }
      return options.find((o) => `${o[field]}` === `${value}`) || {
        [field]: "",
        [labelField]: "",
      };
    },
    [options, value, multiple, field]
  );

  const renderOption = (p, option, index, ownerState) => {
    // Đảm bảo key luôn unique - sử dụng key từ props nếu có, nếu không thì tạo mới
    const { key: propKey, ...restProps } = p;
    const optionKey = propKey ?? option?.[field] ?? option?.id ?? option?.value ?? `option-${index}`;
    
    return renderOptionCustom ? (
      renderOptionCustom(p, option, index, ownerState)
    ) : (
      <Box component="li" {...restProps} key={String(optionKey)} sx={{}}>
        {ownerState.getOptionLabel(option)}
      </Box>
    );
  };

  const renderLabel = () => (
    <>
      {label}{" "}
      {rq ? (
        <span
          style={{
            verticalAlign: "middle",
            color: VPB_THEMES.colors.red,
          }}
        >
          *
        </span>
      ) : null}
    </>
  );

  return (
    <FormControl
      variant="outlined"
      className={className}
      sx={{ width, minWidth }}
    >
      {isLabelTop && (
        <label
          style={{
            fontSize: 13,
            marginBottom: 5,
            lineHeight: "17px",
            fontWeight: 600,
            fontFamily: "SVN_Gilroy",
            color: VPB_THEMES.colors.secondaryText,
          }}
        >
          {renderLabel()}
        </label>
      )}

      {tooltip ? (
        <Tooltip title={tooltip} arrow>
          <Box sx={{ width: "100%" }}>
            <AutocompleteStyle
              {...props}
              size={size}
              multiple={multiple}
              disableClearable={disableClearable}
              options={options}
              value={internalValue}
              renderOption={renderOption}
              // getOptionDisabled={option => option.disabled}
              getOptionLabel={(option) => `${option[labelField]}`}
              renderInput={(params) => (
                <TextField
                  {...params}
                  placeholder={placeholder}
                  focused={focused}
                  label={isLabelTop ? null : label && renderLabel()}
                  error={!!errorMessage}
                  onChange={(e) => {
                    if (!e.target.value) {
                      onChange({
                        obj: options.find((o) => o[field] === value),
                        target: { name: props.name, value: e.target.value },
                      });
                    }
                  }}
                />
              )}
              onBlur={(_, val) => {
                if (multiple) {
                  const selectedValues = Array.isArray(val)
                    ? val.map((obj) => obj?.[field])
                    : [];
                  onBlur({
                    target: { name: props.name, value: selectedValues },
                  });
                } else {
                  onBlur({
                    target: { name: props.name, value: (val || {})[field] },
                  });
                }
              }}
              onChange={(_, val) => {
                if (multiple) {
                  // Khi multiple, val là array các objects, cần map thành array các values
                  const selectedValues = Array.isArray(val)
                    ? val.map((obj) => obj?.[field])
                    : [];
                  onChange({
                    obj: val,
                    target: { name: props.name, value: selectedValues },
                  });
                } else {
                  onChange({
                    obj: val,
                    target: { name: props.name, value: (val || {})[field] },
                  });
                }
              }}
            />
          </Box>
        </Tooltip>
      ) : (
        <AutocompleteStyle
          {...props}
          size={size}
          multiple={multiple}
          disableClearable={disableClearable}
          options={options}
          value={internalValue}
          renderOption={renderOption}
          // getOptionDisabled={option => option.disabled}
          getOptionLabel={(option) => `${option[labelField]}`}
          renderInput={(params) => (
            <TextField
              {...params}
              placeholder={placeholder}
              focused={focused}
              label={isLabelTop ? null : label && renderLabel()}
              error={!!errorMessage}
              onChange={(e) => {
                if (!e.target.value) {
                  onChange({
                    obj: options.find((o) => o[field] === value),
                    target: { name: props.name, value: e.target.value },
                  });
                }
              }}
            />
          )}
          onBlur={(_, val) => {
            if (multiple) {
              const selectedValues = Array.isArray(val)
                ? val.map((obj) => obj?.[field])
                : [];
              onBlur({
                target: { name: props.name, value: selectedValues },
              });
            } else {
              onBlur({
                target: { name: props.name, value: (val || {})[field] },
              });
            }
          }}
          onChange={(_, val) => {
            if (multiple) {
              // Khi multiple, val là array các objects, cần map thành array các values
              const selectedValues = Array.isArray(val)
                ? val.map((obj) => obj?.[field])
                : [];
              onChange({
                obj: val,
                target: { name: props.name, value: selectedValues },
              });
            } else {
              onChange({
                obj: val,
                target: { name: props.name, value: (val || {})[field] },
              });
            }
          }}
        />
      )}
      <ErrorMessage errorMessage={errorMessage} />
    </FormControl>
  );
};

export default memo(AppSelectSearchField);
