import { Modal } from "@mui/material";
import React from "react";
import { VPB_THEMES } from "utils/configs";

import Button from "../AppButton";
import { ModalHeader } from "../ModelContent";
import { ModalContentStyle } from "../ModelContent/style";

const ConfirmModal = ({
  id,
  open = false,
  title = "",
  mesage,
  message,
  messageWarning = "",
  confirmText = "Xác nhận",
  cancelText = "Hủy",
  danger = false,
  onClose = () => {},
  onSubmit = () => {},
}) => {
  const content =
    message || mesage || "Are you sure that you want to do this action!";

  return (
    <Modal open={open}>
      <ModalContentStyle style={{ top: "25%" }}>
        <div className="content" style={{ maxWidth: 320 }}>
          <ModalHeader handleClose={() => onClose(false)} />
          {title ? (
            <h3
              style={{
                marginTop: 0,
                fontWeight: 600,
                marginBottom: 16,
                padding: "0 16px",
                textAlign: "center",
                color: VPB_THEMES.colors.gray[500],
              }}
            >
              {title}
            </h3>
          ) : null}
          <h3
            style={{
              marginTop: 0,
              fontWeight: 600,
              marginBottom: messageWarning ? 12 : 37,
              padding: "0 16px",
              textAlign: "center",
              color: VPB_THEMES.colors.gray[500],
            }}
          >
            {content}
          </h3>
          {messageWarning ? (
            <h6
              style={{
                margin: 0,
                fontSize: 12,
                marginBottom: 24,
                padding: "0 16px",
                textAlign: "center",
                fontWeight: "normal",
                color: VPB_THEMES.colors.red,
              }}
            >
              {messageWarning}
            </h6>
          ) : null}
          <div className="footer">
            <Button
              outline
              type="button"
              style={{ width: 120 }}
              onClick={() => onClose(false)}
            >
              {cancelText}
            </Button>
            <Button
              type="button"
              style={{
                width: 120,
                ...(danger ? { background: VPB_THEMES.colors.red } : {}),
              }}
              onClick={() => onSubmit(id)}
            >
              {confirmText}
            </Button>
          </div>
        </div>
      </ModalContentStyle>
    </Modal>
  );
};

export default ConfirmModal;
