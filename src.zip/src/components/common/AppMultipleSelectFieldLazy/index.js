import CloseIcon from "@mui/icons-material/Close";
import { Box, Checkbox, Chip } from "@mui/material";
import Autocomplete from "@mui/material/Autocomplete";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import cloneDeep from "lodash/cloneDeep";
import debounce from "lodash/debounce";
import isArray from "lodash/isArray";
import without from "lodash/without";
import PropTypes from "prop-types";
import React, {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { FixedSizeList } from "react-window";

import { VPB_THEMES } from "../../../utils/configs";
import {
  ChipCloseStyle,
  ChipLabelStyle,
  SelectedStyle,
} from "../AppMultipleSelectField/style";
import ErrorMessage from "../ErrorMessage";
import InputLabel from "../InputLabel";

const ITEM_HEIGHT = 48;
const MAX_VISIBLE_ITEMS = 8;

/**
 * Component Multiple Select với virtual scrolling và lazy loading
 * Tối ưu performance cho danh sách dài
 */
const AppMultipleSelectFieldLazy = ({
  rq,
  label,
  field = "",
  errorMessage,
  enabledSearch = true,
  size = "small",
  enabledSelectAll,
  labelField = "",
  startAdornment,
  options = [],
  value = [],
  className,
  isLabelTop,
  onChange = () => {},
  ...props
}) => {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [open, setOpen] = useState(false);
  const key = useMemo(() => field || "id", [field]);
  const labelKey = useMemo(() => labelField || "name", [labelField]);

  const internalValue = useMemo(() => (isArray(value) ? value : []), [value]);

  // Debounce search để tối ưu performance
  useEffect(() => {
    const debounced = debounce(() => {
      setDebouncedSearch(search);
    }, 300);
    debounced();
    return () => {
      debounced.cancel();
    };
  }, [search]);

  // Tối ưu filter: chỉ filter khi có search, giới hạn số items nếu quá nhiều
  const searchOpt = useMemo(() => {
    let filtered = options || [];

    // Nếu không có search và danh sách quá dài, chỉ lấy 1000 items đầu tiên
    if (!debouncedSearch && filtered.length > 1000) {
      filtered = filtered.slice(0, 1000);
    }

    if (debouncedSearch) {
      const searchLower = debouncedSearch.toLowerCase();
      filtered = filtered.filter((o) => {
        return `${o[labelKey]}`.toLowerCase().includes(searchLower);
      });
      // Giới hạn kết quả search tối đa 5000 items
      if (filtered.length > 5000) {
        filtered = filtered.slice(0, 5000);
      }
    }

    return filtered;
  }, [options, debouncedSearch, labelKey]);

  const selectedOptions = useMemo(() => {
    return (options || []).filter((o) => internalValue.includes(o[key]));
  }, [options, internalValue, key]);

  const handleDelete = useCallback(
    (val) => {
      const clone = isArray(value) ? cloneDeep(value) : [];
      onChange({
        target: {
          name: props.name,
          value: without(clone, val),
        },
      });
    },
    [value, onChange, props.name]
  );

  const handleCheckAll = useCallback(() => {
    if (internalValue.length < searchOpt.length) {
      onChange({
        target: {
          name: props.name,
          value: searchOpt.map((o) => o[key]),
        },
      });
      return;
    }
    onChange({
      target: {
        name: props.name,
        value: [],
      },
    });
  }, [internalValue.length, searchOpt, key, props.name, onChange]);

  const getLabel = () => (
    <>
      {label}{" "}
      {rq ? (
        <span
          style={{
            verticalAlign: "middle",
            color: VPB_THEMES.colors.red,
          }}
        >
          *
        </span>
      ) : null}
    </>
  );

  const ListboxComponent = React.useCallback((listboxProps) => {
    const { children, ...other } = listboxProps;
    const items = React.Children.toArray(children);
    const itemCount = items.length;
    const height = Math.min(
      itemCount * ITEM_HEIGHT,
      MAX_VISIBLE_ITEMS * ITEM_HEIGHT
    );

     const renderRow = ({ index, style }) => {
       const item = items[index];
       if (!item) return null;
       return (
         <Box
           component="div"
           style={{
             ...style,
             display: "flex",
             alignItems: "center",
             width: "100%",
           }}
         >
           {item}
         </Box>
       );
     };

    return (
      <Box
        {...other}
        component="ul"
        sx={{
          margin: 0,
          padding: 0,
          height: height,
          overflow: "hidden",
          position: "relative",
        }}
      >
        {itemCount > 0 ? (
          <FixedSizeList
            height={height}
            itemCount={itemCount}
            itemSize={ITEM_HEIGHT}
            width="100%"
            overscanCount={5}
          >
            {renderRow}
          </FixedSizeList>
        ) : (
          <Box sx={{ padding: 2, textAlign: "center" }}>Không có dữ liệu</Box>
        )}
      </Box>
    );
  }, []);

  const renderTags = (value, getTagProps) => (
    <SelectedStyle>
      {value.map((option, index) => {
        const { key: tagKey, ...tagProps } = getTagProps({ index });
        return (
          <Chip
            key={tagKey}
            {...tagProps}
            sx={{
              height: "unset",
              maxWidth: "100%",
              ".MuiChip-label": {
                paddingLeft: "8px",
                paddingRight: "8px",
                whiteSpace: "nowrap",
                overflow: "visible",
                maxWidth: "none",
              },
            }}
            label={
              <ChipLabelStyle
                style={{
                  maxWidth: "none",
                  whiteSpace: "nowrap",
                }}
              >
                {option[labelKey]}
              </ChipLabelStyle>
            }
          />
        );
      })}
    </SelectedStyle>
  );

  const renderOption = (props, option, { selected }) => (
    <li
      {...props}
      key={option[key]}
      style={{
        ...props.style,
        width: "100%",
      }}
    >
      <Checkbox checked={selected} sx={{ marginRight: 1 }} />
      {option[labelKey]}
    </li>
  );

  const renderInput = (params) => (
    <TextField
      {...params}
      size={size}
      placeholder={props.placeholder || "Chọn người dùng để chia sẻ"}
      inputProps={{
        ...params.inputProps,
        autoComplete: "new-password",
      }}
      InputProps={{
        ...params.InputProps,
        startAdornment: startAdornment || params.InputProps.startAdornment,
      }}
      error={!!errorMessage}
    />
  );

  return (
    <FormControl
      fullWidth
      variant="standard"
      className={className}
      disabled={props.disabled}
    >
      {!isLabelTop && (
        <InputLabel
          size={size}
          startAdornment={startAdornment}
          shrink
          htmlFor="bootstrap-input"
        >
          {getLabel()}
        </InputLabel>
      )}

      {isLabelTop && (
        <label
          style={{
            fontSize: 12,
            marginBottom: 5,
            lineHeight: "17px",
            fontFamily: "SVN_Gilroy",
            color: VPB_THEMES.colors.secondaryText,
          }}
        >
          {getLabel()}
        </label>
      )}

      <Autocomplete
        multiple
        open={open}
        onOpen={() => setOpen(true)}
        onClose={(event, reason) => {
          // Đóng khi click outside hoặc press Escape, không đóng khi chọn item
          if (reason !== "selectOption") {
            setOpen(false);
          }
        }}
        disableCloseOnSelect
        options={searchOpt}
        value={selectedOptions}
        getOptionLabel={(option) => option[labelKey] || ""}
        isOptionEqualToValue={(option, value) => option[key] === value[key]}
        onChange={(event, newValue) => {
          const newIds = newValue.map((v) => v[key]);
          onChange({
            target: {
              name: props.name,
              value: newIds,
            },
          });
        }}
        onInputChange={(event, newInputValue, reason) => {
          if (reason === "input") {
            setSearch(newInputValue);
          }
        }}
        renderTags={renderTags}
        renderOption={renderOption}
        renderInput={renderInput}
        ListboxComponent={ListboxComponent}
        ListboxProps={{
          style: {
            overflow: "hidden",
            maxHeight: "none",
          },
        }}
        filterOptions={(x) => x}
        disableListWrap
        {...props}
      />

      {enabledSelectAll && open && (
        <div style={{ padding: "8px 16px", borderBottom: "1px solid #e0e0e0" }}>
          <Checkbox
            checked={
              internalValue.length === searchOpt.length && searchOpt.length > 0
            }
            indeterminate={
              internalValue.length > 0 &&
              internalValue.length < searchOpt.length
            }
            onChange={handleCheckAll}
            size="small"
          />
          <span style={{ marginLeft: 8, fontSize: 14 }}>
            Chọn tất cả ({internalValue.length}/{searchOpt.length})
          </span>
        </div>
      )}

      <ErrorMessage errorMessage={errorMessage} />
    </FormControl>
  );
};

AppMultipleSelectFieldLazy.propTypes = {
  rq: PropTypes.bool,
  label: PropTypes.string,
  field: PropTypes.string,
  errorMessage: PropTypes.string,
  enabledSearch: PropTypes.bool,
  size: PropTypes.string,
  enabledSelectAll: PropTypes.bool,
  labelField: PropTypes.string,
  startAdornment: PropTypes.node,
  options: PropTypes.array,
  value: PropTypes.array,
  className: PropTypes.string,
  isLabelTop: PropTypes.bool,
  onChange: PropTypes.func,
};

export default memo(AppMultipleSelectFieldLazy);
