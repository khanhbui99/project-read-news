import { Select } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';
import React, { memo } from 'react';

import ErrorMessage from '../ErrorMessage';
import InputLabel from '../InputLabel';
import OutlineInput from '../OutlineInput';

const AppSelectField = ({
  label,
  minWidth,
  notBorder,
  field = '',
  errorMessage,
  size = 'small',
  labelField = '',
  width = '100%',
  startAdornment,
  options = [],
  className,
  ...props
}) => (
  <FormControl
    variant="outlined"
    className={className}
    sx={{ width, minWidth }}
  >
    <InputLabel size={size} startAdornment={startAdornment}>
      {label}
    </InputLabel>
    <Select
      input={
        <OutlineInput
          size={size}
          label={label}
          notBorder={notBorder}
          error={!!errorMessage}
          startAdornment={startAdornment}
          {...props}
        />
      }
      {...props}
    >
      {(options || []).map(o => (
        <MenuItem key={o[field || 'value']} value={o[field || 'value']}>
          {o[labelField || 'label']}
        </MenuItem>
      ))}
    </Select>
    <ErrorMessage errorMessage={errorMessage} />
  </FormControl>
);

export default memo(AppSelectField);
