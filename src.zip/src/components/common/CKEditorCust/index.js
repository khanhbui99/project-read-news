import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import { useEffect, useState } from "react";

import { CKEditorWrapper } from "./style";
import ErrorMessage from "../ErrorMessage";

export default function CKEditorCust({
  name,
  value = "",
  errorMessage = "",
  isReadOnly = false,
  classNameWrapper = "",
  onChange = () => {},
  onBlur = () => {},
}) {
  // Track if editor is mounted
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    return () => setIsMounted(false);
  }, []);

  // Kiểm tra nếu ClassicEditor không tồn tại
  if (!ClassicEditor) {
    console.error("CKEditor not loaded");
    return <div>Error loading editor</div>;
  }

  const handleChange = (content) => {
    onChange(name ? { target: { name, value: content } } : content);
  };

  const handleBlur = (_, editor) => {
    if (!name) {
      onBlur();
      return;
    }

    onBlur({
      target: {
        name,
        value: editor?.getData?.() || "",
      },
    });
  };

  return (
    <CKEditorWrapper className={classNameWrapper} $errorMessage={errorMessage}>
      {isMounted && (
        <div className="editor-wrapper">
          <CKEditor
            name={name}
            editor={ClassicEditor}
            disabled={isReadOnly}
            config={{
              toolbar: {
                items: [
                  "heading",
                  "|",
                  "bold",
                  "italic",
                  "strikethrough",
                  "underline",
                  "|",
                  "fontSize",
                  "fontFamily",
                  "fontColor",
                  "fontBackgroundColor",
                  "|",
                  "alignment",
                  "indent",
                  "outdent",
                  "|",
                  "numberedList",
                  "bulletedList",
                  "|",
                  "blockQuote",
                  "|",
                  "undo",
                  "redo",
                ],
                shouldNotGroupWhenFull: true,
              },
              fontSize: {
                options: [9, 11, 13, "default", 17, 19, 21],
              },
              alignment: {
                options: ["left", "center", "right", "justify"],
              },
              table: {
                contentToolbar: [
                  "tableColumn",
                  "tableRow",
                  "mergeTableCells",
                  "tableProperties",
                  "tableCellProperties",
                ],
              },
              language: "vi",
            }}
            data={value || ""}
            onChange={(event, editor) => {
              const content = editor.getData();
              handleChange(content);
            }}
            onBlur={handleBlur}
            onError={(err) => console.error("Editor error:", err)}
          />
        </div>
      )}
      <ErrorMessage errorMessage={errorMessage} />
    </CKEditorWrapper>
  );
}
