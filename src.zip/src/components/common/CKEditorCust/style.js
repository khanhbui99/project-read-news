import styled from "styled-components";

export const CKEditorWrapper = styled.div`
  position: relative;

  .editor-wrapper {
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .ck-editor__editable {
    min-height: 200px;
    padding: 1rem;
    background: white !important;
  }

  .ck.ck-editor__editable_inline {
    border: 1px solid #ddd;
  }

  .ck.ck-editor__editable_inline.ck-focused {
    border: 1px solid #1976d2;
    box-shadow: 0 0 3px #1976d2;
  }

  .ck.ck-toolbar {
    background: #f8f9fa;
    border: none;
    border-bottom: 1px solid #ddd;
  }

  .ck.ck-content {
    border-color: ${({ $errorMessage }) =>
      $errorMessage ? "#d32f2f !important" : "var(--ck-color-base-border)"};
  }

  .ck.ck-dropdown__panel {
    max-height: 250px;
    overflow-y: auto;
  }

  .ck.ck-button {
    cursor: pointer;
    &:hover {
      background: #e9ecef;
    }
  }
`;
