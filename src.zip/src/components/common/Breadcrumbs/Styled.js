import Breadcrumbs from '@mui/material/Breadcrumbs';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs'

const BreadcrumbStyled = styled(Breadcrumbs)`
  .MuiBreadcrumbs-ol {
    .MuiBreadcrumbs-li {
      .MuiTypography-root {
        font-family: 'SVN_Gilroy';
        font-weight: 600;
        font-size: 18px;
        line-height: 150%;
        vertical-align: middle;
        color: ${VPB_THEMES.colors.darkBlue}
      }
    }

    .MuiBreadcrumbs-separator {
      margin: 0;

      svg {
        font-size: 24px;
        color: ${VPB_THEMES.colors.green}
      }
    }
  }
`;

export default BreadcrumbStyled;