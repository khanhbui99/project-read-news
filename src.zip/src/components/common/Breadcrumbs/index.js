import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import Link from '@mui/material/Link';
import { VPB_THEMES } from 'utils/configs'

import BreadcrumbStyled from './Styled';


const CustomSeparator = ({ nav = [] }) => {
  return (
    <BreadcrumbStyled
      aria-label="breadcrumb"
      separator={<NavigateNextIcon />} 
    >
      {nav.map(_n => (
        <Link
          component="span"
          underline="none"
          color="inherit" 
          key={`${_n?.id}-${_n?.name}`}
        >
          {_n?.name || ''}
        </Link>
      ))}
    </BreadcrumbStyled>
  )
}

export default CustomSeparator;