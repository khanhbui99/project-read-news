import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import CloseIcon from "@mui/icons-material/Close";
import { IconButton, InputAdornment, Popover } from "@mui/material";
import dayjs from "dayjs";
import PropTypes from "prop-types";
import { memo, useMemo, useState } from "react";
import { VPB_THEMES } from "utils/configs";
import { DateFormat4 } from "utils/constants";

import AppDatePickerField from "../AppDatePickerField";
import AppTextField from "../AppTextField";
import { RangePanel } from "./Styled";

const toDayjs = (value) => {
  if (!value) return null;
  const date = dayjs(value);
  return date.isValid() ? date : null;
};

const formatRangeLabel = (fromDate, toDate) => {
  const from = toDayjs(fromDate);
  const to = toDayjs(toDate);
  if (from && to) {
    return `${from.format(DateFormat4)} - ${to.format(DateFormat4)}`;
  }
  if (from) return `${from.format(DateFormat4)} - ...`;
  if (to) return `... - ${to.format(DateFormat4)}`;
  return "";
};

const AppDateRangeField = ({
  label = "Từ ngày - Đến ngày",
  placeholder = "Chọn khoảng ngày",
  fromDate = null,
  toDate = null,
  disabled = false,
  fullWidth = true,
  isLabelTop = true,
  onChange,
}) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const displayValue = useMemo(
    () => formatRangeLabel(fromDate, toDate),
    [fromDate, toDate],
  );
  const hasValue = Boolean(displayValue);
  const open = Boolean(anchorEl);

  const emitChange = (nextFrom, nextTo) => {
    let from = toDayjs(nextFrom);
    let to = toDayjs(nextTo);
    if (from && to && to.isBefore(from, "day")) {
      const swap = from;
      from = to;
      to = swap;
    }
    onChange?.({
      fromDate: from,
      toDate: to,
    });
  };

  return (
    <>
      <AppTextField
        fullWidth={fullWidth}
        isLabelTop={isLabelTop}
        name="dateRange"
        label={label}
        placeholder={placeholder}
        value={displayValue}
        disabled={disabled}
        onClick={(e) => {
          if (disabled) return;
          setAnchorEl(e.currentTarget);
        }}
        inputProps={{ readOnly: true }}
        sx={{
          cursor: "pointer",
          "& input": { cursor: "pointer" },
        }}
        startAdornment={
          <InputAdornment position="start">
            <CalendarTodayOutlinedIcon
              sx={{ color: VPB_THEMES.colors.textLight, fontSize: 18 }}
            />
          </InputAdornment>
        }
        endAdornment={
          hasValue && !disabled ? (
            <InputAdornment position="end">
              <IconButton
                size="small"
                aria-label="Xóa khoảng ngày"
                onClick={(e) => {
                  e.stopPropagation();
                  emitChange(null, null);
                }}
              >
                <CloseIcon
                  sx={{ color: VPB_THEMES.colors.textLight, fontSize: 16 }}
                />
              </IconButton>
            </InputAdornment>
          ) : null
        }
      />

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        transformOrigin={{ vertical: "top", horizontal: "left" }}
      >
        <RangePanel>
          <AppDatePickerField
            fullWidth
            isLabelTop
            name="fromDate"
            label="Từ ngày"
            value={fromDate}
            maxDate={toDate || undefined}
            onChange={(e) =>
              emitChange(e?.target?.value ?? e, toDate)
            }
          />
          <AppDatePickerField
            fullWidth
            isLabelTop
            name="toDate"
            label="Đến ngày"
            value={toDate}
            minDate={fromDate || undefined}
            onChange={(e) =>
              emitChange(fromDate, e?.target?.value ?? e)
            }
          />
        </RangePanel>
      </Popover>
    </>
  );
};

AppDateRangeField.propTypes = {
  label: PropTypes.string,
  placeholder: PropTypes.string,
  fromDate: PropTypes.any,
  toDate: PropTypes.any,
  disabled: PropTypes.bool,
  fullWidth: PropTypes.bool,
  isLabelTop: PropTypes.bool,
  onChange: PropTypes.func,
};

export default memo(AppDateRangeField);
