import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const RangePanel = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  padding: 12px;
  min-width: 340px;
  background: ${VPB_THEMES.colors.white};
`;
