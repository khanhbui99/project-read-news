import { Box } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const CalendarContainer = styled(Box)`
  width: 100%;
  padding: 16px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);

  .fc {
    font-family: inherit;
  }

  .fc-header-toolbar {
    margin-bottom: 1.5em;
  }

  .fc-button {
    background: ${VPB_THEMES.colors.buttonInactive};
    border: none;
    color: ${VPB_THEMES.colors.white};
    padding: 8px 16px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
    text-transform: none;
    transition: all 0.2s ease;

    &:hover:not(:disabled):not(.fc-button-active) {
      background: ${VPB_THEMES.colors.gray[400]};
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    &:focus:not(:disabled) {
      outline: none;
      box-shadow: 0 0 0 3px rgba(0, 119, 190, 0.3);
    }

    &.fc-button-active {
      background: ${VPB_THEMES.gradient[2]} !important;
      opacity: 1;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    &:disabled {
      background: ${VPB_THEMES.colors.buttonDisabled};
      color: ${VPB_THEMES.colors.gray[300]};
      cursor: not-allowed;
      opacity: 1;
    }

    &:not(:disabled).fc-button-active:focus,
    &:not(:disabled):active:focus,
    &:not(:disabled):active {
      box-shadow: none !important;
    }
  }

  .fc-button-primary:not(:disabled).fc-button-active:focus,
  .fc-button-primary:not(:disabled):active:focus {
    box-shadow: none !important;
  }

  .fc-button-primary:not(:disabled):not(.fc-button-active) {
    background: ${VPB_THEMES.colors.buttonInactive};
  }

  /* Button "Hôm nay" - active dùng theme, disabled dùng màu xám */
  .fc-today-button {
    border: none !important;
    color: ${VPB_THEMES.colors.white} !important;

    &:not(:disabled) {
      background: ${VPB_THEMES.gradient[2]} !important;

      &:hover {
        opacity: 0.9;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
      }

      &:focus {
        outline: none;
        box-shadow: 0 0 0 3px rgba(0, 119, 190, 0.3);
      }

      &:active:focus,
      &:active {
        box-shadow: none !important;
      }
    }

    &:disabled {
      background: ${VPB_THEMES.colors.buttonInactive} !important;
      cursor: not-allowed;
      opacity: 1;
    }
  }

  /* Button prev/next giữ màu theme */
  .fc-prev-button,
  .fc-next-button {
    background: ${VPB_THEMES.gradient[2]} !important;
    border: none !important;

    &:hover {
      opacity: 0.9;
      transform: translateY(-1px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    &:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(0, 119, 190, 0.3);
    }

    &:not(:disabled):active:focus,
    &:not(:disabled):active {
      box-shadow: none !important;
    }
  }

  .fc-daygrid-day.fc-day-today {
    background-color: rgba(0, 119, 190, 0.08);
  }

  .fc-event {
    border-radius: 4px;
    padding: 2px 4px;
    cursor: pointer;
    transition: opacity 0.2s;

    &:hover {
      opacity: 0.8;
    }
  }

  .fc-daygrid-event {
    margin: 2px 0;
  }

  .fc-timegrid-event {
    border-radius: 4px;
  }

  .fc-list-event {
    cursor: pointer;
  }

  /* Mobile responsive styles */
  @media (max-width: 768px) {
    padding: 12px 8px;
    border-radius: 8px;

    .fc-header-toolbar {
      margin-bottom: 1em;
      flex-wrap: wrap;
      gap: 8px;
    }

    .fc-toolbar-chunk {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .fc-toolbar-title {
      font-size: 18px;
      font-weight: 600;
      margin: 0 8px;
      order: 3;
      width: 100%;
      text-align: center;
      margin-top: 8px;
    }

    .fc-button {
      padding: 6px 12px;
      font-size: 12px;
      border-radius: 6px;
      min-width: auto;
    }

    .fc-prev-button,
    .fc-next-button {
      padding: 6px 10px;
      font-size: 14px;
    }

    .fc-today-button {
      padding: 6px 12px;
      font-size: 12px;
    }

    .fc-button-group {
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
    }

    .fc-button-group .fc-button {
      padding: 6px 10px;
      font-size: 11px;
    }

    .fc-col-header-cell {
      padding: 8px 4px;
      font-size: 12px;
    }

    .fc-daygrid-day-frame {
      min-height: 60px;
    }

    .fc-daygrid-day-number {
      font-size: 12px;
      padding: 4px;
    }

    .fc-event {
      padding: 2px 4px;
      font-size: 11px;
      line-height: 1.2;
    }

    .fc-event-title {
      font-size: 11px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .fc-daygrid-event {
      margin: 1px 2px;
    }

    .fc-scrollgrid {
      font-size: 12px;
    }

    .fc-timegrid-slot {
      font-size: 11px;
    }

    .fc-timegrid-col {
      min-width: 60px;
    }
  }

  @media (max-width: 480px) {
    padding: 8px 4px;

    .fc-toolbar-title {
      font-size: 16px;
      margin-top: 4px;
    }

    .fc-button {
      padding: 5px 8px;
      font-size: 11px;
    }

    .fc-prev-button,
    .fc-next-button {
      padding: 5px 8px;
      font-size: 12px;
    }

    .fc-today-button {
      padding: 5px 10px;
      font-size: 11px;
    }

    .fc-button-group .fc-button {
      padding: 5px 8px;
      font-size: 10px;
    }

    .fc-col-header-cell {
      padding: 6px 2px;
      font-size: 11px;
    }

    .fc-daygrid-day-frame {
      min-height: 50px;
    }

    .fc-daygrid-day-number {
      font-size: 11px;
      padding: 2px;
    }

    .fc-event {
      padding: 1px 3px;
      font-size: 10px;
    }

    .fc-event-title {
      font-size: 10px;
    }
  }
`;

