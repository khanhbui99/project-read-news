import dayGridPlugin from "@fullcalendar/daygrid";
import listPlugin from "@fullcalendar/list";
import FullCalendar from "@fullcalendar/react";
import timeGridPlugin from "@fullcalendar/timegrid";
import PropTypes from "prop-types";
import { useRef } from "react";

import { CalendarContainer } from "./Styled";

const AppCalendar = ({
  events = [],
  initialView = "dayGridMonth",
  locale = "vi",
  onEventClick,
  onDatesSet,
  headerToolbar = {
    left: "prev,next today",
    center: "title",
    right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek",
  },
  height = "auto",
  eventDisplay = "block",
  dayHeaderFormat = {
    weekday: "short",
  },
  titleFormat = {
    month: "long",
    year: "numeric",
  },
  buttonText = {
    today: "Hôm nay",
    month: "Tháng",
    week: "Tuần",
    day: "Ngày",
    list: "Danh sách",
  },
  firstDay = 1,
  ...otherProps
}) => {
  const calendarRef = useRef(null);
  const currentViewRef = useRef(initialView);
  const lastDateRangeRef = useRef(null);

  // Xử lý datesSet - chỉ call onDatesSet khi date range thay đổi (không phải khi chỉ thay đổi view)
  const handleDatesSet = (dateInfo) => {
    const newView = dateInfo.view.type;
    
    // Format dates to YYYY-MM-DD string
    const formatDate = (date) => {
      if (typeof date === 'string') return date.split('T')[0];
      const d = new Date(date);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    };

    const startDate = formatDate(dateInfo.start);
    const endDate = formatDate(dateInfo.end);

    // Nếu chỉ thay đổi view (không thay đổi date range), không call onDatesSet
    if (
      newView !== currentViewRef.current &&
      lastDateRangeRef.current &&
      lastDateRangeRef.current.startDate === startDate &&
      lastDateRangeRef.current.endDate === endDate
    ) {
      // Chỉ cập nhật view, không call API
      currentViewRef.current = newView;
      return;
    }

    // Nếu date range không thay đổi, không call onDatesSet
    if (
      lastDateRangeRef.current &&
      lastDateRangeRef.current.startDate === startDate &&
      lastDateRangeRef.current.endDate === endDate
    ) {
      return;
    }

    // Cập nhật view và date range
    currentViewRef.current = newView;
    lastDateRangeRef.current = { startDate, endDate };

    // Chỉ call onDatesSet khi date range thay đổi (prev/next month)
    if (onDatesSet) {
      onDatesSet(dateInfo);
    }
  };

  return (
    <CalendarContainer>
      <FullCalendar
        ref={calendarRef}
        plugins={[dayGridPlugin, timeGridPlugin, listPlugin]}
        initialView={initialView}
        locale={locale}
        events={events}
        eventClick={onEventClick}
        datesSet={handleDatesSet}
        headerToolbar={headerToolbar}
        height={height}
        eventDisplay={eventDisplay}
        dayHeaderFormat={dayHeaderFormat}
        titleFormat={titleFormat}
        buttonText={buttonText}
        firstDay={firstDay}
        {...otherProps}
      />
    </CalendarContainer>
  );
};

AppCalendar.propTypes = {
  events: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
      title: PropTypes.string.isRequired,
      start: PropTypes.string.isRequired,
      end: PropTypes.string,
      backgroundColor: PropTypes.string,
      borderColor: PropTypes.string,
      extendedProps: PropTypes.object,
    })
  ),
  initialView: PropTypes.string,
  locale: PropTypes.string,
  onEventClick: PropTypes.func,
  onDatesSet: PropTypes.func,
  headerToolbar: PropTypes.object,
  height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  eventDisplay: PropTypes.string,
  dayHeaderFormat: PropTypes.object,
  titleFormat: PropTypes.object,
  buttonText: PropTypes.object,
  firstDay: PropTypes.number,
};

export default AppCalendar;

