import TextField from '@mui/material/TextField';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs'

const TextFieldStyle = styled(TextField)`
  & .MuiInputBase-root {
    border-radius: 8px !important;

    &.Mui-disabled {
      background: ${VPB_THEMES.colors.table.headerBg};

      fieldset {
        border-color: ${VPB_THEMES.colors.table.headerBg};
      }
    }

    fieldset {
      border-width: 1px !important;
      border-color: ${VPB_THEMES.colors.gray.fieldset};
    }
  }

  & .MuiInputBase-input {
    padding-top: 10.5px !important;
    padding-bottom: 10.5px !important;
  }

  & .MuiFormLabel-root {
    font-size: 1.075rem;
    transform: translate(14px, ${p => (p.size === 'small' ? 10 : 14)}px)
      scale(1);

    &.Mui-focused,
    &.MuiFormLabel-filled {
      transform: translate(14px, -9px) scale(0.75);
    }
  }

  & legend span {
    font-size: 0.8125rem;
  }
`;

export default TextFieldStyle;
