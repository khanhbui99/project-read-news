import FormControl from "@mui/material/FormControl";
import { memo, useEffect, useRef, useState } from "react";
import { numberWithCommas } from "utils/helpers";

import { VPB_THEMES } from "../../../utils/configs";
import ErrorMessage from "../ErrorMessage";
import TextFieldStyle from "./style";

const AppInputField = ({
  label,
  commas,
  minWidth,
  className,
  rq = false,
  isLabelTop,
  value = "",
  delay = 100,
  errorMessage,
  size = "small",
  width = "100%",
  onBlur = () => {},
  onChange = () => {},
  ...props
}) => {
  const timeout = useRef(null);
  const [internalValue, setInternalValue] = useState(value);

  const handleChange = (e) => {
    const event = e;
    setInternalValue(e.target.value);

    if (timeout.current) clearTimeout(timeout.current);

    if (delay) {
      timeout.current = setTimeout(() => {
        if (commas) event.target.value = e.target.value.replaceAll(",", "");
        onChange(event);
      }, delay);
      return;
    }

    onChange(event);
  };

  const handleBlur = (e) => {
    const event = e;
    if (commas) event.target.value = e.target.value.replaceAll(",", "");
    onBlur(event);
  };

  useEffect(() => {
    if (!commas) setInternalValue(value);
    else setInternalValue(numberWithCommas(value));
  }, [value]);

  const getLabel = () => {
    if (!label) return undefined;
    return (
      <>
        {label}
        {rq ? (
          <span
            style={{
              verticalAlign: "middle",
              color: VPB_THEMES.colors.red,
            }}
          >
            *
          </span>
        ) : null}
      </>
    );
  };

  return (
    <FormControl
      variant="outlined"
      className={className}
      sx={{ width, minWidth }}
    >
      {isLabelTop && (
        <label
          style={{
            fontSize: 12,
            marginBottom: 5,
            lineHeight: "17px",
            fontFamily: "SVN_Gilroy",
            color: VPB_THEMES.colors.secondaryText,
          }}
        >
          {getLabel()}
        </label>
      )}

      <TextFieldStyle
        id={name}
        {...props}
        size={size}
        label={isLabelTop ? null : getLabel()}
        value={internalValue}
        error={!!errorMessage}
        onBlur={handleBlur}
        onChange={handleChange}
      />
      <ErrorMessage errorMessage={errorMessage} />
    </FormControl>
  );
};

export default memo(AppInputField);
