import styled, { keyframes } from 'styled-components';
import { VPB_THEMES } from 'utils/configs';

const focusKeyframe = keyframes`
  0% {
    width: 0
  }
  99.99% {
    width: 290%;
  }
  100% {
    width: 0;
  }
`;

const lightKeyframe = keyframes`
0% {
  left: -34px;
}
8.9% {
  left: calc(100% + 34px);
}
9% {
  left: -34px;
}
100% {
  left: -34px;
}
`;

const hoverKeyframe = keyframes`
0% {
  width: 0;
}
100% {
  width: 100%;
}
`;

const filteredProps = prop =>
  !['wFull', 'outline', 'radiusFull', 'textSmall'].includes(prop);

const ButtonStyle = styled.button.withConfig({
  shouldForwardProp: filteredProps,
})`
  gap: 8px;
  height: 40px;
  overflow: hidden;
  position: relative;
  align-items: center;
  display: inline-flex;
  min-width: max-content;
  justify-content: center;
  text-transform: capitalize;
  ${p => (p.wFull ? 'width: 100%' : '')};
  opacity: ${p => (p.disabled ? 0.55 : 1)};
  cursor: ${p => (p.disabled ? 'no-drop' : 'pointer')};
  font-size: ${({ textSmall = true }) => (textSmall ? 14 : 16)}px;
  font-weight: ${({ textSmall = true }) => (textSmall ? 600 : 700)};

  &:after {
    top: -10px;
    left: -34px;
    width: 23px;
    content: '';
    bottom: -10px;
    position: absolute;
    transform: rotate(30deg);
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgb(255, 255, 255, 15%) 50%,
      transparent 100%
    );

    animation-delay: 1s;
    animation-duration: 15s;
    animation-name: ${lightKeyframe};
    animation-timing-function: linear;
    animation-iteration-count: infinite;
  }

  &:hover {
    &::after {
      top: 0;
      left: 0;
      width: 0;
      bottom: 0;
      transform: none;
      border-radius: 7px;
      opacity: ${p => (p.outline ? 0.08 : 0.2)};
      background: ${p => (p.outline ? VPB_THEMES.colors.green : '#ffffff')};

      animation-delay: 0s;
      animation-duration: 0.15s;
      animation-iteration-count: 1;
      animation-fill-mode: forwards;
      animation-name: ${hoverKeyframe};
    }
  }

  &::before {
    top: 0;
    left: 0;
    width: 0;
    bottom: 0;
    content: '';
    position: absolute;
    border-radius: 7px;
    transition: width 0.2s;
    opacity: ${p => (p.outline ? 0.08 : 0.2)};
    background-color: ${p => (p.outline ? VPB_THEMES.colors.green : '#ffffff')};
  }

  &:focus {
    &::before {
      animation-duration: 0.15s;
      animation-iteration-count: 1;
      animation-timing-function: linear;
      animation-name: ${focusKeyframe};
    }
  }

  .start-icon {
    display: inline-block;
    
    /* Apply color filter to icons in outline buttons to match text color #00AD53 */
    ${p => p.outline ? `
      img {
        filter: brightness(0) saturate(100%) invert(48%) sepia(93%) saturate(1352%) hue-rotate(94deg) brightness(97%) contrast(101%);
      }
    ` : ''}
  }
  &.search-button {
    background-color: ${VPB_THEMES.colors.darkBlue} !important;
  }
`;

export default ButtonStyle;

export const CircleButtonStyle = styled(ButtonStyle)`
  width: 40px;
  border-radius: 40px;
  border-color: ${VPB_THEMES.colors.green};
  color: ${p => (p.outline ? VPB_THEMES.colors.green : '#ffffff')};
  border: ${p => (p.outline ? `1px solid ${VPB_THEMES.colors.green}` : 'none')};
  border: ${p => (p.outline ? `1px solid ${VPB_THEMES.colors.green}` : 'none')};
  background-color: ${p =>
    p.outline ? 'transparent' : VPB_THEMES.colors.green};
`;

export const SecondaryButtonStyle = styled(ButtonStyle)`
  padding-left: 8px;
  padding-right: 8px;
  border-radius: ${p => (p.radiusFull ? '40px' : '8px')};
  color: ${p => (p.outline ? VPB_THEMES.gradient[1] : '#ffffff')};
  border: ${p => (p.outline ? `1px solid ${VPB_THEMES.gradient[1]}` : 'none')};
  background-color: ${p =>
    p.outline ? 'transparent' : VPB_THEMES.gradient[1]};
`;

export const PrimaryButtonStyle = styled(ButtonStyle)`
  border: none;
  color: #ffffff;
  padding: 0 42px;
  border-radius: 40px;
  background: ${VPB_THEMES.gradient[2]};
  ${p => (p.wFull ? 'width: 100%' : '')};
`;
