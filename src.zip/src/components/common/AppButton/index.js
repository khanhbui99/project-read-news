import { CircularProgress } from '@mui/material';
import React, { useMemo } from 'react';

import Tooltip from '../Tooltip';
import {
  CircleButtonStyle,
  PrimaryButtonStyle,
  SecondaryButtonStyle,
} from './style';

const Flag = ({ children }) => <>{children}</>;

const AppButton = ({
  wFull,
  tooltip,
  btnType,
  outline,
  disabled,
  children,
  loadding,
  startIcon,
  radiusFull,
  type = 'submit',
  ...props
}) => {
  const isDisabled = useMemo(() => loadding || disabled, [loadding, disabled]);

  const Tip = useMemo(() => (isDisabled ? Flag : Tooltip), [isDisabled]);

  switch (btnType) {
    case 'primary':
      return (
        <Tip arrow title={tooltip}>
          <PrimaryButtonStyle
            type={type}
            wFull={wFull}
            disabled={isDisabled}
            {...props}
          >
            {loadding ? (
              <CircularProgress
                color="inherit"
                style={{ width: 20, height: 20 }}
              />
            ) : null}
            {!loadding && startIcon ? (
              <span className="start-icon">{startIcon}</span>
            ) : null}
            {children}
          </PrimaryButtonStyle>
        </Tip>
      );

    case 'circle':
      return (
        <Tip arrow title={tooltip}>
          <CircleButtonStyle
            type={type}
            outline={outline}
            disabled={isDisabled}
            {...props}
          >
            {loadding ? (
              <CircularProgress
                color="inherit"
                style={{ width: 20, height: 20 }}
              />
            ) : (
              children
            )}
          </CircleButtonStyle>
        </Tip>
      );

    default:
      return (
        <Tip arrow title={tooltip}>
          <SecondaryButtonStyle
            type={type}
            wFull={wFull}
            outline={outline}
            radiusFull={radiusFull}
            disabled={isDisabled}
            {...props}
          >
            {loadding ? (
              <CircularProgress
                color="inherit"
                style={{ width: 20, height: 20 }}
              />
            ) : null}
            {!loadding && startIcon ? (
              <span className="start-icon">{startIcon}</span>
            ) : null}
            {children}
          </SecondaryButtonStyle>
        </Tip>
      );
  }
};

export default AppButton;
