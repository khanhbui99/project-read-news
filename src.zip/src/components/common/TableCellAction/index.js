import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import { IconButton } from '@mui/material';
import Icons from 'assets/icons/common';
import PropTypes from 'prop-types';

import { TableCellActionStyle } from './style';

const TableCellAction = ({
  id,
  extendElement,
  hiddenEdit = false,
  hiddenDelete = false,
  hiddenDetail = false,
  justifyContent = 'end',
  minWidth = 'max-content',
  onActive = () => {},
  handleDel = () => {},
  handleEdit = () => {},
  handleDetail = () => {},
}) => (
  <TableCellActionStyle
    style={{
      minWidth,
      justifyContent,
    }}
    onClick={() => onActive(id)}
  >
    {extendElement || null}
    {!hiddenDetail ? (
      <IconButton onClick={() => handleDetail(id)}>
        <VisibilityOutlinedIcon />
      </IconButton>
    ) : null}
    {!hiddenEdit ? (
      <IconButton onClick={() => handleEdit(id)}>
        <img alt="pencil" src={Icons.pencil} />
      </IconButton>
    ) : null}
    {!hiddenDelete && (
      <IconButton onClick={() => handleDel(id)}>
        <img src={Icons.trash} alt="trash" />
      </IconButton>
    )}
  </TableCellActionStyle>
);

TableCellAction.propTypes = {
  id: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  extendElement: PropTypes.oneOfType([
    PropTypes.node,
    PropTypes.func,
  ]),
  hiddenEdit: PropTypes.bool,
  hiddenDelete: PropTypes.bool,
  hiddenDetail: PropTypes.bool,
  justifyContent: PropTypes.oneOf([
    'start',
    'center',
    'end',
    'flex-start',
    'flex-end',
    'space-between',
    'space-around',
    'space-evenly',
  ]),
  minWidth: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
  ]),
  onActive: PropTypes.func,
  handleDel: PropTypes.func,
  handleEdit: PropTypes.func,
  handleDetail: PropTypes.func,
};

export default TableCellAction;
