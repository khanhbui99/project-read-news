import CloseIcon from '@mui/icons-material/Close';
import MoreVertIcon from '@mui/icons-material/SettingsOutlined';
import { Collapse, Divider, IconButton } from '@mui/material';
import cloneDeep from 'lodash/cloneDeep';
import React, { useState } from 'react';

import AppCheckboxField from '../AppCheckboxField';
import {
  AbsoluteActionStyle,
  CollapseWrapStyle,
  FormControlLabelStyle,
} from './style';

const TableCellHeaderAction = ({
  value = [],
  onChange = () => {},
  onChecked = () => {},
}) => {
  const [checked, setChecked] = useState(false);

  const handleChange = (i, event) => {
    const newVal = cloneDeep(value);
    newVal[i].checked = event.target.checked;
    onChange(newVal);
  };

  const handleChangeAll = e => {
    const newVal = cloneDeep(value);
    newVal.forEach((v, i) => {
      if (!v.required) newVal[i].checked = e.target.checked;
    });
    onChange(newVal);
  };

  return (
    <>
      <AbsoluteActionStyle>
        <IconButton
          onClick={() => {
            onChecked(!checked);
            setChecked(t => !t);
          }}
        >
          {checked ? <CloseIcon /> : <MoreVertIcon />}
        </IconButton>
      </AbsoluteActionStyle>
      <CollapseWrapStyle>
        <Collapse in={checked} timeout={0}>
          <FormControlLabelStyle
            control={
              <AppCheckboxField
                checked={!value.some(v => !v.checked)}
                onChange={handleChangeAll}
              />
            }
            label={<span style={{ fontSize: '18px' }}>Select all</span>}
          />
          <Divider />
          {(value || []).map((v, i) =>
            !v.required ? (
              <FormControlLabelStyle
                key={i}
                label={v.name}
                control={
                  <AppCheckboxField
                    name={`${v.id}`}
                    disabled={v.required}
                    checked={!!v.checked}
                    onChange={e => handleChange(i, e)}
                  />
                }
              />
            ) : null,
          )}
        </Collapse>
      </CollapseWrapStyle>
    </>
  );
};

export default TableCellHeaderAction;
