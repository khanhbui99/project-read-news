import { FormControlLabel } from '@mui/material';
import styled from 'styled-components';
import { VPB_THEMES } from 'utils/configs';
import { pxToRem } from 'utils/helpers';

export const TableCellActionStyle = styled.div`
  display: flex;
  align-items: center;

  svg {
    // transform: scale(1.1);
    transform: scale(0.823);
    color: ${VPB_THEMES.colors.btnColor};

    &.rotate {
      transform: scale(1.1) rotate(45deg);
    }
  }
`;

export const CollapseWrapStyle = styled.div`
  top: 56px;
  right: 1px;
  z-index: 1;
  overflow-y: auto;
  max-height: 373px;
  border-radius: 8px;
  position: absolute;
  background-color: #fff;
  padding: 0 ${pxToRem(16)};
  box-shadow: ${VPB_THEMES.bosShadow};

  @media screen and (min-width: 1281px) {
    max-height: 403px;
  }

  @media screen and (min-width: 1367px) {
    max-height: 433px;
  }
`;

export const FormControlLabelStyle = styled(FormControlLabel)`
  color: #000;
  display: block !important;
  text-align: left !important;
`;

export const AbsoluteActionStyle = styled.div`
  top: 0px;
  right: 2px;
  height: 48px;
  display: flex;
  position: absolute;
  align-items: center;
  padding: 8.5px ${pxToRem(12)};
  justify-content: center;
  background-color: ${VPB_THEMES.colors.white};
  border-start-end-radius: 7px;
`;
