import { clearMessageByFieldAction } from "App/store/actions";
import { useSnackbar } from "notistack";
import { useEffect } from "react";
import { useOneState, useDispatchRedux } from "utils/hooks/useRedux";
import injectKey from "utils/injectKey";

const SnackbarNotifier = () => {
  const { enqueueSnackbar } = useSnackbar();

  const clearMessageByField = useDispatchRedux(clearMessageByFieldAction);

  const { error, success } = useOneState(injectKey.GLOBAL, "message");

  useEffect(() => {
    if (!success) return;

    enqueueSnackbar(success, { variant: "success" });
    clearMessageByField("success");
  }, [success, enqueueSnackbar, clearMessageByField]);

  useEffect(() => {
    if (!error) return;

    enqueueSnackbar(error, { variant: "error" });
    clearMessageByField("error");
  }, [error, enqueueSnackbar, clearMessageByField]);

  return null;
};

export default SnackbarNotifier;
