import MenuIcon from "@mui/icons-material/Menu";
import { IconButton } from "@mui/material";
import { toggleMobileSidebarAction } from "App/store/actions";
import ConfirmModal from "components/common/ConfirmModal";
import NotificationBell from "components/NotificationBell";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";

import MyProfile from "../MyProfile";
import HeaderMenuToolbar from "./components/HeaderMenuToolbar";
import { useLogic } from "./hook";
import HeaderBarContainer, { HamburgerButtonStyled } from "./style";

function HeaderBar() {
  const dispatch = useDispatch();
  const [isMobile, setIsMobile] = useState(false);
  const {
    name,
    anchorEl,
    isOpenConfirmModal,
    accountConcurrentInfos,
    orgCharts,
    onToggleMenu,
    openProfile,
    onSwitchRole,
    onHandleOpenConfirmModal,
    onLogout,
    setOpenConfirmModal,
    handleRoleChart,
  } = useLogic();

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleToggleMobileSidebar = () => {
    dispatch(toggleMobileSidebarAction());
  };

  return (
    <HeaderBarContainer>
      {isMobile && (
        <HamburgerButtonStyled onClick={handleToggleMobileSidebar}>
          <MenuIcon />
        </HamburgerButtonStyled>
      )}
      <div className="user-info">
        <NotificationBell />
        <div className="menu-avatar" onClick={onToggleMenu}>
          <MyProfile
            disableCollapsed
            style={{ padding: 0 }}
            open={!!anchorEl}
          />
        </div>
      </div>
      {/* external component */}
      <HeaderMenuToolbar
        name={name}
        anchorEl={anchorEl}
        orgCharts={orgCharts}
        accountConcurrentInfos={accountConcurrentInfos}
        openProfile={openProfile}
        onHandleOpenConfirmModal={onHandleOpenConfirmModal}
        onLogout={onLogout}
        onToggleMenu={onToggleMenu}
        handleRoleChart={handleRoleChart}
      />
      <ConfirmModal
        open={isOpenConfirmModal}
        mesage="Bạn có chăc chắn muốn thực hiện hành động này"
        onSubmit={onSwitchRole}
        onClose={setOpenConfirmModal}
      />
    </HeaderBarContainer>
  );
}
export default HeaderBar;
