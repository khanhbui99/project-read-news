import {
  logoutAction,
  switchRoleAction,
  toggleMenuAction,
  toggleMenuParentAction,
} from "App/store/actions";
import { MENU_TYPE } from "App/store/constants";
import { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router";
import {
  adminPrefix,
  TOKEN_NAME,
  IL_USER_SELECTED_ORGCHART,
} from "utils/constants";

export function useLogic() {
  const dispatch = useDispatch();
  const history = useHistory();

  const userEmailSelected = useRef(null);
  const userChartIdSelected = useRef(null);

  const { userInfo = {} } = useSelector((state) => state.global);
  const { accountConcurrentInfos = [], orgCharts = [], name } = userInfo;

  const [anchorEl, setAnchorEl] = useState(null);
  const [isOpenConfirmModal, setOpenConfirmModal] = useState(false);

  const onToggleMenu = (event) => {
    const target = event ? event.currentTarget : null;
    setAnchorEl(target);
  };

  const onNavigationToDashboardCommon = () => {
    dispatch(toggleMenuParentAction(MENU_TYPE.common));
    dispatch(toggleMenuAction(MENU_TYPE.common));
    history.push(`/dashboard`);
  };

  const onLogout = () => {
    dispatch(logoutAction());
    onToggleMenu(null);
  };

  const onHandleOpenConfirmModal = ({ email, chartId }) => {
    userEmailSelected.current = email;
    userChartIdSelected.current = chartId;
    setOpenConfirmModal(true);
  };

  const onSwitchRole = () => {
    setOpenConfirmModal(false);
    onToggleMenu(null);
    dispatch(
      switchRoleAction({
        email: userEmailSelected.current,
        chartId: userChartIdSelected.current,
      })
    );
  };

  const openProfile = () => {
    history.push(`${adminPrefix()}/profile`);
    onToggleMenu(null);
  };

  const handleRoleChart = (item) => {
    localStorage.setItem(TOKEN_NAME, `Bearer ${item.token}`);
    localStorage.setItem(IL_USER_SELECTED_ORGCHART, item.orgChartId);
    setTimeout(() => {
      history.push("/");
    }, 100);
  };

  return {
    anchorEl,
    isOpenConfirmModal,
    accountConcurrentInfos,
    orgCharts,
    name,
    onToggleMenu,
    openProfile,
    onSwitchRole,
    onHandleOpenConfirmModal,
    onLogout,
    setOpenConfirmModal,
    onNavigationToDashboardCommon,
    handleRoleChart,
  };
}
