import { IconButton } from "@mui/material";
import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";
import { pxToRem } from "utils/helpers";

export const ConcurrentListContainer = styled.div`
  max-height: 250px;
  overflow: auto;
  padding: 5px 0px;
  -ms-overflow-style: none;
  scrollbar-width: none;
`;

export const ProfileAvatar = styled.img`
  height: 25px;
  width: 25px;
`;
export const SettingsAvatar = styled.img`
  height: 25px;
  width: 25px;
`;

export const MenuPopup = styled.div`
  padding: 24px 16px;
`;

const HeaderBarContainer = styled.div`
  /* position: sticky; */
  top: 0;
  background: white;
  z-index: 1;
  height: 60px;
  /* padding: 0 ${pxToRem(32)}; */
  display: flex;
  justify-content: flex-end;
  align-items: center;
  /* border-bottom: 0.5px solid ${VPB_THEMES.colors.gray[200]}; */
  box-shadow: 0px 2px 10px 0px rgba(0, 0, 0, 0.06);
  padding: 0px 25px;
  .user-info {
    height: 100%;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 16px;
  }
  .icon-settings-common {
    padding: 8px;
    border-radius: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: ${VPB_THEMES.colors.gray[200]};
    img {
      filter: brightness(0);
      max-width: unset;
    }
  }
  [role="tablist"] {
    align-items: flex-end !important;
  }
  .tab-header {
    width: 160px;
    padding: 6px 18px !important;
    height: 36px;
    min-height: 36px;
    margin-right: 4px;
    background-color: #ededed;
    margin-bottom: 2px;
  }
  .tab-header.Mui-selected {
    background-color: ${VPB_THEMES.colors.green} !important;
    color: white;
    border-top-right-radius: 8px;
    border-top-left-radius: 8px;
    min-height: 42px !important;
  }
  .menu-avatar {
    /* border-radius: 8px;
    padding: 0px 8px; */
  }
  .select-parent {
    display: flex;
    gap: 11px;
    align-items: center;
    .title {
      font-family: SVN-Gilroy;
      font-size: 14px;
      font-weight: 600;
      line-height: 21px;
      text-align: left;
      text-underline-position: from-font;
      text-decoration-skip-ink: none;
    }
  }
  .link {
    cursor: pointer;
  }

  @media (max-width: 768px) {
    justify-content: space-between;
    padding: 0px 16px;
  }
`;

export const HamburgerButtonStyled = styled(IconButton)`
  display: none;
  color: ${VPB_THEMES.colors.gray[500]};
  
  @media (max-width: 768px) {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px;
  }
`;

export default HeaderBarContainer;
