import NotificationsIcon from "@mui/icons-material/Notifications";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import {
  Badge,
  Box,
  Divider,
  IconButton,
  Popover,
  Tooltip,
} from "@mui/material";
import { setLoadingAction } from "App/store/actions";
import { useCallback, useEffect, useState } from "react";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";
import { VPB_THEMES } from "utils/configs";
import { responseCode } from "utils/constants";
import { useDispatchRedux } from "utils/hooks/useRedux";

import NotificationHeader from "./NotificationHeader";
import NotificationList from "./NotificationList";
import NotificationReadModal from "./NotificationReadModal";
import NotificationTabs from "./NotificationTabs";

const PAGE_SIZE = 10;

const isSuccessMeta = (meta = {}) =>
  meta?.code === responseCode["IL-200"] || meta?.code === "LMS-200";

const isNotificationRead = (item = {}) =>
  item.isRead === true ||
  item.read === true ||
  Boolean(item.readAt) ||
  String(item.status || "").toUpperCase() === "READ";

const normalizeFiles = (item = {}) => {
  const raw =
    item.files ||
    item.attachments ||
    item.attachmentFiles ||
    item.evidenceFiles ||
    [];
  if (!Array.isArray(raw)) return [];
  return raw
    .map((file, index) => {
      if (!file) return null;
      return {
        ...file,
        id: file.id ?? file.fileId ?? file.attachmentId ?? index,
        refId: file.refId ?? file.fileRefId ?? null,
        fileName:
          file.fileName ||
          file.name ||
          file.originalFileName ||
          file.originalName ||
          "Tệp đính kèm",
        fileSize: file.fileSize ?? file.size ?? file.byteSize ?? 0,
        fileKey: file.fileKey || file.key || null,
      };
    })
    .filter(Boolean);
};

const normalizeNotification = (item = {}) => ({
  ...item,
  id: item.id ?? item.notificationId,
  refId: item.refId ?? item.manualNotificationId ?? null,
  manualNotificationId:
    item.refId ??
    item.manualNotificationId ??
    item.sourceNotificationId ??
    item.notificationId ??
    item.id,
  title: item.title || item.subject || "Thông báo",
  content: item.content || item.message || item.body || "",
  createdAt: item.createdAt || item.createdDate || item.sentAt || item.time,
  isRead: isNotificationRead(item),
  files: normalizeFiles(item),
});

const NotificationBell = () => {
  const setLoadingPage = useDispatchRedux(setLoadingAction);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [markingAll, setMarkingAll] = useState(false);
  const [filterTab, setFilterTab] = useState(0); // 0: All, 1: Unread
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [hasFetchedInitial, setHasFetchedInitial] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState(null);

  const isOpen = Boolean(anchorEl);
  const isReadModalOpen = Boolean(selectedNotification);

  const fetchUnreadCount = useCallback(async () => {
    try {
      const { data: res = {} } = await ApiReq.get({
        url: urlApi.teacherService.notifications.unreadCount,
      });
      const { data = 0, meta = {} } = res;

      if (isSuccessMeta(meta)) {
        const count =
          typeof data === "number"
            ? data
            : data?.count ?? data?.unreadCount ?? 0;
        setUnreadCount(Number(count) || 0);
      }
    } catch (err) {
      console.error("Error fetching unread count:", err);
    }
  }, []);

  const fetchNotifications = useCallback(async (pageNum = 0, isLoadMore = false) => {
    if (isLoadMore) {
      setLoadingMore(true);
    } else {
      setLoading(true);
    }

    try {
      const { data: res = {} } = await ApiReq.get({
        url: urlApi.teacherService.notifications.list,
        params: {
          page: pageNum,
          size: PAGE_SIZE,
          sort: "createdAt,desc",
        },
      });
      const { data = [], meta = {} } = res;

      if (isSuccessMeta(meta)) {
        const rawItems = Array.isArray(data)
          ? data
          : data?.items || data?.content || data?.records || [];
        const items = rawItems.map(normalizeNotification);

        setNotifications((prev) => (isLoadMore ? [...prev, ...items] : items));

        const totalPages =
          data?.totalPages ??
          meta?.totalPages ??
          data?.page?.totalPages;
        if (totalPages != null) {
          setHasMore(pageNum + 1 < Number(totalPages));
        } else {
          setHasMore(items.length >= PAGE_SIZE);
        }
      }
    } catch (err) {
      console.error("Error fetching notifications:", err);
    } finally {
      if (isLoadMore) {
        setLoadingMore(false);
      } else {
        setLoading(false);
      }
    }
  }, []);

  const markAsRead = useCallback(async (notificationId, isRead) => {
    if (isRead || notificationId == null) return;

    try {
      const { data: res = {} } = await ApiReq.put({
        url: urlApi.teacherService.notifications.markAsRead(notificationId),
      });
      const { meta = {} } = res;

      if (isSuccessMeta(meta)) {
        setNotifications((prev) =>
          prev.map((notif) =>
            notif.id === notificationId ? { ...notif, isRead: true } : notif
          )
        );
        setUnreadCount((prev) => Math.max(0, prev - 1));
      }
    } catch (err) {
      console.error("Error marking notification as read:", err);
    }
  }, []);

  const markAllAsRead = useCallback(async () => {
    if (markingAll || unreadCount <= 0) return;
    setMarkingAll(true);
    try {
      const { data: res = {} } = await ApiReq.put({
        url: urlApi.teacherService.notifications.markAllAsRead,
      });
      const { meta = {} } = res;

      if (isSuccessMeta(meta)) {
        setNotifications((prev) =>
          prev.map((notif) => ({ ...notif, isRead: true }))
        );
        setUnreadCount(0);
      }
    } catch (err) {
      console.error("Error marking all notifications as read:", err);
    } finally {
      setMarkingAll(false);
    }
  }, [markingAll, unreadCount]);

  const fetchNotificationDetail = useCallback(
    async (notification) => {
      if (notification?.id == null) return;

      setLoadingPage(true);
      try {
        const { data: res = {} } = await ApiReq.get({
          url: urlApi.teacherService.notifications.detail(notification.id),
        });
        const { data, meta = {} } = res;

        if (isSuccessMeta(meta) && data) {
          setSelectedNotification(
            normalizeNotification({
              ...notification,
              ...data,
            }),
          );
          return;
        }

        setSelectedNotification(normalizeNotification(notification));
      } catch (err) {
        console.error("Error fetching notification detail:", err);
        setSelectedNotification(normalizeNotification(notification));
      } finally {
        setLoadingPage(false);
      }
    },
    [setLoadingPage],
  );

  const handleNotificationClick = (notification) => {
    markAsRead(notification.id, notification.isRead);
    setSelectedNotification(normalizeNotification(notification));
    setAnchorEl(null);
    fetchNotificationDetail(notification);
  };

  const handleCloseReadModal = () => {
    setSelectedNotification(null);
  };

  const handleLoadMore = useCallback(() => {
    if (!loadingMore && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      fetchNotifications(nextPage, true);
    }
  }, [loadingMore, hasMore, page, fetchNotifications]);

  const handleRefresh = useCallback(() => {
    setPage(0);
    setHasMore(true);
    setNotifications([]);
    fetchNotifications(0, false);
    fetchUnreadCount();
  }, [fetchNotifications, fetchUnreadCount]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);

    if (!isOpen && !hasFetchedInitial) {
      setPage(0);
      setHasMore(true);
      fetchNotifications(0, false);
      setHasFetchedInitial(true);
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const formatTime = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return "Vừa xong";
    if (diffMins < 60) return `${diffMins} phút trước`;
    if (diffHours < 24) return `${diffHours} giờ trước`;
    if (diffDays < 7) return `${diffDays} ngày trước`;
    return date.toLocaleDateString("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  useEffect(() => {
    fetchUnreadCount();
    const interval = setInterval(fetchUnreadCount, 60000);
    return () => clearInterval(interval);
  }, [fetchUnreadCount]);

  const displayCount = unreadCount > 99 ? "99+" : unreadCount;
  const filteredNotifications =
    filterTab === 1 ? notifications.filter((n) => !n.isRead) : notifications;
  const localUnreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <>
      <Tooltip title="Thông báo">
        <IconButton onClick={handleClick} size="medium">
          <Badge
            badgeContent={displayCount}
            color="error"
            sx={{
              "& .MuiBadge-badge": {
                fontWeight: 700,
                fontSize: "0.7rem",
              },
            }}
          >
            {unreadCount > 0 ? (
              <NotificationsActiveIcon
                sx={{ color: VPB_THEMES.colors.primaryBlue }}
              />
            ) : (
              <NotificationsIcon />
            )}
          </Badge>
        </IconButton>
      </Tooltip>

      <Popover
        open={isOpen}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        PaperProps={{
          sx: {
            width: 420,
            maxWidth: "calc(100vw - 32px)",
            maxHeight: "calc(100vh - 100px)",
            mt: 1,
            borderRadius: 2,
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.12)",
            overflow: "hidden",
          },
        }}
      >
        <NotificationHeader
          unreadCount={unreadCount}
          onRefresh={handleRefresh}
          onMarkAllRead={markAllAsRead}
          markingAll={markingAll}
        />

        <NotificationTabs
          activeTab={filterTab}
          onTabChange={(e, newValue) => setFilterTab(newValue)}
          unreadCount={localUnreadCount}
        />

        <Divider />

        <Box
          sx={{
            maxHeight: 500,
            overflowY: "auto",
            overflowX: "hidden",
            "&::-webkit-scrollbar": {
              width: 8,
            },
            "&::-webkit-scrollbar-track": {
              background: VPB_THEMES.colors.lightBg,
            },
            "&::-webkit-scrollbar-thumb": {
              background: VPB_THEMES.colors.gray[300],
              borderRadius: 4,
              "&:hover": {
                background: VPB_THEMES.colors.gray[400],
              },
            },
          }}
        >
          <NotificationList
            loading={loading}
            loadingMore={loadingMore}
            notifications={filteredNotifications}
            filterTab={filterTab}
            hasMore={hasMore}
            onNotificationClick={handleNotificationClick}
            onLoadMore={handleLoadMore}
            formatTime={formatTime}
          />
        </Box>
      </Popover>

      <NotificationReadModal
        open={isReadModalOpen}
        notification={selectedNotification}
        onClose={handleCloseReadModal}
      />
    </>
  );
};

export default NotificationBell;
