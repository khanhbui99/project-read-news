import { Box, CircularProgress } from "@mui/material";
import PropTypes from "prop-types";
import { useCallback, useEffect, useRef } from "react";

import EmptyNotification from "./EmptyNotification";
import NotificationItem from "./NotificationItem";

const NotificationList = ({
  loading,
  loadingMore,
  notifications,
  filterTab,
  hasMore,
  onNotificationClick,
  onLoadMore,
  formatTime,
}) => {
  const observerTarget = useRef(null);

  // Intersection Observer for infinite scroll
  const handleObserver = useCallback(
    (entries) => {
      const [target] = entries;
      if (target.isIntersecting && hasMore && !loadingMore && !loading) {
        onLoadMore();
      }
    },
    [hasMore, loadingMore, loading, onLoadMore]
  );

  useEffect(() => {
    const element = observerTarget.current;
    const option = {
      root: null,
      rootMargin: "100px", // Load more when 100px from bottom
      threshold: 0,
    };

    const observer = new IntersectionObserver(handleObserver, option);
    if (element) observer.observe(element);

    return () => {
      if (element) observer.unobserve(element);
    };
  }, [handleObserver]);

  if (loading && notifications.length === 0) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}>
        <CircularProgress size={32} />
      </Box>
    );
  }

  if (!loading && notifications.length === 0) {
    return <EmptyNotification filterTab={filterTab} />;
  }

  return (
    <Box>
      {notifications.map((notification) => (
        <NotificationItem
          key={notification.id}
          notification={notification}
          onClick={onNotificationClick}
          formatTime={formatTime}
        />
      ))}

      {/* Intersection Observer Target */}
      {hasMore && <Box ref={observerTarget} sx={{ height: 20 }} />}

      {/* Loading More Indicator */}
      {loadingMore && (
        <Box sx={{ display: "flex", justifyContent: "center", py: 2 }}>
          <CircularProgress size={24} />
        </Box>
      )}
    </Box>
  );
};

NotificationList.propTypes = {
  loading: PropTypes.bool.isRequired,
  loadingMore: PropTypes.bool.isRequired,
  notifications: PropTypes.array.isRequired,
  filterTab: PropTypes.number.isRequired,
  hasMore: PropTypes.bool.isRequired,
  onNotificationClick: PropTypes.func.isRequired,
  onLoadMore: PropTypes.func.isRequired,
  formatTime: PropTypes.func.isRequired,
};

export default NotificationList;

