// This file is kept for potential future custom styled components
// Currently using inline MUI sx prop for Facebook-like design

export default {};
