import NotificationsIcon from "@mui/icons-material/Notifications";
import { Box, Typography } from "@mui/material";
import PropTypes from "prop-types";
import { VPB_THEMES } from "utils/configs";

const EmptyNotification = ({ filterTab }) => {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        py: 8,
        px: 3,
      }}
    >
      <NotificationsIcon
        sx={{ fontSize: 64, color: VPB_THEMES.colors.gray[300], mb: 2 }}
      />
      <Typography
        variant="h6"
        sx={{
          fontWeight: 600,
          color: VPB_THEMES.colors.textDark,
          mb: 0.5,
        }}
      >
        {filterTab === 1 ? "Không có thông báo chưa đọc" : "Chưa có thông báo"}
      </Typography>
      <Typography
        sx={{
          fontSize: "0.875rem",
          color: VPB_THEMES.colors.textLight,
          textAlign: "center",
        }}
      >
        {filterTab === 1
          ? "Tất cả thông báo đã được đọc"
          : "Thông báo mới sẽ xuất hiện tại đây"}
      </Typography>
    </Box>
  );
};

EmptyNotification.propTypes = {
  filterTab: PropTypes.number.isRequired,
};

export default EmptyNotification;

