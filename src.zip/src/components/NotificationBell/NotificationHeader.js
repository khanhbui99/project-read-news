import DoneAllIcon from "@mui/icons-material/DoneAll";
import RefreshIcon from "@mui/icons-material/Refresh";
import { Box, CircularProgress, IconButton, Tooltip, Typography } from "@mui/material";
import PropTypes from "prop-types";
import { VPB_THEMES } from "utils/configs";

const NotificationHeader = ({
  unreadCount,
  onRefresh,
  onMarkAllRead,
  markingAll = false,
}) => {
  return (
    <Box sx={{ p: 2, pb: 1 }}>
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Typography
          variant="h6"
          sx={{ fontWeight: 700, color: VPB_THEMES.colors.textDark }}
        >
          Thông báo
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
          {unreadCount > 0 && (
            <Box
              sx={{
                backgroundColor: VPB_THEMES.colors.red,
                color: VPB_THEMES.colors.white,
                borderRadius: "12px",
                px: 1.5,
                py: 0.5,
                fontSize: "0.75rem",
                fontWeight: 700,
                mr: 0.5,
              }}
            >
              {unreadCount} mới
            </Box>
          )}
          {unreadCount > 0 ? (
            <Tooltip title="Đánh dấu đã đọc tất cả">
              <span>
                <IconButton
                  onClick={onMarkAllRead}
                  size="small"
                  disabled={markingAll}
                  sx={{
                    color: VPB_THEMES.colors.primaryBlue,
                    "&:hover": {
                      backgroundColor: `${VPB_THEMES.colors.primaryBlue}10`,
                    },
                  }}
                >
                  {markingAll ? (
                    <CircularProgress size={16} />
                  ) : (
                    <DoneAllIcon fontSize="small" />
                  )}
                </IconButton>
              </span>
            </Tooltip>
          ) : null}
          <Tooltip title="Làm mới">
            <IconButton
              onClick={onRefresh}
              size="small"
              sx={{
                color: VPB_THEMES.colors.textLight,
                "&:hover": {
                  color: VPB_THEMES.colors.primaryBlue,
                  backgroundColor: `${VPB_THEMES.colors.primaryBlue}10`,
                },
              }}
            >
              <RefreshIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>
    </Box>
  );
};

NotificationHeader.propTypes = {
  unreadCount: PropTypes.number.isRequired,
  onRefresh: PropTypes.func.isRequired,
  onMarkAllRead: PropTypes.func,
  markingAll: PropTypes.bool,
};

export default NotificationHeader;
