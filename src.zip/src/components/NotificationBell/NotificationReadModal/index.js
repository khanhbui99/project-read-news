import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import { CircularProgress, DialogContent, Tooltip } from "@mui/material";
import AppDialog from "components/common/AppDialog";
import DialogHeader from "components/common/AppDialog/components/DialogHeader";
import PropTypes from "prop-types";
import { useState } from "react";
import * as ApiReq from "services/api.request";
import urlApi from "services/api.url";

import {
  ContentBox,
  DownloadBtn,
  FileIcon,
  FileItem,
  FileLeft,
  FileList,
  FileMeta,
  FileName,
  FileSize,
  HeaderCaption,
  HeaderIconBox,
  HeaderLead,
  HeaderText,
  HeaderTitle,
  Intro,
  MainTitle,
  MetaPill,
  MetaRow,
  ModalBody,
  Panel,
  PanelDot,
  PanelHead,
  PanelTitle,
  Shell,
  SoftHeader,
} from "./Styled";

const formatDateTime = (value) => {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleString("vi-VN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const formatFileSize = (bytes) => {
  const size = Number(bytes);
  if (!Number.isFinite(size) || size <= 0) return "";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
};

const getDownloadSourceId = (notification = {}) =>
  notification.refId ?? notification.manualNotificationId ?? null;

const getDownloadFileId = (file = {}) => file.id ?? null;

const NotificationReadModal = ({ open, notification, onClose }) => {
  const [downloadingFileId, setDownloadingFileId] = useState(null);

  if (!open || !notification) return null;

  const title = String(notification.title || "").trim();
  const content = String(notification.content || "").trim();
  const createdAtText = formatDateTime(notification.createdAt);
  const files = Array.isArray(notification.files) ? notification.files : [];
  const sourceId = getDownloadSourceId(notification);

  const hasMeta = Boolean(createdAtText) || files.length > 0;
  const hasContent = Boolean(content);
  const hasFiles = files.length > 0;

  const handleDownload = async (file) => {
    const fileId = getDownloadFileId(file);
    if (!fileId || !sourceId) return;
    setDownloadingFileId(fileId);
    try {
      await ApiReq.download({
        url: urlApi.managementService.manualNotifications.downloadFile(
          sourceId,
          fileId,
        ),
        method: "GET",
        folderName: file.fileName || "attachment",
      });
    } catch (err) {
      console.error("Error downloading notification file:", err);
    } finally {
      setDownloadingFileId(null);
    }
  };

  return (
    <AppDialog open={open} align="right" onClose={onClose}>
      <Shell>
        <SoftHeader>
          <DialogHeader handleClose={onClose}>
            <HeaderLead>
              <HeaderIconBox>
                <NotificationsNoneOutlinedIcon />
              </HeaderIconBox>
              <HeaderText>
                <HeaderTitle>Thông báo</HeaderTitle>
                <HeaderCaption>Nội dung từ nhà trường</HeaderCaption>
              </HeaderText>
            </HeaderLead>
          </DialogHeader>
        </SoftHeader>

        <DialogContent style={{ width: 560, maxWidth: "100%" }}>
          <ModalBody>
            <Intro>
              <MainTitle>{title || "Thông báo mới"}</MainTitle>

              {hasMeta ? (
                <MetaRow>
                  {createdAtText ? (
                    <MetaPill>
                      <CalendarMonthOutlinedIcon />
                      {createdAtText}
                    </MetaPill>
                  ) : null}
                  {hasFiles ? (
                    <MetaPill>
                      <InsertDriveFileOutlinedIcon />
                      {files.length} tệp đính kèm
                    </MetaPill>
                  ) : null}
                </MetaRow>
              ) : null}
            </Intro>

            {hasContent ? (
              <Panel>
                <PanelHead>
                  <PanelDot />
                  <PanelTitle>Nội dung thông báo</PanelTitle>
                </PanelHead>
                <ContentBox>{content}</ContentBox>
              </Panel>
            ) : null}

            {hasFiles ? (
              <Panel>
                <PanelHead>
                  <PanelDot $tone="orange" />
                  <PanelTitle>Tệp đính kèm ({files.length})</PanelTitle>
                </PanelHead>
                <FileList>
                  {files.map((file) => {
                    const fileId = getDownloadFileId(file);
                    const isDownloading =
                      downloadingFileId != null &&
                      String(downloadingFileId) === String(fileId);
                    const sizeText = formatFileSize(file.fileSize);
                    return (
                      <FileItem
                        key={fileId || file.fileKey || file.fileName}
                      >
                        <FileLeft>
                          <FileIcon>
                            <InsertDriveFileOutlinedIcon />
                          </FileIcon>
                          <FileMeta>
                            <FileName>
                              {file.fileName || "Tệp đính kèm"}
                            </FileName>
                            {sizeText ? (
                              <FileSize>{sizeText}</FileSize>
                            ) : null}
                          </FileMeta>
                        </FileLeft>
                        <Tooltip arrow title="Tải xuống">
                          <span>
                            <DownloadBtn
                              type="button"
                              disabled={
                                isDownloading || fileId == null || !sourceId
                              }
                              onClick={() => handleDownload(file)}
                            >
                              {isDownloading ? (
                                <CircularProgress size={14} color="inherit" />
                              ) : (
                                <DownloadOutlinedIcon sx={{ fontSize: 16 }} />
                              )}
                              Tải về
                            </DownloadBtn>
                          </span>
                        </Tooltip>
                      </FileItem>
                    );
                  })}
                </FileList>
              </Panel>
            ) : null}
          </ModalBody>
        </DialogContent>
      </Shell>
    </AppDialog>
  );
};

NotificationReadModal.propTypes = {
  open: PropTypes.bool,
  notification: PropTypes.object,
  onClose: PropTypes.func,
};

export default NotificationReadModal;
