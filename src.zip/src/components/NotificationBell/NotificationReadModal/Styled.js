import styled from "styled-components";
import { VPB_THEMES } from "utils/configs";

export const Shell = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100%;
  background: linear-gradient(
    180deg,
    ${VPB_THEMES.colors.eff6ff} 0%,
    ${VPB_THEMES.colors.lightBg} 42%,
    ${VPB_THEMES.colors.white} 100%
  );
  font-family: SVN_Gilroy, sans-serif;
`;

export const SoftHeader = styled.div`
  & > div {
    margin-bottom: 0;
    padding: 14px 16px;
    background: rgba(255, 255, 255, 0.86);
    border-bottom: 1px solid ${VPB_THEMES.colors.borderMedium};
    backdrop-filter: blur(8px);

    .title {
      padding-right: 44px;
      font-size: 16px;
      font-weight: 700;
      line-height: 1.35;
      color: ${VPB_THEMES.colors.textDark};
    }

    .close-icon {
      top: 50%;
      right: 0;
      transform: translateY(-50%);
      width: 36px;
      height: 36px;
      border-radius: 12px;
      color: ${VPB_THEMES.colors.textDark};
      background: ${VPB_THEMES.colors.lightBg};
      transition: background 0.15s ease, color 0.15s ease;

      &:hover {
        color: ${VPB_THEMES.colors.primaryBlue};
        background: ${VPB_THEMES.colors.f0f9ff};
      }
    }
  }
`;

export const HeaderLead = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
`;

export const HeaderIconBox = styled.span`
  width: 40px;
  height: 40px;
  border-radius: 12px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: ${VPB_THEMES.colors.primaryBlue};
  background: ${VPB_THEMES.colors.f0f9ff};

  .MuiSvgIcon-root {
    font-size: 22px;
  }
`;

export const HeaderText = styled.div`
  min-width: 0;
`;

export const HeaderTitle = styled.div`
  font-family: SVN_Gilroy, sans-serif;
  font-size: 16px;
  font-weight: 800;
  line-height: 1.3;
  color: ${VPB_THEMES.colors.textDark};
`;

export const HeaderCaption = styled.div`
  margin-top: 2px;
  font-family: SVN_Gilroy, sans-serif;
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
`;

export const ModalBody = styled.div`
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 8px 4px 24px;
`;

export const Intro = styled.div`
  display: flex;
  flex-direction: column;
  gap: 12px;
`;

export const MainTitle = styled.h2`
  margin: 0;
  font-size: 22px;
  font-weight: 800;
  line-height: 1.35;
  color: ${VPB_THEMES.colors.textDark};
  word-break: break-word;
`;

export const MetaRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
`;

export const MetaPill = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 7px 12px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 700;
  color: ${VPB_THEMES.colors.textDark};
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 2px 10px rgba(15, 23, 42, 0.05);

  .MuiSvgIcon-root {
    font-size: 16px;
    color: ${VPB_THEMES.colors.primaryBlue};
  }
`;

export const Panel = styled.section`
  padding: 18px;
  border-radius: 18px;
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 4px 20px rgba(15, 23, 42, 0.05);
`;

export const PanelHead = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 14px;
`;

export const PanelDot = styled.span`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: ${({ $tone }) =>
    $tone === "orange"
      ? VPB_THEMES.colors.sunnyOrange
      : $tone === "green"
        ? VPB_THEMES.colors.statusActiveDot
        : VPB_THEMES.colors.secondaryBlue};
  box-shadow: 0 0 0 4px
    ${({ $tone }) =>
      $tone === "orange"
        ? VPB_THEMES.colors.fffbeb
        : $tone === "green"
          ? VPB_THEMES.colors.f0fdf4
          : VPB_THEMES.colors.f0f9ff};
`;

export const PanelTitle = styled.h3`
  margin: 0;
  font-size: 15px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.textDark};
`;

export const ContentBox = styled.div`
  padding: 16px 18px;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.lightBg};
  font-size: 15px;
  font-weight: 500;
  line-height: 1.8;
  color: ${VPB_THEMES.colors.textDark};
  white-space: pre-wrap;
  word-break: break-word;
  max-height: calc(100vh - 360px);
  overflow: auto;
`;

export const FileList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;

export const FileItem = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 14px;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.lightBg};
  transition: background 0.15s ease, box-shadow 0.15s ease;

  &:hover {
    background: ${VPB_THEMES.colors.f0f9ff};
    box-shadow: 0 4px 14px rgba(0, 119, 190, 0.08);
  }
`;

export const FileLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  flex: 1;
`;

export const FileIcon = styled.span`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  flex-shrink: 0;
  border-radius: 14px;
  background: ${VPB_THEMES.colors.white};
  color: ${VPB_THEMES.colors.primaryBlue};
  box-shadow: 0 2px 10px rgba(0, 119, 190, 0.1);

  .MuiSvgIcon-root {
    font-size: 22px;
  }
`;

export const FileMeta = styled.div`
  min-width: 0;
  flex: 1;
`;

export const FileName = styled.div`
  font-size: 14px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.textDark};
  word-break: break-word;
`;

export const FileSize = styled.div`
  margin-top: 3px;
  font-size: 12px;
  font-weight: 600;
  color: ${VPB_THEMES.colors.textLight};
`;

export const DownloadBtn = styled.button`
  border: none;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 9px 14px;
  border-radius: 999px;
  font-family: SVN_Gilroy, sans-serif;
  font-size: 13px;
  font-weight: 800;
  color: ${VPB_THEMES.colors.primaryBlue};
  background: ${VPB_THEMES.colors.white};
  box-shadow: 0 2px 10px rgba(0, 119, 190, 0.12);

  &:hover {
    background: ${VPB_THEMES.colors.f0f9ff};
  }

  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;
