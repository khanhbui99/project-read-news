import { Box, Tab, Tabs } from "@mui/material";
import PropTypes from "prop-types";
import { VPB_THEMES } from "utils/configs";

const NotificationTabs = ({ activeTab, onTabChange, unreadCount }) => {
  return (
    <Box sx={{ borderBottom: 1, borderColor: "divider", px: 2 }}>
      <Tabs
        value={activeTab}
        onChange={onTabChange}
        sx={{
          minHeight: 44,
          "& .MuiTab-root": {
            minHeight: 44,
            textTransform: "none",
            fontWeight: 600,
            fontSize: "0.9375rem",
            color: VPB_THEMES.colors.textLight,
            px: 2,
            "&.Mui-selected": {
              color: VPB_THEMES.colors.primaryBlue,
            },
          },
          "& .MuiTabs-indicator": {
            backgroundColor: VPB_THEMES.colors.primaryBlue,
            height: 3,
          },
        }}
      >
        <Tab label={`Tất cả`} />
        <Tab label={`Chưa đọc (${unreadCount})`} />
      </Tabs>
    </Box>
  );
};

NotificationTabs.propTypes = {
  activeTab: PropTypes.number.isRequired,
  onTabChange: PropTypes.func.isRequired,
  unreadCount: PropTypes.number.isRequired,
};

export default NotificationTabs;

