import AccessTimeIcon from "@mui/icons-material/AccessTime";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CircleIcon from "@mui/icons-material/Circle";
import InfoIcon from "@mui/icons-material/Info";
import WarningIcon from "@mui/icons-material/Warning";
import { Avatar, Box, Typography } from "@mui/material";
import PropTypes from "prop-types";
import { VPB_THEMES } from "utils/configs";

const NotificationItem = ({ notification, onClick, formatTime }) => {
  const getNotificationIcon = (type) => {
    switch (type) {
      case "success":
        return { icon: CheckCircleIcon, color: VPB_THEMES.colors.green };
      case "warning":
        return { icon: WarningIcon, color: VPB_THEMES.colors.yellow };
      case "error":
        return { icon: WarningIcon, color: VPB_THEMES.colors.red };
      default:
        return { icon: InfoIcon, color: VPB_THEMES.colors.primaryBlue };
    }
  };

  const iconData = getNotificationIcon(notification.type);
  const IconComponent = iconData.icon;

  return (
    <Box
      onClick={() => onClick(notification)}
      sx={{
        display: "flex",
        gap: 1.5,
        padding: 2,
        cursor: "pointer",
        backgroundColor: notification.isRead
          ? "transparent"
          : `${VPB_THEMES.colors.primaryBlue}08`,
        borderBottom: `1px solid ${VPB_THEMES.colors.table.borderMedium}`,
        transition: "all 0.2s",
        position: "relative",
        "&:hover": {
          backgroundColor: notification.isRead
            ? VPB_THEMES.colors.shade
            : `${VPB_THEMES.colors.primaryBlue}12`,
        },
      }}
    >
      {/* Icon/Avatar */}
      <Avatar
        sx={{
          width: 56,
          height: 56,
          backgroundColor: `${iconData.color}15`,
          flexShrink: 0,
        }}
      >
        <IconComponent sx={{ fontSize: 28, color: iconData.color }} />
      </Avatar>

      {/* Content */}
      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography
          sx={{
            fontSize: "0.9375rem",
            fontWeight: notification.isRead ? 400 : 600,
            color: VPB_THEMES.colors.textDark,
            mb: 0.5,
            lineHeight: 1.4,
          }}
        >
          {notification.title || "Thông báo"}
        </Typography>

        {(notification.content || notification.message) && (
          <Typography
            sx={{
              fontSize: "0.875rem",
              color: VPB_THEMES.colors.textLight,
              mb: 0.75,
              display: "-webkit-box",
              WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
              lineHeight: 1.5,
            }}
          >
            {notification.content || notification.message}
          </Typography>
        )}

        <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
          <AccessTimeIcon
            sx={{ fontSize: 14, color: VPB_THEMES.colors.primaryBlue }}
          />
          <Typography
            sx={{
              fontSize: "0.8125rem",
              color: VPB_THEMES.colors.primaryBlue,
              fontWeight: 500,
            }}
          >
            {formatTime(notification.createdAt || notification.createdDate)}
          </Typography>
        </Box>
      </Box>

      {/* Unread indicator */}
      {!notification.isRead && (
        <CircleIcon
          sx={{
            fontSize: 12,
            color: VPB_THEMES.colors.primaryBlue,
            position: "absolute",
            right: 16,
            top: "50%",
            transform: "translateY(-50%)",
          }}
        />
      )}
    </Box>
  );
};

NotificationItem.propTypes = {
  notification: PropTypes.shape({
    id: PropTypes.number,
    type: PropTypes.string,
    title: PropTypes.string,
    content: PropTypes.string,
    message: PropTypes.string,
    isRead: PropTypes.bool,
    createdAt: PropTypes.string,
    createdDate: PropTypes.string,
  }).isRequired,
  onClick: PropTypes.func.isRequired,
  formatTime: PropTypes.func.isRequired,
};

export default NotificationItem;

