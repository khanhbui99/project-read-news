import {
  toggleMobileSidebarAction,
  closeMobileSidebarAction,
} from 'App/store/actions';
import SidebarIcons from 'assets/icons/sidebar';
import { memo, useCallback, useEffect, useMemo, useState } from 'react';
import { VERSION } from 'utils/constants';
import { useDispatchRedux, useOneState } from 'utils/hooks/useRedux';
import injectKey from 'utils/injectKey';

import LogoIcon from '../Logo';
import Menu from './Menu';
import SidebarStyle, {
  LogoWrap,
  MenuWrap, 
  VersionWrap,
  SidebarArrowStyle,
  SidebarWrapArrowStyle,
  SidebarBackdrop,
} from './style';

const MOBILE_BREAKPOINT = 768;

const Sidebar = () => {
  const toggleMobileSidebarDispatch = useDispatchRedux(toggleMobileSidebarAction);
  const closeMobileSidebarDispatch = useDispatchRedux(closeMobileSidebarAction);
  
  const isMobileSidebarOpen = useOneState(injectKey.GLOBAL, 'isMobileSidebarOpen');
  
  const [isMobile, setIsMobile] = useState(() => window.innerWidth <= MOBILE_BREAKPOINT);

  const toggleSidebar = useCallback(() => {
    if (isMobile) {
      toggleMobileSidebarDispatch();
    }
  }, [isMobile, toggleMobileSidebarDispatch]);

  const handleBackdropClick = useCallback(() => {
    closeMobileSidebarDispatch();
  }, [closeMobileSidebarDispatch]);

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth <= MOBILE_BREAKPOINT;
      setIsMobile(mobile);
      if (!mobile) closeMobileSidebarDispatch();
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, [closeMobileSidebarDispatch]);

  useEffect(() => {
    document.body.style.overflow = isMobileSidebarOpen && isMobile ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [isMobileSidebarOpen, isMobile]);

  const arrowButton = useMemo(() => (
    isMobile && (
      <SidebarArrowStyle
        src={SidebarIcons.collapseMenuBtn}
        onClick={toggleSidebar}
      />
    )
  ), [isMobile, toggleSidebar]);

  return (
    <>
      <SidebarBackdrop isMobileOpen={isMobileSidebarOpen} onClick={handleBackdropClick} />
      <SidebarStyle 
        isMobile={isMobile}
        isMobileOpen={isMobileSidebarOpen}
      >
        <LogoWrap>
          <LogoIcon />
          {isMobile && (
            <SidebarWrapArrowStyle onClick={toggleSidebar}>
              {arrowButton}
            </SidebarWrapArrowStyle>
          )}
        </LogoWrap>
        <MenuWrap>
          <Menu />
          <VersionWrap>{VERSION}</VersionWrap>
        </MenuWrap>
      </SidebarStyle>
    </>
  );
};

export default memo(Sidebar);
