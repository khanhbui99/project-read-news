import styled from "styled-components";
import { SIDEBAR_WITH, VPB_THEMES } from "utils/configs";

import ButtonStyle from "../common/AppButton/style";

const SidebarStyle = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 1000;
  color: #ffffff;
  background: ${VPB_THEMES.gradient["1"]};
  width: ${SIDEBAR_WITH}px;
  padding: 16px;
  transition: transform 0.3s ease-in-out;

  @media (max-width: 1024px) {
    padding: 12px;
  }

  @media (max-width: 768px) {
    transform: ${(p) =>
      p.isMobileOpen ? "translateX(0)" : "translateX(-100%)"};
    box-shadow: ${(p) =>
      p.isMobileOpen ? "4px 0 20px rgba(0, 0, 0, 0.3)" : "none"};
  }

  @media (max-width: 480px) {
    width: 85%;
    max-width: 320px;
  }
`;

const SidebarBackdrop = styled.div`
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  z-index: 999;
  opacity: ${(p) => (p.isMobileOpen ? 1 : 0)};
  visibility: ${(p) => (p.isMobileOpen ? "visible" : "hidden")};
  transition: opacity 0.3s ease-in-out, visibility 0.3s ease-in-out;

  @media (max-width: 768px) {
    display: block;
  }
`;

const MenuWrap = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: calc(100% - 24px);
  padding-top: 32px;
  overflow-y: auto;
  overflow-x: hidden;

  &::-webkit-scrollbar {
    width: 4px;
  }

  &::-webkit-scrollbar-track {
    background: transparent;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 2px;

    &:hover {
      background: rgba(255, 255, 255, 0.5);
    }
  }

  @media (max-width: 768px) {
    padding-top: 24px;
    height: calc(100% - 16px);
  }
`;

const LogoWrap = styled.div`
  display: flex;
  padding: 0 8px;
  align-items: center;
  justify-content: space-between;
  min-height: 48px;
  flex-shrink: 0;

  @media (max-width: 768px) {
    padding: 0 12px;
    min-height: 56px;
  }
`;

const VersionWrap = styled.div`
  text-align: right;
  font-size: 11px;
  padding-top: 16px;
  flex-shrink: 0;

  @media (max-width: 768px) {
    text-align: center;
    padding-top: 12px;
    font-size: 10px;
  }
`;

const SidebarWrapArrowStyle = styled.div`
  line-height: 1;
  cursor: pointer;
  position: relative;

  &::before {
    inset: -8px;
    content: "";
    position: absolute;
    border-radius: 100px;
    transition: background-color 0.5s;
  }

  &:hover {
    &:before {
      background-color: rgb(0, 0, 0, 0.0275);
    }
  }
`;

const SidebarArrowStyle = styled.img`
  cursor: pointer;
  transition: opacity 0.3s;

  @media (min-width: 769px) {
    display: none;
  }
`;

const Button = styled(ButtonStyle)`
  height: 32px;
  border-radius: 8px;
  border: 1px solid #fff;
  color: ${(p) => (p.outline ? "#ffffff" : VPB_THEMES.colors.green)};
  background-color: ${(p) => (p.outline ? "transparent" : "#ffffff")};
`;

// remove props in DOM
Button.shouldForwardProp = (prop) => !["outline"].includes(prop);
SidebarStyle.shouldForwardProp = (prop) =>
  !["isMobileOpen", "isMobile"].includes(prop);
SidebarBackdrop.shouldForwardProp = (prop) => !["isMobileOpen"].includes(prop);

export {
  Button,
  MenuWrap,
  LogoWrap,
  VersionWrap,
  SidebarArrowStyle,
  SidebarWrapArrowStyle,
  SidebarBackdrop,
};
export default SidebarStyle;
