import Skeleton from '@mui/material/Skeleton';
import Stack from '@mui/material/Stack';
import * as React from 'react';

export default function MenuSkeleton({ elementLength = 10 }) {
  return (
    <>
      {Array.from({ length: elementLength }, (v, i) => i).map(() => (
        <Stack spacing={1}>
          <Skeleton variant="rounded" width={210} height={60} />
        </Stack>
      ))}
    </>
  );
}
