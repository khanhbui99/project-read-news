import { setPageTitleAction } from "App/store/actions";
import SidebarIcons from "assets/icons/sidebar";
import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useHistory, useLocation, matchPath } from "react-router-dom";
import { adminPrefix } from "utils/constants";
import { isSvgUrl } from "utils/helpers";

import {
  Fieldset,
  MenuItemLabelStyle,
  MenuItemLabelTextStyle,
  MenuItemStyle,
  SubMenuItemStyle,
  TooltipStyle,
} from "./style";
import Svg from "../../common/Svg";

const MenuItem = ({
  url,
  icon,
  name,
  padding,
  children,
  parentId,
  isDivider,
}) => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(false);
  const { isMiniSidebar } = useSelector((state) => state.global);

  const isNormalIcon = useMemo(() => !parentId, [children, parentId]);
  const isMiniIcon = useMemo(
    () => !isNormalIcon && isMiniSidebar,
    [isNormalIcon, isMiniSidebar]
  );
  const isNullIcon = useMemo(
    () => !isNormalIcon && !isMiniSidebar,
    [isNormalIcon, isMiniSidebar]
  );

  const path = useMemo(() => `${adminPrefix()}${url}`, [url]);

  const tooltipTitle = useMemo(() => {
    if (children)
      return (
        <span
          style={{
            padding: 6,
            fontSize: 12,
            fontWeight: 700,
            lineHeight: "24px",
          }}
        >
          {name}
        </span>
      );

    return name;
  }, [name]);

  const toggleMenu = () => {
    setOpen(!open);
  };

  const handleClick = () => {
    if (!children || parentId) {
      history.push(path);
      return;
    }

    toggleMenu();
  };

  const renderIcon = (src, style) =>
    isSvgUrl(src) ? (
      <Svg className="icon" url={src} style={style} />
    ) : (
      <img className="icon" src={src} style={style} alt="menuItem" />
    );

  useEffect(() => {
    // setOpen(pathname.includes(path) && children);
    setOpen(
      matchPath(pathname, {
        path: path,
      }) && children
    );
  }, [pathname]);

  useEffect(() => {
    setActive(
      matchPath(pathname, {
        path: path,
      }) ||
        (!open &&
          isNormalIcon &&
          matchPath(pathname, {
            path: path,
          }))
    );
    if (pathname === path) dispatch(setPageTitleAction(name));
  }, [open, pathname]);

  return !isDivider ? (
    <>
      <TooltipStyle
        arrow
        placement="right"
        title={tooltipTitle}
        disableHoverListener={!isMiniSidebar}
      >
        <MenuItemStyle
          active={active}
          padding={padding}
          isMiniSidebar={isMiniSidebar}
          isNullIcon={isNullIcon}
          onClick={handleClick}
        >
          <MenuItemLabelStyle
            className="menu-item__label"
            isMiniSidebar={isMiniSidebar}
          >
            {isNormalIcon ? renderIcon(icon) : null}
            {/* <img className="icon" src={SidebarIcons.folderOpen} /> */}

            {isMiniIcon
              ? renderIcon(icon, { padding: children ? 0 : 4 })
              : null}

            {isNullIcon ? (
              <div className="icon">
                <div className="dot" />
              </div>
            ) : null}

            {isMiniSidebar ? null : (
              <MenuItemLabelTextStyle active={active}>
                {name}
              </MenuItemLabelTextStyle>
            )}
          </MenuItemLabelStyle>
          {!isMiniSidebar && children && !parentId ? (
            <img
              alt="arrow"
              src={SidebarIcons.bottomArrow}
              style={{
                transform: `rotate(${open ? 0 : -90}deg)`,
                transition: "transform 0.5s",
              }}
            />
          ) : null}
        </MenuItemStyle>
      </TooltipStyle>
      {children ? (
        <SubMenuItemStyle
          open={open}
          count={children?.length || 0}
          isMiniSidebar={isMiniSidebar}
        >
          {children}
        </SubMenuItemStyle>
      ) : null}
    </>
  ) : (
    <Fieldset isMiniSidebar={isMiniSidebar}>
      {!isMiniSidebar ? <legend>{name}</legend> : null}
    </Fieldset>
  );
};

export default MenuItem;
