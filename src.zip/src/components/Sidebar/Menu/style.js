import { Tooltip, tooltipClasses } from "@mui/material";
import React from "react";
import styled, { keyframes } from "styled-components";
import {
  MENU_ITEM_HEIGHT,
  MINI_MENU_ITEM_HEIGHT,
  PROFILE_HEIGHT,
  PROFILE_PADDING_TOP,
  VPB_THEMES,
} from "utils/configs";

const menuItemBottom = 8;

const activeKeyframe = keyframes`
0% {
  left: -26px;
}
8.9% {
  left: calc(100% + 26px);
}
9% {
  left: -26px;
}
100% {
  left: -26px;
}
`;

const MenuStyle = styled.div`
  overflow-x: auto;
  position: relative;
  max-height: calc(100% - ${PROFILE_HEIGHT + PROFILE_PADDING_TOP}px);

  &::-webkit-scrollbar {
    width: 0;
  }
`;
export default MenuStyle;

const MenuItemStyle = styled.div`
  display: flex;
  padding: 0 10px;
  cursor: pointer;
  overflow: hidden;
  position: relative;
  border-radius: 8px;
  align-items: center;
  margin-bottom: ${menuItemBottom}px;
  ${(p) => (p.isMiniSidebar ? "margin-left: 4px; margin-right: 4px;" : "")}
  justify-content: ${(p) => (p.isMiniSidebar ? "center" : "space-between")};
  background-color: ${(p) => (p.active ? "rgb(255, 255, 255, 24%)" : "unset")};
  min-height: ${(p) =>
    p.isMiniSidebar ? MINI_MENU_ITEM_HEIGHT : MENU_ITEM_HEIGHT}px;

  &:after {
    top: -5px;
    left: -26px;
    width: 15px;
    content: "";
    bottom: -5px;
    position: absolute;
    transform: rotate(30deg);
    background: linear-gradient(
      90deg,
      transparent 0%,
      rgb(255, 255, 255, 18%) 50%,
      transparent 100%
    );

    animation-delay: 1s;
    animation-duration: 15s;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
    animation-name: ${(p) => (p.active ? activeKeyframe : "")};
  }

  &:hover {
    background-color: rgb(255, 255, 255, 24%);
  }

  & .icon {
    align-items: center;
    width: ${(p) => (p.isMiniSidebar ? 28 : 24)}px;
    height: ${(p) => (p.isMiniSidebar ? 28 : 24)}px;
    margin-right: ${(p) => (p.isMiniSidebar ? 0 : 8)}px;
    /* margin-left: ${(p) => (p.isNullIcon && !p.isMiniSidebar ? 14 : 0)}px; */
    .dot {
      width: 4px;
      height: 4px;
      background-color: white;
      border-radius: 10px;
    }
  }
`;

const SubMenuItemStyle = styled.div`
  transition: height 0.25s;
  overflow: ${(p) => (p.open ? "unset" : "hidden")};
  /* height: ${(p) =>
    p.open
      ? p.count *
        (menuItemBottom +
          (p.isMiniSidebar ? MINI_MENU_ITEM_HEIGHT : MENU_ITEM_HEIGHT))
      : 0}px; */
  height: ${(p) => (p.open ? "auto" : "0px")};
  width: 80%;
  margin-left: 15%;
  .menu-item__label-text {
    display: ${(p) => (p.open ? "unset" : "none")};
  }
  & .icon {
    display: flex;
    align-items: center;
    width: 0px;
    width: auto;
    height: ${(p) => (p.isMiniSidebar ? 28 : 24)}px;
    margin-right: ${(p) => (p.isMiniSidebar ? 0 : 8)}px;
    .dot {
      width: 4px;
      height: 4px;
      background-color: white;
      border-radius: 10px;
    }
  }
`;

const MenuItemLabelStyle = styled.div`
  display: flex;
  align-items: center;

  svg {
    margin-right: ${(p) => (p.isMiniSidebar ? 0 : 8)}px;
  }
`;

const MenuItemLabelTextStyle = styled.span`
  font-weight: ${(p) => (p.active ? 700 : 500)};
`;

const TooltipStyle = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(() => ({
  [`& .${tooltipClasses.tooltip}`]: {
    left: "8px",
    color: "#ffffff",
    fontSize: "11px",
    borderRadius: "8px",
    padding: "8px 12px",
    boxShadow: VPB_THEMES.bosShadow,
    background: VPB_THEMES.gradient[2],
  },
  [`& .${tooltipClasses.arrow}`]: {
    color: VPB_THEMES.colors.blue,
  },
}));

const Fieldset = styled.fieldset`
  border-left: none;
  border-right: none;
  border-bottom: none;
  border-top: ${(p) => (p.isMiniSidebar ? 1 : 0)}px solid #fff;
  margin-top: ${(p) => (p.isMiniSidebar ? 8 : 16)}px;
  padding: 8px;
  padding-bottom: 0px;

  &:first-child {
    margin-top: 0;
  }

  legend {
    font-family: SVN-Gilroy;
    font-size: 14px;
    font-weight: 700;
    line-height: 21px;
    text-align: left;
  }
`;

// remove props in DOM
Fieldset.shouldForwardProp = (prop) => !["isMiniSidebar"].includes(prop);
TooltipStyle.shouldForwardProp = (prop) =>
  !["active", "isMiniSidebar"].includes(prop);
MenuItemLabelTextStyle.shouldForwardProp = (prop) => !["active"].includes(prop);
MenuItemLabelStyle.shouldForwardProp = (prop) =>
  !["isMiniSidebar"].includes(prop);
SubMenuItemStyle.shouldForwardProp = (prop) =>
  !["open", "isMiniSidebar", "count"].includes(prop);
MenuItemStyle.shouldForwardProp = (prop) =>
  !["active", "isMiniSidebar", "isNullIcon"].includes(prop);

export {
  MenuItemStyle,
  SubMenuItemStyle,
  MenuItemLabelStyle,
  MenuItemLabelTextStyle,
  TooltipStyle,
  Fieldset,
};
