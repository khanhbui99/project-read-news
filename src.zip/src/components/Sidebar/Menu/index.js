import { compareToOrder } from 'App/helpers';
import get from 'lodash/get';
import { useSelector } from 'react-redux';

import MenuItem from './MenuItem';
import MenuStyle from './style';

const Menu = () => {
  const { menuType, menuRouter } = useSelector(state => state.global);

  const renderMenuItem = ({ child, ...m }) => (
    <MenuItem key={m.id} {...m}>
      {child && child.length
        ? child
            .filter(c => !c.hidden)
            .sort(compareToOrder)
            .map(c => renderMenuItem({ ...c }))
        : null}
    </MenuItem>
  );

  return (
    <MenuStyle>
      {get(menuRouter, menuType, [])
        .filter(m => !m.hidden)
        .map(m => renderMenuItem({ ...m }))}
    </MenuStyle>
  );
};

export default Menu;
