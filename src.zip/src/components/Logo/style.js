import styled from "styled-components";
import { LOGO_HEIGHT, VPB_THEMES } from "utils/configs";

const LogoStyle = styled.div`
  text-align: center;
  height: ${(p) => p.height || LOGO_HEIGHT}px;
  display: flex;
  align-items: center;
  justify-content: center;
  
  a {
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
  }
`;

export const LogoContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: ${(p) => (p.$isMiniSidebar ? "center" : "flex-start")};
  gap: ${(p) => (p.$isMiniSidebar ? "0" : "10px")};
  width: 100%;
`;

export const GraduationCapIcon = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  
  svg {
    display: block;
  }
`;

export const LogoText = styled.div`
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  color: #FFFFFF;
  line-height: 1.2;
  font-family: 'SVN_Gilroy', sans-serif;
  text-transform: uppercase;
  white-space: nowrap;
  text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

export default LogoStyle;
