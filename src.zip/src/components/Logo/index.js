import { School } from "@mui/icons-material";
import logo_thcscaugiay from "assets/images/login/logo_thcscaugiay.jpg";
import AppImage from "components/common/AppImage";
import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { VPB_THEMES } from "utils/configs";

import LogoStyle, { LogoContainer, GraduationCapIcon, LogoText } from "./style";

const Logo = ({ height }) => {
  const { isMiniSidebar } = useSelector((state) => state.global);

  return (
    <LogoStyle height={height} $isMiniSidebar={isMiniSidebar}>
      <Link to="/">
        <LogoContainer $isMiniSidebar={isMiniSidebar}>
          <GraduationCapIcon $isMiniSidebar={isMiniSidebar}>
            {/* <School
              sx={{
                fontSize: isMiniSidebar ? 32 : 40,
                color: "#FFE082", // Vàng nhạt - tương phản tốt với gradient xanh
                display: "block",
                filter: "drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3))",
              }}
            /> */}
            <AppImage src={logo_thcscaugiay} width={40} height={40} />
          </GraduationCapIcon>
          {!isMiniSidebar && (
            <LogoText>
              THCS Cầu Giấy
              <sub style={{ fontSize: 8, display: "block" }}>
                Khơi nguồn những tiềm năng
              </sub>
            </LogoText>
          )}
        </LogoContainer>
      </Link>
    </LogoStyle>
  );
};

export default Logo;
