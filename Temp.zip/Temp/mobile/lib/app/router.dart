import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../navigation/types.dart';
import '../navigation/tab_scaffold.dart';
import '../modules/home/screens/home_screen.dart';
import '../modules/messages/screens/messages_screen.dart';
import '../modules/notifications/screens/notifications_screen.dart';
import '../modules/account/screens/account_screen.dart';
import '../modules/settings/screens/settings_screen.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: AppRoutes.home,
    routes: [
      ShellRoute(
        builder: (context, state, child) => TabScaffold(child: child),
        routes: [
          GoRoute(path: AppRoutes.home, builder: (_, __) => const HomeScreen()),
          GoRoute(path: AppRoutes.messages, builder: (_, __) => const MessagesScreen()),
          GoRoute(path: AppRoutes.notifications, builder: (_, __) => const NotificationsScreen()),
          GoRoute(path: AppRoutes.account, builder: (_, __) => const AccountScreen()),
          GoRoute(path: AppRoutes.settings, builder: (_, __) => const SettingsScreen()),
        ],
      ),
    ],
  );
});
