import 'package:flutter/material.dart';
import '../../theme/colors.dart';

/// LoadingService — Imperative global loading overlay.
/// Callable from anywhere without BuildContext.
class LoadingService {
  static GlobalKey<NavigatorState>? _navigatorKey;
  static OverlayEntry? _overlayEntry;

  static set navigatorKey(GlobalKey<NavigatorState> key) => _navigatorKey = key;

  /// Show full-screen loading overlay
  static void show() {
    if (_overlayEntry != null) return; // Already showing
    final overlay = _navigatorKey?.currentState?.overlay;
    if (overlay == null) return;

    _overlayEntry = OverlayEntry(
      builder: (_) => const _LoadingOverlayWidget(),
    );
    overlay.insert(_overlayEntry!);
  }

  /// Hide loading overlay
  static void hide() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }
}

class _LoadingOverlayWidget extends StatelessWidget {
  const _LoadingOverlayWidget();

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withOpacity(0.4),
      child: const Center(
        child: CircularProgressIndicator(
          color: AppColors.primary,
          strokeWidth: 3,
        ),
      ),
    );
  }
}
