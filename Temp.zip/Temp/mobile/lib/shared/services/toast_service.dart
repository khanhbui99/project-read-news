import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../theme/colors.dart';

enum ToastType { success, error, warning, info }

/// AppToast — Lightweight notification (auto-dismiss, non-blocking)
/// Use for passive events. For user actions → use NotifyService (modal)
class AppToast {
  static void show(String message, {ToastType type = ToastType.info}) {
    final color = _colorForType(type);
    Fluttertoast.showToast(
      msg: message,
      backgroundColor: color,
      textColor: Colors.white,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      fontSize: 14,
    );
  }

  static void success(String message) => show(message, type: ToastType.success);
  static void error(String message) => show(message, type: ToastType.error);
  static void warning(String message) => show(message, type: ToastType.warning);
  static void info(String message) => show(message, type: ToastType.info);

  static Color _colorForType(ToastType type) {
    switch (type) {
      case ToastType.success:
        return AppColors.success;
      case ToastType.error:
        return AppColors.error;
      case ToastType.warning:
        return AppColors.warning;
      case ToastType.info:
        return AppColors.info;
    }
  }
}
