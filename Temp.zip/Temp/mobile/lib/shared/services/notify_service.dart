import 'package:flutter/material.dart';
import '../widgets/app_modal.dart';

/// ModalResult — result of a modal interaction
enum ModalResult { confirmed, dismissed }

/// NotifyService — Imperative modal notification service.
/// Shows AppModal from anywhere using GlobalNavigatorKey.
class NotifyService {
  static GlobalKey<NavigatorState>? navigatorKey;

  /// Show notification modal (imperative)
  static Future<ModalResult> show({
    required ModalType type,
    required String title,
    String? message,
    String? confirmText,
    String? cancelText,
    bool dismissible = true,
  }) async {
    final context = navigatorKey?.currentState?.context;
    if (context == null) return ModalResult.dismissed;

    return await AppModal.show(
      context,
      ModalConfig(
        type: type,
        title: title,
        message: message,
        confirmText: confirmText,
        cancelText: cancelText,
        dismissible: dismissible,
      ),
    );
  }

  /// Shorthand: success notification
  static Future<ModalResult> success(String title, {String? message}) =>
      show(type: ModalType.success, title: title, message: message);

  /// Shorthand: error notification
  static Future<ModalResult> error(String title, {String? message}) =>
      show(type: ModalType.error, title: title, message: message);

  /// Shorthand: warning notification
  static Future<ModalResult> warning(String title, {String? message}) =>
      show(type: ModalType.warning, title: title, message: message);

  /// Shorthand: info notification
  static Future<ModalResult> info(String title, {String? message}) =>
      show(type: ModalType.info, title: title, message: message);

  /// Shorthand: confirm dialog (returns confirmed/dismissed)
  static Future<ModalResult> confirm(String title, {String? message, String? confirmText}) =>
      show(type: ModalType.confirm, title: title, message: message, confirmText: confirmText);
}
