import 'package:flutter_dotenv/flutter_dotenv.dart';

/// EnvConfig — Validated environment configuration
class EnvConfig {
  final String apiBaseUrl;
  final String appName;
  final String environment; // dev, staging, prod
  final bool enableLogging;

  const EnvConfig({
    required this.apiBaseUrl,
    required this.appName,
    required this.environment,
    this.enableLogging = false,
  });

  bool get isDev => environment == 'dev';
  bool get isStaging => environment == 'staging';
  bool get isProd => environment == 'prod';

  static Future<EnvConfig> load() async {
    const env = String.fromEnvironment('ENV', defaultValue: 'dev');
    await dotenv.load(fileName: '.env.$env');

    final apiBaseUrl = dotenv.get('API_BASE_URL');
    final appName = dotenv.get('APP_NAME');
    final environment = dotenv.get('ENVIRONMENT', fallback: env);
    final enableLogging = dotenv.getBool('ENABLE_LOGGING', fallback: true);

    // Validation
    assert(apiBaseUrl.startsWith('http://') || apiBaseUrl.startsWith('https://'),
        'API_BASE_URL must start with http:// or https://');
    assert(['dev', 'staging', 'prod'].contains(environment),
        'ENVIRONMENT must be one of: dev, staging, prod');
    assert(appName.isNotEmpty, 'APP_NAME must not be empty');

    return EnvConfig(
      apiBaseUrl: apiBaseUrl,
      appName: appName,
      environment: environment,
      enableLogging: enableLogging,
    );
  }
}
