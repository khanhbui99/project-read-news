import 'package:flutter/material.dart';

/// ContainerBase — Scroll + padding + keyboard dismiss + pull-to-refresh.
/// SafeArea handled at TabScaffold level (App layer).
class ContainerBase extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? backgroundColor;
  final RefreshCallback? onRefresh;
  final ScrollController? scrollController;

  const ContainerBase({
    super.key,
    required this.child,
    this.padding,
    this.backgroundColor,
    this.onRefresh,
    this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
    final defaultPadding = padding ?? const EdgeInsets.symmetric(horizontal: 16, vertical: 8);
    final bgColor = backgroundColor ?? Theme.of(context).scaffoldBackgroundColor;

    Widget content = SingleChildScrollView(
      controller: scrollController,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: defaultPadding,
      child: child,
    );

    if (onRefresh != null) {
      content = RefreshIndicator(
        onRefresh: onRefresh!,
        child: content,
      );
    }

    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Container(
        color: bgColor,
        child: content,
      ),
    );
  }
}
