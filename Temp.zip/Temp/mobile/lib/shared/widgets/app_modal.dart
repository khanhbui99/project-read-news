import 'package:flutter/material.dart';
import '../../theme/colors.dart';
import '../services/notify_service.dart';

enum ModalType { confirm, success, error, warning, info }

class ModalConfig {
  final ModalType type;
  final String title;
  final String? message;
  final String? confirmText;
  final String? cancelText;
  final bool dismissible;

  const ModalConfig({
    required this.type,
    required this.title,
    this.message,
    this.confirmText,
    this.cancelText,
    this.dismissible = true,
  });
}

/// AppModal — Bottom sheet modal with 5 types
class AppModal {
  static Future<ModalResult> show(BuildContext context, ModalConfig config) async {
    final result = await showModalBottomSheet<ModalResult>(
      context: context,
      isDismissible: config.dismissible,
      enableDrag: config.dismissible,
      backgroundColor: Colors.transparent,
      builder: (_) => _ModalContent(config: config),
    );
    return result ?? ModalResult.dismissed;
  }
}

class _ModalContent extends StatelessWidget {
  final ModalConfig config;
  const _ModalContent({required this.config});

  @override
  Widget build(BuildContext context) {
    final isCentered = config.type == ModalType.success || config.type == ModalType.error;
    final hasCancel = config.type == ModalType.confirm || config.type == ModalType.warning;
    final typeColor = _typeColor(config.type);
    final typeIcon = _typeIcon(config.type);
    final typeBgColor = _typeBgColor(config.type);

    return Container(
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: isCentered ? CrossAxisAlignment.center : CrossAxisAlignment.start,
        children: [
          // Header: icon + title
          if (isCentered) ...[
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(shape: BoxShape.circle, color: typeBgColor),
              alignment: Alignment.center,
              child: Icon(typeIcon, color: typeColor, size: 28),
            ),
            const SizedBox(height: 12),
            Text(config.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600)),
          ] else ...[
            Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(shape: BoxShape.circle, color: typeBgColor),
                alignment: Alignment.center,
                child: Icon(typeIcon, color: typeColor, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(child: Text(config.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600))),
            ]),
          ],

          if (config.message != null) ...[
            const SizedBox(height: 12),
            Text(config.message!, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary), textAlign: isCentered ? TextAlign.center : TextAlign.start),
          ],

          const SizedBox(height: 24),

          // Actions
          Row(
            mainAxisAlignment: isCentered ? MainAxisAlignment.center : MainAxisAlignment.end,
            children: [
              if (hasCancel)
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context, ModalResult.dismissed),
                    child: Text(config.cancelText ?? 'Hủy'),
                  ),
                ),
              if (hasCancel) const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: typeColor),
                  onPressed: () => Navigator.pop(context, ModalResult.confirmed),
                  child: Text(config.confirmText ?? (hasCancel ? 'Xác nhận' : 'OK')),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _typeColor(ModalType type) {
    switch (type) {
      case ModalType.confirm: return AppColors.primary;
      case ModalType.success: return AppColors.success;
      case ModalType.error: return AppColors.error;
      case ModalType.warning: return AppColors.warning;
      case ModalType.info: return AppColors.info;
    }
  }

  Color _typeBgColor(ModalType type) {
    switch (type) {
      case ModalType.confirm: return AppColors.primarySurface;
      case ModalType.success: return AppColors.successLight;
      case ModalType.error: return AppColors.errorLight;
      case ModalType.warning: return AppColors.warningLight;
      case ModalType.info: return AppColors.infoLight;
    }
  }

  IconData _typeIcon(ModalType type) {
    switch (type) {
      case ModalType.confirm: return Icons.help_outline_rounded;
      case ModalType.success: return Icons.check_circle_outline_rounded;
      case ModalType.error: return Icons.error_outline_rounded;
      case ModalType.warning: return Icons.warning_amber_rounded;
      case ModalType.info: return Icons.info_outline_rounded;
    }
  }
}
