import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

/// ShimmerSkeleton — Animated placeholder while loading
class ShimmerSkeleton extends StatelessWidget {
  final double? width;
  final double height;
  final double borderRadius;

  const ShimmerSkeleton({
    super.key,
    this.width,
    this.height = 20,
    this.borderRadius = 8,
  });

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey[300]!,
      highlightColor: Colors.grey[100]!,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(borderRadius),
        ),
      ),
    );
  }

  /// List skeleton (multiple lines)
  static Widget list({int count = 5, double spacing = 12}) {
    return Column(
      children: List.generate(count, (i) => Padding(
        padding: EdgeInsets.only(bottom: spacing),
        child: ShimmerSkeleton(height: 60, width: double.infinity),
      )),
    );
  }

  /// Card skeleton
  static Widget card() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ShimmerSkeleton(width: 150, height: 24),
        SizedBox(height: 12),
        ShimmerSkeleton(height: 16),
        SizedBox(height: 8),
        ShimmerSkeleton(width: 200, height: 16),
        SizedBox(height: 16),
        ShimmerSkeleton(height: 120),
      ],
    );
  }
}
