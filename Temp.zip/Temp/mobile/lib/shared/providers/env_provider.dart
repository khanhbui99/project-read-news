import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/env_config.dart';

/// Env config provider — overridden at ProviderScope level after loading
final envConfigProvider = Provider<EnvConfig>((ref) {
  throw UnimplementedError('envConfigProvider must be overridden with loaded EnvConfig');
});
