import 'package:flutter/material.dart';
import '../../../shared/widgets/container_base.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ContainerBase(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          Text('Tin nhắn', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 24),
          Center(child: Text('Chưa có tin nhắn nào', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey))),
        ],
      ),
    );
  }
}
