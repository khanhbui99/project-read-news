import 'package:flutter/material.dart';
import '../../../shared/widgets/container_base.dart';
import '../../../theme/colors.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ContainerBase(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Cài đặt', style: Theme.of(context).textTheme.headlineMedium),
          ),
          _buildSection(context, 'Chung', [
            _SettingItem(icon: Icons.language, label: 'Ngôn ngữ', value: 'Tiếng Việt'),
            _SettingItem(icon: Icons.notifications_outlined, label: 'Thông báo', value: 'Bật'),
            _SettingItem(icon: Icons.lock_outline, label: 'Bảo mật'),
            _SettingItem(icon: Icons.storage_outlined, label: 'Lưu trữ & Dữ liệu'),
          ]),
          _buildSection(context, 'Về ứng dụng', [
            _SettingItem(icon: Icons.phone_android, label: 'Phiên bản', value: '1.0.0'),
            _SettingItem(icon: Icons.description_outlined, label: 'Điều khoản sử dụng'),
            _SettingItem(icon: Icons.shield_outlined, label: 'Chính sách bảo mật'),
          ]),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
                onPressed: () {},
                child: const Text('Đăng xuất'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(BuildContext context, String title, List<_SettingItem> items) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(title, style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w600)),
          ),
          ...items.map((item) => ListTile(
            leading: Icon(item.icon, size: 20),
            title: Text(item.label, style: Theme.of(context).textTheme.bodyMedium),
            trailing: item.value != null
                ? Text(item.value!, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey))
                : const Icon(Icons.chevron_right, size: 20, color: Colors.grey),
            dense: true,
            onTap: () {},
          )),
        ],
      ),
    );
  }
}

class _SettingItem {
  final IconData icon;
  final String label;
  final String? value;
  const _SettingItem({required this.icon, required this.label, this.value});
}
