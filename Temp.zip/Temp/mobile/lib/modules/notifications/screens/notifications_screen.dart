import 'package:flutter/material.dart';
import '../../../shared/widgets/container_base.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ContainerBase(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          Text('Thông báo', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 24),
          Center(child: Text('Không có thông báo mới', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey))),
        ],
      ),
    );
  }
}
