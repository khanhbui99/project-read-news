import 'package:flutter/material.dart';

/// AppTypography — Text theme for the app
class AppTypography {
  AppTypography._();

  static const String fontFamily = 'System';

  static TextTheme get textTheme => const TextTheme(
        displayLarge: TextStyle(fontSize: 36, fontWeight: FontWeight.w700, height: 1.2),
        displayMedium: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, height: 1.2),
        displaySmall: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, height: 1.3),
        headlineLarge: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, height: 1.3),
        headlineMedium: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, height: 1.3),
        headlineSmall: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, height: 1.4),
        titleLarge: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, height: 1.4),
        titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, height: 1.4),
        titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, height: 1.4),
        bodyLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w400, height: 1.5),
        bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w400, height: 1.5),
        bodySmall: TextStyle(fontSize: 12, fontWeight: FontWeight.w400, height: 1.4),
        labelLarge: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, height: 1.4),
        labelMedium: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, height: 1.3),
        labelSmall: TextStyle(fontSize: 10, fontWeight: FontWeight.w500, height: 1.3),
      );
}
