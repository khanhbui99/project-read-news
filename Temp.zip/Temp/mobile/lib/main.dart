import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'shared/models/env_config.dart';
import 'shared/providers/env_provider.dart';
import 'app/app.dart';

Future<void> main() async {
  // Step 1: Ensure Flutter bindings
  WidgetsFlutterBinding.ensureInitialized();

  // Step 2: Load and validate environment config
  final envConfig = await EnvConfig.load();

  // Step 3: Lock orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  // Step 4: Run app with ProviderScope
  runApp(
    ProviderScope(
      overrides: [
        envConfigProvider.overrideWithValue(envConfig),
      ],
      child: const App(),
    ),
  );
}
