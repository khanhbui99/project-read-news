/// Route paths
class AppRoutes {
  AppRoutes._();

  static const String home = '/home';
  static const String messages = '/messages';
  static const String notifications = '/notifications';
  static const String account = '/account';
  static const String settings = '/settings';
  static const String login = '/login';
}

/// Tab enum
enum AppTab {
  messages,
  notifications,
  home,
  settings,
  account;

  String get path {
    switch (this) {
      case AppTab.home: return AppRoutes.home;
      case AppTab.messages: return AppRoutes.messages;
      case AppTab.notifications: return AppRoutes.notifications;
      case AppTab.account: return AppRoutes.account;
      case AppTab.settings: return AppRoutes.settings;
    }
  }

  String get label {
    switch (this) {
      case AppTab.home: return 'Trang chủ';
      case AppTab.messages: return 'Tin nhắn';
      case AppTab.notifications: return 'Thông báo';
      case AppTab.account: return 'Tài khoản';
      case AppTab.settings: return 'Cài đặt';
    }
  }
}
