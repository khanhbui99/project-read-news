import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'types.dart';
import '../../theme/colors.dart';

/// TabScaffold — ShellRoute builder wrapping content with SafeArea + custom tab bar
class TabScaffold extends StatelessWidget {
  final Widget child;
  const TabScaffold({super.key, required this.child});

  int _currentIndex(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    final tabs = AppTab.values;
    for (int i = 0; i < tabs.length; i++) {
      if (location == tabs[i].path) return i;
    }
    return 2; // Default: home (center)
  }

  @override
  Widget build(BuildContext context) {
    final currentIndex = _currentIndex(context);

    return SafeArea(
      child: Scaffold(
        body: child,
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: currentIndex,
          onTap: (index) => context.go(AppTab.values[index].path),
          type: BottomNavigationBarType.fixed,
          selectedItemColor: AppColors.primary,
          unselectedItemColor: AppColors.textSecondary,
          backgroundColor: AppColors.surface,
          selectedFontSize: 11,
          unselectedFontSize: 11,
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), activeIcon: Icon(Icons.chat_bubble), label: 'Tin nhắn'),
            BottomNavigationBarItem(icon: Icon(Icons.notifications_outlined), activeIcon: Icon(Icons.notifications), label: 'Thông báo'),
            BottomNavigationBarItem(icon: Icon(Icons.home_outlined), activeIcon: Icon(Icons.home), label: 'Trang chủ'),
            BottomNavigationBarItem(icon: Icon(Icons.settings_outlined), activeIcon: Icon(Icons.settings), label: 'Cài đặt'),
            BottomNavigationBarItem(icon: Icon(Icons.person_outline), activeIcon: Icon(Icons.person), label: 'Tài khoản'),
          ],
        ),
      ),
    );
  }
}
