# React Parent Template

Production-ready React boilerplate for team-wide AI-assisted development.

## Tech Stack

| Category | Technology |
|----------|-----------|
| Build | Vite 5 + TypeScript 5 |
| UI | React 18 + Styled Components 6 |
| Routing | React Router v7 |
| State | Zustand 4 |
| Data Fetching | TanStack Query 5 |
| Forms | React Hook Form 7 + Zod 3 |
| i18n | react-i18next 14 |
| HTTP | Axios 1 |
| Testing | Vitest + RTL + Playwright + fast-check |
| Linting | ESLint 8 + Prettier 3 |

## Getting Started

```bash
npm install
npm run dev
```

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start dev server (port 3000) |
| `npm run build` | Production build |
| `npm run build:staging` | Staging build |
| `npm run build:production` | Production build (explicit) |
| `npm run test` | Run unit + PBT tests |
| `npm run test:e2e` | Run Playwright E2E tests |
| `npm run lint` | ESLint check |
| `npm run format` | Prettier format |

## Project Structure

```
src/
├── app/                    # App bootstrap (providers, routes, App)
├── modules/                # Business modules (feature-based)
│   ├── example/            # Example module pattern
│   └── examples/           # Demo pages (showcase + CRUD)
├── shared/                 # Shared/reusable code
│   ├── components/         # UI components (layouts, modals, loading)
│   ├── hooks/              # Custom hooks (useTheme, etc.)
│   ├── services/           # Services (API client, loading, modal)
│   ├── utils/              # Utilities (createLazyRoute, etc.)
│   ├── types/              # Global TypeScript types
│   ├── config/             # App configuration (env validation)
│   └── i18n/               # Internationalization (en, vi)
├── styles/                 # Theme, media helpers, global styles
├── assets/                 # Static assets
└── test/                   # Test setup
```

## Conventions

### Module Structure
Each module under `src/modules/{name}/` contains:
- `components/` — Module-specific components
- `hooks/` — Module query hooks (TanStack Query)
- `services/` — API service functions
- `stores/` — Zustand stores
- `pages/` — Route page components
- `index.ts` — Public API (only import from here cross-module)
- `routes.ts` — Route definitions

### Naming
- Components: PascalCase (`ModalConfirm.tsx`)
- Modals: `Modal{Name}` pattern
- Hooks: `use{Name}` pattern
- Stores: `use{Name}Store`
- Services: `{name}Service`

### Global Services (imperative, callable anywhere)
```typescript
import { setLoading } from '@/shared/services/loadingService';
import { showConfirm, showSuccess, showError } from '@/shared/services/modalService';
```

### Theme
- Auto-detects system preference (light/dark/system)
- Uses React Context (separate from Zustand)
- Persists to localStorage

### Responsive
- Mobile-first approach
- Use `media.up('md')` in styled-components
- Breakpoints: xs(0), sm(576), md(768), lg(992), xl(1200), xxl(1400)

## Environment Variables

Copy `.env.example` → `.env.local` and fill in values:

| Variable | Description |
|----------|-------------|
| `VITE_APP_TITLE` | Application title |
| `VITE_APP_ENV` | Environment (development/staging/production) |
| `VITE_API_BASE_URL` | Backend API base URL |
| `TELEGRAM_CHAT_ID` | Telegram chat ID for notifications |
| `TELEGRAM_BOT_TOKEN` | Telegram bot token |

## Example Pages

- `/examples/showcase` — All shared components demo
- `/examples/crud` — Full CRUD flow with drawer + table

## Testing

- Unit tests: `npm run test`
- Property-based tests: included in test suite (fast-check)
- E2E: `npm run test:e2e`

## For AI-Assisted Development

This template is designed for teams using AI to code. Patterns are:
- Consistent and predictable
- Well-typed with explicit interfaces
- Example-driven (see `/examples/` pages)
- Agent rule files in `.kiro/rules/` for workflow automation
