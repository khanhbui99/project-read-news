import { test, expect } from '@playwright/test';

test('home page loads successfully', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('body')).toBeVisible();
});

test('showcase page renders all sections', async ({ page }) => {
  await page.goto('/examples/showcase');
  await expect(page.getByText('Component Showcase')).toBeVisible();
  await expect(page.getByText('Modal System')).toBeVisible();
  await expect(page.getByText('Global Loading')).toBeVisible();
  await expect(page.getByText('Theme')).toBeVisible();
});

test('theme toggle works', async ({ page }) => {
  await page.goto('/examples/showcase');
  await page.getByText('🌙').click();
  // Dark mode should change background
  const body = page.locator('body');
  await expect(body).toBeVisible();
});
