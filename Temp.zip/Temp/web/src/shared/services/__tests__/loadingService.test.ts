import { describe, it, expect, beforeEach } from 'vitest';
import { useLoadingStore, setLoading } from '../loadingService';

describe('Loading Service', () => {
  beforeEach(() => {
    useLoadingStore.setState({ isVisible: false });
  });

  it('should initialize with isVisible false', () => {
    expect(useLoadingStore.getState().isVisible).toBe(false);
  });

  it('should set loading to true', () => {
    setLoading(true);
    expect(useLoadingStore.getState().isVisible).toBe(true);
  });

  it('should set loading to false', () => {
    setLoading(true);
    setLoading(false);
    expect(useLoadingStore.getState().isVisible).toBe(false);
  });

  it('should be idempotent for same value', () => {
    setLoading(true);
    setLoading(true);
    setLoading(true);
    expect(useLoadingStore.getState().isVisible).toBe(true);

    setLoading(false);
    expect(useLoadingStore.getState().isVisible).toBe(false);
  });
});
