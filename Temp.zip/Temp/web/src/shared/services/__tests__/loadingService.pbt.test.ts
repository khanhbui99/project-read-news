import { describe, it, expect, beforeEach } from 'vitest';
import * as fc from 'fast-check';
import { useLoadingStore, setLoading } from '../loadingService';

describe('Loading Service - Property Based Tests', () => {
  beforeEach(() => {
    useLoadingStore.setState({ isVisible: false });
  });

  it('Property: setLoading(v) always results in isVisible === v', () => {
    fc.assert(
      fc.property(fc.boolean(), (visible) => {
        setLoading(visible);
        expect(useLoadingStore.getState().isVisible).toBe(visible);
      }),
    );
  });

  it('Property: setLoading is idempotent — calling with same value N times equals calling once', () => {
    fc.assert(
      fc.property(
        fc.boolean(),
        fc.integer({ min: 1, max: 100 }),
        (visible, n) => {
          for (let i = 0; i < n; i++) {
            setLoading(visible);
          }
          expect(useLoadingStore.getState().isVisible).toBe(visible);
        },
      ),
    );
  });

  it('Property: last call wins — for any sequence of booleans, final state matches last value', () => {
    fc.assert(
      fc.property(fc.array(fc.boolean(), { minLength: 1, maxLength: 50 }), (sequence) => {
        sequence.forEach((v) => setLoading(v));
        const lastValue = sequence[sequence.length - 1];
        expect(useLoadingStore.getState().isVisible).toBe(lastValue);
      }),
    );
  });
});
