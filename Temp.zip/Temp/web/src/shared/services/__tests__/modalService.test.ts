import { describe, it, expect, beforeEach } from 'vitest';
import { useModalStore } from '../modalService';

describe('Modal Service', () => {
  beforeEach(() => {
    useModalStore.setState({ stack: [] });
  });

  it('should initialize with empty stack', () => {
    expect(useModalStore.getState().stack).toHaveLength(0);
  });

  it('should open a modal and add to stack', () => {
    const store = useModalStore.getState();
    store.open({ type: 'info', title: 'Test', message: 'Hello' });
    expect(useModalStore.getState().stack).toHaveLength(1);
  });

  it('should assign unique IDs to each modal', () => {
    const store = useModalStore.getState();
    store.open({ type: 'info', title: 'A', message: '' });
    store.open({ type: 'info', title: 'B', message: '' });
    const ids = useModalStore.getState().stack.map((m) => m.id);
    expect(new Set(ids).size).toBe(2);
  });

  it('should close a specific modal by ID', () => {
    const store = useModalStore.getState();
    store.open({ type: 'info', title: 'A', message: '' });
    store.open({ type: 'info', title: 'B', message: '' });

    const firstId = useModalStore.getState().stack[0].id;
    store.close(firstId);

    const remaining = useModalStore.getState().stack;
    expect(remaining).toHaveLength(1);
    expect(remaining[0].title).toBe('B');
  });

  it('should close all modals', () => {
    const store = useModalStore.getState();
    store.open({ type: 'info', title: 'A', message: '' });
    store.open({ type: 'success', title: 'B', message: '' });
    store.open({ type: 'error', title: 'C', message: '' });

    store.closeAll();
    expect(useModalStore.getState().stack).toHaveLength(0);
  });

  it('should resolve Promise when modal is closed with result', async () => {
    const store = useModalStore.getState();
    const promise = store.open<boolean>({ type: 'confirm', title: 'Confirm', message: '' });

    const id = useModalStore.getState().stack[0].id;
    store.close(id, true);

    const result = await promise;
    expect(result).toBe(true);
  });

  it('should resolve all Promises with undefined on closeAll', async () => {
    const store = useModalStore.getState();
    const p1 = store.open({ type: 'info', title: '1', message: '' });
    const p2 = store.open({ type: 'info', title: '2', message: '' });

    store.closeAll();

    expect(await p1).toBeUndefined();
    expect(await p2).toBeUndefined();
  });
});
