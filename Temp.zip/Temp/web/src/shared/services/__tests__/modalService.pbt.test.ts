import { describe, it, expect, beforeEach } from 'vitest';
import * as fc from 'fast-check';
import { useModalStore } from '../modalService';

describe('Modal Service - Property Based Tests', () => {
  beforeEach(() => {
    useModalStore.setState({ stack: [] });
  });

  it('Property: all modal IDs in stack are unique after any number of opens', () => {
    fc.assert(
      fc.property(fc.integer({ min: 1, max: 20 }), async (count) => {
        const store = useModalStore.getState();
        for (let i = 0; i < count; i++) {
          store.open({ type: 'info', title: `Modal ${i}`, message: 'test' });
        }
        const ids = useModalStore.getState().stack.map((m) => m.id);
        const uniqueIds = new Set(ids);
        expect(uniqueIds.size).toBe(ids.length);
      }),
    );
  });

  it('Property: close(id) removes exactly that modal from the stack', () => {
    fc.assert(
      fc.property(fc.integer({ min: 2, max: 10 }), async (count) => {
        const store = useModalStore.getState();
        for (let i = 0; i < count; i++) {
          store.open({ type: 'info', title: `Modal ${i}`, message: 'test' });
        }

        const stack = useModalStore.getState().stack;
        const targetId = stack[0].id;
        store.close(targetId);

        const newStack = useModalStore.getState().stack;
        expect(newStack.length).toBe(count - 1);
        expect(newStack.find((m) => m.id === targetId)).toBeUndefined();
      }),
    );
  });

  it('Property: closeAll() empties the stack completely', () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 15 }), async (count) => {
        const store = useModalStore.getState();
        for (let i = 0; i < count; i++) {
          store.open({ type: 'success', title: 'test', message: 'test' });
        }
        store.closeAll();
        expect(useModalStore.getState().stack.length).toBe(0);
      }),
    );
  });
});
