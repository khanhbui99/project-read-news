import { create } from 'zustand';

interface LoadingStore {
  isVisible: boolean;
  setLoading: (visible: boolean) => void;
}

export const useLoadingStore = create<LoadingStore>((set) => ({
  isVisible: false,
  setLoading: (visible: boolean) => set({ isVisible: visible }),
}));

// Imperative API — callable from anywhere (non-React code, interceptors, services)
export function setLoading(visible: boolean): void {
  useLoadingStore.getState().setLoading(visible);
}
