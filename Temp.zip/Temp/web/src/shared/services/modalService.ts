import { create } from 'zustand';

export type ModalType = 'confirm' | 'success' | 'error' | 'warning' | 'info' | 'custom';

export interface ModalConfig<T = unknown> {
  id: string;
  type: ModalType;
  component?: React.ComponentType<ModalComponentProps<T>>;
  props?: Record<string, unknown>;
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  closable?: boolean;
}

export interface ModalComponentProps<T = unknown> {
  onClose: (result?: T) => void;
  onConfirm: (result?: T) => void;
}

interface ModalEntry extends ModalConfig {
  resolve: (result?: unknown) => void;
}

interface ModalStore {
  stack: ModalEntry[];
  open: <T>(config: Omit<ModalConfig<T>, 'id'>) => Promise<T | undefined>;
  close: (id: string, result?: unknown) => void;
  closeAll: () => void;
}

export const useModalStore = create<ModalStore>((set, get) => ({
  stack: [],

  open: <T>(config: Omit<ModalConfig<T>, 'id'>): Promise<T | undefined> => {
    const id = crypto.randomUUID();
    return new Promise<T | undefined>((resolve) => {
      const entry: ModalEntry = {
        ...config,
        id,
        resolve: resolve as (result?: unknown) => void,
      };
      set((state) => ({ stack: [...state.stack, entry] }));
    });
  },

  close: (id: string, result?: unknown) => {
    const entry = get().stack.find((m) => m.id === id);
    if (entry) {
      entry.resolve(result);
      set((state) => ({ stack: state.stack.filter((m) => m.id !== id) }));
    }
  },

  closeAll: () => {
    get().stack.forEach((entry) => entry.resolve(undefined));
    set({ stack: [] });
  },
}));

// Imperative API
export function openModal<T>(config: Omit<ModalConfig<T>, 'id'>): Promise<T | undefined> {
  return useModalStore.getState().open(config);
}

export function closeAllModals(): void {
  useModalStore.getState().closeAll();
}

// Shorthand helpers
export function showConfirm(title: string, message: string): Promise<boolean | undefined> {
  return openModal<boolean>({ type: 'confirm', title, message, closable: false });
}

export function showSuccess(title: string, message: string): Promise<void> {
  return openModal<void>({ type: 'success', title, message, closable: true });
}

export function showError(title: string, message: string): Promise<void> {
  return openModal<void>({ type: 'error', title, message, closable: false });
}

export function showWarning(title: string, message: string): Promise<boolean | undefined> {
  return openModal<boolean>({ type: 'warning', title, message, closable: false });
}

export function showInfo(title: string, message: string): Promise<void> {
  return openModal<void>({ type: 'info', title, message, closable: true });
}
