import axios, { AxiosInstance, AxiosRequestConfig, AxiosError } from 'axios';
import { env } from '@/shared/config/env';
import { setLoading } from './loadingService';

export interface AppError {
  message: string;
  status?: number;
  code?: string;
  details?: unknown;
}

interface RequestConfig extends AxiosRequestConfig {
  withLoading?: boolean;
}

let authToken: string | null = null;

export function setAuthToken(token: string | null): void {
  authToken = token;
}

export function getAuthToken(): string | null {
  return authToken;
}

const instance: AxiosInstance = axios.create({
  baseURL: env.VITE_API_BASE_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// Request interceptor
instance.interceptors.request.use((config) => {
  if (authToken) {
    config.headers.Authorization = `Bearer ${authToken}`;
  }
  return config;
});

// Response interceptor
instance.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    if (error.response?.status === 401) {
      // TODO: Implement token refresh logic
      setAuthToken(null);
      window.location.href = '/login';
    }
    return Promise.reject(normalizeError(error));
  },
);

function normalizeError(error: AxiosError): AppError {
  if (error.response) {
    return {
      message: (error.response.data as any)?.message || error.message,
      status: error.response.status,
      code: error.code,
      details: error.response.data,
    };
  }
  return {
    message: error.message || 'Network error',
    code: error.code,
  };
}

export const apiClient = {
  async get<T>(url: string, config?: RequestConfig): Promise<T> {
    const { withLoading = false, ...axiosConfig } = config || {};
    if (withLoading) setLoading(true);
    try {
      const res = await instance.get<T>(url, axiosConfig);
      return res.data;
    } finally {
      if (withLoading) setLoading(false);
    }
  },

  async post<T>(url: string, data?: unknown, config?: RequestConfig): Promise<T> {
    const { withLoading = false, ...axiosConfig } = config || {};
    if (withLoading) setLoading(true);
    try {
      const res = await instance.post<T>(url, data, axiosConfig);
      return res.data;
    } finally {
      if (withLoading) setLoading(false);
    }
  },

  async put<T>(url: string, data?: unknown, config?: RequestConfig): Promise<T> {
    const { withLoading = false, ...axiosConfig } = config || {};
    if (withLoading) setLoading(true);
    try {
      const res = await instance.put<T>(url, data, axiosConfig);
      return res.data;
    } finally {
      if (withLoading) setLoading(false);
    }
  },

  async patch<T>(url: string, data?: unknown, config?: RequestConfig): Promise<T> {
    const { withLoading = false, ...axiosConfig } = config || {};
    if (withLoading) setLoading(true);
    try {
      const res = await instance.patch<T>(url, data, axiosConfig);
      return res.data;
    } finally {
      if (withLoading) setLoading(false);
    }
  },

  async delete<T>(url: string, config?: RequestConfig): Promise<T> {
    const { withLoading = false, ...axiosConfig } = config || {};
    if (withLoading) setLoading(true);
    try {
      const res = await instance.delete<T>(url, axiosConfig);
      return res.data;
    } finally {
      if (withLoading) setLoading(false);
    }
  },
};
