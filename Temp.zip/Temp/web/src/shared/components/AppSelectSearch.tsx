import { useState, useRef, useEffect, forwardRef } from 'react';
import styled from 'styled-components';

export interface SelectOption {
  value: string;
  label: string;
}

interface AppSelectSearchProps {
  options: SelectOption[];
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  label?: string;
  error?: string;
  disabled?: boolean;
  fullWidth?: boolean;
  searchable?: boolean;
}

const Wrapper = styled.div<{ $fullWidth: boolean }>`
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: ${({ $fullWidth }) => ($fullWidth ? '100%' : 'auto')};
  position: relative;
`;

const Label = styled.label`
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  color: ${({ theme }) => theme.colors.text};
`;

const SelectTrigger = styled.button<{ $hasError: boolean; $open: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(1.5)}`};
  border: 1px solid ${({ theme, $hasError, $open }) =>
    $hasError ? theme.colors.error : $open ? theme.colors.primary : theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  background: ${({ theme }) => theme.colors.surface};
  color: ${({ theme }) => theme.colors.text};
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  font-family: inherit;
  width: 100%;
  cursor: pointer;
  transition: border-color ${({ theme }) => theme.transitions.fast};

  &:disabled {
    background: ${({ theme }) => theme.colors.surfaceHover};
    cursor: not-allowed;
  }
`;

const Placeholder = styled.span`
  color: ${({ theme }) => theme.colors.textDisabled};
`;

const Dropdown = styled.div`
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 1000;
  margin-top: 4px;
  background: ${({ theme }) => theme.colors.surface};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  box-shadow: ${({ theme }) => theme.shadows.lg};
  max-height: 200px;
  overflow-y: auto;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(1.5)}`};
  border: none;
  border-bottom: 1px solid ${({ theme }) => theme.colors.divider};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  background: transparent;
  color: ${({ theme }) => theme.colors.text};
  outline: none;
`;

const Option = styled.div<{ $selected: boolean }>`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(1.5)}`};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  cursor: pointer;
  background: ${({ theme, $selected }) => ($selected ? theme.colors.primaryLight : 'transparent')};
  color: ${({ theme, $selected }) => ($selected ? theme.colors.primary : theme.colors.text)};

  &:hover {
    background: ${({ theme }) => theme.colors.surfaceHover};
  }
`;

const ErrorText = styled.span`
  font-size: ${({ theme }) => theme.typography.fontSize.xs};
  color: ${({ theme }) => theme.colors.error};
`;

export function AppSelectSearch({
  options,
  value,
  onChange,
  placeholder = 'Select...',
  label,
  error,
  disabled = false,
  fullWidth = true,
  searchable = true,
}: AppSelectSearchProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find((o) => o.value === value);

  const filtered = searchable
    ? options.filter((o) => o.label.toLowerCase().includes(search.toLowerCase()))
    : options;

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <Wrapper $fullWidth={fullWidth} ref={wrapperRef}>
      {label && <Label>{label}</Label>}
      <SelectTrigger
        type="button"
        $hasError={!!error}
        $open={open}
        onClick={() => !disabled && setOpen(!open)}
        disabled={disabled}
      >
        {selectedOption ? selectedOption.label : <Placeholder>{placeholder}</Placeholder>}
        <span>{open ? '▲' : '▼'}</span>
      </SelectTrigger>
      {open && (
        <Dropdown>
          {searchable && (
            <SearchInput
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search..."
              autoFocus
            />
          )}
          {filtered.length === 0 ? (
            <Option $selected={false} style={{ color: 'gray' }}>No results</Option>
          ) : (
            filtered.map((option) => (
              <Option
                key={option.value}
                $selected={option.value === value}
                onClick={() => {
                  onChange?.(option.value);
                  setOpen(false);
                  setSearch('');
                }}
              >
                {option.label}
              </Option>
            ))
          )}
        </Dropdown>
      )}
      {error && <ErrorText>{error}</ErrorText>}
    </Wrapper>
  );
}
