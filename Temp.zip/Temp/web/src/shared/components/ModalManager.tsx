import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import styled from 'styled-components';
import { useModalStore, type ModalType } from '@/shared/services/modalService';
import { ModalConfirm } from './modals/ModalConfirm';
import { ModalSuccess } from './modals/ModalSuccess';
import { ModalError } from './modals/ModalError';
import { ModalWarning } from './modals/ModalWarning';
import { ModalInfo } from './modals/ModalInfo';

const Backdrop = styled.div`
  position: fixed;
  inset: 0;
  z-index: 10000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: ${({ theme }) => theme.colors.overlay};
`;

const modalComponents: Record<ModalType, React.ComponentType<any>> = {
  confirm: ModalConfirm,
  success: ModalSuccess,
  error: ModalError,
  warning: ModalWarning,
  info: ModalInfo,
  custom: () => null,
};

export function ModalManager() {
  const { stack, close, closeAll } = useModalStore();

  // Close all modals on route change
  let location: ReturnType<typeof useLocation> | null = null;
  try {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    location = useLocation();
  } catch {
    // ModalManager might be outside RouterProvider
  }

  useEffect(() => {
    if (stack.length > 0 && location) {
      closeAll();
    }
    // Only trigger on location change, not on stack change
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location?.pathname]);

  if (stack.length === 0) return null;

  return (
    <>
      {stack.map((modal) => {
        const ModalComponent =
          modal.type === 'custom' && modal.component
            ? modal.component
            : modalComponents[modal.type];

        return (
          <Backdrop
            key={modal.id}
            onClick={() => modal.closable !== false && close(modal.id, undefined)}
            role="presentation"
          >
            <div
              role={modal.type === 'confirm' || modal.type === 'warning' ? 'alertdialog' : 'dialog'}
              aria-modal="true"
              aria-labelledby={`modal-title-${modal.id}`}
              onClick={(e) => e.stopPropagation()}
            >
              <ModalComponent
                {...modal.props}
                title={modal.title}
                message={modal.message}
                confirmText={modal.confirmText}
                cancelText={modal.cancelText}
                onConfirm={(result?: unknown) => close(modal.id, result ?? true)}
                onClose={(result?: unknown) => close(modal.id, result ?? undefined)}
              />
            </div>
          </Backdrop>
        );
      })}
    </>
  );
}
