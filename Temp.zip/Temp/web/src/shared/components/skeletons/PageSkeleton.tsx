import styled, { keyframes } from 'styled-components';

const shimmer = keyframes`
  0% { background-position: -200px 0; }
  100% { background-position: calc(200px + 100%) 0; }
`;

const SkeletonBox = styled.div<{ $width?: string; $height?: string }>`
  width: ${({ $width }) => $width || '100%'};
  height: ${({ $height }) => $height || '20px'};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  background: linear-gradient(
    90deg,
    ${({ theme }) => theme.colors.surfaceHover} 25%,
    ${({ theme }) => theme.colors.divider} 50%,
    ${({ theme }) => theme.colors.surfaceHover} 75%
  );
  background-size: 200px 100%;
  animation: ${shimmer} 1.5s infinite;
`;

const Container = styled.div`
  padding: ${({ theme }) => theme.spacing(3)};
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing(2)};
`;

export function PageSkeleton() {
  return (
    <Container>
      <SkeletonBox $width="40%" $height="32px" />
      <SkeletonBox $width="60%" $height="16px" />
      <SkeletonBox $height="200px" />
      <SkeletonBox $width="80%" $height="16px" />
      <SkeletonBox $width="70%" $height="16px" />
    </Container>
  );
}
