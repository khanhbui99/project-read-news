import styled from 'styled-components';

type TextVariant = 'body' | 'caption' | 'label' | 'helper';
type TextColor = 'default' | 'secondary' | 'disabled' | 'error' | 'success';

interface AppTextProps {
  variant?: TextVariant;
  color?: TextColor;
  bold?: boolean;
  as?: keyof JSX.IntrinsicElements;
  children: React.ReactNode;
  className?: string;
}

const colorMap: Record<TextColor, string> = {
  default: 'text',
  secondary: 'textSecondary',
  disabled: 'textDisabled',
  error: 'error',
  success: 'success',
};

const variantMap: Record<TextVariant, { size: string; lineHeight: string }> = {
  body: { size: 'base', lineHeight: '1.6' },
  caption: { size: 'xs', lineHeight: '1.4' },
  label: { size: 'sm', lineHeight: '1.4' },
  helper: { size: 'xs', lineHeight: '1.3' },
};

const StyledText = styled.span<{
  $variant: TextVariant;
  $color: TextColor;
  $bold: boolean;
}>`
  font-size: ${({ theme, $variant }) => theme.typography.fontSize[variantMap[$variant].size]};
  line-height: ${({ $variant }) => variantMap[$variant].lineHeight};
  color: ${({ theme, $color }) => theme.colors[colorMap[$color]]};
  font-weight: ${({ theme, $bold }) =>
    $bold ? theme.typography.fontWeight.semibold : theme.typography.fontWeight.normal};
`;

export function AppText({
  variant = 'body',
  color = 'default',
  bold = false,
  as = 'span',
  children,
  className,
}: AppTextProps) {
  return (
    <StyledText as={as} $variant={variant} $color={color} $bold={bold} className={className}>
      {children}
    </StyledText>
  );
}
