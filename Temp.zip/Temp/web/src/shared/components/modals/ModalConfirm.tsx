import styled from 'styled-components';
import type { ModalComponentProps } from '@/shared/services/modalService';

const Container = styled.div`
  background: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  padding: ${({ theme }) => theme.spacing(4)};
  min-width: 360px;
  max-width: 480px;
  box-shadow: ${({ theme }) => theme.shadows.xl};
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing(1.5)};
  margin-bottom: ${({ theme }) => theme.spacing(1.5)};
`;

const Icon = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.primaryLight};
  color: ${({ theme }) => theme.colors.primary};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
`;

const Title = styled.h3`
  font-size: ${({ theme }) => theme.typography.fontSize.lg};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  color: ${({ theme }) => theme.colors.text};
`;

const Message = styled.p`
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-bottom: ${({ theme }) => theme.spacing(3)};
  line-height: 1.5;
`;

const Actions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: ${({ theme }) => theme.spacing(1.5)};
`;

const Button = styled.button<{ $variant?: 'primary' | 'ghost' }>`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(2.5)}`};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  transition: all ${({ theme }) => theme.transitions.fast};

  ${({ $variant, theme }) =>
    $variant === 'primary'
      ? `
    background: ${theme.colors.primary};
    color: ${theme.colors.textInverse};
    &:hover { background: ${theme.colors.primaryDark}; }
  `
      : `
    background: transparent;
    color: ${theme.colors.textSecondary};
    border: 1px solid ${theme.colors.border};
    &:hover { background: ${theme.colors.surfaceHover}; }
  `}
`;

interface Props extends ModalComponentProps<boolean> {
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
}

export function ModalConfirm({ title, message, confirmText, cancelText, onConfirm, onClose }: Props) {
  return (
    <Container>
      <Header>
        <Icon>?</Icon>
        <Title>{title || 'Confirm'}</Title>
      </Header>
      <Message>{message || 'Are you sure you want to proceed?'}</Message>
      <Actions>
        <Button $variant="ghost" onClick={() => onClose(false)}>
          {cancelText || 'Cancel'}
        </Button>
        <Button $variant="primary" onClick={() => onConfirm(true)}>
          {confirmText || 'Confirm'}
        </Button>
      </Actions>
    </Container>
  );
}
