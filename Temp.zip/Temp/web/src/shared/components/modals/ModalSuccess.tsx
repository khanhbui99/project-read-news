import styled from 'styled-components';
import type { ModalComponentProps } from '@/shared/services/modalService';

const Container = styled.div`
  background: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  padding: ${({ theme }) => theme.spacing(4)};
  min-width: 360px;
  max-width: 480px;
  box-shadow: ${({ theme }) => theme.shadows.xl};
  text-align: center;
`;

const Icon = styled.div`
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.successLight};
  color: ${({ theme }) => theme.colors.success};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  margin: 0 auto ${({ theme }) => theme.spacing(2)};
`;

const Title = styled.h3`
  font-size: ${({ theme }) => theme.typography.fontSize.lg};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: ${({ theme }) => theme.spacing(1)};
`;

const Message = styled.p`
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-bottom: ${({ theme }) => theme.spacing(3)};
`;

const Button = styled.button`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(3)}`};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  background: ${({ theme }) => theme.colors.success};
  color: white;
  transition: all ${({ theme }) => theme.transitions.fast};
  &:hover { opacity: 0.9; }
`;

interface Props extends ModalComponentProps<void> {
  title?: string;
  message?: string;
}

export function ModalSuccess({ title, message, onClose }: Props) {
  return (
    <Container>
      <Icon>✓</Icon>
      <Title>{title || 'Success'}</Title>
      <Message>{message || 'Operation completed successfully.'}</Message>
      <Button onClick={() => onClose()}>OK</Button>
    </Container>
  );
}
