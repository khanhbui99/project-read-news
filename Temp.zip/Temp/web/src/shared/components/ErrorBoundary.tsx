import React from 'react';
import styled from 'styled-components';

const Fallback = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 24px;
  text-align: center;
`;

const Title = styled.h2`
  font-size: 1.25rem;
  margin-bottom: 8px;
  color: ${({ theme }) => theme.colors.text};
`;

const Message = styled.p`
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-bottom: 16px;
`;

const RetryButton = styled.button`
  padding: 8px 20px;
  background: ${({ theme }) => theme.colors.primary};
  color: white;
  border-radius: ${({ theme }) => theme.borderRadius.md};
  font-weight: 500;
  &:hover { opacity: 0.9; }
`;

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  handleRetry = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (this.state.hasError) {
      return (
        <Fallback>
          <Title>Something went wrong</Title>
          <Message>Failed to load this page. Please try again.</Message>
          <RetryButton onClick={this.handleRetry}>Retry</RetryButton>
        </Fallback>
      );
    }
    return this.props.children;
  }
}
