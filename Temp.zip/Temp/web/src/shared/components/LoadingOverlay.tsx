import styled, { keyframes } from 'styled-components';
import { useLoadingStore } from '@/shared/services/loadingService';

const spin = keyframes`
  to { transform: rotate(360deg); }
`;

const Overlay = styled.div`
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
  background: ${({ theme }) => theme.colors.overlay};
  transition: opacity ${({ theme }) => theme.transitions.fast};
`;

const Spinner = styled.div`
  width: 48px;
  height: 48px;
  border: 4px solid ${({ theme }) => theme.colors.surface};
  border-top-color: ${({ theme }) => theme.colors.primary};
  border-radius: 50%;
  animation: ${spin} 0.8s linear infinite;
`;

export function LoadingOverlay() {
  const isVisible = useLoadingStore((s) => s.isVisible);

  if (!isVisible) return null;

  return (
    <Overlay role="status" aria-label="Loading">
      <Spinner />
    </Overlay>
  );
}
