import styled from 'styled-components';

interface ModalActionsProps {
  children: React.ReactNode;
  align?: 'left' | 'right' | 'between';
  border?: boolean;
}

const Container = styled.div<{ $align: string; $border: boolean }>`
  position: sticky;
  bottom: 0;
  display: flex;
  align-items: center;
  gap: ${({ theme }) => theme.spacing(1.5)};
  padding: ${({ theme }) => `${theme.spacing(1.5)} ${theme.spacing(3)}`};
  background: ${({ theme }) => theme.colors.surface};
  border-top: ${({ $border, theme }) => ($border ? `1px solid ${theme.colors.divider}` : 'none')};
  flex-shrink: 0;

  justify-content: ${({ $align }) => {
    switch ($align) {
      case 'left':
        return 'flex-start';
      case 'between':
        return 'space-between';
      default:
        return 'flex-end';
    }
  }};
`;

export function ModalActions({ children, align = 'right', border = true }: ModalActionsProps) {
  return (
    <Container $align={align} $border={border}>
      {children}
    </Container>
  );
}
