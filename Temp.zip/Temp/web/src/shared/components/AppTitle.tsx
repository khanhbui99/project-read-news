import styled from 'styled-components';

type TitleLevel = 1 | 2 | 3 | 4 | 5 | 6;

interface AppTitleProps {
  level?: TitleLevel;
  children: React.ReactNode;
  className?: string;
}

const sizeMap: Record<TitleLevel, string> = {
  1: '4xl',
  2: '3xl',
  3: '2xl',
  4: 'xl',
  5: 'lg',
  6: 'base',
};

const StyledTitle = styled.h1<{ $level: TitleLevel }>`
  font-size: ${({ theme, $level }) => theme.typography.fontSize[sizeMap[$level]]};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
  color: ${({ theme }) => theme.colors.text};
  line-height: 1.3;
  margin: 0;
`;

export function AppTitle({ level = 2, children, className }: AppTitleProps) {
  return (
    <StyledTitle as={`h${level}` as keyof JSX.IntrinsicElements} $level={level} className={className}>
      {children}
    </StyledTitle>
  );
}
