import { useEffect } from 'react';
import styled, { css, keyframes } from 'styled-components';
import { media } from '@/styles/media';

export type DrawerPosition = 'right' | 'left' | 'top' | 'bottom';

interface ModalContainerProps {
  open: boolean;
  onClose: () => void;
  position?: DrawerPosition;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  width?: string;
  closeOnBackdrop?: boolean;
  showCloseButton?: boolean;
}

const slideUp = keyframes`
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
`;

const slideFromRight = keyframes`
  from { transform: translateX(100%); }
  to { transform: translateX(0); }
`;

const slideFromLeft = keyframes`
  from { transform: translateX(-100%); }
  to { transform: translateX(0); }
`;

const Backdrop = styled.div<{ $open: boolean }>`
  position: fixed;
  inset: 0;
  z-index: 10001;
  background: ${({ theme }) => theme.colors.overlay};
  opacity: ${({ $open }) => ($open ? 1 : 0)};
  visibility: ${({ $open }) => ($open ? 'visible' : 'hidden')};
  transition: opacity ${({ theme }) => theme.transitions.normal},
              visibility ${({ theme }) => theme.transitions.normal};
`;

const Panel = styled.div<{ $position: DrawerPosition; $width?: string }>`
  position: fixed;
  z-index: 10002;
  background: ${({ theme }) => theme.colors.surface};
  display: flex;
  flex-direction: column;
  overflow: hidden;
  box-shadow: ${({ theme }) => theme.shadows.xl};

  /* Desktop/Tablet: slide from configured side */
  ${({ $position, $width }) => {
    const minWidth = $width || '50vw';
    switch ($position) {
      case 'left':
        return css`
          top: 0; left: 0; bottom: 0;
          min-width: ${minWidth};
          animation: ${slideFromLeft} 300ms ease forwards;
        `;
      case 'right':
      default:
        return css`
          top: 0; right: 0; bottom: 0;
          min-width: ${minWidth};
          animation: ${slideFromRight} 300ms ease forwards;
        `;
    }
  }}

  /* Mobile: always bottom sheet */
  ${media.down('md')} {
    top: auto;
    bottom: 0;
    left: 0;
    right: 0;
    width: 100vw;
    height: 90vh;
    min-width: unset;
    border-radius: 16px 16px 0 0;
    animation: ${slideUp} 300ms ease forwards;
  }
`;

const DragHandle = styled.div`
  display: none;

  ${media.down('md')} {
    display: flex;
    justify-content: center;
    padding: ${({ theme }) => theme.spacing(1)} 0;

    &::after {
      content: '';
      width: 40px;
      height: 4px;
      border-radius: 2px;
      background: ${({ theme }) => theme.colors.border};
    }
  }
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${({ theme }) => `${theme.spacing(2)} ${theme.spacing(3)}`};
  border-bottom: 1px solid ${({ theme }) => theme.colors.divider};
  flex-shrink: 0;
`;

const HeaderInfo = styled.div``;

const Title = styled.h2`
  font-size: ${({ theme }) => theme.typography.fontSize.xl};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  color: ${({ theme }) => theme.colors.text};
`;

const Subtitle = styled.p`
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-top: 2px;
`;

const CloseButton = styled.button`
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  color: ${({ theme }) => theme.colors.textSecondary};
  transition: all ${({ theme }) => theme.transitions.fast};

  &:hover {
    background: ${({ theme }) => theme.colors.surfaceHover};
    color: ${({ theme }) => theme.colors.text};
  }
`;

const Content = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: ${({ theme }) => theme.spacing(3)};
`;

export function ModalContainer({
  open,
  onClose,
  position = 'right',
  title,
  subtitle,
  children,
  actions,
  width,
  closeOnBackdrop = true,
  showCloseButton = true,
}: ModalContainerProps) {
  // Lock body scroll when open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  // Escape key to close
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <>
      <Backdrop $open={open} onClick={closeOnBackdrop ? onClose : undefined} />
      <Panel
        $position={position}
        $width={width}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-container-title"
      >
        <DragHandle />
        <Header>
          <HeaderInfo>
            {title && <Title id="modal-container-title">{title}</Title>}
            {subtitle && <Subtitle>{subtitle}</Subtitle>}
          </HeaderInfo>
          {showCloseButton && <CloseButton onClick={onClose}>✕</CloseButton>}
        </Header>
        <Content>{children}</Content>
        {actions}
      </Panel>
    </>
  );
}
