import React, { Suspense } from 'react';
import { ErrorBoundary } from '@/shared/components/ErrorBoundary';

export interface LazyRouteOptions {
  factory: () => Promise<{ default: React.ComponentType }>;
  skeleton: React.ComponentType;
}

const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

async function loadWithRetry(
  factory: () => Promise<{ default: React.ComponentType }>,
  retries: number = MAX_RETRIES,
): Promise<{ default: React.ComponentType }> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await factory();
    } catch (error) {
      if (attempt === retries) throw error;
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS * (attempt + 1)));
    }
  }
  throw new Error('Failed to load module');
}

export function createLazyRoute({ factory, skeleton: Skeleton }: LazyRouteOptions): React.ReactNode {
  const LazyComponent = React.lazy(() => loadWithRetry(factory));

  return (
    <ErrorBoundary>
      <Suspense fallback={<Skeleton />}>
        <LazyComponent />
      </Suspense>
    </ErrorBoundary>
  );
}
