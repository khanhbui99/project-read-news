import { describe, it, expect } from 'vitest';

// Testing the pure resolveTheme logic (same as in the context implementation)
type ThemeMode = 'light' | 'dark' | 'system';

function resolveTheme(mode: ThemeMode, systemPrefersDark: boolean): 'light' | 'dark' {
  if (mode === 'light') return 'light';
  if (mode === 'dark') return 'dark';
  return systemPrefersDark ? 'dark' : 'light';
}

describe('Theme Context - resolveTheme', () => {
  it('should return "light" when mode is "light"', () => {
    expect(resolveTheme('light', false)).toBe('light');
    expect(resolveTheme('light', true)).toBe('light');
  });

  it('should return "dark" when mode is "dark"', () => {
    expect(resolveTheme('dark', false)).toBe('dark');
    expect(resolveTheme('dark', true)).toBe('dark');
  });

  it('should follow system preference when mode is "system"', () => {
    expect(resolveTheme('system', false)).toBe('light');
    expect(resolveTheme('system', true)).toBe('dark');
  });

  it('should never return anything other than "light" or "dark"', () => {
    const modes: ThemeMode[] = ['light', 'dark', 'system'];
    const bools = [true, false];

    for (const mode of modes) {
      for (const pref of bools) {
        const result = resolveTheme(mode, pref);
        expect(['light', 'dark']).toContain(result);
      }
    }
  });
});
