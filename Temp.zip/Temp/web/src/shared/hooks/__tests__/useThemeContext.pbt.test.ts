import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';

type ThemeMode = 'light' | 'dark' | 'system';

// Pure function extracted for testing (mirrors implementation logic)
function resolveTheme(mode: ThemeMode, systemPrefersDark: boolean): 'light' | 'dark' {
  if (mode === 'light') return 'light';
  if (mode === 'dark') return 'dark';
  return systemPrefersDark ? 'dark' : 'light';
}

describe('Theme Context - Property Based Tests', () => {
  it('Property: resolveTheme always returns "light" or "dark" for any valid mode', () => {
    fc.assert(
      fc.property(
        fc.constantFrom<ThemeMode>('light', 'dark', 'system'),
        fc.boolean(),
        (mode, systemPrefersDark) => {
          const result = resolveTheme(mode, systemPrefersDark);
          expect(['light', 'dark']).toContain(result);
        },
      ),
    );
  });

  it('Property: "light" mode always resolves to "light" regardless of system preference', () => {
    fc.assert(
      fc.property(fc.boolean(), (systemPrefersDark) => {
        expect(resolveTheme('light', systemPrefersDark)).toBe('light');
      }),
    );
  });

  it('Property: "dark" mode always resolves to "dark" regardless of system preference', () => {
    fc.assert(
      fc.property(fc.boolean(), (systemPrefersDark) => {
        expect(resolveTheme('dark', systemPrefersDark)).toBe('dark');
      }),
    );
  });

  it('Property: "system" mode follows system preference exactly', () => {
    fc.assert(
      fc.property(fc.boolean(), (systemPrefersDark) => {
        const result = resolveTheme('system', systemPrefersDark);
        expect(result).toBe(systemPrefersDark ? 'dark' : 'light');
      }),
    );
  });
});
