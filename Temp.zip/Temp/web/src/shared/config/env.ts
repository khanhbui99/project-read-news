import { z } from 'zod';

const envSchema = z.object({
  VITE_APP_TITLE: z.string().min(1),
  VITE_APP_ENV: z.enum(['development', 'staging', 'production']),
  VITE_API_BASE_URL: z.string().url(),
});

type Env = z.infer<typeof envSchema>;

function validateEnv(): Env {
  const result = envSchema.safeParse({
    VITE_APP_TITLE: import.meta.env.VITE_APP_TITLE,
    VITE_APP_ENV: import.meta.env.VITE_APP_ENV,
    VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
  });

  if (!result.success) {
    console.error('❌ Invalid environment variables:', result.error.flatten().fieldErrors);
    throw new Error('Invalid environment variables. Check .env file.');
  }

  return result.data;
}

export const env = validateEnv();

export const isDev = env.VITE_APP_ENV === 'development';
export const isStaging = env.VITE_APP_ENV === 'staging';
export const isProd = env.VITE_APP_ENV === 'production';
