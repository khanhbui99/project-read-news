import { createBrowserRouter, type RouteObject } from 'react-router-dom';
import { createLazyRoute } from '@/shared/utils/createLazyRoute';
import { EndUserLayout } from '@/layouts/EndUserLayout';
import { AdminLayout } from '@/layouts/AdminLayout';
import { PageSkeleton } from '@/shared/components/skeletons/PageSkeleton';

/**
 * AppRouter — Nơi quản lý tập trung toàn bộ pages/routes của ứng dụng.
 *
 * Quy tắc:
 * - Mỗi module export routes của mình tại `modules/{name}/routes.ts`
 * - Import và đăng ký tại đây theo layout tương ứng
 * - Mọi route đều phải lazy load + skeleton
 */

// ===================== END USER ROUTES =====================
const endUserRoutes: RouteObject[] = [
  {
    path: '/',
    element: createLazyRoute({
      factory: () => import('@/modules/examples/pages/ExampleShowcasePage'),
      skeleton: PageSkeleton,
    }),
  },
  {
    path: '/examples/showcase',
    element: createLazyRoute({
      factory: () => import('@/modules/examples/pages/ExampleShowcasePage'),
      skeleton: PageSkeleton,
    }),
  },
];

// ===================== ADMIN ROUTES =====================
const adminRoutes: RouteObject[] = [
  {
    path: '/admin',
    element: createLazyRoute({
      factory: () => import('@/modules/examples/pages/ExampleCRUDPage'),
      skeleton: PageSkeleton,
    }),
  },
  {
    path: '/admin/crud',
    element: createLazyRoute({
      factory: () => import('@/modules/examples/pages/ExampleCRUDPage'),
      skeleton: PageSkeleton,
    }),
  },
];

// ===================== ROUTER DEFINITION =====================
export const router = createBrowserRouter([
  {
    element: <EndUserLayout />,
    children: endUserRoutes,
  },
  {
    element: <AdminLayout />,
    children: adminRoutes,
  },
  {
    // 404 catch-all (no layout wrapper — fullscreen page)
    path: '*',
    lazy: () => import('@/modules/common/pages/NotFoundPage').then((m) => ({ Component: m.default })),
  },
]);
