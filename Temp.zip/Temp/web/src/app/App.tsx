import { RouterProvider } from 'react-router-dom';
import { router } from './AppRouter';

export default function App() {
  return <RouterProvider router={router} />;
}
