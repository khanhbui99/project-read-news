import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { I18nextProvider } from 'react-i18next';
import { ThemeContextProvider } from '@/shared/hooks/useThemeContext';
import { ModalManager } from '@/shared/components/ModalManager';
import { LoadingOverlay } from '@/shared/components/LoadingOverlay';
import i18n from '@/shared/i18n';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 1,
    },
  },
});

interface AppProvidersProps {
  children: React.ReactNode;
}

export function AppProviders({ children }: AppProvidersProps) {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <ThemeContextProvider>
          {children}
          <ModalManager />
          <LoadingOverlay />
        </ThemeContextProvider>
      </I18nextProvider>
    </QueryClientProvider>
  );
}
