import { createBrowserRouter } from 'react-router-dom';
import { createLazyRoute } from '@/shared/utils/createLazyRoute';
import { EndUserLayout } from '@/layouts/EndUserLayout';
import { AdminLayout } from '@/layouts/AdminLayout';
import { PageSkeleton } from '@/shared/components/skeletons/PageSkeleton';

export const router = createBrowserRouter([
  {
    element: <EndUserLayout />,
    children: [
      {
        path: '/',
        element: createLazyRoute({
          factory: () => import('@/modules/examples/pages/ExampleShowcasePage'),
          skeleton: PageSkeleton,
        }),
      },
    ],
  },
  {
    element: <AdminLayout />,
    children: [
      {
        path: '/admin',
        element: createLazyRoute({
          factory: () => import('@/modules/examples/pages/ExampleCRUDPage'),
          skeleton: PageSkeleton,
        }),
      },
    ],
  },
  {
    element: <EndUserLayout />,
    children: [
      {
        path: '/examples/showcase',
        element: createLazyRoute({
          factory: () => import('@/modules/examples/pages/ExampleShowcasePage'),
          skeleton: PageSkeleton,
        }),
      },
    ],
  },
]);
