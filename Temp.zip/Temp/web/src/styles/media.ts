export const BREAKPOINTS = {
  xs: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1400,
} as const;

export type BreakpointKey = keyof typeof BREAKPOINTS;

export const media = {
  up: (breakpoint: BreakpointKey): string => {
    const value = BREAKPOINTS[breakpoint];
    return `@media (min-width: ${value}px)`;
  },
  down: (breakpoint: BreakpointKey): string => {
    const value = BREAKPOINTS[breakpoint] - 0.02;
    return `@media (max-width: ${value}px)`;
  },
  between: (min: BreakpointKey, max: BreakpointKey): string => {
    return `@media (min-width: ${BREAKPOINTS[min]}px) and (max-width: ${BREAKPOINTS[max] - 0.02}px)`;
  },
};
