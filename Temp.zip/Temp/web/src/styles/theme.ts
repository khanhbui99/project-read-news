export interface Theme {
  colors: {
    primary: string;
    primaryLight: string;
    primaryDark: string;
    secondary: string;
    secondaryLight: string;
    secondaryDark: string;
    background: string;
    surface: string;
    surfaceHover: string;
    overlay: string;
    text: string;
    textSecondary: string;
    textDisabled: string;
    textInverse: string;
    border: string;
    borderHover: string;
    divider: string;
    error: string;
    errorLight: string;
    warning: string;
    warningLight: string;
    success: string;
    successLight: string;
    info: string;
    infoLight: string;
  };
  breakpoints: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    xxl: string;
  };
  spacing: (factor: number) => string;
  typography: {
    fontFamily: string;
    fontSize: Record<string, string>;
    fontWeight: Record<string, number>;
  };
  shadows: Record<string, string>;
  borderRadius: Record<string, string>;
  transitions: Record<string, string>;
}

const baseTheme = {
  breakpoints: {
    xs: '0px',
    sm: '576px',
    md: '768px',
    lg: '992px',
    xl: '1200px',
    xxl: '1400px',
  },
  spacing: (factor: number) => `${factor * 8}px`,
  typography: {
    fontFamily:
      "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      '2xl': '1.5rem',
      '3xl': '1.875rem',
      '4xl': '2.25rem',
    },
    fontWeight: {
      light: 300,
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
    },
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
  },
  borderRadius: {
    sm: '4px',
    md: '8px',
    lg: '12px',
    xl: '16px',
    full: '9999px',
  },
  transitions: {
    fast: '150ms ease',
    normal: '300ms ease',
    slow: '500ms ease',
  },
};

export const lightTheme: Theme = {
  ...baseTheme,
  colors: {
    primary: '#0077B6',         // Xanh nước biển - màu chủ đạo THCS Cầu Giấy
    primaryLight: '#E8F4FD',    // Very light ocean blue tint
    primaryDark: '#005F8C',     // Deeper ocean blue for active
    secondary: '#00B4D8',       // Cyan/turquoise accent
    secondaryLight: '#E6F9FC',  // Very light cyan tint
    secondaryDark: '#0096B4',   // Deeper cyan
    background: '#FAFAF9',
    surface: '#FFFFFF',
    surfaceHover: '#F5F5F4',
    overlay: 'rgba(0, 0, 0, 0.4)',
    text: '#1C1917',
    textSecondary: '#78716C',
    textDisabled: '#A8A29E',
    textInverse: '#FAFAF9',
    border: '#E7E5E4',
    borderHover: '#D6D3D1',
    divider: '#F5F5F4',
    error: '#EF4444',
    errorLight: '#FEF2F2',
    warning: '#F59E0B',
    warningLight: '#FFFBEB',
    success: '#10B981',
    successLight: '#ECFDF5',
    info: '#3B82F6',
    infoLight: '#EFF6FF',
  },
};

export const darkTheme: Theme = {
  ...baseTheme,
  colors: {
    primary: '#90E0EF',         // Lighter ocean blue for dark bg
    primaryLight: '#023E58',    // Deep blue tint
    primaryDark: '#0077B6',     // Standard ocean blue
    secondary: '#48CAE4',       // Brighter cyan for dark bg
    secondaryLight: '#012A3F',  // Deep cyan tint
    secondaryDark: '#00B4D8',
    background: '#0F172A',
    surface: '#1E293B',
    surfaceHover: '#334155',
    overlay: 'rgba(0, 0, 0, 0.6)',
    text: '#F8FAFC',
    textSecondary: '#94A3B8',
    textDisabled: '#475569',
    textInverse: '#0F172A',
    border: '#334155',
    borderHover: '#475569',
    divider: '#1E293B',
    error: '#F87171',
    errorLight: '#450A0A',
    warning: '#FBBF24',
    warningLight: '#451A03',
    success: '#34D399',
    successLight: '#022C22',
    info: '#60A5FA',
    infoLight: '#172554',
  },
};
