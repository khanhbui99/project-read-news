import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';
import { media, BREAKPOINTS, type BreakpointKey } from '../media';

const breakpointKeys: BreakpointKey[] = ['xs', 'sm', 'md', 'lg', 'xl', 'xxl'];

describe('Media Helpers - Property Based Tests', () => {
  it('Property: media.up() always produces valid @media (min-width: Xpx) format', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...breakpointKeys),
        (bp) => {
          const result = media.up(bp);
          expect(result).toMatch(/^@media \(min-width: \d+(\.\d+)?px\)$/);
        },
      ),
    );
  });

  it('Property: media.down() always produces valid @media (max-width: Xpx) format', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...breakpointKeys),
        (bp) => {
          const result = media.down(bp);
          expect(result).toMatch(/^@media \(max-width: -?\d+(\.\d+)?px\)$/);
        },
      ),
    );
  });

  it('Property: breakpoints are strictly ascending', () => {
    for (let i = 0; i < breakpointKeys.length - 1; i++) {
      expect(BREAKPOINTS[breakpointKeys[i]]).toBeLessThan(BREAKPOINTS[breakpointKeys[i + 1]]);
    }
  });

  it('Property: media.up(bp) value matches BREAKPOINTS[bp]', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...breakpointKeys),
        (bp) => {
          const result = media.up(bp);
          expect(result).toContain(`${BREAKPOINTS[bp]}px`);
        },
      ),
    );
  });
});
