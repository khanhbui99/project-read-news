import { describe, it, expect } from 'vitest';
import { media, BREAKPOINTS } from '../media';

describe('Media Helpers', () => {
  it('media.up("sm") should return correct min-width query', () => {
    expect(media.up('sm')).toBe('@media (min-width: 576px)');
  });

  it('media.up("md") should return correct min-width query', () => {
    expect(media.up('md')).toBe('@media (min-width: 768px)');
  });

  it('media.up("xs") should return @media (min-width: 0px)', () => {
    expect(media.up('xs')).toBe('@media (min-width: 0px)');
  });

  it('media.down("md") should return max-width just below md', () => {
    expect(media.down('md')).toBe('@media (max-width: 767.98px)');
  });

  it('media.between("sm", "lg") should return combined query', () => {
    expect(media.between('sm', 'lg')).toBe(
      '@media (min-width: 576px) and (max-width: 991.98px)',
    );
  });

  it('breakpoints should be in ascending order', () => {
    const keys = Object.keys(BREAKPOINTS) as (keyof typeof BREAKPOINTS)[];
    for (let i = 0; i < keys.length - 1; i++) {
      expect(BREAKPOINTS[keys[i]]).toBeLessThan(BREAKPOINTS[keys[i + 1]]);
    }
  });
});
