import { Outlet } from 'react-router-dom';
import styled from 'styled-components';
import { media } from '@/styles/media';

const Layout = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`;

const Header = styled.header`
  height: 64px;
  display: flex;
  align-items: center;
  padding: 0 ${({ theme }) => theme.spacing(3)};
  background: ${({ theme }) => theme.colors.surface};
  border-bottom: 1px solid ${({ theme }) => theme.colors.divider};
  position: sticky;
  top: 0;
  z-index: 100;

  ${media.up('lg')} {
    padding: 0 ${({ theme }) => theme.spacing(6)};
  }
`;

const Logo = styled.div`
  font-size: ${({ theme }) => theme.typography.fontSize.xl};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
  color: ${({ theme }) => theme.colors.primary};
`;

const Main = styled.main`
  flex: 1;
  padding: ${({ theme }) => theme.spacing(3)};

  ${media.up('lg')} {
    padding: ${({ theme }) => theme.spacing(4)};
    max-width: 1200px;
    margin: 0 auto;
    width: 100%;
  }
`;

const Footer = styled.footer`
  padding: ${({ theme }) => `${theme.spacing(3)} ${theme.spacing(3)}`};
  text-align: center;
  color: ${({ theme }) => theme.colors.textSecondary};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  border-top: 1px solid ${({ theme }) => theme.colors.divider};
`;

export function EndUserLayout() {
  return (
    <Layout>
      <Header>
        <Logo>Template</Logo>
      </Header>
      <Main>
        <Outlet />
      </Main>
      <Footer>© 2024 React Parent Template</Footer>
    </Layout>
  );
}
