import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import styled from 'styled-components';
import { media } from '@/styles/media';

const Layout = styled.div`
  display: flex;
  min-height: 100vh;
`;

const Sidebar = styled.aside<{ $collapsed: boolean }>`
  width: 260px;
  background: ${({ theme }) => theme.colors.surface};
  border-right: 1px solid ${({ theme }) => theme.colors.divider};
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  transition: transform ${({ theme }) => theme.transitions.normal};

  ${media.down('md')} {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    z-index: 200;
    transform: ${({ $collapsed }) => ($collapsed ? 'translateX(-100%)' : 'translateX(0)')};
  }
`;

const SidebarHeader = styled.div`
  height: 64px;
  display: flex;
  align-items: center;
  padding: 0 ${({ theme }) => theme.spacing(2.5)};
  font-size: ${({ theme }) => theme.typography.fontSize.lg};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
  color: ${({ theme }) => theme.colors.primary};
  border-bottom: 1px solid ${({ theme }) => theme.colors.divider};
`;

const SidebarNav = styled.nav`
  flex: 1;
  padding: ${({ theme }) => theme.spacing(2)};
`;

const NavItem = styled.a`
  display: block;
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(2)}`};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  color: ${({ theme }) => theme.colors.textSecondary};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  transition: all ${({ theme }) => theme.transitions.fast};

  &:hover {
    background: ${({ theme }) => theme.colors.surfaceHover};
    color: ${({ theme }) => theme.colors.text};
  }
`;

const MainArea = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
`;

const TopBar = styled.header`
  height: 64px;
  display: flex;
  align-items: center;
  padding: 0 ${({ theme }) => theme.spacing(3)};
  background: ${({ theme }) => theme.colors.surface};
  border-bottom: 1px solid ${({ theme }) => theme.colors.divider};
`;

const MenuButton = styled.button`
  display: none;
  width: 36px;
  height: 36px;
  align-items: center;
  justify-content: center;
  border-radius: ${({ theme }) => theme.borderRadius.md};
  color: ${({ theme }) => theme.colors.text};
  font-size: 20px;

  ${media.down('md')} {
    display: flex;
  }

  &:hover {
    background: ${({ theme }) => theme.colors.surfaceHover};
  }
`;

const Content = styled.main`
  flex: 1;
  padding: ${({ theme }) => theme.spacing(3)};

  ${media.up('lg')} {
    padding: ${({ theme }) => theme.spacing(4)};
  }
`;

const Overlay = styled.div<{ $visible: boolean }>`
  display: none;

  ${media.down('md')} {
    display: ${({ $visible }) => ($visible ? 'block' : 'none')};
    position: fixed;
    inset: 0;
    z-index: 199;
    background: ${({ theme }) => theme.colors.overlay};
  }
`;

export function AdminLayout() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(true);

  return (
    <Layout>
      <Overlay $visible={!sidebarCollapsed} onClick={() => setSidebarCollapsed(true)} />
      <Sidebar $collapsed={sidebarCollapsed}>
        <SidebarHeader>Admin</SidebarHeader>
        <SidebarNav>
          <NavItem href="/admin">Dashboard</NavItem>
          <NavItem href="/examples/showcase">Showcase</NavItem>
        </SidebarNav>
      </Sidebar>
      <MainArea>
        <TopBar>
          <MenuButton onClick={() => setSidebarCollapsed(!sidebarCollapsed)}>☰</MenuButton>
        </TopBar>
        <Content>
          <Outlet />
        </Content>
      </MainArea>
    </Layout>
  );
}
