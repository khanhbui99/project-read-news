import styled from 'styled-components';
import { media } from '@/styles/media';

/**
 * Module Styles — Nơi quản lý tập trung styles cho module example.
 *
 * Quy tắc:
 * - Đặt tất cả styled-components dùng chung trong module tại đây
 * - Import từ file này thay vì define inline trong component
 * - Giúp AI và team nhất quán về styling trong module
 */

export const ModuleContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing(3)};
  padding: ${({ theme }) => theme.spacing(2)};

  ${media.up('md')} {
    padding: ${({ theme }) => theme.spacing(3)};
  }
`;

export const ModuleHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: ${({ theme }) => theme.spacing(2)};
`;

export const ModuleTitle = styled.h1`
  font-size: ${({ theme }) => theme.typography.fontSize['2xl']};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
  color: ${({ theme }) => theme.colors.text};
`;

export const ModuleCard = styled.div`
  background: ${({ theme }) => theme.colors.surface};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  padding: ${({ theme }) => theme.spacing(3)};
`;

export const ModuleGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: ${({ theme }) => theme.spacing(2)};

  ${media.up('md')} {
    grid-template-columns: repeat(2, 1fr);
  }

  ${media.up('lg')} {
    grid-template-columns: repeat(3, 1fr);
  }
`;
