import { create } from 'zustand';

export interface ExampleItem {
  id: string;
  name: string;
  description: string;
  createdAt: string;
}

interface ExampleState {
  items: ExampleItem[];
  addItem: (item: ExampleItem) => void;
  removeItem: (id: string) => void;
  updateItem: (id: string, updates: Partial<ExampleItem>) => void;
  clearAll: () => void;
}

export const useExampleStore = create<ExampleState>((set) => ({
  items: [],
  addItem: (item) => set((state) => ({ items: [...state.items, item] })),
  removeItem: (id) => set((state) => ({ items: state.items.filter((i) => i.id !== id) })),
  updateItem: (id, updates) =>
    set((state) => ({
      items: state.items.map((i) => (i.id === id ? { ...i, ...updates } : i)),
    })),
  clearAll: () => set({ items: [] }),
}));
