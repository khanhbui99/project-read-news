import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { exampleService } from '../services/exampleService';
import type { ExampleItem } from '../stores/exampleStore';

const QUERY_KEY = ['examples'];

export function useExampleList() {
  return useQuery({
    queryKey: QUERY_KEY,
    queryFn: exampleService.getAll,
  });
}

export function useExampleById(id: string) {
  return useQuery({
    queryKey: [...QUERY_KEY, id],
    queryFn: () => exampleService.getById(id),
    enabled: !!id,
  });
}

export function useCreateExample() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: exampleService.create,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEY }),
  });
}

export function useDeleteExample() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: exampleService.delete,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEY }),
  });
}

export function useUpdateExample() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<ExampleItem> }) =>
      exampleService.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: QUERY_KEY }),
  });
}
