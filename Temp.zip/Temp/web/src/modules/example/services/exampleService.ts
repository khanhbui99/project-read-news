import { apiClient } from '@/shared/services/apiClient';
import type { ExampleItem } from '../stores/exampleStore';

export const exampleService = {
  getAll: () => apiClient.get<ExampleItem[]>('/examples'),
  getById: (id: string) => apiClient.get<ExampleItem>(`/examples/${id}`),
  create: (data: Omit<ExampleItem, 'id' | 'createdAt'>) =>
    apiClient.post<ExampleItem>('/examples', data),
  update: (id: string, data: Partial<ExampleItem>) =>
    apiClient.put<ExampleItem>(`/examples/${id}`, data),
  delete: (id: string) => apiClient.delete<void>(`/examples/${id}`),
};
