import styled, { keyframes } from 'styled-components';
import { media } from '@/styles/media';

/**
 * Module Styles — Common
 * Nơi quản lý tập trung styles cho module common (error pages, shared pages).
 */

// ===================== KEYFRAMES =====================

export const float = keyframes`
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  25% { transform: translateY(-15px) rotate(2deg); }
  50% { transform: translateY(-5px) rotate(-1deg); }
  75% { transform: translateY(-20px) rotate(1deg); }
`;

export const pulse = keyframes`
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
`;

export const drift = keyframes`
  0% { transform: translateX(0) translateY(0); }
  33% { transform: translateX(30px) translateY(-20px); }
  66% { transform: translateX(-20px) translateY(10px); }
  100% { transform: translateX(0) translateY(0); }
`;

export const shake = keyframes`
  0%, 100% { transform: translateX(0); }
  10% { transform: translateX(-5px) rotate(-1deg); }
  20% { transform: translateX(5px) rotate(1deg); }
  30% { transform: translateX(-3px); }
  40% { transform: translateX(3px); }
  50% { transform: translateX(0); }
`;

export const glitch = keyframes`
  0%, 100% { text-shadow: 2px 0 #EF4444, -2px 0 #3B82F6; }
  25% { text-shadow: -2px 0 #EF4444, 2px 0 #3B82F6; }
  50% { text-shadow: 2px 2px #EF4444, -2px -2px #3B82F6; }
  75% { text-shadow: -2px 2px #EF4444, 2px -2px #3B82F6; }
`;

export const flicker = keyframes`
  0%, 100% { opacity: 1; }
  41% { opacity: 1; }
  42% { opacity: 0.8; }
  43% { opacity: 1; }
  45% { opacity: 0.3; }
  46% { opacity: 1; }
  50% { opacity: 1; }
  51% { opacity: 0.6; }
  52% { opacity: 1; }
`;

export const rotate = keyframes`
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
`;

// ===================== SHARED LAYOUT =====================

export const FullPageContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: ${({ theme }) => theme.spacing(4)};
  background: ${({ theme }) => theme.colors.background};
  position: relative;
  overflow: hidden;
`;

export const PageTitle = styled.h1`
  font-size: ${({ theme }) => theme.typography.fontSize['2xl']};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
  color: ${({ theme }) => theme.colors.text};
  margin-top: ${({ theme }) => theme.spacing(2)};
  text-align: center;
  position: relative;
  z-index: 1;

  ${media.up('md')} {
    font-size: ${({ theme }) => theme.typography.fontSize['3xl']};
  }
`;

export const PageDescription = styled.p`
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-top: ${({ theme }) => theme.spacing(1)};
  text-align: center;
  max-width: 440px;
  line-height: 1.6;
  position: relative;
  z-index: 1;
`;

export const PageButtonGroup = styled.div`
  display: flex;
  gap: ${({ theme }) => theme.spacing(2)};
  margin-top: ${({ theme }) => theme.spacing(4)};
  position: relative;
  z-index: 1;
  flex-wrap: wrap;
  justify-content: center;
`;

export const PageIllustration = styled.div`
  font-size: 4rem;
  margin-bottom: ${({ theme }) => theme.spacing(2)};
`;

export const ErrorCode = styled.div`
  font-size: 8rem;
  font-weight: 900;
  position: relative;
  z-index: 1;

  ${media.down('sm')} {
    font-size: 5rem;
  }
`;

// ===================== BUTTONS =====================

export const PrimaryPageButton = styled.button`
  padding: ${({ theme }) => `${theme.spacing(1.5)} ${theme.spacing(4)}`};
  background: ${({ theme }) => theme.colors.primary};
  color: white;
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  transition: all ${({ theme }) => theme.transitions.fast};
  box-shadow: 0 4px 14px ${({ theme }) => theme.colors.primaryLight};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px ${({ theme }) => theme.colors.primaryLight};
  }
`;

export const GhostPageButton = styled.button`
  padding: ${({ theme }) => `${theme.spacing(1.5)} ${theme.spacing(4)}`};
  background: transparent;
  color: ${({ theme }) => theme.colors.textSecondary};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  transition: all ${({ theme }) => theme.transitions.fast};

  &:hover {
    border-color: ${({ theme }) => theme.colors.primary};
    color: ${({ theme }) => theme.colors.primary};
  }
`;

export const DangerPageButton = styled.button`
  padding: ${({ theme }) => `${theme.spacing(1.5)} ${theme.spacing(4)}`};
  background: ${({ theme }) => theme.colors.error};
  color: white;
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  font-size: ${({ theme }) => theme.typography.fontSize.base};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  transition: all ${({ theme }) => theme.transitions.fast};
  box-shadow: 0 4px 14px ${({ theme }) => theme.colors.errorLight};

  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px ${({ theme }) => theme.colors.errorLight};
  }
`;

// ===================== 404 SPECIFIC =====================

export const Particle = styled.div<{ $delay: number; $size: number; $x: number; $y: number }>`
  position: absolute;
  width: ${({ $size }) => $size}px;
  height: ${({ $size }) => $size}px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.primaryLight};
  opacity: 0.6;
  top: ${({ $y }) => $y}%;
  left: ${({ $x }) => $x}%;
  animation: ${drift} ${({ $delay }) => 8 + $delay}s ease-in-out infinite;
  animation-delay: ${({ $delay }) => $delay}s;
`;

export const Dots = styled.div`
  display: flex;
  gap: 8px;
  margin-top: ${({ theme }) => theme.spacing(6)};
  position: relative;
  z-index: 1;
`;

export const Dot = styled.div<{ $delay: number }>`
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.primary};
  animation: ${pulse} 2s ease-in-out infinite;
  animation-delay: ${({ $delay }) => $delay}s;
`;

// ===================== 500 SPECIFIC =====================

export const GlowOrb = styled.div`
  position: absolute;
  width: 300px;
  height: 300px;
  border-radius: 50%;
  background: radial-gradient(
    circle,
    ${({ theme }) => theme.colors.errorLight} 0%,
    transparent 70%
  );
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  opacity: 0.6;
  animation: ${flicker} 4s ease-in-out infinite;
`;

export const GearIcon = styled.div`
  position: absolute;
  font-size: 6rem;
  opacity: 0.08;
  animation: ${rotate} 20s linear infinite;

  &:nth-child(1) { top: 10%; right: 10%; }
  &:nth-child(2) { bottom: 15%; left: 8%; animation-direction: reverse; font-size: 4rem; }
  &:nth-child(3) { top: 60%; right: 5%; font-size: 3rem; }
`;

export const StatusBar = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: ${({ theme }) => theme.spacing(5)};
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(2)}`};
  background: ${({ theme }) => theme.colors.errorLight};
  border-radius: ${({ theme }) => theme.borderRadius.full};
  position: relative;
  z-index: 1;
`;

export const StatusDot = styled.div`
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.error};
  animation: ${flicker} 2s ease-in-out infinite;
`;

export const StatusText = styled.span`
  font-size: ${({ theme }) => theme.typography.fontSize.xs};
  color: ${({ theme }) => theme.colors.error};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
`;
