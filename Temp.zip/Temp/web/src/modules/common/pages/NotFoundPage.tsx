import { useNavigate } from 'react-router-dom';
import {
  FullPageContainer,
  PageTitle,
  PageDescription,
  PageButtonGroup,
  PageIllustration,
  ErrorCode,
  PrimaryPageButton,
  GhostPageButton,
  Particle,
  Dots,
  Dot,
  float,
} from '../styles';
import styled from 'styled-components';

const FloatingCode = styled(ErrorCode)`
  color: ${({ theme }) => theme.colors.primary};
  animation: ${float} 6s ease-in-out infinite;
  text-shadow: 0 20px 40px ${({ theme }) => theme.colors.primaryLight};
`;

const FloatingIllustration = styled(PageIllustration)`
  animation: ${float} 4s ease-in-out infinite;
  animation-delay: 0.5s;
`;

const particles = [
  { delay: 0, size: 60, x: 10, y: 20 },
  { delay: 2, size: 40, x: 80, y: 15 },
  { delay: 4, size: 80, x: 70, y: 70 },
  { delay: 1, size: 50, x: 20, y: 75 },
  { delay: 3, size: 30, x: 90, y: 50 },
  { delay: 5, size: 45, x: 5, y: 50 },
];

export default function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <FullPageContainer>
      {particles.map((p, i) => (
        <Particle key={i} $delay={p.delay} $size={p.size} $x={p.x} $y={p.y} />
      ))}
      <FloatingIllustration>🧭</FloatingIllustration>
      <FloatingCode>404</FloatingCode>
      <PageTitle>Page not found</PageTitle>
      <PageDescription>
        The page you're looking for doesn't exist or has been moved. Let's get you back on track.
      </PageDescription>
      <PageButtonGroup>
        <PrimaryPageButton onClick={() => navigate('/')}>Go Home</PrimaryPageButton>
        <GhostPageButton onClick={() => navigate(-1)}>Go Back</GhostPageButton>
      </PageButtonGroup>
      <Dots>
        <Dot $delay={0} />
        <Dot $delay={0.3} />
        <Dot $delay={0.6} />
      </Dots>
    </FullPageContainer>
  );
}
