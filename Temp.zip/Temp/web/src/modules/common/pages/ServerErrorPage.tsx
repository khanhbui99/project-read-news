import { useNavigate } from 'react-router-dom';
import {
  FullPageContainer,
  PageTitle,
  PageDescription,
  PageButtonGroup,
  PageIllustration,
  ErrorCode,
  DangerPageButton,
  GhostPageButton,
  GlowOrb,
  GearIcon,
  StatusBar,
  StatusDot,
  StatusText,
  glitch,
  shake,
} from '../styles';
import styled from 'styled-components';

const GlitchCode = styled(ErrorCode)`
  color: ${({ theme }) => theme.colors.error};
  animation: ${glitch} 3s ease-in-out infinite;
`;

const ShakingIllustration = styled(PageIllustration)`
  margin-bottom: ${({ theme }) => theme.spacing(1)};
  animation: ${shake} 4s ease-in-out infinite;
  animation-delay: 1s;
`;

const DangerGhostButton = styled(GhostPageButton)`
  &:hover {
    border-color: ${({ theme }) => theme.colors.error};
    color: ${({ theme }) => theme.colors.error};
  }
`;

export default function ServerErrorPage() {
  const navigate = useNavigate();

  return (
    <FullPageContainer>
      <GlowOrb />
      <GearIcon>⚙</GearIcon>
      <GearIcon>⚙</GearIcon>
      <GearIcon>⚙</GearIcon>
      <ShakingIllustration>🔥</ShakingIllustration>
      <GlitchCode>500</GlitchCode>
      <PageTitle>Internal Server Error</PageTitle>
      <PageDescription>
        Something went wrong on our end. Our team has been notified and is working on a fix. Please
        try again in a moment.
      </PageDescription>
      <PageButtonGroup>
        <DangerPageButton onClick={() => window.location.reload()}>Try Again</DangerPageButton>
        <DangerGhostButton onClick={() => navigate('/')}>Go Home</DangerGhostButton>
      </PageButtonGroup>
      <StatusBar>
        <StatusDot />
        <StatusText>Service disruption detected</StatusText>
      </StatusBar>
    </FullPageContainer>
  );
}
