import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import styled from 'styled-components';

const schema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().min(5, 'At least 5 characters'),
  priority: z.enum(['low', 'medium', 'high']),
});

type FormData = z.infer<typeof schema>;

const Form = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing(2.5)};
`;

const Field = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

const Label = styled.label`
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  color: ${({ theme }) => theme.colors.text};
`;

const Input = styled.input`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(1.5)}`};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  background: ${({ theme }) => theme.colors.background};
  color: ${({ theme }) => theme.colors.text};
  &:focus { outline: none; border-color: ${({ theme }) => theme.colors.primary}; }
`;

const Select = styled.select`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(1.5)}`};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  background: ${({ theme }) => theme.colors.background};
  color: ${({ theme }) => theme.colors.text};
`;

const ErrorText = styled.span`
  font-size: ${({ theme }) => theme.typography.fontSize.xs};
  color: ${({ theme }) => theme.colors.error};
`;

interface Props {
  onSubmit?: (data: FormData) => void;
}

export function ExampleFormContent({ onSubmit }: Props) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { priority: 'medium' },
  });

  return (
    <Form>
      <form id="drawer-form" onSubmit={handleSubmit((data) => onSubmit?.(data))}>
        <Field>
          <Label>Title</Label>
          <Input {...register('title')} placeholder="Enter title" />
          {errors.title && <ErrorText>{errors.title.message}</ErrorText>}
        </Field>
        <Field>
          <Label>Description</Label>
          <Input {...register('description')} placeholder="Enter description" />
          {errors.description && <ErrorText>{errors.description.message}</ErrorText>}
        </Field>
        <Field>
          <Label>Priority</Label>
          <Select {...register('priority')}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </Select>
        </Field>
      </form>
    </Form>
  );
}
