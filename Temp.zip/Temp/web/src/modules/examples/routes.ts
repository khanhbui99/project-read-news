import type { RouteObject } from 'react-router-dom';
import { createLazyRoute } from '@/shared/utils/createLazyRoute';
import { PageSkeleton } from '@/shared/components/skeletons/PageSkeleton';

export const exampleRoutes: RouteObject[] = [
  {
    path: '/examples/showcase',
    element: createLazyRoute({
      factory: () => import('./pages/ExampleShowcasePage'),
      skeleton: PageSkeleton,
    }),
  },
  {
    path: '/examples/crud',
    element: createLazyRoute({
      factory: () => import('./pages/ExampleCRUDPage'),
      skeleton: PageSkeleton,
    }),
  },
];
