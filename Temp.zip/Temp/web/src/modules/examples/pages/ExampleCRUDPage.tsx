import { useState } from 'react';
import styled from 'styled-components';
import { setLoading } from '@/shared/services/loadingService';
import { showConfirm, showSuccess, showError } from '@/shared/services/modalService';
import { ModalContainer } from '@/shared/components/ModalContainer';
import { ModalActions } from '@/shared/components/ModalActions';
import { ExampleFormContent } from '../components/ExampleFormContent';

const Page = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing(3)};
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Title = styled.h1`
  font-size: ${({ theme }) => theme.typography.fontSize['2xl']};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
`;

const Button = styled.button<{ $variant?: 'primary' | 'danger' | 'ghost' }>`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(2)}`};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  transition: all ${({ theme }) => theme.transitions.fast};

  ${({ $variant, theme }) => {
    switch ($variant) {
      case 'danger':
        return `background: ${theme.colors.error}; color: white;`;
      case 'ghost':
        return `background: transparent; color: ${theme.colors.textSecondary}; border: 1px solid ${theme.colors.border};`;
      default:
        return `background: ${theme.colors.primary}; color: white;`;
    }
  }}

  &:hover { opacity: 0.9; }
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: ${({ theme }) => theme.colors.surface};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  overflow: hidden;
`;

const Th = styled.th`
  text-align: left;
  padding: ${({ theme }) => `${theme.spacing(1.5)} ${theme.spacing(2)}`};
  background: ${({ theme }) => theme.colors.surfaceHover};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  color: ${({ theme }) => theme.colors.textSecondary};
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
`;

const Td = styled.td`
  padding: ${({ theme }) => `${theme.spacing(1.5)} ${theme.spacing(2)}`};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  border-bottom: 1px solid ${({ theme }) => theme.colors.divider};
`;

const Actions = styled.div`
  display: flex;
  gap: ${({ theme }) => theme.spacing(1)};
`;

// Mock data
const mockItems = [
  { id: '1', title: 'Setup project', description: 'Initialize boilerplate', priority: 'high' },
  { id: '2', title: 'Create components', description: 'Build shared UI', priority: 'medium' },
  { id: '3', title: 'Write tests', description: 'Add unit tests', priority: 'low' },
];

export default function ExampleCRUDPage() {
  const [items, setItems] = useState(mockItems);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleCreate = () => {
    setEditingId(null);
    setDrawerOpen(true);
  };

  const handleEdit = (id: string) => {
    setEditingId(id);
    setDrawerOpen(true);
  };

  const handleDelete = async (id: string) => {
    const confirmed = await showConfirm('Delete Item', 'This action cannot be undone.');
    if (confirmed) {
      setLoading(true);
      await new Promise((r) => setTimeout(r, 500));
      setItems((prev) => prev.filter((i) => i.id !== id));
      setLoading(false);
      await showSuccess('Deleted', 'Item removed successfully.');
    }
  };

  const handleSave = async () => {
    setLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    setLoading(false);
    setDrawerOpen(false);
    await showSuccess('Saved', editingId ? 'Item updated.' : 'Item created.');
  };

  return (
    <Page>
      <Header>
        <Title>CRUD Example</Title>
        <Button onClick={handleCreate}>+ Create</Button>
      </Header>

      <Table>
        <thead>
          <tr>
            <Th>Title</Th>
            <Th>Description</Th>
            <Th>Priority</Th>
            <Th>Actions</Th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <Td>{item.title}</Td>
              <Td>{item.description}</Td>
              <Td>{item.priority}</Td>
              <Td>
                <Actions>
                  <Button $variant="ghost" onClick={() => handleEdit(item.id)}>Edit</Button>
                  <Button $variant="danger" onClick={() => handleDelete(item.id)}>Delete</Button>
                </Actions>
              </Td>
            </tr>
          ))}
        </tbody>
      </Table>

      <ModalContainer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        title={editingId ? 'Edit Item' : 'Create Item'}
        subtitle={editingId ? `Editing #${editingId}` : 'Fill in the details'}
        actions={
          <ModalActions>
            <Button $variant="ghost" onClick={() => setDrawerOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save</Button>
          </ModalActions>
        }
      >
        <ExampleFormContent />
      </ModalContainer>
    </Page>
  );
}
