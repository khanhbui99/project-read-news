import { useState } from 'react';
import styled from 'styled-components';
import { useTranslation } from 'react-i18next';
import { useTheme } from '@/shared/hooks/useThemeContext';
import { setLoading } from '@/shared/services/loadingService';
import { showConfirm, showSuccess, showError, showWarning, showInfo } from '@/shared/services/modalService';
import { ModalContainer } from '@/shared/components/ModalContainer';
import { ModalActions } from '@/shared/components/ModalActions';
import { ExampleForm } from '../components/ExampleForm';
import { ExampleFormContent } from '../components/ExampleFormContent';
import { media, BREAKPOINTS } from '@/styles/media';

const Page = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing(4)};
`;

const SectionTitle = styled.h1`
  font-size: ${({ theme }) => theme.typography.fontSize['3xl']};
  font-weight: ${({ theme }) => theme.typography.fontWeight.bold};
  color: ${({ theme }) => theme.colors.text};
`;

const Section = styled.section`
  background: ${({ theme }) => theme.colors.surface};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.lg};
  padding: ${({ theme }) => theme.spacing(3)};
`;

const SectionHeading = styled.h2`
  font-size: ${({ theme }) => theme.typography.fontSize.xl};
  font-weight: ${({ theme }) => theme.typography.fontWeight.semibold};
  margin-bottom: ${({ theme }) => theme.spacing(2)};
  color: ${({ theme }) => theme.colors.text};
`;

const ButtonGroup = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: ${({ theme }) => theme.spacing(1)};
`;

const Button = styled.button<{ $color?: string }>`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(2)}`};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  font-weight: ${({ theme }) => theme.typography.fontWeight.medium};
  background: ${({ $color, theme }) => $color || theme.colors.primary};
  color: white;
  transition: opacity ${({ theme }) => theme.transitions.fast};
  &:hover { opacity: 0.9; }
`;

const ColorGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: ${({ theme }) => theme.spacing(1)};
`;

const ColorSwatch = styled.div<{ $color: string }>`
  background: ${({ $color }) => $color};
  height: 60px;
  border-radius: ${({ theme }) => theme.borderRadius.md};
  display: flex;
  align-items: flex-end;
  padding: 4px 8px;
  font-size: 10px;
  color: ${({ theme }) => theme.colors.textInverse};
`;

const ThemeToggle = styled.div`
  display: flex;
  gap: ${({ theme }) => theme.spacing(1)};
`;

const ToggleBtn = styled.button<{ $active: boolean }>`
  padding: ${({ theme }) => `${theme.spacing(1)} ${theme.spacing(2)}`};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  background: ${({ $active, theme }) => ($active ? theme.colors.primary : theme.colors.surfaceHover)};
  color: ${({ $active, theme }) => ($active ? 'white' : theme.colors.text)};
  border: 1px solid ${({ theme }) => theme.colors.border};
`;

const ResponsiveBox = styled.div`
  padding: ${({ theme }) => theme.spacing(2)};
  background: ${({ theme }) => theme.colors.primaryLight};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  text-align: center;
  font-size: ${({ theme }) => theme.typography.fontSize.sm};

  &::after {
    content: 'Mobile (xs)';
  }

  ${media.up('sm')} { &::after { content: 'Small (sm: ≥576px)'; } }
  ${media.up('md')} { &::after { content: 'Medium (md: ≥768px)'; } }
  ${media.up('lg')} { &::after { content: 'Large (lg: ≥992px)'; } }
  ${media.up('xl')} { &::after { content: 'X-Large (xl: ≥1200px)'; } }
  ${media.up('xxl')} { &::after { content: 'XX-Large (xxl: ≥1400px)'; } }
`;

const LangButton = styled.button<{ $active: boolean }>`
  padding: 4px 12px;
  border-radius: ${({ theme }) => theme.borderRadius.sm};
  font-size: ${({ theme }) => theme.typography.fontSize.sm};
  background: ${({ $active, theme }) => ($active ? theme.colors.secondary : 'transparent')};
  color: ${({ $active, theme }) => ($active ? 'white' : theme.colors.text)};
  border: 1px solid ${({ theme }) => theme.colors.border};
`;

export default function ExampleShowcasePage() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const { mode, setMode } = useTheme();
  const { t, i18n } = useTranslation();

  const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

  return (
    <Page>
      <SectionTitle>Component Showcase</SectionTitle>

      {/* Modal Types */}
      <Section>
        <SectionHeading>Modal System</SectionHeading>
        <ButtonGroup>
          <Button onClick={() => showConfirm('Confirm', 'Are you sure you want to proceed?')}>
            Confirm
          </Button>
          <Button $color="#10B981" onClick={() => showSuccess('Success', 'Operation completed!')}>
            Success
          </Button>
          <Button $color="#EF4444" onClick={() => showError('Error', 'Something went wrong.')}>
            Error
          </Button>
          <Button $color="#F59E0B" onClick={() => showWarning('Warning', 'This is risky.')}>
            Warning
          </Button>
          <Button $color="#3B82F6" onClick={() => showInfo('Info', 'Just a heads up.')}>
            Info
          </Button>
        </ButtonGroup>
      </Section>

      {/* Drawer */}
      <Section>
        <SectionHeading>ModalContainer (Drawer)</SectionHeading>
        <Button onClick={() => setDrawerOpen(true)}>Open Drawer →</Button>
        <ModalContainer
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          position="right"
          title="Example Drawer"
          subtitle="This is a reusable drawer panel"
          actions={
            <ModalActions>
              <Button $color="#78716C" onClick={() => setDrawerOpen(false)}>Cancel</Button>
              <Button onClick={() => setDrawerOpen(false)}>Save</Button>
            </ModalActions>
          }
        >
          <ExampleFormContent />
        </ModalContainer>
      </Section>

      {/* Loading */}
      <Section>
        <SectionHeading>Global Loading</SectionHeading>
        <Button
          onClick={async () => {
            setLoading(true);
            await delay(2000);
            setLoading(false);
          }}
        >
          Trigger 2s Loading
        </Button>
      </Section>

      {/* Theme */}
      <Section>
        <SectionHeading>Theme</SectionHeading>
        <ThemeToggle>
          <ToggleBtn $active={mode === 'light'} onClick={() => setMode('light')}>
            ☀️ {t('theme.light')}
          </ToggleBtn>
          <ToggleBtn $active={mode === 'dark'} onClick={() => setMode('dark')}>
            🌙 {t('theme.dark')}
          </ToggleBtn>
          <ToggleBtn $active={mode === 'system'} onClick={() => setMode('system')}>
            💻 {t('theme.system')}
          </ToggleBtn>
        </ThemeToggle>
        <ColorGrid style={{ marginTop: 16 }}>
          <ColorSwatch $color="#6366F1">primary</ColorSwatch>
          <ColorSwatch $color="#14B8A6">secondary</ColorSwatch>
          <ColorSwatch $color="#10B981">success</ColorSwatch>
          <ColorSwatch $color="#F59E0B">warning</ColorSwatch>
          <ColorSwatch $color="#EF4444">error</ColorSwatch>
          <ColorSwatch $color="#3B82F6">info</ColorSwatch>
        </ColorGrid>
      </Section>

      {/* Responsive */}
      <Section>
        <SectionHeading>Responsive Breakpoints</SectionHeading>
        <ResponsiveBox />
      </Section>

      {/* Form */}
      <Section>
        <SectionHeading>Form (React Hook Form + Zod)</SectionHeading>
        <ExampleForm onSubmit={(data) => showSuccess('Submitted', JSON.stringify(data))} />
      </Section>

      {/* i18n */}
      <Section>
        <SectionHeading>Internationalization</SectionHeading>
        <ButtonGroup>
          <LangButton $active={i18n.language === 'en'} onClick={() => i18n.changeLanguage('en')}>
            English
          </LangButton>
          <LangButton $active={i18n.language === 'vi'} onClick={() => i18n.changeLanguage('vi')}>
            Tiếng Việt
          </LangButton>
        </ButtonGroup>
        <p style={{ marginTop: 12 }}>
          {t('common.save')} | {t('common.cancel')} | {t('common.confirm')} | {t('errors.generic')}
        </p>
      </Section>
    </Page>
  );
}
