# Implementation Tasks

## Task 1: Project Scaffold & Configuration

- [ ] 1.1 Initialize Vite + React + TypeScript project with `npm create vite@latest`
  - [x] 1.1.1 Create `package.json` with all required dependencies (react, react-dom, react-router-dom, zustand, @tanstack/react-query, styled-components, react-hook-form, zod, react-i18next, i18next, axios)
  - [x] 1.1.2 Create `package.json` devDependencies (vite, typescript, vitest, @testing-library/react, playwright, fast-check, eslint, prettier)
  - [x] 1.1.3 Create `tsconfig.json` with path aliases (`@/` → `src/`)
  - [x] 1.1.4 Create `vite.config.ts` with path alias resolution and build config
- [x] 1.2 Create folder structure
  - [x] 1.2.1 Create `src/app/` directory with placeholder files (App.tsx, providers.tsx, routes.tsx)
  - [x] 1.2.2 Create `src/modules/` directory with example module structure
  - [x] 1.2.3 Create `src/shared/` directory tree (components/, hooks/, services/, utils/, types/, i18n/)
  - [x] 1.2.4 Create `src/assets/` and `src/styles/` directories
  - [x] 1.2.5 Create `src/main.tsx` entry point
  - [x] 1.2.6 Create `src/vite-env.d.ts`
  - [x] 1.2.7 Create `index.html`
- [x] 1.3 Configure ESLint + Prettier
  - [x] 1.3.1 Create `.eslintrc.cjs` with TypeScript-aware rules and React plugin
  - [x] 1.3.2 Create `.prettierrc` with team formatting standards
  - [x] 1.3.3 Create `.eslintignore` and `.prettierignore`

## Task 2: Theme System

- [x] 2.1 Create theme token definitions
  - [x] 2.1.1 Create `src/styles/theme.ts` with light and dark Theme objects (full color palette: primary, secondary, semantic colors with light tints, background, surface, text, border tokens)
  - [x] 2.1.2 Create `src/styles/styled.d.ts` for styled-components type augmentation
  - [x] 2.1.3 Create `src/styles/GlobalStyles.ts` with CSS reset and base styles
- [x] 2.2 Create responsive media helpers
  - [x] 2.2.1 Create `src/styles/media.ts` with `media.up()`, `media.down()`, `media.between()` utilities using Bootstrap breakpoints
- [x] 2.3 Create ThemeContext
  - [x] 2.3.1 Create `src/shared/hooks/useThemeContext.tsx` with ThemeContextProvider, useTheme hook
  - [x] 2.3.2 Implement system preference detection via `window.matchMedia`
  - [x] 2.3.3 Implement localStorage persistence (key: 'theme-mode') with fallback on error
  - [x] 2.3.4 Implement real-time system preference change listener

## Task 3: Layout System

- [x] 3.1 Create EndUserLayout
  - [x] 3.1.1 Create `src/shared/components/layouts/EndUserLayout.tsx` with header, main content (Outlet), footer
  - [x] 3.1.2 Implement responsive behavior (mobile-first)
- [x] 3.2 Create AdminLayout
  - [x] 3.2.1 Create `src/shared/components/layouts/AdminLayout.tsx` with sidebar, header, main content (Outlet)
  - [x] 3.2.2 Implement sidebar collapse on mobile (below md breakpoint)
  - [x] 3.2.3 Implement sidebar toggle button for mobile

## Task 4: Loading Service

- [x] 4.1 Create loading store
  - [x] 4.1.1 Create `src/shared/services/loadingService.ts` with Zustand store (isVisible, setLoading)
  - [x] 4.1.2 Export imperative `setLoading(boolean)` function
- [x] 4.2 Create LoadingOverlay component
  - [x] 4.2.1 Create `src/shared/components/LoadingOverlay.tsx` with full-screen overlay and spinner
  - [x] 4.2.2 Add aria-busy attribute on app root when loading
  - [x] 4.2.3 Add enter/exit animation

## Task 5: Modal System

- [ ] 5.1 Create modal store
  - [x] 5.1.1 Create `src/shared/services/modalService.ts` with Zustand store (stack, open, close, closeAll)
  - [x] 5.1.2 Implement Promise-based open/close flow with UUID generation
  - [x] 5.1.3 Export imperative functions: openModal, closeAllModals
  - [x] 5.1.4 Export shorthand helpers: showConfirm, showSuccess, showError, showWarning, showInfo
- [ ] 5.2 Create Modal type components
  - [x] 5.2.1 Create `src/shared/components/modals/ModalConfirm.tsx` (Confirm + Cancel buttons, blue/primary icon)
  - [x] 5.2.2 Create `src/shared/components/modals/ModalSuccess.tsx` (OK button, green icon)
  - [x] 5.2.3 Create `src/shared/components/modals/ModalError.tsx` (OK/Retry buttons, red icon)
  - [x] 5.2.4 Create `src/shared/components/modals/ModalWarning.tsx` (Proceed + Cancel buttons, amber icon)
  - [x] 5.2.5 Create `src/shared/components/modals/ModalInfo.tsx` (OK button, soft blue icon)
- [ ] 5.3 Create ModalManager
  - [x] 5.3.1 Create `src/shared/components/ModalManager.tsx` that renders the modal stack
  - [x] 5.3.2 Implement focus trap, Escape key handling, backdrop click
  - [x] 5.3.3 Implement route change detection → closeAll()
  - [x] 5.3.4 Add accessible attributes (aria-modal, role="dialog"/"alertdialog")

## Task 6: ModalContainer (Drawer Panel)

- [ ] 6.1 Create ModalContainer component
  - [x] 6.1.1 Create `src/shared/components/ModalContainer.tsx` with slide-in animation from configurable position
  - [x] 6.1.2 Implement desktop/tablet behavior: min-width 50vw, height 100vh, slide from configured side
  - [x] 6.1.3 Implement mobile behavior: bottom sheet, 100vw width, 90vh height, slide up, rounded top corners (16px), drag handle
  - [x] 6.1.4 Implement header section (sticky top): title, subtitle, close button
  - [x] 6.1.5 Implement scrollable content area (overflow-y: auto, flex-grow: 1)
  - [x] 6.1.6 Implement backdrop overlay with configurable click-to-close
  - [x] 6.1.7 Implement body scroll lock and focus trap when open
  - [x] 6.1.8 Add accessible attributes (aria-modal, role="dialog", aria-labelledby)
- [ ] 6.2 Create ModalActions component
  - [x] 6.2.1 Create `src/shared/components/ModalActions.tsx` with sticky bottom positioning
  - [x] 6.2.2 Implement alignment options (left, right, between)
  - [x] 6.2.3 Implement optional top border separator
  - [x] 6.2.4 Add consistent padding (16px horizontal, 12px vertical)

## Task 7: Lazy Loading & Error Boundary

- [ ] 7.1 Create lazy loading utility
  - [x] 7.1.1 Create `src/shared/utils/createLazyRoute.tsx` with React.lazy + Suspense + skeleton fallback
  - [x] 7.1.2 Implement loadWithRetry: 3 retries with exponential backoff (1s, 2s, 3s)
- [ ] 7.2 Create Error Boundary
  - [x] 7.2.1 Create `src/shared/components/ErrorBoundary.tsx` for chunk load failures
  - [ ] 7.2.2 Create `src/shared/components/ChunkErrorFallback.tsx` with retry button
- [ ] 7.3 Create skeleton components
  - [ ] 7.3.1 Create `src/shared/components/skeletons/BaseSkeleton.tsx` (reusable skeleton primitive)
  - [x] 7.3.2 Create `src/shared/components/skeletons/PageSkeleton.tsx` (generic page skeleton)

## Task 8: API Client

- [ ] 8.1 Create API client service
  - [x] 8.1.1 Create `src/shared/services/apiClient.ts` with Axios instance and typed methods (get, post, put, patch, delete)
  - [x] 8.1.2 Implement request interceptor: attach auth token from memory storage
  - [x] 8.1.3 Implement response interceptor: handle 401 (token refresh attempt, redirect to login on failure)
  - [x] 8.1.4 Implement optional loading integration (setLoading on withLoading: true)
  - [x] 8.1.5 Implement error normalization to AppError interface
- [ ] 8.2 Create shared types
  - [x] 8.2.1 Create `src/shared/types/api.ts` with AppError, RequestConfig, ApiClientConfig interfaces

## Task 9: Routing

- [ ] 9.1 Configure React Router v7
  - [x] 9.1.1 Create `src/app/routes.tsx` with createBrowserRouter, layout routes (EndUser + Admin), lazy route definitions
  - [x] 9.1.2 Define RouteDefinition type with layout, skeleton, and meta fields
  - [x] 9.1.3 Wire up example module routes and example pages routes

## Task 10: Application Entry & Providers

- [ ] 10.1 Create AppProviders
  - [x] 10.1.1 Create `src/app/providers.tsx` with correct provider nesting: QueryClientProvider → I18nextProvider → ThemeContextProvider → children + ModalManager + LoadingOverlay
  - [x] 10.1.2 Initialize QueryClient with staleTime: 5min, retry: 1
- [ ] 10.2 Create App component
  - [x] 10.2.1 Create `src/app/App.tsx` with RouterProvider
  - [x] 10.2.2 Update `src/main.tsx` to render AppProviders → App

## Task 11: State Management (Zustand)

- [ ] 11.1 Create example module store
  - [x] 11.1.1 Create `src/modules/example/stores/exampleStore.ts` demonstrating Zustand pattern (items CRUD)

## Task 12: Data Fetching (TanStack Query)

- [ ] 12.1 Create example query hook
  - [x] 12.1.1 Create `src/modules/example/hooks/useExampleQuery.ts` demonstrating useQuery pattern
  - [x] 12.1.2 Create `src/modules/example/services/exampleService.ts` demonstrating service layer pattern

## Task 13: Form Handling

- [ ] 13.1 Create example form
  - [x] 13.1.1 Create `src/modules/examples/components/ExampleForm.tsx` with React Hook Form + Zod schema validation
  - [x] 13.1.2 Create `src/modules/examples/components/ExampleFormContent.tsx` for use inside ModalContainer

## Task 14: Internationalization

- [ ] 14.1 Configure i18n
  - [x] 14.1.1 Create `src/shared/i18n/index.ts` with i18next initialization, language detection, fallback to 'en'
  - [x] 14.1.2 Create `src/shared/i18n/locales/en.json` with example translation keys
  - [x] 14.1.3 Create `src/shared/i18n/locales/vi.json` with Vietnamese translations

## Task 15: Example Pages

- [ ] 15.1 Create Example Showcase Page
  - [x] 15.1.1 Create `src/modules/examples/pages/ExampleShowcasePage.tsx` demonstrating all shared components (modal types, drawer, loading, theme, responsive, form, query, i18n)
  - [ ] 15.1.2 Create `src/modules/examples/components/ColorPaletteGrid.tsx`
  - [ ] 15.1.3 Create `src/modules/examples/components/ResponsiveIndicator.tsx`
- [ ] 15.2 Create Example CRUD Page
  - [x] 15.2.1 Create `src/modules/examples/pages/ExampleCRUDPage.tsx` demonstrating full CRUD flow with ModalContainer, table, forms, confirmation
- [ ] 15.3 Create example module exports
  - [x] 15.3.1 Create `src/modules/examples/routes.ts` and `src/modules/examples/index.ts`

## Task 16: Testing Setup

- [ ] 16.1 Configure Vitest
  - [x] 16.1.1 Create `vitest.config.ts` with jsdom environment, path aliases, setup files
  - [x] 16.1.2 Create `src/test/setup.ts` with testing-library configuration
- [ ] 16.2 Configure Playwright
  - [x] 16.2.1 Create `playwright.config.ts` with base URL and browser config
  - [x] 16.2.2 Create `e2e/example.spec.ts` with basic E2E test example
- [ ] 16.3 Write property-based tests
  - [x] 16.3.1 Create `src/shared/services/__tests__/loadingService.pbt.test.ts` — test setLoading idempotence property
  - [x] 16.3.2 Create `src/shared/services/__tests__/modalService.pbt.test.ts` — test modal stack uniqueness, close resolves Promise, closeAll resolves all
  - [x] 16.3.3 Create `src/shared/hooks/__tests__/useThemeContext.pbt.test.ts` — test theme resolution always returns 'light' or 'dark'
  - [x] 16.3.4 Create `src/styles/__tests__/media.pbt.test.ts` — test media helpers produce valid CSS media query strings
- [ ] 16.4 Write unit tests
  - [x] 16.4.1 Create `src/shared/services/__tests__/loadingService.test.ts`
  - [x] 16.4.2 Create `src/shared/services/__tests__/modalService.test.ts`
  - [x] 16.4.3 Create `src/shared/hooks/__tests__/useThemeContext.test.ts`
  - [x] 16.4.4 Create `src/styles/__tests__/media.test.ts`

## Task 17: Agent Rules & Telegram Integration

- [ ] 17.1 Create agent rule files
  - [x] 17.1.1 Create `.kiro/rules/feature-workflow.yaml` with trigger, steps, and Telegram notification config
  - [x] 17.1.2 Create placeholder `.env.example` with TELEGRAM_CHAT_ID and TELEGRAM_BOT_TOKEN variables

## Task 18: Environment Configuration

- [ ] 18.1 Create environment files
  - [x] 18.1.1 Create `.env.example` with all required environment variables (VITE_API_BASE_URL, VITE_APP_TITLE, TELEGRAM_CHAT_ID, TELEGRAM_BOT_TOKEN)
  - [x] 18.1.2 Create `.env.development` with development environment values (localhost API, debug flags)
  - [x] 18.1.3 Create `.env.staging` with staging environment values
  - [x] 18.1.4 Create `.env.production` with production environment placeholders
  - [x] 18.1.5 Add `.env*.local` to `.gitignore`
- [ ] 18.2 Create env config utility
  - [x] 18.2.1 Create `src/shared/config/env.ts` with typed environment variable access and validation via Zod schema
  - [x] 18.2.2 Export typed `env` object with runtime validation on app init
- [ ] 18.3 Update Vite config for environments
  - [x] 18.3.1 Add `envDir` and mode-based env loading in `vite.config.ts`
  - [x] 18.3.2 Add build scripts in `package.json`: `build:dev`, `build:staging`, `build:production`

## Task 19: Documentation & Final Polish

- [ ] 19.1 Create README.md
  - [x] 19.1.1 Write project README with getting started, folder structure, conventions, and team guidelines for AI-assisted development
- [ ] 19.2 Verify build
  - [ ] 19.2.1 Run `npm install` and `npm run build` to verify zero errors
  - [ ] 19.2.2 Run `npm run lint` to verify zero linting errors
  - [ ] 19.2.3 Run `npm run test` to verify all tests pass
