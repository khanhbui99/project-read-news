# Design Document: React Parent Template

## Overview

This feature establishes a production-ready React parent template (boilerplate) using Vite, TypeScript, and a curated modern stack. The template provides a hybrid architecture combining module-based business logic with shared utilities, featuring dual layouts (EndUser/Admin), global state management via Zustand, data fetching with TanStack Query, styled-components theming with dark/light mode, internationalization, and imperative global services (loading overlay, modal system). It also includes agent rule files for workflow automation with Telegram notification integration.

The template follows mobile-first responsive design with Bootstrap-standard breakpoints, lazy-loaded routes with skeleton fallbacks, and a comprehensive testing strategy using Vitest, React Testing Library, and Playwright.

## Architecture

```mermaid
graph TD
    subgraph Entry["Entry Point"]
        Main["main.tsx"]
    end

    subgraph AppLayer["App Layer"]
        App["App.tsx"]
        Providers["providers.tsx"]
        Routes["routes.tsx"]
    end

    subgraph Providers_Detail["Provider Stack"]
        QP["QueryClientProvider"]
        RP["RouterProvider"]
        TP["ThemeProvider"]
        I18N["I18nProvider"]
    end

    subgraph Layouts["Layouts"]
        EUL["EndUserLayout"]
        AL["AdminLayout"]
    end

    subgraph Modules["Business Modules"]
        M1["modules/example/"]
        M2["modules/auth/"]
        M3["modules/.../"]
    end

    subgraph Shared["Shared Layer"]
        SC["components/"]
        SH["hooks/"]
        SS["services/"]
        SU["utils/"]
        ST["types/"]
        SI["i18n/"]
    end

    subgraph Global["Global Services"]
        Loading["LoadingOverlay"]
        Modal["ModalManager"]
        Notify["Notifications"]
    end

    Main --> App
    App --> Providers
    Providers --> QP & RP & TP & I18N
    RP --> Routes
    Routes --> Layouts
    EUL --> Modules
    AL --> Modules
    Modules --> Shared
    Modules --> Global
    Shared --> Global
```

## Sequence Diagrams

### App Initialization Flow

```mermaid
sequenceDiagram
    participant Browser
    participant Main as main.tsx
    participant Providers as providers.tsx
    participant Theme as ThemeContext
    participant I18n as react-i18next
    participant Router as React Router v7
    participant Layout as Layout Component

    Browser->>Main: Load application
    Main->>Providers: Render AppProviders
    Providers->>Theme: Initialize theme (read localStorage / system pref)
    Providers->>I18n: Initialize i18n (detect language)
    Providers->>Router: Create RouterProvider
    Router->>Layout: Match route → select layout
    Layout->>Browser: Render page with skeleton fallback
```

### Theme Toggle Flow

```mermaid
sequenceDiagram
    participant User
    participant Toggle as ThemeToggle
    participant Ctx as ThemeContext
    participant LS as localStorage
    participant SC as StyledComponents ThemeProvider

    User->>Toggle: Click theme toggle
    Toggle->>Ctx: setThemeMode('dark' | 'light' | 'system')
    Ctx->>LS: Persist preference
    Ctx->>SC: Update theme object
    SC->>Toggle: Re-render with new theme
```

### Global Loading Flow

```mermaid
sequenceDiagram
    participant Component as Any Component/Service
    participant API as setLoading()
    participant Store as loadingStore (Zustand)
    participant Overlay as LoadingOverlay

    Component->>API: setLoading(true)
    API->>Store: isVisible = true
    Store->>Overlay: Show full-screen overlay
    Component->>API: setLoading(false)
    API->>Store: isVisible = false
    Store->>Overlay: Hide overlay
```

### Modal System Flow

```mermaid
sequenceDiagram
    participant Caller as Any Component
    participant MS as modalService
    participant Store as modalStore (Zustand)
    participant Manager as ModalManager
    participant Modal as ModalConfirm

    Caller->>MS: openModal({ type: 'confirm', props })
    MS->>Store: push modal to stack
    Store->>Manager: Re-render modal stack
    Manager->>Modal: Render ModalConfirm with props
    Modal->>MS: onConfirm / onCancel
    MS->>Store: pop modal from stack
    MS->>Caller: resolve Promise with result
```


## Components and Interfaces

### Component 1: AppProviders

**Purpose**: Wraps the entire application with all necessary context providers in the correct nesting order.

**Interface**:
```typescript
interface AppProvidersProps {
  children: React.ReactNode;
}

// Provider nesting order (outermost to innermost):
// 1. QueryClientProvider (data fetching)
// 2. ThemeContextProvider (theme state + styled-components ThemeProvider)
// 3. I18nextProvider (translations)
// 4. RouterProvider (routing)
```

**Responsibilities**:
- Initialize QueryClient with default options
- Set up theme context with system preference detection
- Configure i18n instance
- Provide router with lazy-loaded route definitions

---

### Component 2: ThemeContext

**Purpose**: Manages light/dark/system theme preference, persists to localStorage, and provides the resolved theme to styled-components.

**Interface**:
```typescript
type ThemeMode = 'light' | 'dark' | 'system';

interface ThemeContextValue {
  mode: ThemeMode;
  resolvedTheme: 'light' | 'dark';
  setMode: (mode: ThemeMode) => void;
}

interface Theme {
  colors: {
    // Primary palette - soft, warm, approachable
    primary: string;        // Main brand color (soft indigo/blue)
    primaryLight: string;   // Lighter variant for hover/backgrounds
    primaryDark: string;    // Darker variant for active states
    secondary: string;      // Accent color (soft teal/mint)
    secondaryLight: string;
    secondaryDark: string;

    // Backgrounds - gentle, easy on the eyes
    background: string;     // Page background (warm off-white / dark navy)
    surface: string;        // Card/panel background (slightly elevated)
    surfaceHover: string;   // Surface on hover state
    overlay: string;        // Modal backdrop (semi-transparent)

    // Text - readable with good contrast but not harsh
    text: string;           // Primary text (soft black / warm white)
    textSecondary: string;  // Secondary/muted text
    textDisabled: string;   // Disabled state text
    textInverse: string;    // Text on colored backgrounds

    // Borders & Dividers
    border: string;         // Default border (subtle)
    borderHover: string;    // Border on hover
    divider: string;        // Divider lines (very subtle)

    // Semantic colors - friendly & rounded feel
    error: string;          // Soft red (not harsh)
    errorLight: string;     // Error background tint
    warning: string;        // Warm amber
    warningLight: string;   // Warning background tint
    success: string;        // Fresh green
    successLight: string;   // Success background tint
    info: string;           // Calm blue
    infoLight: string;      // Info background tint
  };
  breakpoints: {
    xs: string;  // '0px'
    sm: string;  // '576px'
    md: string;  // '768px'
    lg: string;  // '992px'
    xl: string;  // '1200px'
    xxl: string; // '1400px'
  };
  spacing: (factor: number) => string;
  typography: {
    fontFamily: string;
    fontSize: Record<string, string>;
    fontWeight: Record<string, number>;
  };
  shadows: Record<string, string>;
  borderRadius: Record<string, string>;
  transitions: Record<string, string>;
}
```

**Responsibilities**:
- Detect system color scheme preference via `matchMedia`
- Listen to system preference changes in real-time
- Persist user choice to localStorage key `theme-mode`
- Resolve 'system' mode to actual 'light' or 'dark'
- Provide styled-components `ThemeProvider` with resolved theme object

---

### Component 3: Layout System

**Purpose**: Provides dual layout structures (EndUser and Admin) selected based on route configuration.

**Interface**:
```typescript
interface LayoutProps {
  children: React.ReactNode;
}

interface RouteConfig {
  path: string;
  element: React.LazyExoticComponent<React.ComponentType>;
  layout: 'enduser' | 'admin';
  skeleton: React.ComponentType;
  meta?: {
    requiresAuth?: boolean;
    title?: string;
  };
}
```

**Responsibilities**:
- EndUserLayout: Header, main content, footer
- AdminLayout: Sidebar navigation, header, main content area
- Responsive behavior: sidebar collapses on mobile
- Route-based layout switching via route configuration

---

### Component 4: Loading Service (Imperative)

**Purpose**: Provides global full-screen loading overlay controllable from anywhere via a single `setLoading(boolean)` function.

**Interface**:
```typescript
interface LoadingStore {
  isVisible: boolean;
  setLoading: (visible: boolean) => void;
}

// Imperative API (callable from non-React code, anywhere in the app)
declare function setLoading(visible: boolean): void;
```

**Responsibilities**:
- Single function `setLoading(true/false)` to show/hide loading overlay
- Full-screen overlay with spinner animation
- Accessible: aria-busy on root element
- Can be called from API interceptors, services, components (non-React context)

---

### Component 5: Modal System

**Purpose**: Global modal/dialog management with stack support, promise-based API, and multiple modal types covering all common UX scenarios.

**Interface**:
```typescript
type ModalType = 'confirm' | 'success' | 'error' | 'warning' | 'info' | 'custom';

interface ModalConfig<T = unknown> {
  id: string;
  type: ModalType;
  component?: React.ComponentType<ModalComponentProps<T>>;
  props?: Record<string, unknown>;
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  icon?: React.ReactNode; // Auto-assigned based on type if not provided
  closable?: boolean;     // Whether user can close without action (default: true for info/success, false for confirm)
}

interface ModalComponentProps<T = unknown> {
  onClose: (result?: T) => void;
  onConfirm: (result?: T) => void;
}

interface ModalStore {
  stack: ModalConfig[];
  open: <T>(config: Omit<ModalConfig<T>, 'id'>) => Promise<T | undefined>;
  close: (id: string, result?: unknown) => void;
  closeAll: () => void;
}

// Imperative API
declare function openModal<T>(config: Omit<ModalConfig<T>, 'id'>): Promise<T | undefined>;
declare function closeAllModals(): void;

// Shorthand helpers for each type
declare function showConfirm(title: string, message: string): Promise<boolean>;
declare function showSuccess(title: string, message: string): Promise<void>;
declare function showError(title: string, message: string): Promise<void>;
declare function showWarning(title: string, message: string): Promise<boolean>;
declare function showInfo(title: string, message: string): Promise<void>;
```

**Modal Types & Behavior**:
| Type | Icon Color | Buttons | Auto-close | Use Case |
|------|-----------|---------|------------|----------|
| `confirm` | Blue/Primary | Confirm + Cancel | No | User must decide (delete, submit, etc.) |
| `success` | Green | OK | Optional | Operation completed successfully |
| `error` | Red | OK / Retry | No | Something went wrong, user must acknowledge |
| `warning` | Orange/Amber | Proceed + Cancel | No | Risky action, user needs to confirm awareness |
| `info` | Blue/Soft | OK | Optional | Informational message to the user |
| `custom` | N/A | Custom | Custom | Developer-defined modal component |

**Responsibilities**:
- Stack-based modal management (multiple modals can be open)
- Promise-based resolution for confirm/cancel flows
- Naming convention: `Modal{ComponentName}` (e.g., ModalConfirm, ModalSuccess, ModalError, ModalWarning, ModalInfo)
- Each type has a distinct icon and color scheme matching the theme
- Keyboard handling (Escape to close if closable, focus trap)
- Backdrop click handling (configurable per type)
- Accessible: aria-modal, role="dialog" or role="alertdialog", focus management
- Shorthand functions for quick usage without full config

---

### Component 5b: ModalContainer (Drawer-style Panel)

**Purpose**: A shared reusable drawer/panel container that slides in from a configurable position (default: right). Used as the default container for modal content that requires more space (forms, detail views, lists). Designed for team-wide reuse with consistent behavior across the entire app.

**Interface**:
```typescript
type DrawerPosition = 'right' | 'left' | 'top' | 'bottom';

interface ModalContainerProps {
  open: boolean;
  onClose: () => void;
  position?: DrawerPosition;          // Default: 'right'
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;          // Sticky footer action buttons
  width?: string;                     // Override min 50% rule if needed
  closeOnBackdrop?: boolean;          // Default: true
  showCloseButton?: boolean;          // Default: true
}

// Sticky action group component (reusable across all drawers)
interface ModalActionsProps {
  children: React.ReactNode;
  align?: 'left' | 'right' | 'between';  // Default: 'right'
  border?: boolean;                        // Top border separator, default: true
}
```

**Layout & Sizing Rules**:
```
┌─────────────────────────────────────────────────────────┐
│ Desktop/Tablet (≥ md: 768px):                           │
│                                                         │
│  ┌──────────────┬─────────────────────────────────────┐ │
│  │              │  ModalContainer (min-width: 50vw)    │ │
│  │   Backdrop   │  ┌───────────────────────────────┐  │ │
│  │   (overlay)  │  │ Header: title + close button  │  │ │
│  │              │  ├───────────────────────────────┤  │ │
│  │              │  │                               │  │ │
│  │              │  │ Content (scrollable body)     │  │ │
│  │              │  │                               │  │ │
│  │              │  ├───────────────────────────────┤  │ │
│  │              │  │ Actions (sticky bottom)       │  │ │
│  └──────────────┴──┴───────────────────────────────┘  │ │
│                                                         │
├─────────────────────────────────────────────────────────┤
│ Mobile (< md: 768px):                                   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │ (10vh gap at top - can see backdrop)            │    │
│  ├─────────────────────────────────────────────────┤    │
│  │ ModalContainer (width: 100vw, height: 90vh)     │    │
│  │ border-radius: 16px 16px 0 0 (rounded top)     │    │
│  │ slides UP from bottom like mobile app sheet     │    │
│  │ ┌─────────────────────────────────────────────┐ │    │
│  │ │ Drag handle bar (optional swipe-to-close)   │ │    │
│  │ │ Header: title + close button               │ │    │
│  │ ├─────────────────────────────────────────────┤ │    │
│  │ │                                             │ │    │
│  │ │ Content (scrollable, flex-grow)             │ │    │
│  │ │                                             │ │    │
│  │ ├─────────────────────────────────────────────┤ │    │
│  │ │ Actions (sticky bottom, always visible)     │ │    │
│  │ └─────────────────────────────────────────────┘ │    │
│  └─────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────┘
```

**Responsive Behavior**:
| Viewport | Width | Height | Animation |
|----------|-------|--------|-----------|
| Desktop (≥ lg) | min 50vw, configurable | 100vh | Slides from configured side (right/left/top/bottom) |
| Tablet (md - lg) | min 50vw | 100vh | Slides from configured side |
| Mobile (< md) | 100vw (full width) | 90vh | Always slides from bottom (like mobile app sheet), rounded top corners |

**Responsibilities**:
- Slides in from configured position with smooth CSS transition (300ms ease)
- Minimum width: 50% viewport (desktop/tablet), 100% viewport (mobile)
- Height: 100vh (desktop/tablet), 90vh (mobile - leaves 10% gap at top)
- Mobile: always slides from bottom regardless of `position` prop, with rounded top corners (border-radius: 16px 16px 0 0) and optional drag handle for swipe-to-close gesture
- Header section: title + optional subtitle + close button (sticky top)
- Content section: scrollable body (overflow-y: auto, flex-grow: 1)
- Actions section: sticky bottom with consistent padding, top border separator
- Backdrop overlay with configurable click-to-close
- Focus trap when open
- Body scroll lock when open
- Smooth enter/exit animations (slide + fade backdrop)
- Z-index management for stacking multiple drawers
- Accessible: aria-modal, role="dialog", aria-labelledby

**ModalActions (Sticky Footer)**:
```typescript
// Reusable action bar — always sticks to bottom of ModalContainer
// Used for: Save/Cancel, Confirm/Deny, Submit, Next/Back, etc.

export function ModalActions({ children, align = 'right', border = true }: ModalActionsProps) {
  // Renders a flex container at the bottom
  // Sticky positioning ensures it's always visible even when content scrolls
  // Consistent padding: 16px horizontal, 12px vertical
  // Optional top border for visual separation from content
}

// Convenience: pre-built action patterns
interface ActionPresets {
  SaveCancel: (onSave: () => void, onCancel: () => void) => React.ReactNode;
  ConfirmDeny: (onConfirm: () => void, onDeny: () => void) => React.ReactNode;
  SubmitOnly: (onSubmit: () => void) => React.ReactNode;
  Custom: (children: React.ReactNode) => React.ReactNode;
}
```

**Example Usage**:
```typescript
import { ModalContainer, ModalActions } from '@/shared/components/ModalContainer';

// In a module
function ModalEditUser({ open, user, onClose }: Props) {
  return (
    <ModalContainer
      open={open}
      onClose={onClose}
      position="right"
      title="Edit User"
      subtitle={user.email}
      actions={
        <ModalActions align="right">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={handleSave}>Save Changes</Button>
        </ModalActions>
      }
    >
      {/* Scrollable content */}
      <FormSection>
        <Input label="Name" value={user.name} />
        <Input label="Email" value={user.email} />
        {/* ... more form fields */}
      </FormSection>
    </ModalContainer>
  );
}
```

---

### Component 6: Lazy Loading with Skeleton

**Purpose**: All route-level components are lazy-loaded with a skeleton fallback instead of a generic spinner.

**Interface**:
```typescript
interface LazyRouteOptions {
  factory: () => Promise<{ default: React.ComponentType }>;
  skeleton: React.ComponentType;
}

declare function createLazyRoute(options: LazyRouteOptions): React.ReactNode;
```

**Responsibilities**:
- React.lazy wrapper with Suspense + skeleton fallback
- Error boundary for failed chunk loads with retry
- Preloading hints for likely next routes

---

### Component 7: API Client (Shared Service)

**Purpose**: Centralized HTTP client with interceptors, auth token handling, and integration with global loading.

**Interface**:
```typescript
interface ApiClientConfig {
  baseURL: string;
  timeout?: number;
  withLoading?: boolean;
}

interface ApiClient {
  get<T>(url: string, config?: RequestConfig): Promise<T>;
  post<T>(url: string, data?: unknown, config?: RequestConfig): Promise<T>;
  put<T>(url: string, data?: unknown, config?: RequestConfig): Promise<T>;
  patch<T>(url: string, data?: unknown, config?: RequestConfig): Promise<T>;
  delete<T>(url: string, config?: RequestConfig): Promise<T>;
}

interface RequestConfig {
  withLoading?: boolean;
  headers?: Record<string, string>;
  params?: Record<string, string | number>;
}
```

**Responsibilities**:
- Axios-based HTTP client
- Request interceptor: attach auth token
- Response interceptor: handle 401 (redirect to login), global error handling
- Optional integration with showLoading/hideLoading per request


## Data Models

### Route Configuration

```typescript
interface RouteDefinition {
  path: string;
  element: () => Promise<{ default: React.ComponentType }>;
  layout: 'enduser' | 'admin';
  skeleton: React.ComponentType;
  meta: RouteMeta;
  children?: RouteDefinition[];
}

interface RouteMeta {
  requiresAuth: boolean;
  roles?: string[];
  title: string;
  breadcrumb?: string;
}
```

**Validation Rules**:
- `path` must be a valid URL path segment
- `layout` must be one of the defined layout types
- `skeleton` must be provided for every lazy route
- `meta.title` is required for document title and i18n

### Theme Configuration

```typescript
// Light Theme - Soft, warm, approachable (inspired by nature tones)
const lightTheme: Theme = {
  colors: {
    primary: '#6366F1',         // Soft indigo
    primaryLight: '#EEF2FF',    // Very light indigo tint
    primaryDark: '#4F46E5',     // Deeper indigo for active
    secondary: '#14B8A6',       // Fresh teal/mint
    secondaryLight: '#F0FDFA',  // Very light teal tint
    secondaryDark: '#0D9488',   // Deeper teal

    background: '#FAFAF9',      // Warm off-white (not pure white)
    surface: '#FFFFFF',         // White cards
    surfaceHover: '#F5F5F4',   // Subtle warm gray hover
    overlay: 'rgba(0, 0, 0, 0.4)',

    text: '#1C1917',            // Warm near-black (not pure black)
    textSecondary: '#78716C',   // Warm gray
    textDisabled: '#A8A29E',    // Lighter warm gray
    textInverse: '#FAFAF9',     // For colored backgrounds

    border: '#E7E5E4',          // Subtle warm border
    borderHover: '#D6D3D1',    // Slightly darker on hover
    divider: '#F5F5F4',         // Very subtle divider

    error: '#EF4444',           // Friendly red
    errorLight: '#FEF2F2',     // Very light red tint
    warning: '#F59E0B',        // Warm amber
    warningLight: '#FFFBEB',   // Very light amber tint
    success: '#10B981',        // Fresh emerald green
    successLight: '#ECFDF5',   // Very light green tint
    info: '#3B82F6',           // Calm blue
    infoLight: '#EFF6FF',      // Very light blue tint
  },
};

// Dark Theme - Cozy, not harsh (navy-based, not pure black)
const darkTheme: Theme = {
  colors: {
    primary: '#818CF8',         // Lighter indigo for dark bg
    primaryLight: '#1E1B4B',    // Deep indigo tint
    primaryDark: '#6366F1',     // Standard indigo
    secondary: '#2DD4BF',      // Brighter teal for dark bg
    secondaryLight: '#042F2E', // Deep teal tint
    secondaryDark: '#14B8A6',

    background: '#0F172A',      // Deep navy (not pure black)
    surface: '#1E293B',        // Slate card background
    surfaceHover: '#334155',   // Slightly lighter slate
    overlay: 'rgba(0, 0, 0, 0.6)',

    text: '#F8FAFC',            // Soft white (not pure white)
    textSecondary: '#94A3B8',  // Slate gray
    textDisabled: '#475569',   // Darker slate
    textInverse: '#0F172A',    // For colored backgrounds

    border: '#334155',          // Slate border
    borderHover: '#475569',    // Lighter on hover
    divider: '#1E293B',        // Very subtle divider

    error: '#F87171',          // Softer red for dark
    errorLight: '#450A0A',     // Deep red tint
    warning: '#FBBF24',        // Brighter amber for dark
    warningLight: '#451A03',   // Deep amber tint
    success: '#34D399',        // Brighter green for dark
    successLight: '#022C22',   // Deep green tint
    info: '#60A5FA',           // Brighter blue for dark
    infoLight: '#172554',      // Deep blue tint
  },
};
```

**Design Philosophy**:
- Light mode: Warm stone/neutral tones as base, avoiding cold grays. Feels like natural light.
- Dark mode: Navy-based (not pure black), easier on the eyes during night coding sessions.
- Colors are soft and rounded — no harsh saturated tones. Primary indigo feels trustworthy and modern.
- Semantic colors (error, warning, success, info) have dedicated light-tint variants for backgrounds, creating a gentle visual hierarchy.

```typescript
interface ThemeTokens {
  light: Theme;
  dark: Theme;
}

interface BreakpointValues {
  xs: 0;
  sm: 576;
  md: 768;
  lg: 992;
  xl: 1200;
  xxl: 1400;
}
```

**Validation Rules**:
- Both light and dark themes must define all color tokens
- Breakpoint values must be in ascending order
- Spacing factor must be a positive number

### Module Structure

```typescript
// Each business module exports a public API via index.ts
interface ModuleExport {
  // Route fragments for this module
  routes: RouteDefinition[];
  // Optional: Zustand stores scoped to this module
  stores?: Record<string, unknown>;
}
```

**Validation Rules**:
- Module must export at least `routes`
- Module internals (components, hooks, services) are private unless exported
- Cross-module imports only via the module's `index.ts`

### Agent Rule File Structure

```typescript
interface AgentRule {
  name: string;
  description: string;
  trigger: AgentTrigger;
  steps: AgentStep[];
  notifications?: TelegramNotification;
}

interface AgentTrigger {
  type: 'file-change' | 'command' | 'schedule';
  pattern?: string;
  command?: string;
  cron?: string;
}

interface AgentStep {
  action: string;
  params: Record<string, unknown>;
  condition?: string;
}

interface TelegramNotification {
  enabled: boolean;
  chatId: string;
  events: ('start' | 'complete' | 'error' | 'confirm')[];
  confirmTimeout?: number; // seconds to wait for user confirmation
}
```

## Key Functions with Formal Specifications

### Function 1: createThemeContext()

```typescript
function createThemeContext(): {
  ThemeContextProvider: React.FC<{ children: React.ReactNode }>;
  useTheme: () => ThemeContextValue;
}
```

**Preconditions:**
- `window.matchMedia` is available (browser environment)
- `localStorage` is accessible

**Postconditions:**
- Returns a provider component and a hook
- Provider initializes theme from localStorage or system preference
- `useTheme()` throws if called outside provider
- Theme changes are persisted to localStorage synchronously

**Loop Invariants:** N/A

---

### Function 2: createLoadingStore()

```typescript
function createLoadingStore(): LoadingStore
```

**Preconditions:**
- Zustand is available

**Postconditions:**
- `isVisible` starts as false
- `setLoading(true)` sets isVisible to true
- `setLoading(false)` sets isVisible to false
- Idempotent: calling setLoading with same value multiple times has no side effects

**Loop Invariants:** N/A

---

### Function 3: createModalStore()

```typescript
function createModalStore(): ModalStore
```

**Preconditions:**
- Zustand is available

**Postconditions:**
- `stack` starts as empty array
- `open()` returns a Promise that resolves when modal is closed
- `close(id, result)` removes modal from stack and resolves its Promise with result
- `closeAll()` resolves all pending Promises with undefined
- Each modal receives a unique ID (UUID)

**Loop Invariants:**
- Stack length equals number of currently open modals
- Each modal in stack has a unique `id`

---

### Function 4: createApiClient(config)

```typescript
function createApiClient(config: ApiClientConfig): ApiClient
```

**Preconditions:**
- `config.baseURL` is a valid URL string
- `config.timeout` (if provided) is a positive number

**Postconditions:**
- Returns an ApiClient instance with all HTTP method helpers
- Requests include auth token from token storage (if available)
- 401 responses trigger auth refresh or redirect flow
- If `withLoading` is true, showLoading/hideLoading wraps the request lifecycle
- Network errors are transformed into a consistent error format

**Loop Invariants:** N/A

---

### Function 5: createLazyRoute(options)

```typescript
function createLazyRoute(options: LazyRouteOptions): React.ReactNode
```

**Preconditions:**
- `options.factory` is a function returning a dynamic import Promise
- `options.skeleton` is a valid React component

**Postconditions:**
- Returns a Suspense-wrapped lazy component
- While loading: skeleton component is displayed
- On load failure: error boundary catches and offers retry
- On success: actual component renders

**Loop Invariants:** N/A

## Algorithmic Pseudocode

### Theme Resolution Algorithm

```typescript
// Algorithm: Resolve the effective theme based on user preference and system setting
function resolveTheme(mode: ThemeMode): 'light' | 'dark' {
  // PRECONDITION: mode ∈ {'light', 'dark', 'system'}
  
  if (mode === 'light') return 'light';
  if (mode === 'dark') return 'dark';
  
  // mode === 'system': detect from OS preference
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  return prefersDark ? 'dark' : 'light';
  
  // POSTCONDITION: return value ∈ {'light', 'dark'}
}

// Algorithm: Initialize theme on app start
function initializeTheme(): { mode: ThemeMode; resolved: 'light' | 'dark' } {
  // Step 1: Read persisted preference
  const stored = localStorage.getItem('theme-mode') as ThemeMode | null;
  const mode: ThemeMode = stored ?? 'system';
  
  // Step 2: Resolve actual theme
  const resolved = resolveTheme(mode);
  
  // Step 3: Listen for system changes (if mode === 'system')
  // mediaQuery.addEventListener('change', callback)
  
  return { mode, resolved };
  // POSTCONDITION: mode is valid, resolved is 'light' or 'dark'
}
```

### Loading Service Algorithm

```typescript
// Algorithm: Simple boolean-based loading state
// Single function: setLoading(true) to show, setLoading(false) to hide

function setLoading(store: LoadingStore, visible: boolean): void {
  // PRECONDITION: visible is boolean
  store.isVisible = visible;
  // POSTCONDITION: store.isVisible === visible
}
```

### Modal Stack Management Algorithm

```typescript
// Algorithm: Stack-based modal management with Promise resolution

type ModalEntry = ModalConfig & {
  resolve: (result?: unknown) => void;
};

function openModal<T>(
  store: { stack: ModalEntry[] },
  config: Omit<ModalConfig<T>, 'id'>
): Promise<T | undefined> {
  // PRECONDITION: config.type is valid
  const id = crypto.randomUUID();
  
  return new Promise<T | undefined>((resolve) => {
    const entry: ModalEntry = { ...config, id, resolve };
    store.stack = [...store.stack, entry];
    // POSTCONDITION: stack.length increased by 1, last item has our id
  });
}

function closeModal(
  store: { stack: ModalEntry[] },
  id: string,
  result?: unknown
): void {
  // PRECONDITION: id exists in stack (or no-op if not found)
  const entry = store.stack.find((m) => m.id === id);
  if (entry) {
    entry.resolve(result);
    store.stack = store.stack.filter((m) => m.id !== id);
  }
  // POSTCONDITION: modal with `id` removed, its Promise resolved
}

function closeAllModals(store: { stack: ModalEntry[] }): void {
  // Resolve all pending with undefined
  store.stack.forEach((entry) => entry.resolve(undefined));
  store.stack = [];
  // POSTCONDITION: stack is empty, all Promises resolved
}
```

### Route Lazy Loading with Retry Algorithm

```typescript
// Algorithm: Lazy load a route component with retry on chunk failure

const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;

async function loadWithRetry(
  factory: () => Promise<{ default: React.ComponentType }>,
  retries: number = MAX_RETRIES
): Promise<{ default: React.ComponentType }> {
  // PRECONDITION: retries >= 0
  for (let attempt = 0; attempt <= retries; attempt++) {
    // LOOP INVARIANT: attempt ∈ [0, retries], previous attempts failed
    try {
      return await factory();
      // POSTCONDITION: module loaded successfully
    } catch (error) {
      if (attempt === retries) throw error;
      await new Promise((r) => setTimeout(r, RETRY_DELAY_MS * (attempt + 1)));
    }
  }
  throw new Error('Failed to load module');
}

function createLazyRoute({ factory, skeleton: Skeleton }: LazyRouteOptions): React.ReactNode {
  const LazyComponent = React.lazy(() => loadWithRetry(factory));
  
  return (
    <ErrorBoundary fallback={<ChunkErrorFallback onRetry={() => window.location.reload()} />}>
      <React.Suspense fallback={<Skeleton />}>
        <LazyComponent />
      </React.Suspense>
    </ErrorBoundary>
  );
}
```

### Responsive Breakpoint Helper Algorithm

```typescript
// Algorithm: Mobile-first media query helper for styled-components

const BREAKPOINTS: Record<string, number> = {
  xs: 0,
  sm: 576,
  md: 768,
  lg: 992,
  xl: 1200,
  xxl: 1400,
};

// Usage in styled-components: ${media.up('md')} { ... }
const media = {
  up: (breakpoint: keyof typeof BREAKPOINTS): string => {
    // PRECONDITION: breakpoint is a valid key
    const value = BREAKPOINTS[breakpoint];
    return `@media (min-width: ${value}px)`;
    // POSTCONDITION: returns valid CSS media query string
  },
  down: (breakpoint: keyof typeof BREAKPOINTS): string => {
    const value = BREAKPOINTS[breakpoint] - 0.02;
    return `@media (max-width: ${value}px)`;
  },
  between: (min: keyof typeof BREAKPOINTS, max: keyof typeof BREAKPOINTS): string => {
    // PRECONDITION: BREAKPOINTS[min] < BREAKPOINTS[max]
    return `@media (min-width: ${BREAKPOINTS[min]}px) and (max-width: ${BREAKPOINTS[max] - 0.02}px)`;
  },
};
```


## Example Usage

### Setting up the App Entry Point

```typescript
// main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { AppProviders } from './app/providers';
import App from './app/App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AppProviders>
      <App />
    </AppProviders>
  </React.StrictMode>
);
```

### Configuring Providers

```typescript
// app/providers.tsx
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeContextProvider } from '@/shared/hooks/useThemeContext';
import { RouterProvider } from 'react-router-dom';
import { router } from './routes';
import { I18nextProvider } from 'react-i18next';
import i18n from '@/shared/i18n';
import { ModalManager } from '@/shared/components/ModalManager';
import { LoadingOverlay } from '@/shared/components/LoadingOverlay';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 5 * 60 * 1000, retry: 1 },
  },
});

export function AppProviders({ children }: { children: React.ReactNode }) {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <ThemeContextProvider>
          <RouterProvider router={router} />
          <ModalManager />
          <LoadingOverlay />
        </ThemeContextProvider>
      </I18nextProvider>
    </QueryClientProvider>
  );
}
```

### Defining Routes with Lazy Loading

```typescript
// app/routes.tsx
import { createBrowserRouter } from 'react-router-dom';
import { createLazyRoute } from '@/shared/utils/createLazyRoute';
import { EndUserLayout } from '@/shared/components/layouts/EndUserLayout';
import { AdminLayout } from '@/shared/components/layouts/AdminLayout';
import { HomeSkeleton } from '@/shared/components/skeletons/HomeSkeleton';
import { DashboardSkeleton } from '@/shared/components/skeletons/DashboardSkeleton';

export const router = createBrowserRouter([
  {
    element: <EndUserLayout />,
    children: [
      {
        path: '/',
        element: createLazyRoute({
          factory: () => import('@/modules/home/pages/HomePage'),
          skeleton: HomeSkeleton,
        }),
      },
    ],
  },
  {
    element: <AdminLayout />,
    children: [
      {
        path: '/admin/dashboard',
        element: createLazyRoute({
          factory: () => import('@/modules/admin/pages/DashboardPage'),
          skeleton: DashboardSkeleton,
        }),
      },
    ],
  },
]);
```

### Using Global Loading (Imperative)

```typescript
// From any component or service
import { setLoading } from '@/shared/services/loadingService';

async function handleSubmit(data: FormData) {
  setLoading(true);
  try {
    await apiClient.post('/submit', data);
  } finally {
    setLoading(false);
  }
}

// From an API interceptor (non-React context)
apiClient.interceptors.request.use((config) => {
  if (config.withLoading !== false) setLoading(true);
  return config;
});
apiClient.interceptors.response.use(
  (response) => { setLoading(false); return response; },
  (error) => { setLoading(false); return Promise.reject(error); }
);
```

### Using the Modal System

```typescript
import { openModal, showConfirm, showSuccess, showError, showWarning, showInfo } from '@/shared/services/modalService';

// Confirmation dialog (returns boolean)
async function handleDelete(item: Item) {
  const confirmed = await showConfirm(
    'Delete Item',
    `Are you sure you want to delete "${item.name}"?`
  );
  if (confirmed) {
    await apiClient.delete(`/items/${item.id}`);
    await showSuccess('Deleted', 'Item has been deleted successfully.');
  }
}

// Error notification
async function handleApiError(error: AppError) {
  await showError('Operation Failed', error.message);
}

// Warning before risky action
async function handleBulkAction() {
  const proceed = await showWarning(
    'Bulk Update',
    'This will update 1,500 records. This action cannot be undone.'
  );
  if (proceed) { /* proceed with bulk action */ }
}

// Informational message
await showInfo('Maintenance', 'System will be down for maintenance at 2:00 AM.');

// Full config for custom modal
await openModal({
  type: 'custom',
  component: ModalCustomForm,
  props: { initialData: someData },
});
```

### Theme Usage in Styled Components

```typescript
import styled from 'styled-components';
import { media } from '@/styles/media';

const Card = styled.div`
  background: ${({ theme }) => theme.colors.surface};
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.md};
  padding: ${({ theme }) => theme.spacing(2)};

  /* Mobile-first: base styles are for mobile */
  display: flex;
  flex-direction: column;

  /* Tablet and up */
  ${media.up('md')} {
    flex-direction: row;
    padding: ${({ theme }) => theme.spacing(4)};
  }
`;
```

### Business Module Structure

```typescript
// modules/example/index.ts (Public API)
export { exampleRoutes } from './routes';
export { useExampleStore } from './stores/exampleStore';

// modules/example/stores/exampleStore.ts
import { create } from 'zustand';

interface ExampleState {
  items: Item[];
  addItem: (item: Item) => void;
  removeItem: (id: string) => void;
}

export const useExampleStore = create<ExampleState>((set) => ({
  items: [],
  addItem: (item) => set((state) => ({ items: [...state.items, item] })),
  removeItem: (id) => set((state) => ({ items: state.items.filter((i) => i.id !== id) })),
}));

// modules/example/hooks/useExampleQuery.ts
import { useQuery } from '@tanstack/react-query';
import { exampleService } from '../services/exampleService';

export function useExampleQuery(id: string) {
  return useQuery({
    queryKey: ['example', id],
    queryFn: () => exampleService.getById(id),
  });
}
```

### Example Pages (Built-in Demo)

The boilerplate includes pre-built example pages at `/examples/*` to help team members quickly understand patterns and conventions. These pages serve as living documentation for AI-assisted development.

```typescript
// modules/examples/pages/ExampleShowcasePage.tsx
// Route: /examples/showcase
// Layout: EndUser
// Purpose: Demonstrates all shared components & patterns in one place

export default function ExampleShowcasePage() {
  return (
    <PageContainer>
      <SectionTitle>Component Showcase</SectionTitle>

      {/* 1. Modal Types Demo */}
      <Section title="Modal System">
        <Button onClick={() => showConfirm('Confirm', 'Are you sure?')}>
          Open Confirm Modal
        </Button>
        <Button onClick={() => showSuccess('Done', 'Operation successful')}>
          Open Success Modal
        </Button>
        <Button onClick={() => showError('Error', 'Something went wrong')}>
          Open Error Modal
        </Button>
        <Button onClick={() => showWarning('Warning', 'This is risky')}>
          Open Warning Modal
        </Button>
        <Button onClick={() => showInfo('Info', 'FYI notification')}>
          Open Info Modal
        </Button>
      </Section>

      {/* 2. ModalContainer (Drawer) Demo */}
      <Section title="Drawer Panel">
        <Button onClick={() => setDrawerOpen(true)}>
          Open Drawer (Right)
        </Button>
        <ModalContainer
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          position="right"
          title="Example Drawer"
          subtitle="This is a drawer panel demo"
          actions={
            <ModalActions>
              <Button variant="ghost" onClick={() => setDrawerOpen(false)}>Cancel</Button>
              <Button variant="primary">Save</Button>
            </ModalActions>
          }
        >
          <ExampleFormContent />
        </ModalContainer>
      </Section>

      {/* 3. Loading Demo */}
      <Section title="Global Loading">
        <Button onClick={async () => {
          setLoading(true);
          await delay(2000);
          setLoading(false);
        }}>
          Trigger 2s Loading
        </Button>
      </Section>

      {/* 4. Theme Demo */}
      <Section title="Theme Colors">
        <ColorPaletteGrid /> {/* Shows all theme colors */}
        <ThemeToggleDemo />  {/* Light/Dark/System toggle */}
      </Section>

      {/* 5. Responsive Demo */}
      <Section title="Responsive Breakpoints">
        <ResponsiveIndicator /> {/* Shows current breakpoint */}
        <ResponsiveGridDemo />  {/* Grid that changes at breakpoints */}
      </Section>

      {/* 6. Form Demo */}
      <Section title="Form (React Hook Form + Zod)">
        <ExampleForm />
      </Section>

      {/* 7. Data Fetching Demo */}
      <Section title="TanStack Query">
        <ExampleQueryDemo />
      </Section>

      {/* 8. i18n Demo */}
      <Section title="Internationalization">
        <LanguageSwitcher />
        <TranslatedContent />
      </Section>
    </PageContainer>
  );
}
```

```typescript
// modules/examples/pages/ExampleCRUDPage.tsx
// Route: /examples/crud
// Layout: Admin
// Purpose: Demonstrates a full CRUD flow using ModalContainer as drawer

export default function ExampleCRUDPage() {
  // Demonstrates:
  // - Data table with TanStack Query
  // - Create/Edit via ModalContainer (drawer right)
  // - Delete with showConfirm
  // - Loading states with setLoading
  // - Form validation with React Hook Form + Zod
  // - Toast success/error feedback
}
```

**Example page structure**:
```
src/modules/examples/
├── pages/
│   ├── ExampleShowcasePage.tsx    # All components demo
│   └── ExampleCRUDPage.tsx        # Full CRUD flow demo
├── components/
│   ├── ColorPaletteGrid.tsx       # Theme colors visual
│   ├── ResponsiveIndicator.tsx    # Current breakpoint display
│   ├── ExampleForm.tsx            # Form demo with validation
│   └── ExampleFormContent.tsx     # Form inside drawer
├── routes.ts
└── index.ts
```

### Agent Rule File Example

```yaml
# .kiro/rules/feature-workflow.yaml
name: feature-development
description: Workflow for developing a new feature with Telegram notifications

trigger:
  type: command
  command: "kiro:start-feature"

steps:
  - action: create-branch
    params:
      prefix: "feature/"
      
  - action: scaffold-module
    params:
      template: "module-boilerplate"
      
  - action: notify-telegram
    params:
      event: start
      message: "🚀 Feature development started: {{feature_name}}"
      
  - action: implement-feature
    params:
      spec: "{{spec_path}}"
      
  - action: notify-telegram
    params:
      event: confirm
      message: "✅ Implementation complete. Approve to proceed with tests?"
      waitForConfirmation: true
      timeout: 300

  - action: run-tests
    params:
      scope: module

  - action: notify-telegram
    params:
      event: complete
      message: "🎉 Feature {{feature_name}} completed. All tests passing."

notifications:
  telegram:
    enabled: true
    chatId: "${TELEGRAM_CHAT_ID}"
    events: [start, complete, error, confirm]
    confirmTimeout: 300
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Theme resolution always produces a valid concrete theme

*For any* ThemeMode value ('light', 'dark', or 'system'), calling `resolveTheme(mode)` SHALL always return either 'light' or 'dark' — never undefined, null, or any other value.

**Validates: Requirements 2.1, 2.6**

### Property 2: Theme persistence round-trip

*For any* valid ThemeMode value, setting the mode via `setMode(mode)` and then reading from localStorage SHALL return the same mode value. On subsequent application initialization, reading localStorage SHALL restore that same mode.

**Validates: Requirements 2.4, 2.5**

### Property 3: Loading state correctness

*For any* boolean value `v`, after calling `setLoading(v)`, the LoadingStore's `isVisible` property SHALL equal `v`.

**Validates: Requirements 4.2, 4.3**

### Property 4: Loading idempotence

*For any* boolean value `v` and any number of consecutive calls `n >= 1`, calling `setLoading(v)` n times SHALL produce the same observable state as calling it exactly once.

**Validates: Requirement 4.4**

### Property 5: Modal stack ID uniqueness invariant

*For any* sequence of `openModal` calls, all modal IDs in the stack SHALL be unique. No two modals in the stack SHALL ever share the same ID regardless of how many modals are opened.

**Validates: Requirements 5.2, 5.5**

### Property 6: Modal close resolves promise with result

*For any* modal opened via `openModal`, when `close(id, result)` is called with that modal's ID and an arbitrary result value, the Promise returned by `openModal` SHALL resolve with that exact result value, and the modal SHALL be removed from the stack.

**Validates: Requirement 5.3**

### Property 7: Modal closeAll resolves all promises with undefined

*For any* number of open modals in the stack, calling `closeAll()` SHALL empty the stack and resolve every pending modal Promise with `undefined`.

**Validates: Requirement 5.4**

### Property 8: ModalContainer responsive sizing

*For any* viewport width at or above the md breakpoint (768px), the ModalContainer SHALL have a minimum width of 50vw. *For any* viewport width below 768px, the ModalContainer SHALL render at 100vw width and 90vh height.

**Validates: Requirements 6.2, 6.3**

### Property 9: Chunk load retry count

*For any* chunk factory function that always rejects, the `loadWithRetry` function SHALL call the factory exactly 4 times (1 initial + 3 retries) before throwing an error.

**Validates: Requirement 8.3**

### Property 10: API auth token attachment

*For any* outgoing HTTP request made via the ApiClient when an auth token is available in token storage, the request interceptor SHALL attach that token in the Authorization header.

**Validates: Requirement 9.2**

### Property 11: API loading state bracketing

*For any* request made with `withLoading: true`, the ApiClient SHALL call `setLoading(true)` before the request starts and `setLoading(false)` after the request completes (whether successfully or with failure).

**Validates: Requirement 9.4**

### Property 12: API error normalization

*For any* network error or non-2xx response from the ApiClient, the resulting error SHALL conform to the AppError interface shape, regardless of the original error format.

**Validates: Requirement 9.5**

### Property 13: Route layout validity

*For any* RouteDefinition in the route configuration, the `layout` property SHALL be either 'enduser' or 'admin' — no other values are permitted.

**Validates: Requirement 10.5**

### Property 14: Media helper query generation

*For any* valid breakpoint key, `media.up(key)` SHALL produce a syntactically valid CSS media query string in the format `@media (min-width: Xpx)` where X matches the breakpoint value for that key.

**Validates: Requirements 11.2, 11.4**

### Property 15: Breakpoint ordering invariant

*For any* two breakpoint keys where one has a lower ordinal position than the other, the pixel value of the lower-ordinal breakpoint SHALL be strictly less than the pixel value of the higher-ordinal breakpoint.

**Validates: Requirement 11.3**

### Property 16: Zod schema validation before submission

*For any* form input that does not satisfy the associated Zod schema, the form handler SHALL reject submission and prevent the data from reaching the API layer.

**Validates: Requirements 14.3, 20.3**

### Property 17: i18n fallback to default language

*For any* translation key that exists in the default language (English) but is missing in the currently active language, the i18n system SHALL return the English translation rather than the raw key.

**Validates: Requirement 15.2**

### Property 18: Agent rule structure validation

*For any* agent rule YAML file under `.kiro/rules/`, the file SHALL contain valid `trigger` (with type field), `steps` (array of actions), and optionally `notifications` with Telegram configuration.

**Validates: Requirement 19.2**

## Error Handling

### Error Scenario 1: Chunk Load Failure

**Condition**: Network error or cache invalidation causes a lazy-loaded route chunk to fail loading.
**Response**: Error boundary catches the error, displays a user-friendly message with a retry button.
**Recovery**: User clicks retry → page reloads OR loadWithRetry attempts up to 3 automatic retries with exponential backoff.

### Error Scenario 2: API 401 Unauthorized

**Condition**: API response returns 401 status code.
**Response**: Response interceptor catches it, attempts token refresh if refresh token exists.
**Recovery**: If refresh succeeds → retry original request. If refresh fails → clear auth state, redirect to login, show notification.

### Error Scenario 3: Theme localStorage Unavailable

**Condition**: localStorage is blocked (private browsing) or throws quota exceeded.
**Response**: Catch error silently, fall back to 'system' mode in memory only.
**Recovery**: Theme works correctly in-session but won't persist across reloads.

### Error Scenario 4: i18n Translation Missing

**Condition**: A translation key is not found for the current language.
**Response**: react-i18next falls back to the default language (en). If key missing in default too, displays the key itself.
**Recovery**: Log missing key in development mode for developer awareness.

### Error Scenario 5: Modal Promise Never Resolved

**Condition**: Component unmounts while modal is open (route change).
**Response**: ModalManager detects route change and calls `closeAll()`.
**Recovery**: All pending modal Promises resolve with `undefined`, preventing memory leaks.

## Testing Strategy

### Unit Testing Approach

- **Framework**: Vitest + React Testing Library
- **Coverage target**: 80% for shared utilities, hooks, and stores
- **Key test cases**:
  - Theme context: mode switching, system preference detection, localStorage persistence
  - Loading store: setLoading(true/false) toggles visibility correctly, idempotent behavior
  - Modal store: open/close flow, Promise resolution, stack management
  - Media helpers: correct media query string generation
  - API client: interceptor behavior, error transformation

### Property-Based Testing Approach

- **Library**: fast-check (via Vitest)
- **Properties to test**:
  - Loading state is always boolean (setLoading idempotence)
  - Theme resolution always returns 'light' or 'dark' for any valid input
  - Modal stack IDs are always unique after any sequence of open/close operations
  - Breakpoint media queries are syntactically valid for any breakpoint key

### Integration Testing Approach

- **Framework**: Vitest + React Testing Library for component integration
- **Key scenarios**:
  - Full provider tree renders without error
  - Route navigation triggers correct layout
  - Theme toggle persists and applies
  - Modal open → confirm → resolve flow end-to-end

### E2E Testing Approach

- **Framework**: Playwright
- **Key scenarios**:
  - Full app load with lazy routes (verify skeleton → content)
  - Theme switching visual regression
  - Responsive layout changes at breakpoints
  - Modal interaction flows

## Performance Considerations

- **Code splitting**: All routes lazy-loaded to minimize initial bundle size
- **Chunk preloading**: Preload likely-next-route chunks on hover/focus of navigation links
- **React Query caching**: 5-minute stale time to reduce redundant network requests
- **Theme**: CSS custom properties for instant theme switches without re-renders of all styled components (optional optimization)
- **Bundle analysis**: Vite's built-in rollup-plugin-visualizer for monitoring bundle size
- **Font loading**: `font-display: swap` to prevent FOIT

## Security Considerations

- **Auth tokens**: Stored in memory (not localStorage) for XSS mitigation; refresh token in httpOnly cookie
- **API client**: CSRF token handling if needed; no sensitive data in URL params
- **CSP**: Vite config for Content-Security-Policy headers in production
- **Dependencies**: Regular audit via `npm audit`; lock file committed
- **Input sanitization**: All user input validated via Zod schemas before submission
- **Route guards**: Auth-required routes redirect to login if no valid session

## Dependencies

| Package | Purpose | Version Strategy |
|---------|---------|-----------------|
| react | UI library | ^18.x |
| react-dom | DOM rendering | ^18.x |
| react-router-dom | Routing (v7) | ^7.x |
| zustand | State management | ^4.x |
| @tanstack/react-query | Data fetching/caching | ^5.x |
| styled-components | CSS-in-JS styling | ^6.x |
| react-hook-form | Form handling | ^7.x |
| zod | Schema validation | ^3.x |
| react-i18next | Internationalization | ^14.x |
| i18next | i18n core | ^23.x |
| axios | HTTP client | ^1.x |
| vite | Build tool | ^5.x |
| typescript | Type checking | ^5.x |
| vitest | Unit testing | ^1.x |
| @testing-library/react | Component testing | ^14.x |
| playwright | E2E testing | ^1.x |
| fast-check | Property-based testing | ^3.x |
| eslint | Linting | ^8.x |
| prettier | Code formatting | ^3.x |
