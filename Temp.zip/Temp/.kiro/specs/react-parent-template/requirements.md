# Requirements Document

## Introduction

This document defines the requirements for the React Parent Template — a production-ready Vite + React + TypeScript boilerplate designed for team-wide use with AI-assisted coding. The template provides a hybrid architecture (modules + shared), dual layouts, global services (loading, modals), theming, internationalization, data fetching, state management, form validation, and comprehensive testing infrastructure.

## Glossary

- **Template**: The React boilerplate project scaffold
- **AppProviders**: The root component that wraps the application with all context providers
- **ThemeContext**: React Context managing light/dark/system theme preference and providing the resolved theme
- **ThemeMode**: One of 'light', 'dark', or 'system'
- **ResolvedTheme**: The concrete theme applied ('light' or 'dark')
- **LoadingOverlay**: Full-screen overlay component controlled by the loading service
- **LoadingService**: Imperative API exposing `setLoading(boolean)` callable from anywhere
- **ModalManager**: Component that renders the modal stack managed by the modal store
- **ModalStore**: Zustand store holding the modal stack and providing open/close operations
- **ModalContainer**: Drawer-style panel component that slides in from a configured position
- **ModalActions**: Sticky bottom action bar used inside ModalContainer
- **EndUserLayout**: Layout for public-facing routes (header, content, footer)
- **AdminLayout**: Layout for admin routes (sidebar, header, content)
- **LazyRoute**: A route whose component is loaded via React.lazy with a skeleton fallback
- **Skeleton**: A placeholder UI component shown while a lazy route loads
- **ApiClient**: Centralized HTTP client service with interceptors
- **Module**: A self-contained business feature directory under `src/modules/`
- **Shared**: Cross-cutting utilities, components, hooks, and services under `src/shared/`
- **Breakpoint**: A viewport width threshold following Bootstrap conventions (xs, sm, md, lg, xl, xxl)
- **AgentRule**: A workflow automation file defining triggers, steps, and Telegram notifications

## Requirements

### Requirement 1: Application Provider Stack

**User Story:** As a developer, I want a single provider wrapper that initializes all required contexts in the correct order, so that I can bootstrap the app without worrying about provider nesting.

#### Acceptance Criteria

1. THE AppProviders SHALL wrap children with QueryClientProvider, ThemeContextProvider, I18nextProvider, and RouterProvider in the specified nesting order
2. WHEN the application mounts, THE AppProviders SHALL initialize QueryClient with a 5-minute stale time and 1 retry default
3. WHEN the application mounts, THE AppProviders SHALL render ModalManager and LoadingOverlay as siblings outside the router tree
4. IF any provider fails to initialize, THEN THE AppProviders SHALL log the error and render an error boundary fallback

### Requirement 2: Theme System

**User Story:** As a user, I want to switch between light, dark, and system-following themes, so that I can use the application comfortably in any environment.

#### Acceptance Criteria

1. THE ThemeContext SHALL support three modes: 'light', 'dark', and 'system'
2. WHEN mode is 'system', THE ThemeContext SHALL resolve the theme based on the operating system preference via `window.matchMedia('(prefers-color-scheme: dark)')`
3. WHEN the operating system preference changes at runtime, THE ThemeContext SHALL update the resolved theme in real-time without requiring a page reload
4. WHEN a user sets a theme mode, THE ThemeContext SHALL persist the choice to localStorage under the key 'theme-mode'
5. WHEN the application initializes, THE ThemeContext SHALL read the persisted mode from localStorage and apply it; if no value is stored, THE ThemeContext SHALL default to 'system'
6. THE ThemeContext SHALL provide a `resolvedTheme` value that is always either 'light' or 'dark'
7. THE ThemeContext SHALL supply the resolved theme object to styled-components ThemeProvider
8. IF localStorage is unavailable or throws an error, THEN THE ThemeContext SHALL fall back to 'system' mode in memory without crashing
9. THE Theme object SHALL define a warm/soft color palette with primary (soft indigo), secondary (fresh teal), semantic colors (error, warning, success, info), background, surface, text, and border tokens for both light and dark variants
10. THE Theme object SHALL include breakpoints matching Bootstrap values (xs:0, sm:576, md:768, lg:992, xl:1200, xxl:1400), spacing function, typography, shadows, borderRadius, and transitions

### Requirement 3: Layout System

**User Story:** As a developer, I want dual layout options so that public pages and admin pages have distinct navigation structures appropriate to their use case.

#### Acceptance Criteria

1. THE Template SHALL provide an EndUserLayout with header, main content area, and footer
2. THE Template SHALL provide an AdminLayout with sidebar navigation, header, and main content area
3. WHEN a route is configured with `layout: 'enduser'`, THE Router SHALL render the EndUserLayout for that route
4. WHEN a route is configured with `layout: 'admin'`, THE Router SHALL render the AdminLayout for that route
5. WHILE the viewport is below the md breakpoint (768px), THE AdminLayout SHALL collapse the sidebar into a toggleable mobile menu
6. THE EndUserLayout and AdminLayout SHALL be responsive following mobile-first design principles

### Requirement 4: Loading Service

**User Story:** As a developer, I want a single imperative function to show/hide a global loading overlay, so that I can indicate loading state from any context including non-React code.

#### Acceptance Criteria

1. THE LoadingService SHALL expose a `setLoading(visible: boolean)` function callable from any JavaScript context (components, services, interceptors)
2. WHEN `setLoading(true)` is called, THE LoadingOverlay SHALL display a full-screen overlay with a spinner animation
3. WHEN `setLoading(false)` is called, THE LoadingOverlay SHALL hide the overlay
4. THE LoadingService SHALL be idempotent: calling `setLoading(true)` multiple consecutive times SHALL have the same effect as calling it once
5. WHILE the LoadingOverlay is visible, THE LoadingOverlay SHALL set `aria-busy="true"` on the application root element
6. THE LoadingStore SHALL initialize with `isVisible` set to false

### Requirement 5: Modal System

**User Story:** As a developer, I want a global promise-based modal system with predefined types, so that I can show confirmations, alerts, and custom dialogs from anywhere without managing modal state manually.

#### Acceptance Criteria

1. THE ModalStore SHALL support modal types: 'confirm', 'success', 'error', 'warning', 'info', and 'custom'
2. WHEN `openModal(config)` is called, THE ModalStore SHALL push a new modal with a unique UUID onto the stack and return a Promise
3. WHEN a modal is closed via `close(id, result)`, THE ModalStore SHALL remove that modal from the stack and resolve its Promise with the provided result
4. WHEN `closeAll()` is called, THE ModalStore SHALL remove all modals from the stack and resolve all pending Promises with undefined
5. THE ModalStore SHALL maintain unique IDs across all modals in the stack at all times
6. THE ModalManager SHALL render each modal in the stack with the correct component based on its type
7. THE Modal system SHALL provide shorthand functions: `showConfirm(title, message)` returning `Promise<boolean>`, `showSuccess(title, message)`, `showError(title, message)`, `showWarning(title, message)`, and `showInfo(title, message)`
8. WHEN a 'confirm' or 'warning' modal is displayed, THE Modal SHALL render both Confirm and Cancel action buttons
9. WHEN a 'success', 'error', or 'info' modal is displayed, THE Modal SHALL render an OK button
10. THE Modal components SHALL follow the naming convention `Modal{ComponentName}` (ModalConfirm, ModalSuccess, ModalError, ModalWarning, ModalInfo)
11. THE Modal system SHALL support keyboard interaction: Escape key closes the modal if it is marked as closable, and focus SHALL be trapped within the open modal
12. THE Modal system SHALL apply accessible attributes: `aria-modal="true"`, `role="dialog"` or `role="alertdialog"`, and manage focus on open/close
13. IF a route change occurs while modals are open, THEN THE ModalManager SHALL call `closeAll()` to prevent orphaned Promises

### Requirement 6: ModalContainer (Drawer Panel)

**User Story:** As a developer, I want a reusable drawer-style panel component, so that I can present forms, detail views, and lists in a consistent side/bottom sheet across the entire application.

#### Acceptance Criteria

1. THE ModalContainer SHALL slide in from the configured position (default: right) with a 300ms ease CSS transition
2. WHILE the viewport width is at or above the md breakpoint (768px), THE ModalContainer SHALL have a minimum width of 50vw and full viewport height (100vh)
3. WHILE the viewport width is below the md breakpoint (768px), THE ModalContainer SHALL render as a bottom sheet with 100vw width and 90vh height, sliding up from the bottom regardless of the configured position prop
4. WHILE the viewport is below md, THE ModalContainer SHALL display rounded top corners (border-radius: 16px 16px 0 0) and an optional drag handle
5. WHEN the ModalContainer is open, THE ModalContainer SHALL lock body scroll and trap focus within the panel
6. WHEN the backdrop is clicked and `closeOnBackdrop` is true, THE ModalContainer SHALL call `onClose`
7. THE ModalContainer SHALL render a sticky header with title, optional subtitle, and close button
8. THE ModalContainer SHALL render a scrollable content area (overflow-y: auto) that fills available space between header and actions
9. THE ModalContainer SHALL apply accessible attributes: `aria-modal="true"`, `role="dialog"`, and `aria-labelledby` referencing the title

### Requirement 7: ModalActions (Sticky Footer)

**User Story:** As a developer, I want a reusable sticky action bar for drawer panels, so that action buttons are always visible regardless of content scroll position.

#### Acceptance Criteria

1. THE ModalActions SHALL render as a sticky-positioned container at the bottom of ModalContainer
2. THE ModalActions SHALL remain visible regardless of content scroll position
3. THE ModalActions SHALL apply consistent padding (16px horizontal, 12px vertical) and an optional top border separator
4. THE ModalActions SHALL support alignment options: 'left', 'right' (default), or 'between'

### Requirement 8: Lazy Loading with Skeleton Fallback

**User Story:** As a developer, I want all route components to be lazy-loaded with skeleton placeholders, so that initial bundle size is minimized and users see immediate visual feedback during loading.

#### Acceptance Criteria

1. THE `createLazyRoute` utility SHALL wrap the component factory with `React.lazy` and `React.Suspense`
2. WHILE a lazy route is loading, THE Suspense boundary SHALL render the specified skeleton component
3. IF a chunk fails to load, THEN THE system SHALL retry up to 3 times with exponential backoff (1s, 2s, 3s delays)
4. IF all retry attempts fail, THEN THE Error Boundary SHALL display a user-friendly message with a retry button
5. EVERY route definition SHALL include a skeleton component; routes without a skeleton SHALL be rejected at type level

### Requirement 9: API Client

**User Story:** As a developer, I want a centralized HTTP client with interceptors, so that authentication, error handling, and loading state are managed consistently across all API calls.

#### Acceptance Criteria

1. THE ApiClient SHALL provide typed methods: `get`, `post`, `put`, `patch`, and `delete`
2. WHEN a request is made, THE ApiClient request interceptor SHALL attach the auth token from token storage if available
3. WHEN an API response returns status 401, THE ApiClient response interceptor SHALL attempt a token refresh; if refresh fails, THE ApiClient SHALL clear auth state and redirect to login
4. WHEN `withLoading` is true in the request config, THE ApiClient SHALL call `setLoading(true)` before the request and `setLoading(false)` after completion or failure
5. IF a network error occurs, THEN THE ApiClient SHALL transform the error into a consistent AppError interface format
6. THE ApiClient SHALL accept a `baseURL` and optional `timeout` (positive number) configuration

### Requirement 10: Routing and Module Architecture

**User Story:** As a developer, I want a hybrid module architecture with clear boundaries, so that business features are isolated and shared code is reusable across the application.

#### Acceptance Criteria

1. THE Template SHALL organize business logic under `src/modules/{moduleName}/` with each module exporting routes via `index.ts`
2. THE Template SHALL organize shared code under `src/shared/` with subdirectories: components, hooks, services, utils, types, and i18n
3. WHEN a module needs to use code from another module, THE module SHALL import only from the target module's `index.ts` public API
4. THE route configuration SHALL support React Router v7 with nested routes, layout routes, and route-level metadata (requiresAuth, title, roles)
5. EVERY RouteDefinition SHALL specify a `layout` property of type 'enduser' or 'admin'

### Requirement 11: Responsive Design

**User Story:** As a user, I want the application to adapt to any screen size, so that I can use it comfortably on mobile, tablet, and desktop devices.

#### Acceptance Criteria

1. THE Template SHALL follow mobile-first responsive design (base styles target mobile, media queries add complexity for larger screens)
2. THE Template SHALL provide a `media` utility object with `up(breakpoint)`, `down(breakpoint)`, and `between(min, max)` helpers generating valid CSS media query strings
3. THE breakpoint values SHALL be strictly ascending: xs(0) < sm(576) < md(768) < lg(992) < xl(1200) < xxl(1400)
4. WHEN used in styled-components, THE media helpers SHALL produce correct `@media (min-width: Xpx)` syntax for the `up` helper

### Requirement 12: State Management

**User Story:** As a developer, I want lightweight global state management, so that I can share state across components without prop drilling or complex boilerplate.

#### Acceptance Criteria

1. THE Template SHALL use Zustand for global and module-scoped state management
2. THE Template SHALL provide pre-configured stores for loading state and modal state
3. WHEN a module needs local state, THE module SHALL define its own Zustand store within its directory

### Requirement 13: Data Fetching

**User Story:** As a developer, I want a standardized data fetching and caching layer, so that server state is managed efficiently with automatic caching, refetching, and error handling.

#### Acceptance Criteria

1. THE Template SHALL use TanStack Query (React Query v5) for all server-state data fetching
2. THE QueryClient SHALL be configured with a default stale time of 5 minutes and 1 retry
3. WHEN a module fetches data, THE module SHALL define query hooks using `useQuery` or `useMutation` from TanStack Query

### Requirement 14: Form Handling and Validation

**User Story:** As a developer, I want a standardized form handling approach with schema-based validation, so that form logic is consistent, type-safe, and reusable across the application.

#### Acceptance Criteria

1. THE Template SHALL use React Hook Form for form state management
2. THE Template SHALL use Zod for schema-based form validation
3. WHEN a form is submitted, THE form handler SHALL validate input against the Zod schema before processing

### Requirement 15: Internationalization

**User Story:** As a developer, I want built-in internationalization support, so that the application can serve users in multiple languages.

#### Acceptance Criteria

1. THE Template SHALL use react-i18next with i18next core for internationalization
2. WHEN a translation key is not found for the current language, THE i18n system SHALL fall back to the default language (English)
3. IF a key is missing in both the current and default language, THEN THE i18n system SHALL display the key itself as fallback text
4. WHILE in development mode, THE i18n system SHALL log missing translation keys to the console

### Requirement 16: Example Pages

**User Story:** As a team member, I want pre-built example pages demonstrating all patterns, so that I can quickly understand the template conventions and use them as reference when building features.

#### Acceptance Criteria

1. THE Template SHALL include an ExampleShowcasePage at route `/examples/showcase` using the EndUser layout
2. THE ExampleShowcasePage SHALL demonstrate: modal types (confirm, success, error, warning, info), ModalContainer drawer, loading overlay, theme colors and toggle, responsive breakpoints, form with validation, TanStack Query usage, and i18n with language switcher
3. THE Template SHALL include an ExampleCRUDPage at route `/examples/crud` using the Admin layout
4. THE ExampleCRUDPage SHALL demonstrate: data table with TanStack Query, create/edit via ModalContainer, delete with confirmation modal, loading states, and form validation with React Hook Form + Zod

### Requirement 17: Testing Infrastructure

**User Story:** As a developer, I want a complete testing setup out of the box, so that I can write unit, property-based, integration, and end-to-end tests without additional configuration.

#### Acceptance Criteria

1. THE Template SHALL configure Vitest as the unit testing framework
2. THE Template SHALL configure React Testing Library for component testing
3. THE Template SHALL configure fast-check for property-based testing integrated with Vitest
4. THE Template SHALL configure Playwright for end-to-end testing
5. THE Template SHALL include example test files demonstrating unit tests, property-based tests, and E2E tests

### Requirement 18: Code Quality Tooling

**User Story:** As a developer, I want preconfigured linting and formatting, so that code style is consistent across the team without manual enforcement.

#### Acceptance Criteria

1. THE Template SHALL configure ESLint with TypeScript-aware rules
2. THE Template SHALL configure Prettier for code formatting
3. THE Template SHALL include configuration files (`.eslintrc`, `.prettierrc`) at project root

### Requirement 19: Agent Rules and Telegram Integration

**User Story:** As a team lead, I want workflow automation rules with Telegram notifications, so that the team receives real-time updates on feature development progress and can confirm actions remotely.

#### Acceptance Criteria

1. THE Template SHALL include agent rule YAML files under `.kiro/rules/`
2. THE AgentRule files SHALL define triggers (file-change, command, or schedule), steps with actions and parameters, and optional Telegram notifications
3. WHEN a notification event occurs (start, complete, error, confirm), THE agent rule SHALL send a message to the configured Telegram chat
4. WHEN a 'confirm' event is triggered, THE agent rule SHALL wait for user confirmation via Telegram within the configured timeout

### Requirement 20: Security Practices

**User Story:** As a developer, I want secure defaults in the template, so that common security vulnerabilities are mitigated from the start.

#### Acceptance Criteria

1. THE Template SHALL store auth tokens in memory (not localStorage) to mitigate XSS attacks
2. THE Template SHALL use httpOnly cookies for refresh tokens
3. THE Template SHALL validate all user input via Zod schemas before API submission
4. THE Template SHALL include Content-Security-Policy header configuration for production builds
5. THE Template SHALL commit lock files and support regular dependency auditing via `npm audit`
