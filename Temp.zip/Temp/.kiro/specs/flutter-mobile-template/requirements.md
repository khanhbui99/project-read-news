# Requirements Document

## Introduction

This document defines the functional and non-functional requirements for the Flutter Mobile Template (THCS Cầu Giấy). The template serves as a production-ready boilerplate for the school's mobile application development team, providing a modular architecture, reusable UI components, imperative global services, and consistent patterns optimized for AI-assisted development.

## Glossary

- **ContainerBase**: A shared widget wrapper that provides scrollable content area with default padding and keyboard dismiss behavior for all screens.
- **TabScaffold**: The ShellRoute builder widget that wraps all tab screens with SafeArea and the AppBottomTabBar.
- **AppBottomTabBar**: A custom-painted bottom navigation bar with SVG curved notch and elevated center Home button.
- **AppHeader**: A top navigation bar (AppBar) for sub-screens providing back button and drawer menu.
- **AppModal**: A bottom sheet modal widget supporting 5 visual types (confirm, success, error, warning, info) with type-dependent layout.
- **AppBottomSheet**: A full-featured bottom sheet at 90% screen height with drag handle, fixed header, scrollable content, and sticky action buttons.
- **AppModalSelect**: A searchable selection bottom sheet with configurable field mapping for picking items from a list.
- **LoadingService**: An imperative full-screen loading overlay service callable from anywhere without BuildContext.
- **NotifyService**: An imperative modal notification service that shows AppModal from anywhere using a GlobalNavigatorKey.
- **AppToast**: A lightweight auto-dismissing toast notification for passive events.
- **DioClient**: The HTTP client wrapper built on Dio with interceptor chain for auth, error handling, and logging.
- **GoRouter**: The declarative navigation router using ShellRoute for tab persistence and route guards for authentication.
- **EnvConfig**: A Freezed model representing validated environment configuration loaded from .env files.
- **AppException**: A Freezed union type representing all possible application error categories.
- **ApiResponse**: A Freezed union type representing success or error API responses.
- **ModalResult**: An enum representing user action on a modal (confirmed or dismissed).
- **ModalType**: An enum of 5 modal visual types: confirm, success, error, warning, info.
- **Shimmer**: A skeleton loading animation effect displayed while data is being fetched.

## Requirements

### Requirement 1: Application Bootstrap

**User Story:** As a developer, I want the app to bootstrap with validated environment configuration and all core services initialized, so that the app starts in a known-good state.

#### Acceptance Criteria

1. WHEN the application starts, THE Bootstrap SHALL initialize Flutter bindings before any other operation
2. WHEN the application starts, THE Bootstrap SHALL load environment configuration from the .env file for the current environment
3. WHEN the environment configuration is loaded, THE Bootstrap SHALL validate that apiBaseUrl starts with "http://" or "https://"
4. WHEN the environment configuration is loaded, THE Bootstrap SHALL validate that environment is one of "dev", "staging", or "prod"
5. WHEN the environment configuration is loaded, THE Bootstrap SHALL validate that appName is not empty
6. IF any required environment variable is missing or invalid, THEN THE Bootstrap SHALL fail fast with an assertion error and prevent the app from starting
7. WHEN environment is validated, THE Bootstrap SHALL wrap the entire application in a ProviderScope with envConfig override
8. WHEN the app runs, THE Bootstrap SHALL lock orientation to portrait-up only

### Requirement 2: Navigation and Routing

**User Story:** As a user, I want to navigate between app sections via tabs and access sub-screens, so that I can use all features of the app with preserved state.

#### Acceptance Criteria

1. THE GoRouter SHALL use a ShellRoute to wrap all five main tab screens (home, messages, notifications, account, settings)
2. WHEN a user switches between tabs, THE GoRouter SHALL preserve the navigation stack of each tab independently
3. WHEN an unauthenticated user attempts to access a protected route, THE GoRouter SHALL redirect to "/login"
4. WHEN an authenticated user attempts to access an auth route (login/register), THE GoRouter SHALL redirect to "/home"
5. WHEN a sub-screen is navigated to, THE GoRouter SHALL render it outside the ShellRoute with its own Scaffold and AppHeader
6. WHEN a deep link is received, THE GoRouter SHALL resolve it to the correct tab and sub-screen

### Requirement 3: Tab Scaffold and SafeArea

**User Story:** As a developer, I want SafeArea handling centralized at the app level, so that individual screens do not need to manage system UI insets.

#### Acceptance Criteria

1. THE TabScaffold SHALL wrap all tab screen content within a SafeArea widget (top and bottom)
2. THE TabScaffold SHALL render the AppBottomTabBar as the bottomNavigationBar
3. WHEN a screen is rendered inside TabScaffold, THE TabScaffold SHALL guarantee that content does not overlap system UI (status bar, notch, home indicator)
4. THE ContainerBase SHALL provide a scrollable area with default padding of EdgeInsets.symmetric(horizontal: 16, vertical: 8)
5. WHEN a user taps outside a text field, THE ContainerBase SHALL dismiss the keyboard
6. WHERE an onRefresh callback is provided, THE ContainerBase SHALL wrap content in a RefreshIndicator for pull-to-refresh

### Requirement 4: Custom Bottom Tab Bar

**User Story:** As a user, I want a visually distinctive bottom navigation bar with an elevated Home button, so that I can quickly access the main sections of the app.

#### Acceptance Criteria

1. THE AppBottomTabBar SHALL render a custom ClipPath with a curved notch for the center item
2. THE AppBottomTabBar SHALL elevate the center tab button (Home) above the bar surface as a floating element
3. WHEN a tab is active, THE AppBottomTabBar SHALL apply the primary ocean blue color (#0077B6) to the active tab icon and label
4. THE AppBottomTabBar SHALL render tab icons using SVG assets via flutter_svg
5. WHEN a user taps a tab, THE AppBottomTabBar SHALL animate the transition between active states

### Requirement 5: AppHeader (Top Navigation)

**User Story:** As a user, I want a consistent top bar on sub-screens with back navigation and a drawer menu, so that I can navigate the app without losing context.

#### Acceptance Criteria

1. THE AppHeader SHALL display a title (text string or custom widget)
2. WHEN showBack is true, THE AppHeader SHALL display a back button that pops the current route
3. WHEN showDrawer is true, THE AppHeader SHALL display a drawer icon that opens a navigation drawer
4. WHEN a user taps a drawer menu item, THE AppHeader SHALL navigate using context.go() to replace the current route (no stacking)
5. THE AppHeader SHALL conform to Material 3 AppBar styling

### Requirement 6: AppModal (Type-Safe Bottom Sheet Modal)

**User Story:** As a developer, I want a reusable modal component with 5 visual types, so that I can display confirm dialogs, success messages, errors, warnings, and info consistently.

#### Acceptance Criteria

1. WHEN AppModal.show() is called with a valid ModalConfig, THE AppModal SHALL display a modal bottom sheet
2. WHEN the modal type is confirm, warning, or info, THE AppModal SHALL render icon and title in a horizontal Row layout
3. WHEN the modal type is success or error, THE AppModal SHALL render icon centered above title in a vertical Column layout
4. WHEN a user taps the confirm button, THE AppModal SHALL return ModalResult.confirmed
5. WHEN a user taps cancel, the back button, or taps outside (if dismissible), THE AppModal SHALL return ModalResult.dismissed
6. WHEN the modal result is returned, THE AppModal SHALL be removed from the widget tree

### Requirement 7: AppBottomSheet

**User Story:** As a developer, I want a full-featured bottom sheet with fixed header, scrollable content, and sticky actions, so that I can present complex content within a consistent container.

#### Acceptance Criteria

1. THE AppBottomSheet SHALL occupy at most 90% of the screen height by default
2. WHERE showDragHandle is true, THE AppBottomSheet SHALL display a drag handle at the top
3. WHERE showCloseButton is true, THE AppBottomSheet SHALL display a close button in the header
4. THE AppBottomSheet SHALL render content in a scrollable area between the fixed header and sticky action buttons
5. WHERE actions are provided, THE AppBottomSheet SHALL render them as sticky buttons at the bottom

### Requirement 8: AppModalSelect (Searchable Selection)

**User Story:** As a user, I want to select an item from a searchable list in a bottom sheet, so that I can quickly find and pick the right option.

#### Acceptance Criteria

1. WHEN AppModalSelect is shown, THE AppModalSelect SHALL display the list of items with a search input field
2. WHEN a user types in the search field, THE AppModalSelect SHALL filter items using the fieldName mapping function
3. WHEN a user taps an item, THE AppModalSelect SHALL invoke the onSelected callback with the selected item
4. WHERE a selectedItem is provided, THE AppModalSelect SHALL visually highlight that item in the list
5. THE AppModalSelect SHALL debounce search input by 300ms to avoid excessive filtering

### Requirement 9: Loading Service

**User Story:** As a developer, I want a global loading overlay callable from anywhere (providers, services, interceptors), so that I can indicate busy state without needing BuildContext.

#### Acceptance Criteria

1. WHEN LoadingService.show() is called, THE LoadingService SHALL display a full-screen semi-transparent overlay with a spinner
2. WHEN LoadingService.hide() is called, THE LoadingService SHALL remove the overlay from the widget tree
3. WHEN LoadingService.show() is called while already showing, THE LoadingService SHALL not create a duplicate overlay (at most one visible at any time)
4. THE LoadingService SHALL use GlobalKey NavigatorState to access the overlay without requiring BuildContext
5. THE LoadingService SHALL provide an alternative Riverpod loadingProvider for widget-level reactive usage

### Requirement 10: NotifyService (Imperative Modal Notification)

**User Story:** As a developer, I want to show modal notifications (success/error/warning/confirm) from anywhere in the app (services, providers, interceptors), so that I can communicate action results to users without BuildContext.

#### Acceptance Criteria

1. WHEN NotifyService.show() is called, THE NotifyService SHALL display an AppModal bottom sheet using the GlobalNavigatorKey
2. THE NotifyService SHALL provide shorthand methods: success(), error(), warning(), info(), confirm()
3. WHEN the user interacts with the modal (OK/Confirm/Cancel), THE NotifyService SHALL return a Future of ModalResult
4. THE NotifyService SHALL share the same GlobalKey NavigatorState as LoadingService
5. WHEN called from a non-widget context (interceptor, service), THE NotifyService SHALL function identically to widget-context usage

### Requirement 11: AppToast (Lightweight Notification)

**User Story:** As a user, I want to see brief, non-blocking notifications for passive events (new messages, sync status, connectivity changes), so that I am informed without interrupting my workflow.

#### Acceptance Criteria

1. WHEN AppToast.show() is called, THE AppToast SHALL display a lightweight toast that auto-dismisses
2. THE AppToast SHALL support 4 types: success, error, warning, info
3. THE AppToast SHALL NOT block user interaction with the underlying UI
4. THE AppToast SHALL be callable from anywhere without BuildContext (imperative)

### Requirement 12: HTTP Client (DioClient)

**User Story:** As a developer, I want a pre-configured HTTP client with automatic token attachment, token refresh, and error normalization, so that module services can focus on business logic.

#### Acceptance Criteria

1. THE DioClient SHALL attach an Authorization Bearer header to all requests when an access token exists in secure storage
2. WHEN a request receives a 401 response, THE DioClient SHALL attempt exactly one token refresh and retry the original request
3. IF the token refresh fails, THEN THE DioClient SHALL log the user out and clear stored tokens
4. WHEN a DioException occurs, THE DioClient SHALL map it to the appropriate AppException subtype (network, unauthorized, server, validation, unknown)
5. THE DioClient SHALL set connect timeout and receive timeout to 30 seconds
6. WHERE enableLogging is true in EnvConfig, THE DioClient SHALL add a LogInterceptor to the interceptor chain
7. WHEN multiple concurrent requests receive 401, THE DioClient SHALL execute only one token refresh and retry all pending requests with the new token

### Requirement 13: Data Models (Freezed + json_serializable)

**User Story:** As a developer, I want immutable, type-safe data models with automatic JSON serialization, so that data handling is predictable and boilerplate-free.

#### Acceptance Criteria

1. THE ApiResponse model SHALL be a Freezed union with success and error variants
2. THE AppException model SHALL be a Freezed union with network, unauthorized, server, validation, and unknown variants
3. THE EnvConfig model SHALL be a Freezed class with required fields: apiBaseUrl, appName, environment
4. WHEN a valid JSON map is provided, THE fromJson factory SHALL produce the correct model instance
5. WHEN a model instance calls toJson(), THE Serializer SHALL produce a valid JSON map that round-trips back to an equivalent instance

### Requirement 14: Theme System (Material 3)

**User Story:** As a developer, I want a centralized Material 3 theme with ocean blue branding and light/dark variants, so that the entire app has consistent visual styling.

#### Acceptance Criteria

1. THE AppTheme SHALL generate a ColorScheme from the seed color ocean blue (#0077B6)
2. THE AppTheme SHALL provide both light() and dark() ThemeData configurations
3. WHEN Material 3 is enabled, THE AppTheme SHALL configure all component themes (AppBar, Button, BottomNav) using color scheme tokens
4. THE AppColors SHALL define semantic colors: success (#2E7D32), error (#D32F2F), warning (#F57C00), info (#0288D1)
5. WHEN the theme mode changes between light and dark, THE AppTheme SHALL maintain brand identity (ocean blue primary) in both modes

### Requirement 15: Internationalization (i18n)

**User Story:** As a user, I want the app to support Vietnamese and English, so that I can use the app in my preferred language.

#### Acceptance Criteria

1. THE i18n System SHALL support two locales: Vietnamese (vi) and English (en)
2. THE i18n System SHALL provide translations for all user-visible strings in both locales
3. WHEN the user changes language preference, THE i18n System SHALL update all displayed strings without restarting the app
4. IF a translation key is missing for a locale, THEN THE i18n System SHALL fall back to the default locale (Vietnamese)

### Requirement 16: Secure Token Storage

**User Story:** As a user, I want my authentication tokens stored securely on the device, so that my session is protected from unauthorized access.

#### Acceptance Criteria

1. THE TokenStorage SHALL store access tokens and refresh tokens using flutter_secure_storage (Keychain on iOS, Keystore on Android)
2. WHEN the user logs out, THE TokenStorage SHALL clear all stored tokens immediately
3. WHEN the app starts, THE TokenStorage SHALL check for existing valid tokens to restore the session
4. THE TokenStorage SHALL NOT store tokens in plain text, shared preferences, or any non-encrypted storage

### Requirement 17: Shimmer Skeleton Loading

**User Story:** As a user, I want to see placeholder skeletons while content is loading, so that I perceive the app as responsive even when waiting for data.

#### Acceptance Criteria

1. WHILE data is loading (AsyncLoading state), THE Shimmer Widget SHALL display animated placeholder shapes matching the expected content layout
2. WHEN data finishes loading, THE Shimmer Widget SHALL be replaced by the actual content
3. THE Shimmer Widget SHALL use a subtle animation that maintains the app's calm aesthetic

### Requirement 18: Module Architecture

**User Story:** As a developer, I want each business domain (home, messages, notifications, account, settings) to be self-contained with its own screens, widgets, providers, models, and services, so that modules are independently maintainable and predictable for AI-assisted development.

#### Acceptance Criteria

1. THE Module Architecture SHALL organize each module with its own screens, widgets, providers, models, and services directories
2. THE Module Architecture SHALL place shared infrastructure (API client, theme, navigation, i18n) in dedicated directories accessible to all modules
3. WHEN a module provider is no longer needed (screen popped), THE Module Architecture SHALL use autoDispose to release resources
4. THE Module Architecture SHALL use Riverpod 2 for all state management and dependency injection without additional DI frameworks

### Requirement 19: Error Handling

**User Story:** As a developer, I want all errors normalized into typed exceptions with clear recovery paths, so that error handling is consistent across the app.

#### Acceptance Criteria

1. WHEN a network timeout or connectivity error occurs, THE DioClient SHALL produce AppException.network
2. WHEN the API returns a 401, THE DioClient SHALL produce AppException.unauthorized (after failed refresh)
3. WHEN the API returns a 422 with field errors, THE DioClient SHALL produce AppException.validation with the error map
4. WHEN the API returns a 5xx status, THE DioClient SHALL produce AppException.server with the status code
5. IF an unexpected error occurs, THEN THE DioClient SHALL produce AppException.unknown
6. WHEN AppException.network is caught by a screen, THE Screen SHALL display a retry option (pull-to-refresh or retry button)
7. WHEN AppException.validation is caught by a form screen, THE Screen SHALL display inline field-level error messages

### Requirement 20: Performance Patterns

**User Story:** As a user, I want the app to be responsive and memory-efficient, so that I have a smooth experience even on lower-end devices.

#### Acceptance Criteria

1. THE App SHALL use ListView.builder for all dynamic lists (never ListView with inline children)
2. THE App SHALL use const constructors and Riverpod select to minimize unnecessary widget rebuilds
3. THE App SHALL use cached_network_image for all remote image loading with disk caching
4. WHEN displaying AppModalSelect, THE AppModalSelect SHALL debounce search input by 300ms
5. THE ShellRoute SHALL keep tab widgets alive to prevent rebuild on tab switch

### Requirement 21: Security

**User Story:** As a developer, I want the template to enforce security best practices by default, so that sensitive data and code are protected.

#### Acceptance Criteria

1. THE App SHALL load all sensitive configuration values from .env files that are gitignored
2. THE App SHALL NOT embed secrets, API keys, or tokens in source code
3. WHEN building a release, THE Build System SHALL use --obfuscate and --split-debug-info flags
4. THE App SHALL validate and sanitize all user inputs before submission to APIs

### Requirement 22: OTA Code Push (Shorebird)

**User Story:** As a developer, I want to push code updates directly to users' devices without going through app store review, so that bug fixes and minor updates are delivered instantly.

#### Acceptance Criteria

1. THE App SHALL integrate Shorebird code push to enable over-the-air Dart code updates
2. WHEN the app starts, THE App SHALL check for available patches from Shorebird
3. IF a patch is available, THE App SHALL download and apply it on next restart (or immediately based on config)
4. THE Shorebird integration SHALL work alongside the existing environment config (dev/staging/production channels)
5. THE Build System SHALL support `shorebird release` and `shorebird patch` commands for CI/CD deployment
