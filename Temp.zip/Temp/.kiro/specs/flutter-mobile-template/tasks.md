# Implementation Tasks: Flutter Mobile Template

## Task 1: Project Scaffold & Configuration

- [x] 1.1 Create `pubspec.yaml` with all dependencies
  - [ ] 1.1.1 Add runtime deps: flutter_riverpod, go_router, dio, freezed_annotation, json_annotation, flutter_svg, flutter_localizations, intl, flutter_secure_storage, flutter_dotenv, cached_network_image, shimmer, fluttertoast, shorebird_code_push
  - [ ] 1.1.2 Add dev deps: build_runner, riverpod_generator, riverpod_annotation, freezed, json_serializable, glados, mocktail
  - [ ] 1.1.3 Configure assets paths (icons/, images/, .env)
- [ ] 1.2 Create `analysis_options.yaml` with strict lint rules
- [ ] 1.3 Create folder structure
  - [ ] 1.3.1 Create lib/app/ (app.dart, providers.dart, router.dart)
  - [ ] 1.3.2 Create lib/navigation/ (tab_scaffold.dart, app_bottom_tab_bar.dart, types.dart)
  - [ ] 1.3.3 Create lib/modules/ with 5 modules (home, messages, notifications, account, settings) each with screens/, widgets/, providers/, models/, services/
  - [ ] 1.3.4 Create lib/shared/ (widgets/, services/, providers/, models/, utils/, l10n/)
  - [ ] 1.3.5 Create lib/theme/ (app_theme.dart, colors.dart, typography.dart)
  - [ ] 1.3.6 Create assets/icons/, assets/images/
- [ ] 1.4 Create environment files
  - [ ] 1.4.1 Create .env.development, .env.staging, .env.production, .env.example
  - [ ] 1.4.2 Create lib/shared/models/env_config.dart (Freezed model + validation)
  - [ ] 1.4.3 Create lib/shared/providers/env_provider.dart
- [ ] 1.5 Create `shorebird.yaml` config file

## Task 2: Theme System (Material 3)

- [ ] 2.1 Create lib/theme/colors.dart — AppColors with ocean blue #0077B6, semantic colors
- [ ] 2.2 Create lib/theme/typography.dart — AppTypography text theme
- [ ] 2.3 Create lib/theme/app_theme.dart — ThemeData light() and dark() from ColorScheme.fromSeed

## Task 3: App Bootstrap & Providers

- [ ] 3.1 Create lib/main.dart — bootstrap (ensureInitialized, loadEnv, orientation lock, runApp with ProviderScope)
- [ ] 3.2 Create lib/app/app.dart — MaterialApp.router with GlobalKey, theme, l10n, routerConfig
- [ ] 3.3 Create lib/app/providers.dart — global provider overrides

## Task 4: Navigation & Routing

- [ ] 4.1 Create lib/navigation/types.dart — route paths, tab enum
- [ ] 4.2 Create lib/app/router.dart — GoRouter with ShellRoute, auth redirect guard, tab routes, sub-routes
- [ ] 4.3 Create lib/navigation/tab_scaffold.dart — SafeArea + Scaffold + AppBottomTabBar (ShellRoute builder)
- [ ] 4.4 Create lib/navigation/app_bottom_tab_bar.dart — Custom ClipPath, SVG curved notch, elevated center Home button, ocean blue active state

## Task 5: Shared Widgets

- [ ] 5.1 Create lib/shared/widgets/container_base.dart — ScrollView + padding + keyboard dismiss + RefreshIndicator
- [ ] 5.2 Create lib/shared/widgets/app_header.dart — AppBar with back, drawer, title. Drawer navigates with go()
- [ ] 5.3 Create lib/shared/widgets/app_modal.dart — 5 types (confirm/success/error/warning/info), horizontal vs vertical layout, ModalResult return
- [ ] 5.4 Create lib/shared/widgets/app_bottom_sheet.dart — 90% height, drag handle, fixed header, scrollable content, sticky actions
- [ ] 5.5 Create lib/shared/widgets/app_modal_select.dart — Searchable list, field/fieldName mapping, debounce 300ms
- [ ] 5.6 Create lib/shared/widgets/app_button.dart — Variants (primary, secondary, danger, ghost, outline), sizes
- [ ] 5.7 Create lib/shared/widgets/app_text.dart — Typography variants
- [ ] 5.8 Create lib/shared/widgets/app_input.dart — Label, error, helper text
- [ ] 5.9 Create lib/shared/widgets/shimmer_skeleton.dart — Shimmer loading placeholder
- [ ] 5.10 Create lib/shared/widgets/widgets.dart — Barrel export

## Task 6: Imperative Services

- [ ] 6.1 Create lib/shared/services/loading_service.dart — GlobalKey + OverlayEntry show/hide
- [ ] 6.2 Create lib/shared/services/notify_service.dart — GlobalKey + showModalBottomSheet, success/error/warning/info/confirm shortcuts
- [ ] 6.3 Create lib/shared/services/toast_service.dart — fluttertoast wrapper, 4 types, imperative
- [ ] 6.4 Create lib/shared/services/token_storage.dart — flutter_secure_storage get/set/clear tokens

## Task 7: HTTP Client (DioClient)

- [ ] 7.1 Create lib/shared/services/dio_client.dart
  - [ ] 7.1.1 Dio instance with baseUrl from EnvConfig, timeouts 30s
  - [ ] 7.1.2 Auth interceptor (attach Bearer token)
  - [ ] 7.1.3 Error interceptor (map DioException → AppException)
  - [ ] 7.1.4 Token refresh on 401 (atomic, single refresh for concurrent requests)
  - [ ] 7.1.5 LogInterceptor when enableLogging

## Task 8: Data Models (Freezed)

- [ ] 8.1 Create lib/shared/models/api_response.dart — Freezed union (success/error)
- [ ] 8.2 Create lib/shared/models/app_exception.dart — Freezed union (network/unauthorized/server/validation/unknown)
- [ ] 8.3 Create lib/shared/models/env_config.dart — Freezed with validation
- [ ] 8.4 Run `dart run build_runner build` to generate .g.dart and .freezed.dart files

## Task 9: Auth Provider

- [ ] 9.1 Create lib/shared/providers/auth_provider.dart — AuthState (authenticated/unauthenticated), login/logout actions
- [ ] 9.2 Create lib/shared/providers/loading_provider.dart — StateProvider<bool> for reactive usage

## Task 10: Internationalization (i18n)

- [ ] 10.1 Create lib/shared/l10n/app_vi.arb — Vietnamese translations
- [ ] 10.2 Create lib/shared/l10n/app_en.arb — English translations
- [ ] 10.3 Configure flutter_localizations in pubspec + MaterialApp

## Task 11: Module Screens (Tab Screens — NO header)

- [ ] 11.1 Create lib/modules/home/screens/home_screen.dart — ContainerBase + content
- [ ] 11.2 Create lib/modules/messages/screens/messages_screen.dart — ContainerBase + empty state
- [ ] 11.3 Create lib/modules/notifications/screens/notifications_screen.dart — ContainerBase + empty state
- [ ] 11.4 Create lib/modules/account/screens/account_screen.dart — ContainerBase + profile/login section
- [ ] 11.5 Create lib/modules/settings/screens/settings_screen.dart — ContainerBase + theme toggle + setting items + logout

## Task 12: Example Sub-Screen (with AppHeader)

- [ ] 12.1 Create lib/modules/home/screens/detail_screen.dart — Scaffold + AppHeader + ContainerBase
- [ ] 12.2 Register sub-route in router.dart outside ShellRoute

## Task 13: Shorebird Integration

- [ ] 13.1 Create shorebird.yaml with app_id placeholder
- [ ] 13.2 Add Shorebird check-for-update logic in main.dart bootstrap
- [ ] 13.3 Document `shorebird release` and `shorebird patch` commands in README

## Task 14: Testing Setup

- [ ] 14.1 Create test/ folder structure mirroring lib/
- [ ] 14.2 Write unit tests for DioClient interceptors (mock adapter)
- [ ] 14.3 Write unit tests for auth_provider (login/logout state transitions)
- [ ] 14.4 Write widget tests for AppModal (type layout verification)
- [ ] 14.5 Write property-based tests (glados) for API error mapping completeness
- [ ] 14.6 Create integration_test/ with bootstrap flow test

## Task 15: Documentation & Rules

- [ ] 15.1 Create mobile/README.md — Getting started, folder structure, conventions, scripts
- [ ] 15.2 Update .kiro/steering/mobile-project-structure.md for Flutter structure
- [ ] 15.3 Verify `flutter analyze` passes with zero issues
- [ ] 15.4 Verify `flutter test` passes
