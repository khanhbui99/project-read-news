# Design Document: Flutter Mobile Template (THCS Cầu Giấy)

## Overview

This design defines a Flutter mobile boilerplate template for THCS Cầu Giấy's development team. The template provides a production-ready architecture with modular structure, reusable components, and consistent patterns that mirror the team's existing web boilerplate. It is optimized for AI-assisted development with clear naming conventions, predictable file locations, and well-defined interfaces.

The architecture follows a module-based separation where each business domain (home, messages, notifications, account, settings) is self-contained with its own screens, widgets, providers, models, and services. Shared infrastructure (API client, theme, navigation, i18n) lives in dedicated directories accessible to all modules. State management uses Riverpod 2 throughout, providing dependency injection, async state handling, and testability without additional DI frameworks.

Key design decisions: SafeArea handling is centralized in ContainerBase (not per-screen); the bottom tab bar uses a custom SVG-based design with curved notch; navigation uses GoRouter with shell routes for tab persistence; and modals follow a type-safe pattern with 5 distinct visual styles.

## Architecture

```mermaid
graph TD
    subgraph App Layer
        MAIN[main.dart] --> APP[App Widget]
        APP --> ROUTER[GoRouter]
        APP --> THEME[ThemeData]
        APP --> L10N[Localizations]
    end

    subgraph Navigation
        ROUTER --> SHELL[ShellRoute - TabScaffold]
        SHELL --> TAB_HOME[/home]
        SHELL --> TAB_MSG[/messages]
        SHELL --> TAB_NOTIF[/notifications]
        SHELL --> TAB_ACCOUNT[/account]
        SHELL --> TAB_SETTINGS[/settings]
        TAB_HOME --> SUB_SCREENS[Sub-screens with AppHeader]
    end

    subgraph Module Layer
        MOD_HOME[Home Module]
        MOD_MSG[Messages Module]
        MOD_NOTIF[Notifications Module]
        MOD_ACC[Account Module]
        MOD_SET[Settings Module]
    end

    subgraph Shared Layer
        WIDGETS[Shared Widgets]
        SERVICES[Shared Services]
        PROVIDERS[Global Providers]
        MODELS[Shared Models]
        UTILS[Utilities]
    end

    subgraph Infrastructure
        DIO[Dio HTTP Client]
        ENV[Environment Config]
        THEME_SYS[Theme System]
        I18N[i18n System]
    end

    MOD_HOME --> WIDGETS
    MOD_HOME --> SERVICES
    SERVICES --> DIO
    DIO --> ENV
```

## Sequence Diagrams

### App Bootstrap Flow

```mermaid
sequenceDiagram
    participant Main as main.dart
    participant Env as EnvConfig
    participant Provider as ProviderScope
    participant App as App Widget
    participant Router as GoRouter
    participant Shell as TabScaffold

    Main->>Env: loadEnvironment()
    Env-->>Main: EnvConfig loaded
    Main->>Provider: ProviderScope(overrides)
    Provider->>App: App()
    App->>Router: GoRouter(routes)
    Router->>Shell: ShellRoute(builder: TabScaffold)
    Shell-->>App: Initial tab rendered
```

### API Request Flow with Interceptors

```mermaid
sequenceDiagram
    participant Screen as Screen/Provider
    participant Service as Module Service
    participant Dio as DioClient
    participant Auth as AuthInterceptor
    participant Error as ErrorInterceptor
    participant API as Backend API

    Screen->>Service: fetchData()
    Service->>Dio: get('/endpoint')
    Dio->>Auth: onRequest - attach token
    Auth->>API: GET /endpoint + Bearer token
    API-->>Error: Response / Error
    alt 401 Unauthorized
        Error->>Auth: refreshToken()
        Auth->>API: POST /refresh
        API-->>Auth: New token
        Auth->>API: Retry original request
        API-->>Error: Success response
    end
    Error-->>Dio: Normalized response
    Dio-->>Service: ApiResponse<T>
    Service-->>Screen: Data / AppException
```

### Modal Display Flow

```mermaid
sequenceDiagram
    participant Screen as Screen
    participant Modal as AppModal
    participant Overlay as ModalOverlay
    participant User as User

    Screen->>Modal: AppModal.show(context, type: success)
    Modal->>Overlay: showModalBottomSheet()
    Overlay-->>User: Display modal with animation
    User->>Overlay: Tap confirm/dismiss
    Overlay-->>Modal: Result (confirmed/dismissed)
    Modal-->>Screen: ModalResult
```

### Loading Service Flow (Imperative)

```mermaid
sequenceDiagram
    participant Caller as Provider/Service/Interceptor
    participant LS as LoadingService
    participant NavKey as GlobalNavigatorKey
    participant Overlay as OverlayEntry
    participant UI as Full-screen Spinner

    Caller->>LS: LoadingService.show()
    LS->>NavKey: navigatorKey.currentState.overlay
    NavKey->>Overlay: insert(LoadingOverlayWidget)
    Overlay->>UI: Render full-screen semi-transparent + spinner
    Note over UI: User sees loading...
    Caller->>LS: LoadingService.hide()
    LS->>Overlay: overlayEntry.remove()
    Overlay-->>UI: Removed from tree
```

### NotifyService Flow (Imperative Modal)

```mermaid
sequenceDiagram
    participant Caller as Provider/Service/Interceptor
    participant NS as NotifyService
    participant NavKey as GlobalNavigatorKey
    participant Sheet as showModalBottomSheet()
    participant Modal as AppModal Widget
    participant User as User

    Caller->>NS: NotifyService.success('Done', message: '...')
    NS->>NavKey: navigatorKey.currentState
    NavKey->>Sheet: showModalBottomSheet(AppModal)
    Sheet->>Modal: Render with type=success (centered icon)
    Modal-->>User: Modal slide up from bottom
    User->>Modal: Tap OK
    Modal-->>Sheet: pop(ModalResult.confirmed)
    Sheet-->>NS: Future resolves
    NS-->>Caller: ModalResult.confirmed
```

### Kiến trúc tổng quan các luồng Global Services

```mermaid
graph LR
    subgraph "Imperative Services (No Context needed)"
        LS[LoadingService.show/hide]
        NS[NotifyService.success/error/confirm]
    end

    subgraph "Shared Infrastructure"
        NAV_KEY[GlobalKey NavigatorState]
        OVERLAY[Overlay API]
        SHEET[showModalBottomSheet]
    end

    subgraph "UI Output"
        LOADING_UI[Full-screen Loading Overlay]
        MODAL_UI[AppModal Bottom Sheet]
    end

    subgraph "Callers (anywhere in app)"
        PROVIDER[Riverpod Provider]
        SERVICE[Module Service]
        INTERCEPTOR[Dio Interceptor]
        CALLBACK[Button Callback]
    end

    PROVIDER --> LS
    SERVICE --> LS
    INTERCEPTOR --> LS
    CALLBACK --> LS
    PROVIDER --> NS
    SERVICE --> NS
    INTERCEPTOR --> NS
    CALLBACK --> NS

    LS --> NAV_KEY --> OVERLAY --> LOADING_UI
    NS --> NAV_KEY --> SHEET --> MODAL_UI
```

### Full Request Lifecycle (Loading + API + Notify)

```mermaid
sequenceDiagram
    participant User
    participant Screen as Screen/Callback
    participant LS as LoadingService
    participant Svc as ModuleService
    participant API as Backend
    participant NS as NotifyService

    User->>Screen: Tap submit button
    Screen->>LS: LoadingService.show()
    Screen->>Svc: service.submitForm(data)
    Svc->>API: POST /submit
    alt Success (200)
        API-->>Svc: 200 OK
        Svc-->>Screen: ApiResponse.success
        Screen->>LS: LoadingService.hide()
        Screen->>NS: NotifyService.success('Saved!')
        NS-->>User: Modal: ✓ Saved! [OK]
    else Error (500)
        API-->>Svc: 500 Error
        Svc-->>Screen: AppException.server
        Screen->>LS: LoadingService.hide()
        Screen->>NS: NotifyService.error('Failed', message: '...')
        NS-->>User: Modal: ✕ Failed [OK]
    else Needs Confirm
        API-->>Svc: 200 + needsConfirm
        Svc-->>Screen: data with warning
        Screen->>LS: LoadingService.hide()
        Screen->>NS: NotifyService.confirm('Proceed?', message: '...')
        NS-->>User: Modal: ? Proceed? [Confirm/Cancel]
        User->>NS: Tap Confirm
        NS-->>Screen: ModalResult.confirmed
        Screen->>LS: LoadingService.show()
        Screen->>Svc: service.confirmSubmit(data)
        Svc->>API: POST /confirm
        API-->>Svc: 200 OK
        Screen->>LS: LoadingService.hide()
        Screen->>NS: NotifyService.success('Done!')
    end
```

## Components and Interfaces

### Component 1: ContainerBase (Built into App — mặc định cho mọi screen)

**Purpose**: SafeArea + ScrollView được tích hợp mặc định vào kiến trúc App, mọi screen tự động có sẵn mà KHÔNG cần khai báo lại.

**Cách hoạt động:**
- `SafeArea` wrap ở cấp App (trong TabScaffold/ShellRoute builder) → mọi screen đều safe cho notch
- `ContainerBase` chỉ là wrapper nhẹ cho phần content: scroll + padding + refresh
- Screen KHÔNG cần tự wrap SafeArea — App đã lo

```dart
/// TabScaffold (ShellRoute builder) — xử lý SafeArea mặc định
class TabScaffold extends StatelessWidget {
  final Widget child;
  const TabScaffold({required this.child});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: child, // <-- Screen content đã được SafeArea wrap
        bottomNavigationBar: const AppBottomTabBar(),
      ),
    );
  }
}

/// ContainerBase — chỉ lo scroll + padding + refresh
/// Dùng cho CONTENT bên trong screen, không lo SafeArea nữa
class ContainerBase extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? backgroundColor;
  final RefreshCallback? onRefresh;
  final ScrollController? scrollController;

  const ContainerBase({
    required this.child,
    this.padding,
    this.backgroundColor,
    this.onRefresh,
    this.scrollController,
  });
}
```

**Mặc định tích hợp (không cần config):**
- ✅ SafeArea (top + bottom) — handled by TabScaffold / Scaffold
- ✅ Scrollable — ContainerBase luôn scroll
- ✅ Keyboard dismiss on tap outside — handled by GestureDetector in ContainerBase
- ✅ Default padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8)

**Screen chỉ cần:**
```dart
// Tab screen — đơn giản nhất
class HomeScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ContainerBase(
      onRefresh: () => ref.read(homeProvider.notifier).refresh(),
      child: Column(children: [...]),
    );
  }
}

// Sub-screen — Scaffold riêng với AppHeader
class DetailScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppHeader(title: 'Detail'),
      body: ContainerBase(
        child: Column(children: [...]),
      ),
    );
  }
}
```

**KHÔNG CẦN truyền:**
- `scrollable` — luôn scroll (nếu cần static dùng `Scaffold(body: ...)` trực tiếp)
- `safeAreaTop` / `safeAreaBottom` — đã xử lý ở App level

---

### Component 2: Custom Bottom Tab Bar

**Purpose**: A custom-painted bottom navigation with SVG curved notch and elevated center button (Home) using ocean blue theme.

```dart
class AppBottomTabBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final List<TabItem> items;

  const AppBottomTabBar({
    required this.currentIndex,
    required this.onTap,
    required this.items,
  });
}

class TabItem {
  final String svgAsset;
  final String svgAssetActive;
  final String label;
  final bool isCenter;

  const TabItem({
    required this.svgAsset,
    required this.svgAssetActive,
    required this.label,
    this.isCenter = false,
  });
}
```

**Responsibilities**:
- Render custom ClipPath with curved notch for center item
- Elevate center tab button (floating above bar)
- Apply ocean blue (#0077B6) to active state
- Support SVG icons via flutter_svg
- Animate tab transitions

---

### Component 3: AppHeader

**Purpose**: Top navigation bar for sub-screens with back button and drawer menu. Drawer navigates to tabs without stacking routes.

```dart
class AppHeader extends StatelessWidget implements PreferredSizeWidget {
  final String? title;
  final Widget? titleWidget;
  final bool showBack;
  final bool showDrawer;
  final List<Widget>? actions;
  final VoidCallback? onBackPressed;

  const AppHeader({
    this.title,
    this.titleWidget,
    this.showBack = true,
    this.showDrawer = true,
    this.actions,
    this.onBackPressed,
  });
}
```

**Responsibilities**:
- Display title (text or custom widget)
- Show back button that pops current route
- Show drawer icon that opens navigation drawer
- Drawer items navigate using `context.go()` (replace, not push) to avoid stacking
- Respect Material 3 AppBar styling

---

### Component 4: AppModal

**Purpose**: Bottom sheet modal with 5 visual types. Type determines layout and icon placement.

```dart
enum ModalType { confirm, success, error, warning, info }

class ModalConfig {
  final ModalType type;
  final String title;
  final String? message;
  final String? confirmText;
  final String? cancelText;
  final Widget? customContent;
  final bool dismissible;

  const ModalConfig({
    required this.type,
    required this.title,
    this.message,
    this.confirmText,
    this.cancelText,
    this.customContent,
    this.dismissible = true,
  });
}

enum ModalResult { confirmed, dismissed }
```

**Layout Rules**:
- `confirm`, `warning`, `info`: Icon + Title in same row (horizontal layout)
- `success`, `error`: Centered icon above title (vertical layout)

---

### Component 5: AppBottomSheet

**Purpose**: Full-featured bottom sheet at 90% screen height with drag handle, fixed header, scrollable content, and sticky action buttons.

```dart
class AppBottomSheet extends StatelessWidget {
  final String title;
  final Widget content;
  final List<Widget>? actions;
  final bool showDragHandle;
  final bool showCloseButton;
  final double heightFactor;

  const AppBottomSheet({
    required this.title,
    required this.content,
    this.actions,
    this.showDragHandle = true,
    this.showCloseButton = true,
    this.heightFactor = 0.9,
  });
}
```

---

### Component 6: AppModalSelect

**Purpose**: Searchable selection bottom sheet with configurable field mapping.

```dart
class AppModalSelect<T> extends StatelessWidget {
  final String title;
  final List<T> items;
  final String Function(T) field;       // Display value
  final String Function(T) fieldName;   // Search/match value
  final T? selectedItem;
  final ValueChanged<T> onSelected;
  final String? searchHint;

  const AppModalSelect({
    required this.title,
    required this.items,
    required this.field,
    required this.fieldName,
    this.selectedItem,
    required this.onSelected,
    this.searchHint,
  });
}
```

---

### Component 7: Loading Service (Imperative)

**Purpose**: Global full-screen loading overlay callable from anywhere — providers, services, interceptors, callbacks. Dùng cùng pattern với NotifyService: `GlobalKey<NavigatorState>` + Overlay.

```dart
/// Imperative loading service — callable from anywhere without BuildContext
class LoadingService {
  static final GlobalKey<NavigatorState> _navigatorKey = NotifyService.navigatorKey;
  static OverlayEntry? _overlayEntry;

  /// Show loading overlay
  static void show() {
    if (_overlayEntry != null) return; // Already showing
    final overlay = _navigatorKey.currentState?.overlay;
    if (overlay == null) return;

    _overlayEntry = OverlayEntry(
      builder: (_) => const _LoadingOverlayWidget(),
    );
    overlay.insert(_overlayEntry!);
  }

  /// Hide loading overlay
  static void hide() {
    _overlayEntry?.remove();
    _overlayEntry = null;
  }
}

/// Alternative: Riverpod provider (for widget-level reactivity)
final loadingProvider = StateProvider<bool>((ref) => false);
```

**2 cách sử dụng:**
```dart
// Cách 1: Imperative (từ service, interceptor, anywhere)
LoadingService.show();
await doWork();
LoadingService.hide();

// Cách 2: Riverpod (từ widget/provider muốn reactive)
ref.read(loadingProvider.notifier).state = true;
await doWork();
ref.read(loadingProvider.notifier).state = false;
```

---

### Component 8: Notification Modal Service (Imperative)

**Purpose**: Global imperative notification service that shows AppModal from anywhere (services, providers, callbacks) — giống `setLoading()` nhưng hiển thị Modal thông báo thay vì overlay. Không phải toast — là Modal bottom sheet slide lên với đủ 5 types.

```dart
/// Imperative notification service — callable from anywhere without BuildContext
/// Uses a global navigator key to show modal from non-widget code.

class NotifyService {
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  /// Show notification modal (imperative, no context needed)
  static Future<ModalResult> show({
    required ModalType type,
    required String title,
    String? message,
    String? confirmText,
    String? cancelText,
    bool dismissible = true,
  });

  /// Shorthand helpers — callable from providers, services, interceptors
  static Future<ModalResult> success(String title, {String? message});
  static Future<ModalResult> error(String title, {String? message});
  static Future<ModalResult> warning(String title, {String? message});
  static Future<ModalResult> info(String title, {String? message});
  static Future<ModalResult> confirm(String title, {String? message, String? confirmText});
}
```

**Cách hoạt động:**
1. `NotifyService` giữ 1 `GlobalKey<NavigatorState>` (được set ở MaterialApp)
2. Khi gọi `NotifyService.success(...)` → dùng `navigatorKey.currentState` để show modal bottom sheet
3. Modal hiển thị đúng layout theo type (giống Component 4: AppModal)
4. Trả về `Future<ModalResult>` để caller có thể await kết quả

**So sánh với loading:**
| Loading | NotifyService |
|---------|--------------|
| `ref.read(loadingProvider.notifier).state = true` | `NotifyService.success('Done', message: '...')` |
| Overlay toàn màn hình | Modal bottom sheet |
| Không có tương tác | Có nút OK/Confirm/Cancel |
| Boolean on/off | Trả về ModalResult |

**Usage từ mọi nơi:**
```dart
// Trong provider
Future<void> submitForm() async {
  ref.read(loadingProvider.notifier).state = true;
  try {
    await service.submit(data);
    await NotifyService.success('Thành công', message: 'Dữ liệu đã được lưu');
  } catch (e) {
    await NotifyService.error('Lỗi', message: e.toString());
  } finally {
    ref.read(loadingProvider.notifier).state = false;
  }
}

// Trong API interceptor
if (response.statusCode == 403) {
  NotifyService.warning('Không có quyền', message: 'Bạn không có quyền truy cập tính năng này');
}

// Confirm trước khi xóa
final result = await NotifyService.confirm('Xóa dữ liệu?', message: 'Hành động không thể hoàn tác');
if (result == ModalResult.confirmed) {
  await service.delete(id);
}
```

**Setup trong App:**
```dart
// app.dart
MaterialApp.router(
  navigatorKey: NotifyService.navigatorKey, // <-- Set global key
  routerConfig: router,
  // ...
);
```

---

### Component 9: Toast Service (Lightweight Notification)

**Purpose**: Toast nhẹ cho các thông báo KHÔNG cần user action — hiển thị nhanh, auto-dismiss. Dùng cho các case KHÔNG phải action từ người dùng gọi API.

**Phân biệt Toast vs NotifyService (Modal):**
| | Toast | NotifyService (Modal) |
|---|-------|----------------------|
| Khi nào dùng | Passive notification (background sync, realtime event, info nhẹ) | User action → API → kết quả (success/error/confirm) |
| Cần user tương tác? | Không — auto dismiss | Có — phải tap OK/Confirm |
| Blocking UI? | Không | Có (modal bottom sheet) |
| Ví dụ | "Có tin nhắn mới", "Đã đồng bộ", "Mất kết nối" | "Lưu thành công!", "Xóa thất bại", "Xác nhận xóa?" |

```dart
/// Toast Service — dùng fluttertoast package
/// Imperative, callable from anywhere
class AppToast {
  static void show(String message, {ToastType type = ToastType.info});
  static void success(String message);
  static void error(String message);
  static void warning(String message);
  static void info(String message);
}

enum ToastType { success, error, warning, info }
```

**Usage:**
```dart
// Passive notification — không cần user confirm
AppToast.info('Có 3 tin nhắn mới');
AppToast.warning('Mất kết nối mạng');

// Active notification — user gọi API → dùng NotifyService MODAL
await NotifyService.success('Đã lưu thành công');
final result = await NotifyService.confirm('Xác nhận xóa?');
```

## Data Models

### ApiResponse Model

```dart
@freezed
class ApiResponse<T> with _$ApiResponse<T> {
  const factory ApiResponse.success({
    required T data,
    String? message,
  }) = ApiSuccess<T>;

  const factory ApiResponse.error({
    required String message,
    int? statusCode,
    Map<String, dynamic>? errors,
  }) = ApiError<T>;
}
```

### AppException Model

```dart
@freezed
class AppException with _$AppException {
  const factory AppException.network({String? message}) = NetworkException;
  const factory AppException.unauthorized({String? message}) = UnauthorizedException;
  const factory AppException.server({String? message, int? statusCode}) = ServerException;
  const factory AppException.validation({
    required Map<String, List<String>> errors,
  }) = ValidationException;
  const factory AppException.unknown({String? message}) = UnknownException;
}
```

### Environment Config Model

```dart
@freezed
class EnvConfig with _$EnvConfig {
  const factory EnvConfig({
    required String apiBaseUrl,
    required String appName,
    required String environment, // dev, staging, prod
    @Default(false) bool enableLogging,
    String? sentryDsn,
  }) = _EnvConfig;
}
```

**Validation Rules**:
- `apiBaseUrl` must be a valid URL (starts with http:// or https://)
- `environment` must be one of: dev, staging, prod
- `appName` must not be empty

### Theme Config

```dart
class AppColors {
  // Primary ocean blue
  static const Color primary = Color(0xFF0077B6);
  static const Color primaryLight = Color(0xFF00B4D8);
  static const Color primaryDark = Color(0xFF023E8A);

  // Semantic colors
  static const Color success = Color(0xFF2E7D32);
  static const Color error = Color(0xFFD32F2F);
  static const Color warning = Color(0xFFF57C00);
  static const Color info = Color(0xFF0288D1);

  // Neutrals
  static const Color background = Color(0xFFF8F9FA);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF1A1A2E);
  static const Color textSecondary = Color(0xFF6C757D);
}
```


## Algorithmic Pseudocode

### App Bootstrap Algorithm

```dart
/// ALGORITHM: Application Bootstrap
/// INPUT: none
/// OUTPUT: Running Flutter application with all providers initialized
///
/// Preconditions:
///   - pubspec.yaml dependencies resolved
///   - .env file exists for current environment
///   - Flutter binding available
///
/// Postconditions:
///   - EnvConfig loaded and validated
///   - ProviderScope wraps entire app
///   - GoRouter initialized with all routes
///   - Theme applied based on system/user preference
///   - Localizations loaded (vi/en)

Future<void> bootstrap() async {
  // Step 1: Ensure Flutter bindings
  WidgetsFlutterBinding.ensureInitialized();

  // Step 2: Load environment config
  final envConfig = await EnvConfig.load();
  assert(envConfig.apiBaseUrl.isNotEmpty);
  assert(['dev', 'staging', 'prod'].contains(envConfig.environment));

  // Step 3: Initialize services that need early setup
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // Step 4: Run app with provider scope
  runApp(
    ProviderScope(
      overrides: [
        envConfigProvider.overrideWithValue(envConfig),
      ],
      child: const App(),
    ),
  );
}
```

### Router Configuration Algorithm

```dart
/// ALGORITHM: Router with Shell Route for Tab Persistence
/// INPUT: Authentication state, current tab index
/// OUTPUT: Configured GoRouter with guards and nested navigation
///
/// Preconditions:
///   - All module route paths defined
///   - AuthState provider available
///
/// Postconditions:
///   - Unauthenticated users redirected to /login
///   - Tab state preserved across navigation
///   - Sub-screens render within tab's navigator
///   - Deep links resolve to correct tab + sub-screen
///
/// Loop Invariants:
///   - Shell route always wraps tab screens
///   - Navigation stack per tab is independent

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: '/home',
    redirect: (context, state) {
      final isAuthenticated = authState.isAuthenticated;
      final isAuthRoute = state.matchedLocation.startsWith('/login');

      if (!isAuthenticated && !isAuthRoute) return '/login';
      if (isAuthenticated && isAuthRoute) return '/home';
      return null;
    },
    routes: [
      ShellRoute(
        builder: (context, state, child) => TabScaffold(child: child),
        routes: [
          GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
          GoRoute(path: '/messages', builder: (_, __) => const MessagesScreen()),
          GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
          GoRoute(path: '/account', builder: (_, __) => const AccountScreen()),
          GoRoute(path: '/settings', builder: (_, __) => const SettingsScreen()),
        ],
      ),
      // Sub-routes outside shell (with AppHeader)
      GoRoute(path: '/home/detail/:id', builder: (_, state) => DetailScreen(id: state.pathParameters['id']!)),
    ],
  );
});
```

### Dio Client Initialization Algorithm

```dart
/// ALGORITHM: DioClient with Interceptor Chain
/// INPUT: EnvConfig (baseUrl, tokens)
/// OUTPUT: Configured Dio instance with auth, error, and logging interceptors
///
/// Preconditions:
///   - EnvConfig.apiBaseUrl is valid URL
///   - Token storage service available
///
/// Postconditions:
///   - All requests include Authorization header if token exists
///   - 401 responses trigger token refresh + retry (max 1 retry)
///   - All errors normalized to AppException
///   - Request/Response logged in dev mode
///
/// Invariants:
///   - Token refresh is atomic (no concurrent refresh calls)
///   - Original request queue processed after refresh

class DioClient {
  late final Dio _dio;
  final Ref _ref;
  bool _isRefreshing = false;
  final List<RequestOptions> _pendingRequests = [];

  DioClient(this._ref) {
    final env = _ref.read(envConfigProvider);

    _dio = Dio(BaseOptions(
      baseUrl: env.apiBaseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {'Content-Type': 'application/json'},
    ));

    _dio.interceptors.addAll([
      _authInterceptor(),
      _errorInterceptor(),
      if (env.enableLogging) LogInterceptor(),
    ]);
  }

  Interceptor _authInterceptor() => InterceptorsWrapper(
    onRequest: (options, handler) async {
      final token = await _ref.read(tokenStorageProvider).getAccessToken();
      if (token != null) {
        options.headers['Authorization'] = 'Bearer $token';
      }
      handler.next(options);
    },
    onError: (error, handler) async {
      if (error.response?.statusCode == 401 && !_isRefreshing) {
        _isRefreshing = true;
        try {
          final newToken = await _refreshToken();
          if (newToken != null) {
            // Retry original request
            error.requestOptions.headers['Authorization'] = 'Bearer $newToken';
            final response = await _dio.fetch(error.requestOptions);
            handler.resolve(response);
          } else {
            _ref.read(authStateProvider.notifier).logout();
            handler.next(error);
          }
        } finally {
          _isRefreshing = false;
        }
      } else {
        handler.next(error);
      }
    },
  );

  Interceptor _errorInterceptor() => InterceptorsWrapper(
    onError: (error, handler) {
      final exception = _mapToAppException(error);
      handler.reject(DioException(
        requestOptions: error.requestOptions,
        error: exception,
      ));
    },
  );

  AppException _mapToAppException(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return const AppException.network(message: 'Connection timeout');
      case DioExceptionType.connectionError:
        return const AppException.network(message: 'No internet connection');
      case DioExceptionType.badResponse:
        final statusCode = error.response?.statusCode;
        if (statusCode == 401) {
          return const AppException.unauthorized();
        } else if (statusCode == 422) {
          final errors = error.response?.data['errors'] as Map<String, dynamic>?;
          return AppException.validation(errors: errors?.map(
            (k, v) => MapEntry(k, List<String>.from(v)),
          ) ?? {});
        }
        return AppException.server(statusCode: statusCode);
      default:
        return const AppException.unknown();
    }
  }
}
```

### Theme System Algorithm

```dart
/// ALGORITHM: Material 3 Theme Generation
/// INPUT: ThemeMode (light/dark/system), primary color seed
/// OUTPUT: Complete ThemeData with custom color scheme and typography
///
/// Preconditions:
///   - Primary color defined (ocean blue #0077B6)
///   - Typography scale defined
///
/// Postconditions:
///   - ColorScheme generated from seed color
///   - All component themes use color scheme tokens
///   - Typography uses defined font family and scale
///   - Dark theme inverts appropriately without losing brand identity

class AppTheme {
  static ThemeData light() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: Brightness.light,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.background,
      textTheme: AppTypography.textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: colorScheme.surface,
        foregroundColor: colorScheme.onSurface,
        elevation: 0,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: colorScheme.surface,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textSecondary,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        ),
      ),
    );
  }

  static ThemeData dark() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: Brightness.dark,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      textTheme: AppTypography.textTheme,
      // ... dark overrides
    );
  }
}
```

## Key Functions with Formal Specifications

### Function: ContainerBase.build()

```dart
Widget build(BuildContext context)
```

**Preconditions:**
- `child` is a non-null Widget
- `context` has access to MediaQuery (for SafeArea)

**Postconditions:**
- Returns widget tree: GestureDetector > SafeArea > (ScrollView | child)
- If `scrollable == true`: child wrapped in SingleChildScrollView
- If `onRefresh != null`: wrapped in RefreshIndicator
- SafeArea respects `safeAreaTop` and `safeAreaBottom` flags
- Default padding applied: EdgeInsets.symmetric(horizontal: 16)
- GestureDetector unfocuses keyboard on tap outside text fields

**Loop Invariants:** N/A

---

### Function: AppModal.show()

```dart
static Future<ModalResult> show(BuildContext context, ModalConfig config)
```

**Preconditions:**
- `context` is mounted and has a Navigator ancestor
- `config.type` is a valid ModalType enum value
- `config.title` is non-empty

**Postconditions:**
- Returns `ModalResult.confirmed` if user taps confirm button
- Returns `ModalResult.dismissed` if user taps cancel, back button, or taps outside (when dismissible)
- Modal layout matches type: horizontal (confirm/warning/info) or vertical (success/error)
- Modal is removed from widget tree after result returned

**Loop Invariants:** N/A

---

### Function: DioClient.request()

```dart
Future<ApiResponse<T>> request<T>(
  String path, {
  required T Function(Map<String, dynamic>) fromJson,
  String method = 'GET',
  Map<String, dynamic>? data,
  Map<String, dynamic>? queryParameters,
})
```

**Preconditions:**
- `path` is non-empty string (relative to baseUrl)
- `fromJson` correctly deserializes response data to type T
- Network connectivity available (or error thrown)

**Postconditions:**
- On success: returns `ApiResponse.success(data: T)`
- On failure: returns `ApiResponse.error(message, statusCode)`
- Auth token automatically attached if available
- 401 triggers one token refresh attempt before failing
- All DioExceptions mapped to AppException subtypes

**Loop Invariants:**
- Token refresh retry executes at most once per request

---

### Function: GoRouter redirect guard

```dart
String? redirect(BuildContext context, GoRouterState state)
```

**Preconditions:**
- `authState` provider is initialized
- Route paths are well-formed

**Postconditions:**
- If user is NOT authenticated AND route is NOT auth route → returns '/login'
- If user IS authenticated AND route IS auth route → returns '/home'
- Otherwise → returns null (no redirect)
- Redirect is evaluated on every navigation event

**Loop Invariants:** N/A

## Example Usage

### Screen using ContainerBase (Tab Screen — NO AppHeader)

```dart
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ContainerBase(
      onRefresh: () async {
        await ref.read(homeDataProvider.notifier).refresh();
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Welcome', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 16),
          // ... content
        ],
      ),
    );
  }
}
```

### Sub-screen with AppHeader

```dart
class DetailScreen extends ConsumerWidget {
  final String id;
  const DetailScreen({required this.id, super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppHeader(title: 'Detail'),
      body: ContainerBase(
        child: // ... detail content
      ),
    );
  }
}
```

### Showing a Modal

```dart
final result = await AppModal.show(
  context,
  ModalConfig(
    type: ModalType.confirm,
    title: 'Delete item?',
    message: 'This action cannot be undone.',
    confirmText: 'Delete',
    cancelText: 'Cancel',
  ),
);

if (result == ModalResult.confirmed) {
  await ref.read(itemProvider.notifier).delete(itemId);
}
```

### Using AppModalSelect

```dart
await AppModalSelect.show<Student>(
  context,
  title: 'Select Student',
  items: students,
  field: (s) => s.fullName,
  fieldName: (s) => s.studentId,
  selectedItem: currentStudent,
  onSelected: (student) {
    ref.read(selectedStudentProvider.notifier).state = student;
  },
);
```

### API Service in a Module

```dart
class HomeService {
  final DioClient _client;

  HomeService(this._client);

  Future<ApiResponse<List<Announcement>>> getAnnouncements() {
    return _client.request<List<Announcement>>(
      '/announcements',
      fromJson: (json) => (json['data'] as List)
          .map((e) => Announcement.fromJson(e))
          .toList(),
    );
  }
}

// Provider
final homeServiceProvider = Provider<HomeService>((ref) {
  return HomeService(ref.read(dioClientProvider));
});

// AsyncNotifier usage
final announcementsProvider = AsyncNotifierProvider<AnnouncementsNotifier, List<Announcement>>(
  AnnouncementsNotifier.new,
);

class AnnouncementsNotifier extends AsyncNotifier<List<Announcement>> {
  @override
  Future<List<Announcement>> build() async {
    final response = await ref.read(homeServiceProvider).getAnnouncements();
    return response.when(
      success: (data, _) => data,
      error: (message, _, __) => throw AppException.server(message: message),
    );
  }

  Future<void> refresh() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => build());
  }
}
```

### Loading Overlay Usage

```dart
// In a provider or callback
Future<void> submitForm() async {
  ref.read(loadingProvider.notifier).state = true;
  try {
    await ref.read(formServiceProvider).submit(formData);
    ToastService.success(context, 'Form submitted successfully');
  } on AppException catch (e) {
    ToastService.error(context, e.message ?? 'Submission failed');
  } finally {
    ref.read(loadingProvider.notifier).state = false;
  }
}
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Environment Validation

*For any* EnvConfig input map, the validation shall accept only configs where apiBaseUrl starts with "http://" or "https://", environment is one of "dev"/"staging"/"prod", and appName is non-empty — all other inputs shall be rejected with an assertion error.

**Validates: Requirements 1.3, 1.4, 1.5, 1.6**

### Property 2: Auth Redirect Correctness

*For any* pair of (authState, routePath), the GoRouter redirect function shall return "/login" when unauthenticated and accessing a protected route, return "/home" when authenticated and accessing an auth route, and return null otherwise.

**Validates: Requirements 2.3, 2.4**

### Property 3: Tab Navigation Isolation

*For any* sequence of navigations within a tab T, the navigation stack of all other tabs shall remain unchanged.

**Validates: Requirement 2.2**

### Property 4: Modal Type Layout Consistency

*For any* ModalConfig where type is confirm, warning, or info, the AppModal shall render icon and title in a horizontal Row layout. *For any* ModalConfig where type is success or error, the AppModal shall render icon centered above title in a vertical Column layout.

**Validates: Requirements 6.2, 6.3**

### Property 5: Loading Overlay Idempotence

*For any* sequence of LoadingService.show() calls without intervening hide() calls, at most one loading overlay shall be visible at any time (calling show() while already showing is a no-op).

**Validates: Requirement 9.3**

### Property 6: Token Refresh Atomicity

*For any* set of concurrent requests R1...Rn that all receive 401 responses, the DioClient shall execute exactly one token refresh operation and retry all pending requests with the new token.

**Validates: Requirements 12.2, 12.7**

### Property 7: API Error Mapping Completeness

*For any* DioException E of any type (timeout, connectionError, badResponse with any status code, or unknown), the _mapToAppException function shall return a valid AppException subtype and never throw an exception itself.

**Validates: Requirement 12.4**

### Property 8: Auth Header Attachment

*For any* HTTP request made through the DioClient while an access token exists in secure storage, the request headers shall include an "Authorization" field with value "Bearer {token}".

**Validates: Requirement 12.1**

### Property 9: Serialization Round-Trip

*For any* valid model instance (ApiResponse, AppException, EnvConfig), calling toJson() then fromJson() on the result shall produce an object equivalent to the original instance.

**Validates: Requirements 13.4, 13.5**

### Property 10: AppModalSelect Filtering

*For any* list of items and any search query string, the filtered results from AppModalSelect shall contain only items whose fieldName value contains the search query (case-insensitive match).

**Validates: Requirement 8.2**

### Property 11: Drawer Navigation No-Stack

*For any* drawer menu item in AppHeader, tapping the item shall execute context.go(path) ensuring the route is replaced (not pushed), preventing route stacking when switching between sections.

**Validates: Requirement 5.4**

### Property 12: AppBottomSheet Height Constraint

*For any* AppBottomSheet rendered on any screen size, its height shall not exceed 0.9 × screen height (the heightFactor default).

**Validates: Requirement 7.1**

### Property 13: i18n Completeness

*For all* user-visible translation keys defined in the i18n system, both Vietnamese (vi) and English (en) locale files shall contain a non-empty translation value.

**Validates: Requirement 15.2**

### Property 14: Theme Brand Identity

*For any* theme mode (light or dark), the generated ThemeData shall use ocean blue (#0077B6) as the primary seed color, maintaining brand identity across both modes.

**Validates: Requirement 14.5**

## Error Handling

### Error Scenario 1: Network Unavailable

**Condition**: Device has no internet connectivity
**Response**: DioClient throws `AppException.network(message: 'No internet connection')`
**Recovery**: Screen displays retry button; user can pull-to-refresh when connection restored

### Error Scenario 2: Token Expired (401)

**Condition**: API returns 401 Unauthorized
**Response**: AuthInterceptor attempts one token refresh via refresh token endpoint
**Recovery**: 
- If refresh succeeds: original request retried transparently
- If refresh fails: user logged out, redirected to /login, tokens cleared

### Error Scenario 3: Validation Error (422)

**Condition**: API returns 422 with field-level errors
**Response**: `AppException.validation(errors: Map<String, List<String>>)` propagated to form
**Recovery**: Form fields display inline error messages; user corrects and resubmits

### Error Scenario 4: Server Error (5xx)

**Condition**: API returns 500, 502, 503, etc.
**Response**: `AppException.server(statusCode: code)` with generic message
**Recovery**: Toast displays "Something went wrong. Please try again later." User can retry.

### Error Scenario 5: Missing Environment Variable

**Condition**: Required .env variable is empty or missing at startup
**Response**: App throws assertion error during bootstrap (fail-fast)
**Recovery**: Developer must fix .env file; app will not start in broken state

## Testing Strategy

### Unit Testing Approach

- Test all Riverpod providers in isolation using `ProviderContainer`
- Test DioClient interceptors with mock Dio adapters
- Test GoRouter redirect logic with mock auth states
- Test Freezed model serialization/deserialization
- Coverage goal: 80%+ for services and providers

### Property-Based Testing Approach

**Property Test Library**: `glados` (Dart property-based testing)

- API error mapping: ∀ DioException, output is valid AppException subtype
- Theme generation: ∀ seed color, both light and dark themes produce valid ColorScheme
- Router redirect: ∀ (authState, routePath) pair, redirect produces correct target or null
- EnvConfig validation: ∀ valid .env file, EnvConfig.load() produces valid config

### Widget Testing Approach

- Test ContainerBase renders SafeArea correctly with various configurations
- Test AppModal displays correct layout per ModalType
- Test AppBottomTabBar highlights correct tab on index change
- Test AppHeader drawer navigation uses `go()` not `push()`
- Test LoadingOverlay visibility matches provider state

### Integration Testing Approach

- Full bootstrap flow: env load → provider init → router → first screen
- Auth flow: login → token stored → protected route accessible → logout → redirect
- Tab navigation: switch tabs → verify state preserved → navigate sub-screen → back to tab

## Performance Considerations

- **Lazy loading**: Module providers use `autoDispose` to release memory when screens are popped
- **Image caching**: Use `cached_network_image` for all remote images
- **List rendering**: Use `ListView.builder` (never `ListView(children:)`) for dynamic lists
- **Build minimization**: Use `const` constructors, `select` on providers to limit rebuilds
- **Tab persistence**: ShellRoute keeps tab widgets alive; no rebuild on tab switch
- **Debounce search**: AppModalSelect debounces search input (300ms) to avoid excessive filtering

## Security Considerations

- **Token storage**: Access token and refresh token stored in `flutter_secure_storage` (Keychain/Keystore)
- **Certificate pinning**: Optional Dio interceptor for certificate pinning in production
- **No secrets in code**: All sensitive values loaded from .env (gitignored)
- **Input sanitization**: All user inputs validated before API submission
- **Biometric lock**: Optional biometric authentication for sensitive screens (future)
- **Obfuscation**: Release builds use `--obfuscate --split-debug-info` flags

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| flutter_riverpod | ^2.4.0 | State management + DI |
| riverpod_annotation | ^2.3.0 | Code generation for providers |
| go_router | ^13.0.0 | Declarative navigation |
| dio | ^5.4.0 | HTTP client |
| freezed | ^2.4.0 | Immutable data classes (dev) |
| freezed_annotation | ^2.4.0 | Freezed annotations |
| json_serializable | ^6.7.0 | JSON serialization (dev) |
| json_annotation | ^4.8.0 | JSON annotations |
| flutter_svg | ^2.0.0 | SVG rendering |
| flutter_localizations | sdk | i18n support |
| intl | ^0.18.0 | Internationalization utilities |
| flutter_secure_storage | ^9.0.0 | Secure token storage |
| flutter_dotenv | ^5.1.0 | .env file loading |
| cached_network_image | ^3.3.0 | Image caching |
| shimmer | ^3.0.0 | Skeleton loading effect (shimmer animation) |
| fluttertoast | ^8.2.0 | Toast notification (nhẹ, auto-dismiss, không modal) |
| shorebird_code_push | ^1.0.0 | OTA code push — đẩy update trực tiếp không qua store |
| build_runner | ^2.4.0 | Code generation (dev) |
| riverpod_generator | ^2.3.0 | Provider code gen (dev) |
| glados | ^0.5.0 | Property-based testing (dev) |
| mocktail | ^1.0.0 | Mocking for tests (dev) |
