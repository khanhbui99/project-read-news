---
inclusion: fileMatch
fileMatchPattern: "src/**/*"
---

# Web Project Structure Rules (Chỉ áp dụng cho source web)

Quy tắc cấu trúc CHỈ cho phần web (source tại root `src/`). KHÔNG áp dụng cho `mobile/`.

## Cấu trúc thư mục Web

```
src/
├── app/              # App bootstrap (providers, router, entry)
├── layouts/          # Layout components (EndUser, Admin)
├── modules/          # Business modules (feature-based)
├── shared/           # Shared/reusable code (cross-module)
├── styles/           # Global styles, theme, media helpers
├── assets/           # Static files (images, fonts, icons)
└── test/             # Test setup
```

## Quy tắc KHÔNG ĐƯỢC vi phạm

### 1. Layouts phải nằm trong `src/layouts/`
- KHÔNG đặt layout trong `src/shared/components/layouts/`
- KHÔNG đặt layout trong `src/modules/`
- Layout = EndUserLayout, AdminLayout, AuthLayout...

### 2. Pages phải nằm trong module
- KHÔNG tạo page ở `src/shared/` hoặc `src/app/`
- Mọi page phải thuộc 1 module: `src/modules/{name}/pages/`
- Pages dùng chung (404, 500) → `src/modules/common/pages/`

### 3. Routes quản lý tại `src/app/AppRouter.tsx`
- KHÔNG tạo file router riêng ở module (chỉ export routes config)
- Mọi route đăng ký tập trung tại AppRouter
- Mỗi module CÓ THỂ có `routes.ts` để export route config, nhưng đăng ký cuối cùng luôn ở AppRouter

### 4. Module structure bắt buộc
Khi tạo module mới, LUÔN tạo đủ cấu trúc:
```
src/modules/{name}/
├── components/     # Module-specific components
├── hooks/          # Module hooks (queries, mutations)
├── services/       # API service functions
├── stores/         # Zustand stores
├── pages/          # Page components (route targets)
├── styles/
│   └── index.ts   # Styled-components tập trung
├── routes.ts       # Route definitions (optional)
└── index.ts        # Public API exports
```

### 5. Shared layer chỉ chứa code dùng chung
- `src/shared/components/` — UI components dùng chung (AppButton, AppInput, Modal...)
- `src/shared/hooks/` — Hooks dùng chung (useTheme, useDebounce...)
- `src/shared/services/` — Services dùng chung (apiClient, loading, modal)
- `src/shared/utils/` — Pure utility functions
- `src/shared/types/` — TypeScript types/interfaces dùng chung
- `src/shared/config/` — App configuration (env)
- `src/shared/i18n/` — Internationalization
- KHÔNG đặt pages, layouts, hoặc business logic ở shared

### 6. Styles
- Global theme, media helpers → `src/styles/`
- Module-specific styles → `src/modules/{name}/styles/index.ts`
- KHÔNG tạo file `.css` rời — dùng styled-components

### 7. Import rules
- Cross-module: chỉ import qua `index.ts` public API
- KHÔNG import trực tiếp vào internal files của module khác
- Shared components: `import { AppButton } from '@/shared/components'`
- Layouts: `import { AdminLayout } from '@/layouts/AdminLayout'`
- Theme/Media: `import { media } from '@/styles/media'`

### 8. Naming conventions
- Components: PascalCase (`AppButton.tsx`, `ModalConfirm.tsx`)
- Pages: PascalCase + `Page` suffix (`NotFoundPage.tsx`, `ExampleCRUDPage.tsx`)
- Hooks: camelCase + `use` prefix (`useTheme.ts`, `useExampleQuery.ts`)
- Stores: camelCase + `Store` suffix (`exampleStore.ts`)
- Services: camelCase + `Service` suffix (`apiClient.ts`, `loadingService.ts`)
- Styles: luôn đặt tại `styles/index.ts`

### 9. Không tạo folder mới ngoài cấu trúc
- KHÔNG tạo `src/pages/`, `src/components/`, `src/hooks/` ở root
- KHÔNG tạo `src/lib/`, `src/helpers/`, `src/constants/` — dùng `src/shared/utils/`
- KHÔNG tạo `src/store/` — mỗi module quản lý store riêng

### 10. Environment & Config
- `.env.*` files ở project root
- Typed env access qua `src/shared/config/env.ts`
- KHÔNG hardcode URLs hoặc secrets
