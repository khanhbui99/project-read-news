---
inclusion: fileMatch
fileMatchPattern: "src/modules/**/*"
---

# Module Styles Rule

## Quy tắc bắt buộc

Mỗi module (`src/modules/{name}/`) PHẢI có một file `styles/index.ts` để quản lý tập trung tất cả styled-components dùng chung trong module đó.

## Cấu trúc module chuẩn

```
src/modules/{module-name}/
├── components/
├── hooks/
├── services/
├── stores/
├── pages/
├── styles/
│   └── index.ts    ← Quản lý styles tập trung
├── routes.ts
└── index.ts
```

## Quy tắc sử dụng

1. **KHÔNG** define styled-components inline trong component nếu chúng được dùng ở nhiều nơi trong module
2. **LUÔN** đặt styled-components dùng chung tại `styles/index.ts` của module
3. **IMPORT** từ `../styles` khi sử dụng trong pages/components cùng module
4. Styled-components chỉ dùng trong 1 component DUY NHẤT thì ĐƯỢC phép define inline (hoặc extend từ styles)
5. Khi tạo module mới, LUÔN tạo kèm thư mục `styles/index.ts`
6. Keyframes animations cũng đặt tại `styles/index.ts` và export để page/component import

## Template cho styles/index.ts

```typescript
import styled, { keyframes } from 'styled-components';
import { media } from '@/styles/media';

/**
 * Module Styles — {ModuleName}
 * Nơi quản lý tập trung styles cho module này.
 */

export const ModuleContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${({ theme }) => theme.spacing(3)};
`;

// Thêm các styled-components dùng chung ở đây...
```

## Ví dụ đúng

```typescript
// modules/users/pages/UserListPage.tsx
import { ModuleContainer, ModuleHeader, ModuleTitle } from '../styles';
import { AppButton } from '@/shared/components';

export default function UserListPage() {
  return (
    <ModuleContainer>
      <ModuleHeader>
        <ModuleTitle>Users</ModuleTitle>
        <AppButton>Create</AppButton>
      </ModuleHeader>
    </ModuleContainer>
  );
}
```

## Ví dụ SAI

```typescript
// ❌ KHÔNG LÀM: define styled dùng chung ngay trong component
const Container = styled.div`...`; // Nếu dùng ở nhiều nơi → chuyển vào styles/
const Title = styled.h1`...`;      // Nếu dùng ở nhiều nơi → chuyển vào styles/
```

## Khi cần extend style từ module styles

```typescript
// ✅ ĐÚNG: extend từ shared style khi cần customize nhẹ
import { ErrorCode } from '../styles';
import styled from 'styled-components';

const AnimatedCode = styled(ErrorCode)`
  animation: ${glitch} 3s infinite;
`;
```
