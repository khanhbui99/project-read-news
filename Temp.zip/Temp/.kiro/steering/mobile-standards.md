---
inclusion: manual
---

# React Native Mobile Standards

Rule chuẩn cho repo mobile (React Native). Áp dụng khi team làm việc trên source mobile.
Mục tiêu: giữ nhất quán patterns giữa web và mobile để team dễ chuyển đổi.

## Cấu trúc thư mục Mobile (phải giống logic web)

```
mobile/
├── src/
│   ├── app/                # App entry, providers, navigation
│   │   ├── App.tsx
│   │   ├── providers.tsx   # Giống web: QueryClient, ThemeProvider, I18n
│   │   └── AppNavigator.tsx  # Thay thế AppRouter.tsx (React Navigation)
│   ├── modules/            # Business modules (GIỐNG web)
│   │   ├── common/
│   │   │   ├── screens/    # Thay "pages" → "screens" cho mobile
│   │   │   └── styles/
│   │   ├── example/
│   │   │   ├── components/
│   │   │   ├── hooks/      # SHARE ĐƯỢC — copy từ web
│   │   │   ├── services/   # SHARE ĐƯỢC — copy từ web
│   │   │   ├── stores/     # SHARE ĐƯỢC — copy từ web
│   │   │   ├── screens/
│   │   │   ├── styles/
│   │   │   └── index.ts
│   │   └── examples/
│   ├── shared/             # Shared code
│   │   ├── components/     # Mobile UI components (AppButton, AppText...)
│   │   ├── hooks/          # SHARE ĐƯỢC — useTheme, custom hooks
│   │   ├── services/       # SHARE ĐƯỢC — apiClient, loading, modal
│   │   ├── utils/          # SHARE ĐƯỢC — pure functions
│   │   ├── types/          # SHARE ĐƯỢC — TypeScript types
│   │   ├── config/         # SHARE ĐƯỢC — env validation
│   │   └── i18n/           # SHARE ĐƯỢC — translations
│   ├── navigation/         # React Navigation setup (thay layouts/)
│   │   ├── TabNavigator.tsx
│   │   ├── StackNavigator.tsx
│   │   └── types.ts
│   ├── theme/              # Thay styles/ — React Native theme
│   │   ├── theme.ts        # Colors, spacing, typography (SHARE tokens)
│   │   ├── spacing.ts
│   │   └── typography.ts
│   └── assets/
├── package.json
├── tsconfig.json
├── app.json
└── .kiro/
    └── steering/           # Mobile-specific rules
```

## Mapping Web → Mobile

| Web | Mobile | Share được? |
|-----|--------|-------------|
| `src/app/AppRouter.tsx` | `src/app/AppNavigator.tsx` | ❌ Logic khác |
| `src/layouts/` | `src/navigation/` | ❌ Concept khác |
| `src/modules/{name}/pages/` | `src/modules/{name}/screens/` | ❌ UI khác |
| `src/modules/{name}/hooks/` | `src/modules/{name}/hooks/` | ✅ Copy nguyên |
| `src/modules/{name}/services/` | `src/modules/{name}/services/` | ✅ Copy nguyên |
| `src/modules/{name}/stores/` | `src/modules/{name}/stores/` | ✅ Copy nguyên |
| `src/modules/{name}/styles/` | `src/modules/{name}/styles/` | ❌ StyleSheet vs styled |
| `src/shared/types/` | `src/shared/types/` | ✅ Copy nguyên |
| `src/shared/services/apiClient.ts` | `src/shared/services/apiClient.ts` | ✅ Copy nguyên |
| `src/shared/config/env.ts` | `src/shared/config/env.ts` | ⚠️ Cần adjust import.meta → process.env |
| `src/shared/i18n/` | `src/shared/i18n/` | ✅ Copy nguyên |
| `src/styles/theme.ts` | `src/theme/theme.ts` | ⚠️ Same tokens, different format |
| `styled-components` | `StyleSheet.create` | ❌ Khác hoàn toàn |

## Quy tắc đồng bộ giữa 2 repo

### 1. Types/Interfaces PHẢI giống nhau
```typescript
// Cả web và mobile đều dùng CÙNG interface
interface User {
  id: string;
  name: string;
  email: string;
}
```
→ Khi thay đổi type ở web, PHẢI update ở mobile và ngược lại.

### 2. API Services PHẢI giống nhau
```typescript
// Cùng pattern, cùng endpoints
export const userService = {
  getAll: () => apiClient.get<User[]>('/users'),
  getById: (id: string) => apiClient.get<User>(`/users/${id}`),
};
```

### 3. Zustand Stores PHẢI giống nhau
```typescript
// Cùng state shape, cùng actions
export const useAuthStore = create<AuthState>((set) => ({...}));
```

### 4. Zod Schemas PHẢI giống nhau
```typescript
// Cùng validation rules
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});
```

### 5. i18n translations PHẢI giống nhau
- Cùng key structure
- Cùng file format (JSON)

## Mobile-Specific Patterns

### Navigation (thay Router)
```typescript
// src/app/AppNavigator.tsx
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator<RootStackParamList>();

export function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
```

### Styling (thay styled-components)
```typescript
// modules/{name}/styles/index.ts
import { StyleSheet } from 'react-native';
import { theme } from '@/theme/theme';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    padding: theme.spacing(3),
  },
  title: {
    fontSize: theme.typography.fontSize['2xl'],
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.text,
  },
});
```

### Theme tokens (share format)
```typescript
// src/theme/theme.ts — PHẢI dùng cùng color values với web
export const theme = {
  colors: {
    primary: '#6366F1',       // Giống web
    primaryLight: '#EEF2FF',
    background: '#FAFAF9',
    // ... tất cả tokens giống web theme.ts
  },
  spacing: (factor: number) => factor * 8,
  typography: {
    fontSize: { base: 16, lg: 18, xl: 20, '2xl': 24 },
    fontWeight: { normal: '400', semibold: '600', bold: '700' },
  },
};
```

## Naming Convention Mobile

| Item | Convention | Example |
|------|-----------|---------|
| Screen | PascalCase + `Screen` | `HomeScreen.tsx`, `LoginScreen.tsx` |
| Navigator | PascalCase + `Navigator` | `TabNavigator.tsx` |
| Hook | camelCase + `use` | `useAuth.ts` (giống web) |
| Service | camelCase + `Service` | `authService.ts` (giống web) |
| Store | camelCase + `Store` | `authStore.ts` (giống web) |
| Styles | `styles` export | `styles/index.ts` (StyleSheet.create) |

## Checklist khi tạo feature mới

- [ ] Tạo trên web trước
- [ ] Extract shared code (types, services, stores, schemas)
- [ ] Tạo trên mobile với cùng module name
- [ ] Verify types/services/stores match 100%
- [ ] UI riêng cho mỗi platform
