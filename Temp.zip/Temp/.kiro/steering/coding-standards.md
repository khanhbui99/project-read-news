---
inclusion: auto
---

# Coding Standards — Team Rules (CHUNG cho cả Web + Mobile)

Quy tắc lập trình chuẩn cho toàn team. Áp dụng cho CẢ web và mobile.

## 1. TypeScript Rules

- KHÔNG dùng `any` — dùng `unknown` + type guard nếu cần
- KHÔNG dùng `// @ts-ignore` hoặc `// @ts-nocheck`
- Interface cho props, Type cho unions/primitives
- Export types cùng với component nếu cần dùng bên ngoài
- Dùng `type` inference từ Zod: `type FormData = z.infer<typeof schema>`

## 2. Module Structure (cả web và mobile)

Mỗi module PHẢI có cấu trúc:
```
modules/{name}/
├── components/
├── hooks/
├── services/
├── stores/
├── pages/ (web) hoặc screens/ (mobile)
├── styles/
│   └── index.ts
└── index.ts
```

## 3. Service Layer Pattern (SHARED giữa web + mobile)

```typescript
export const userService = {
  getAll: () => apiClient.get<User[]>('/users'),
  getById: (id: string) => apiClient.get<User>(`/users/${id}`),
  create: (data: CreateDto) => apiClient.post<User>('/users', data),
  update: (id: string, data: UpdateDto) => apiClient.put<User>(`/users/${id}`, data),
  delete: (id: string) => apiClient.delete<void>(`/users/${id}`),
};
```

## 4. Zustand Store Pattern (SHARED)

```typescript
interface ExampleState {
  items: Item[];
  addItem: (item: Item) => void;
  removeItem: (id: string) => void;
}

export const useExampleStore = create<ExampleState>((set) => ({
  items: [],
  addItem: (item) => set((s) => ({ items: [...s.items, item] })),
  removeItem: (id) => set((s) => ({ items: s.items.filter((i) => i.id !== id) })),
}));
```

## 5. Form Validation (SHARED)

- LUÔN dùng Zod schema validation
- KHÔNG validate bằng tay
- Schema file có thể share giữa web và mobile

## 6. Hook Pattern (SHARED)

```typescript
export function useExampleList() {
  return useQuery({ queryKey: ['examples'], queryFn: exampleService.getAll });
}
```

## 7. Import Order

```typescript
// 1. React/RN built-ins
// 2. Third-party libraries
// 3. Shared layer (@/shared, @/styles, @/layouts, @/navigation)
// 4. Module imports (@/modules)
// 5. Relative imports (../styles, ./local)
```

## 8. Error Handling

- API errors: handled by apiClient interceptors → AppError interface
- Form errors: Zod validation messages
- User feedback: platform-specific (web: modal, mobile: Alert/Toast)

## 9. Naming Conventions (cả 2 platform)

| Item | Convention |
|------|-----------|
| Component | PascalCase (`AppButton.tsx`) |
| Hook | camelCase + `use` prefix |
| Store | camelCase + `Store` suffix |
| Service | camelCase + `Service` suffix |
| Type | PascalCase (`UserDto`, `ApiResponse`) |
| Schema | camelCase + `Schema` suffix |

## 10. Export Convention

### Components (shared + module)
- Mỗi component file dùng **`export default`**
- File barrel (`index.ts`) re-export bằng `export { default as ComponentName } from './ComponentName'`
- Cho phép đặt tên linh hoạt khi import ở nơi khác

```typescript
// AppButton.tsx
export default function AppButton({ ... }) { ... }

// index.ts (barrel)
export { default as AppButton } from './AppButton';
export { default as AppText } from './AppText';
export { default as AppModal } from './AppModal';
```

### Hooks, Services, Stores
- Dùng **named export** (không default) vì thường export nhiều thứ từ 1 file
- Barrel re-export bằng `export { functionName } from './file'`

```typescript
// loadingService.ts
export function setLoading(v: boolean) { ... }
export const useLoadingStore = create(...)

// index.ts
export { setLoading, useLoadingStore } from './loadingService';
```

### Pages/Screens
- Dùng **`export default`** (bắt buộc cho lazy loading / React.lazy)

```typescript
// HomePage.tsx (web)
export default function HomePage() { ... }

// HomeScreen.tsx (mobile)
export default function HomeScreen() { ... }
```

## 10. Git Convention

- Branch: `feature/{module}-{desc}`, `fix/{desc}`, `chore/{desc}`
- Commit: conventional commits (`feat:`, `fix:`, `refactor:`, `test:`)
- PR: 1 feature per PR

## 11. Types/Interfaces PHẢI đồng bộ giữa web và mobile

Khi thay đổi type ở 1 platform → PHẢI update platform còn lại.
Shared types nằm tại `shared/types/` của mỗi project.
