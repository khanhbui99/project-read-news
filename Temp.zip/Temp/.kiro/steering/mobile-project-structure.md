---
inclusion: fileMatch
fileMatchPattern: "mobile/**/*"
---

# Mobile Project Structure Rules (Chỉ áp dụng cho source mobile)

Quy tắc cấu trúc CHỉ cho phần mobile (source tại `mobile/`). KHÔNG áp dụng cho web `src/`.

## Cấu trúc thư mục Mobile

```
mobile/
├── src/
│   ├── app/              # App bootstrap (providers, navigator)
│   ├── navigation/       # React Navigation (thay layouts/)
│   ├── modules/          # Business modules (giống web)
│   ├── shared/           # Shared/reusable code
│   ├── theme/            # Theme tokens (giống src/styles/)
│   ├── assets/           # Static files
│   └── test/             # Test setup
├── android/
├── ios/
├── package.json
├── tsconfig.json
├── app.json
└── metro.config.js
```

## Quy tắc KHÔNG ĐƯỢC vi phạm

### 1. Navigation thay Layouts
- KHÔNG tạo `layouts/` — dùng `navigation/` với React Navigation
- Tab/Stack/Drawer navigators đặt tại `src/navigation/`

### 2. Screens thay Pages
- KHÔNG dùng "pages" — mobile dùng "screens"
- `src/modules/{name}/screens/`

### 3. Navigation quản lý tại `src/app/AppNavigator.tsx`
- Giống AppRouter của web — tập trung navigation tại 1 nơi

### 4. Module structure bắt buộc
```
mobile/src/modules/{name}/
├── components/
├── hooks/          # SHARE từ web
├── services/       # SHARE từ web
├── stores/         # SHARE từ web
├── screens/        # Thay pages/
├── styles/
│   └── index.ts   # StyleSheet.create (không styled-components)
└── index.ts
```

### 5. Styling
- Dùng `StyleSheet.create()` — KHÔNG dùng styled-components
- Theme tokens PHẢI giống giá trị web (cùng colors, spacing values)
- KHÔNG hardcode colors/spacing

### 6. Import rules
- Giống web: `@/` alias cho `mobile/src/`
- Cross-module chỉ qua `index.ts`

### 7. Naming
- Screens: PascalCase + `Screen` suffix (`HomeScreen.tsx`, `LoginScreen.tsx`)
- Navigator: PascalCase + `Navigator` suffix (`TabNavigator.tsx`)
- Còn lại giống web (hooks, stores, services)

### 8. Không tạo folder ngoài cấu trúc
- KHÔNG tạo `mobile/src/pages/`
- KHÔNG tạo `mobile/src/components/` ở root — dùng `shared/components/`
- KHÔNG tạo `mobile/src/layouts/` — dùng `navigation/`

### 9. Environment Config
- Dùng `react-native-config` để đọc `.env` files
- Env files: `.env.development`, `.env.staging`, `.env.production` tại `mobile/`
- Typed env access qua `src/shared/config/env.ts` + Zod validation
- KHÔNG hardcode API URLs — dùng `env.API_BASE_URL`
- Android emulator dùng `10.0.2.2` thay `localhost`
- Build theo env: `ENVFILE=.env.staging react-native run-android`

### 10. Export Convention (Mobile)
- Components: `export default function ComponentName`
- Barrel file (`index.ts`): `export { default as ComponentName } from './ComponentName'`
- Services/Hooks: named export (vì export nhiều thứ)
- Screens: `export default function ScreenName`
