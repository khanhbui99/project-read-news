import { Providers } from './providers';
import { AppRouterProvider } from '@/routers';
import { AppErrorBoundary } from '@/shared/components/AppErrorBoundary';
import { GlobalLoading } from '@/shared/components/GlobalLoading';
import { ModalConfirm } from '@/shared/components/ModalConfirm';

export function App() {
  return (
    <AppErrorBoundary>
      <Providers>
        <AppRouterProvider />
        <GlobalLoading />
        <ModalConfirm />
      </Providers>
    </AppErrorBoundary>
  );
}
