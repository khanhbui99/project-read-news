import { useState, createContext, useContext } from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

type ThemeMode = 'light' | 'dark';

interface ThemeContextValue {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextValue>({
  mode: 'light',
  setMode: () => {},
});

export function useTheme() {
  return useContext(ThemeContext);
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: 3,
      refetchOnWindowFocus: false,
    },
  },
});

function buildTheme(mode: ThemeMode) {
  return createTheme({
    palette: {
      mode,
      primary: { main: '#006494' },
      secondary: { main: '#6c757d' },
      error: { main: '#dc3545' },
      warning: { main: '#ffc107' },
      success: { main: '#28a745' },
      info: { main: '#17a2b8' },
    },
    typography: {
      fontFamily: "'SVN_Gilroy', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      fontSize: 14,
      htmlFontSize: 16,
      body1: { fontSize: 14 },
      body2: { fontSize: 14 },
      button: { fontSize: 14, textTransform: 'none' },
    },
    shape: { borderRadius: 8 },
  });
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<ThemeMode>('light');
  const theme = buildTheme(mode);

  return (
    <ThemeContext.Provider value={{ mode, setMode }}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          {children}
        </ThemeProvider>
      </QueryClientProvider>
    </ThemeContext.Provider>
  );
}
