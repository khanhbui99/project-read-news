import { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme as useMuiTheme } from '@mui/material/styles';
import Badge from '@mui/material/Badge';
import MenuIcon from '@mui/icons-material/Menu';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import { SidebarMenu } from '@/shared/components/SidebarMenu';
import { PageBreadcrumb } from '@/shared/components/PageBreadcrumb';
import { MenuSearchTrigger } from '@/shared/components/MenuSearchTrigger';
import { ModalMenuSearch } from '@/shared/components/ModalMenuSearch';
import { HeaderUserMenu } from '@/shared/components/HeaderUserMenu';
import { AppTitle, AppCaption } from '@/shared/components/Styled';
import { useMenu } from '@/shared/hooks/useMenu';

const DRAWER_WIDTH = 300;

export function AdminLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const muiTheme = useMuiTheme();
  const isMobile = useMediaQuery(muiTheme.breakpoints.down('md'));
  const { getAllMenuItems, isLoading: menuLoading } = useMenu();
  const menuItems = getAllMenuItems();
  const [searchOpen, setSearchOpen] = useState(false);

  // Ctrl+K / Cmd+K opens quick menu search
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const drawerContent = (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', bgcolor: 'primary.main', color: '#fff' }}>
      <Toolbar sx={{ gap: 1 }}>
        <Box
          sx={{
            width: 36,
            height: 36,
            borderRadius: 1,
            bgcolor: 'rgba(255,255,255,0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          CM
        </Box>
        <Box>
          <AppTitle size="md" color="white">CMS Admin</AppTitle>
          <AppCaption color="white">Content Management</AppCaption>
        </Box>
      </Toolbar>
      <Divider sx={{ borderColor: 'rgba(255,255,255,0.12)' }} />
      <Box sx={{
        flex: 1,
        overflowY: 'auto',
        px: 1,
        py: 1,
        '&::-webkit-scrollbar': { width: 4 },
        '&::-webkit-scrollbar-thumb': { bgcolor: 'rgba(255,255,255,0.2)', borderRadius: 2 },
        '&::-webkit-scrollbar-track': { bgcolor: 'transparent' },
      }}>
        <SidebarMenu
          items={menuItems}
          loading={menuLoading}
          onNavigate={() => isMobile && setMobileOpen(false)}
        />
      </Box>
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <Box component="nav" sx={{ width: { md: DRAWER_WIDTH }, flexShrink: { md: 0 } }}>
        {isMobile ? (
          <Drawer
            variant="temporary"
            open={mobileOpen}
            onClose={() => setMobileOpen(false)}
            ModalProps={{ keepMounted: true }}
            sx={{ '& .MuiDrawer-paper': { width: DRAWER_WIDTH, bgcolor: 'primary.main', borderRight: 'none' } }}
          >
            {drawerContent}
          </Drawer>
        ) : (
          <Drawer
            variant="permanent"
            sx={{ '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box', bgcolor: 'primary.main', borderRight: 'none' } }}
            open
          >
            {drawerContent}
          </Drawer>
        )}
      </Box>

      {/* Main area */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <AppBar
          position="sticky"
          color="inherit"
          elevation={0}
          sx={{
            bgcolor: '#fff',
            boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
            zIndex: (theme) => theme.zIndex.appBar,
          }}
        >
          <Toolbar sx={{ gap: { xs: 1, sm: 2 }, px: { xs: 1.5, sm: 3 } }}>
            {isMobile && (
              <IconButton edge="start" onClick={() => setMobileOpen(true)} aria-label="Mở menu">
                <MenuIcon />
              </IconButton>
            )}

            {/* Breadcrumb — desktop/tablet only */}
            {!isMobile && <PageBreadcrumb items={menuItems} />}

            <Box sx={{ flex: 1 }} />

            {/* Quick menu search — desktop/tablet only */}
            {!isMobile && <MenuSearchTrigger onClick={() => setSearchOpen(true)} />}

            <IconButton aria-label="Thông báo">
              <Badge badgeContent={2} color="error">
                <NotificationsNoneIcon />
              </Badge>
            </IconButton>
            <HeaderUserMenu />
          </Toolbar>
        </AppBar>

        <Box component="main" sx={{ flex: 1, p: { xs: 2, md: 3 }, overflow: 'auto', bgcolor: '#fff' }}>
          <Outlet />
        </Box>
      </Box>

      <ModalMenuSearch open={searchOpen} onClose={() => setSearchOpen(false)} items={menuItems} />
    </Box>
  );
}
