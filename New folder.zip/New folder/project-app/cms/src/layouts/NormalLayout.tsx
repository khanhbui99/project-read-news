import { Outlet } from 'react-router-dom';
import Box from '@mui/material/Box';

/**
 * Basic layout without sidebar/header.
 * Used for standalone pages (login, error, public pages...).
 * Global overlays (loading, confirm modal) are mounted at App level.
 */
export function NormalLayout() {
  return (
    <Box sx={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Box component="main" sx={{ flex: 1, display: 'flex' }}>
        <Outlet />
      </Box>
    </Box>
  );
}
