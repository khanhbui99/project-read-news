import apiClient from './apiClient';
import { apiUrl } from './apiUrl';
import { handleApiError } from './handleApiError';

export interface MenuItemRaw {
  id: number;
  name: string;
  url: string;
  icon: string;
  parentId: number;
  hidden: boolean;
  component: string;
  orders?: number;
  isDivider?: boolean;
  type?: string;
  isMobile?: boolean;
  child?: MenuItemRaw[];
}

export interface MenuTab {
  id: number;
  value: string;
  label: string;
  children?: { id: number; value: string; label: string }[];
}

export interface MenuResponse {
  data: {
    menuTab: MenuTab[];
    router: Record<string, MenuItemRaw[]>;
  };
  meta: { code: string };
}

export async function fetchMenu(): Promise<MenuResponse> {
  try {
    const { data } = await apiClient.get<MenuResponse>(apiUrl.orgChart.listMenu);
    return data;
  } catch (error) {
    throw handleApiError(error, 'Tải danh sách menu');
  }
}
