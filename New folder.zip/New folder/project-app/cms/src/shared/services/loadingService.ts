type LoadingListener = (loading: boolean) => void;

let isLoading = false;
const listeners: Set<LoadingListener> = new Set();

export function setLoading(loading: boolean) {
  isLoading = loading;
  listeners.forEach((fn) => fn(isLoading));
}

export function getLoading() {
  return isLoading;
}

export function subscribeLoading(listener: LoadingListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
