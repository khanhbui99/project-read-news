/**
 * Centralized storage access.
 * ALL localStorage / sessionStorage / cookie keys must be declared here and
 * accessed only through these helpers — never read/write storage keys directly
 * elsewhere in the codebase.
 *
 * Token keys are driven by environment variables (VITE_TOKEN_KEY,
 * VITE_REFRESH_TOKEN_KEY) so they can differ per environment.
 */
import { env } from '@/shared/config/env';

// ===================== KEYS =====================

export const STORAGE_KEYS = {
  TOKEN: env.tokenKey,
  REFRESH_TOKEN: env.refreshTokenKey,
  USER: 'IL_ADMIN_USER',
  ACTIVE_ORG: 'IL_ADMIN_ACTIVE_ORG',
} as const;

export type StorageKey = (typeof STORAGE_KEYS)[keyof typeof STORAGE_KEYS];

// ===================== LOCAL STORAGE =====================

export const storage = {
  get(key: StorageKey): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  },

  set(key: StorageKey, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch {
      /* ignore quota / privacy-mode errors */
    }
  },

  remove(key: StorageKey): void {
    try {
      localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
  },

  getJSON<T>(key: StorageKey): T | null {
    const raw = storage.get(key);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return null;
    }
  },

  setJSON<T>(key: StorageKey, value: T): void {
    storage.set(key, JSON.stringify(value));
  },

  clearAll(): void {
    Object.values(STORAGE_KEYS).forEach((key) => storage.remove(key as StorageKey));
  },
};

// ===================== TYPED ACCESSORS =====================

/**
 * Full user object as returned by the API (kept raw so no info is lost).
 * Known display fields are optional; extra fields are preserved via index signature.
 */
export interface StoredUser {
  id?: string | number;
  name?: string;
  fullName?: string;
  displayName?: string;
  email?: string;
  username?: string;
  role?: string;
  roleName?: string;
  avatar?: string;
  avatarUrl?: string;
  [key: string]: unknown;
}

export interface ActiveOrg {
  id: string | number;
  name: string;
  roleName?: string;
  orgName?: string;
}

export const authStorage = {
  getToken: () => storage.get(STORAGE_KEYS.TOKEN),
  setToken: (token: string) => storage.set(STORAGE_KEYS.TOKEN, token),
  removeToken: () => storage.remove(STORAGE_KEYS.TOKEN),

  getRefreshToken: () => storage.get(STORAGE_KEYS.REFRESH_TOKEN),
  setRefreshToken: (token: string) => storage.set(STORAGE_KEYS.REFRESH_TOKEN, token),
  removeRefreshToken: () => storage.remove(STORAGE_KEYS.REFRESH_TOKEN),

  getUser: () => storage.getJSON<StoredUser>(STORAGE_KEYS.USER),
  setUser: (user: StoredUser) => storage.setJSON(STORAGE_KEYS.USER, user),
  removeUser: () => storage.remove(STORAGE_KEYS.USER),

  getActiveOrg: () => storage.getJSON<ActiveOrg>(STORAGE_KEYS.ACTIVE_ORG),
  setActiveOrg: (org: ActiveOrg) => storage.setJSON(STORAGE_KEYS.ACTIVE_ORG, org),
  removeActiveOrg: () => storage.remove(STORAGE_KEYS.ACTIVE_ORG),

  clear: () => storage.clearAll(),
};
