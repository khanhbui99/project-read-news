import { showError } from './modalService';

/**
 * Xử lý lỗi API tập trung: log ở DEV + thông báo cho người dùng qua modal lỗi.
 * Dùng trong khối catch của mọi hàm gọi API, sau đó ném lại lỗi để caller
 * (TanStack Query, hook...) vẫn biết request thất bại.
 *
 * @param error  lỗi bắt được (đã được apiClient chuẩn hóa thành Error)
 * @param context  mô tả ngắn hành động đang thực hiện (vd: 'Tải danh sách menu')
 * @param options.silent  true → không hiện thông báo (tự xử lý ở nơi gọi)
 */
export function handleApiError(
  error: unknown,
  context: string,
  options?: { silent?: boolean },
): Error {
  const normalized = error instanceof Error ? error : new Error(String(error));

  if (!options?.silent) {
    showError('Lỗi', `${context} thất bại. ${normalized.message}`);
  }

  return normalized;
}
