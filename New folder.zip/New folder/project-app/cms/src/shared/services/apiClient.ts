import axios from 'axios';
import { authStorage } from '@/shared/services/storageService';
import { env } from '@/shared/config/env';

// API domain driven by environment variables (VITE_API_BASE_URL)

const apiClient = axios.create({
  baseURL: env.apiBaseUrl,
  timeout: env.apiTimeout,
  headers: { 'Content-Type': 'application/json' },
});

// Auth token interceptor
apiClient.interceptors.request.use((config) => {
  const token = authStorage.getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Error normalization interceptor
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      'Đã xảy ra lỗi không xác định';

    // DEV: log chi tiết request/response để debug. PROD: giữ im lặng.
    if (env.isDev) {
      console.error('[apiClient] Request failed:', {
        url: error.config?.url,
        method: error.config?.method,
        status: error.response?.status,
        data: error.response?.data,
        message,
      });
    }

    return Promise.reject(new Error(message));
  },
);

export default apiClient;
