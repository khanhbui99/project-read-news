type ModalType = 'confirm' | 'success' | 'error';

interface ModalState {
  type: ModalType;
  title: string;
  message: string;
  resolve?: (value: boolean) => void;
}

type ModalListener = (state: ModalState | null) => void;

let currentState: ModalState | null = null;
const listeners: Set<ModalListener> = new Set();

function notify() {
  listeners.forEach((fn) => fn(currentState));
}

export function showConfirm(title: string, message: string): Promise<boolean> {
  return new Promise((resolve) => {
    currentState = { type: 'confirm', title, message, resolve };
    notify();
  });
}

export function showSuccess(title: string, message: string): Promise<boolean> {
  return new Promise((resolve) => {
    currentState = { type: 'success', title, message, resolve };
    notify();
  });
}

export function showError(title: string, message: string): Promise<boolean> {
  return new Promise((resolve) => {
    currentState = { type: 'error', title, message, resolve };
    notify();
  });
}

export function closeModal(result: boolean = false) {
  if (currentState?.resolve) {
    currentState.resolve(result);
  }
  currentState = null;
  notify();
}

export function subscribeModal(listener: ModalListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function getModalState() {
  return currentState;
}
