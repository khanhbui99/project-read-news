/**
 * Centralized API endpoint paths grouped by service.
 * Only RELATIVE paths here — the domain is configured in apiClient (baseURL).
 * ALL endpoints must be declared here — never hardcode a path string elsewhere.
 */

// Per-service base path segments
const ORG_CHART = '/org-chart-service/v2/api';

export const apiUrl = {
  orgChart: {
    login: `${ORG_CHART}/public/accounts/sale/login`,
    listMenu: `${ORG_CHART}/public/menu-item/list-menu`,
  },
  // Add other services here, e.g.
  // learning: {
  //   listCourse: '/learning-service/v2/api/courses',
  // },
} as const;
