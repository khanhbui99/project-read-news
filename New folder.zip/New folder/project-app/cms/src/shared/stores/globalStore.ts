import { create } from 'zustand';
import type { MenuItem } from '@/shared/hooks/useMenu';
import { authStorage, type StoredUser, type ActiveOrg } from '@/shared/services/storageService';
import type { OrgChart } from '@/modules/auth/service';

type User = StoredUser;

interface GlobalState {
  // Auth
  user: User | null;
  token: string | null;
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  logout: () => void;

  // Org charts (roles/organizations the user can act as)
  orgCharts: OrgChart[];
  activeOrg: ActiveOrg | null;
  setOrgCharts: (orgs: OrgChart[]) => void;
  setActiveOrg: (org: ActiveOrg) => void;

  // UI - Sidebar
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;

  // Menu
  menuItems: MenuItem[];
  menuLoading: boolean;
  setMenuItems: (items: MenuItem[]) => void;
  setMenuLoading: (loading: boolean) => void;

  // Panel
  panelOpen: boolean;
  setPanelOpen: (open: boolean) => void;
  togglePanel: () => void;
}

export const useGlobalStore = create<GlobalState>((set) => ({
  // Auth — hydrate from storage on init
  user: authStorage.getUser(),
  token: authStorage.getToken(),

  setUser: (user) => {
    if (user) authStorage.setUser(user);
    else authStorage.removeUser();
    set({ user });
  },

  setToken: (token) => {
    if (token) authStorage.setToken(token);
    else authStorage.removeToken();
    set({ token });
  },

  logout: () => {
    authStorage.clear();
    set({ user: null, token: null, orgCharts: [], activeOrg: null });
  },

  // Org charts
  orgCharts: [],
  activeOrg: authStorage.getActiveOrg(),
  setOrgCharts: (orgs) => set({ orgCharts: orgs }),
  setActiveOrg: (org) => {
    authStorage.setActiveOrg(org);
    set({ activeOrg: org });
  },

  // UI - Sidebar
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),

  // Menu
  menuItems: [],
  menuLoading: true,
  setMenuItems: (items) => set({ menuItems: items, menuLoading: false }),
  setMenuLoading: (loading) => set({ menuLoading: loading }),

  // Panel
  panelOpen: false,
  setPanelOpen: (open) => set({ panelOpen: open }),
  togglePanel: () => set((s) => ({ panelOpen: !s.panelOpen })),
}));
