import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import type { FieldConfig } from './types';

interface FormRendererProps {
  fields: FieldConfig[];
  schema: z.ZodSchema;
  defaultValues?: Record<string, unknown>;
  onSubmit: (data: Record<string, unknown>) => void;
  formId: string;
}

export function FormRenderer({ fields, schema, defaultValues, onSubmit, formId }: FormRendererProps) {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: defaultValues as Record<string, string | number | undefined>,
  });

  const getError = (name: string): string | undefined => {
    const err = errors[name];
    return err?.message as string | undefined;
  };

  const renderField = (field: FieldConfig) => {
    const error = getError(field.name);

    switch (field.type) {
      case 'textarea':
        return (
          <Controller
            name={field.name}
            control={control}
            render={({ field: f }) => (
              <TextField
                {...f}
                id={field.name}
                label={field.label}
                placeholder={field.placeholder}
                multiline
                rows={field.rows || 4}
                error={!!error}
                helperText={error || field.helperText}
                required={field.required}
                fullWidth
                size="small"
              />
            )}
          />
        );

      case 'select':
        return (
          <Controller
            name={field.name}
            control={control}
            render={({ field: f }) => (
              <TextField
                {...f}
                id={field.name}
                select
                label={field.label}
                error={!!error}
                helperText={error || field.helperText}
                required={field.required}
                fullWidth
                size="small"
              >
                {field.options.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>{opt.label}</MenuItem>
                ))}
              </TextField>
            )}
          />
        );

      case 'number':
        return (
          <Controller
            name={field.name}
            control={control}
            render={({ field: f }) => (
              <TextField
                {...f}
                id={field.name}
                type="number"
                label={field.label}
                placeholder={field.placeholder}
                error={!!error}
                helperText={error || field.helperText}
                required={field.required}
                fullWidth
                size="small"
                inputProps={{ min: field.min, max: field.max }}
                onChange={(e) => f.onChange(e.target.value ? Number(e.target.value) : '')}
              />
            )}
          />
        );

      case 'date':
      case 'datetime':
        return (
          <Controller
            name={field.name}
            control={control}
            render={({ field: f }) => (
              <TextField
                {...f}
                id={field.name}
                type={field.type === 'datetime' ? 'datetime-local' : 'date'}
                label={field.label}
                error={!!error}
                helperText={error || field.helperText}
                required={field.required}
                fullWidth
                size="small"
                InputLabelProps={{ shrink: true }}
              />
            )}
          />
        );

      default:
        return (
          <Controller
            name={field.name}
            control={control}
            render={({ field: f }) => (
              <TextField
                {...f}
                id={field.name}
                type={field.type}
                label={field.label}
                placeholder={field.placeholder}
                error={!!error}
                helperText={error || field.helperText}
                required={field.required}
                fullWidth
                size="small"
              />
            )}
          />
        );
    }
  };

  return (
    <Box
      component="form"
      id={formId}
      onSubmit={handleSubmit((data) => onSubmit(data as Record<string, unknown>))}
      sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' },
        gap: 2.5,
      }}
    >
      {fields.map((field) => (
        <Box key={field.name} sx={{ gridColumn: field.colSpan === 2 ? 'span 2' : 'span 1' }}>
          {renderField(field)}
        </Box>
      ))}
    </Box>
  );
}
