import apiClient from '@/shared/services/apiClient';
import { handleApiError } from '@/shared/services/handleApiError';
import type { ListQueryParams, PaginatedResponse } from './types';

export function createModuleService<T>(apiEndpoint: string, label = 'Dữ liệu') {
  return {
    getList: async (params: ListQueryParams): Promise<PaginatedResponse<T>> => {
      try {
        const cleanParams = Object.fromEntries(
          Object.entries(params).filter(([, v]) => v !== undefined && v !== ''),
        );
        const { data } = await apiClient.get<PaginatedResponse<T>>(apiEndpoint, {
          params: cleanParams,
        });
        return data;
      } catch (error) {
        throw handleApiError(error, `Tải danh sách ${label}`);
      }
    },

    getById: async (id: string): Promise<T> => {
      try {
        const { data } = await apiClient.get<T>(`${apiEndpoint}/${id}`);
        return data;
      } catch (error) {
        throw handleApiError(error, `Tải chi tiết ${label}`);
      }
    },

    create: async (payload: Partial<T>): Promise<T> => {
      try {
        const { data } = await apiClient.post<T>(apiEndpoint, payload);
        return data;
      } catch (error) {
        throw handleApiError(error, `Tạo ${label}`);
      }
    },

    update: async (id: string, payload: Partial<T>): Promise<T> => {
      try {
        const { data } = await apiClient.put<T>(`${apiEndpoint}/${id}`, payload);
        return data;
      } catch (error) {
        throw handleApiError(error, `Cập nhật ${label}`);
      }
    },

    delete: async (id: string): Promise<void> => {
      try {
        await apiClient.delete(`${apiEndpoint}/${id}`);
      } catch (error) {
        throw handleApiError(error, `Xóa ${label}`);
      }
    },
  };
}
