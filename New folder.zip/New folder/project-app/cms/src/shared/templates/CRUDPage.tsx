import { useState, useMemo } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import { showConfirm, showSuccess, showError } from '@/shared/services/modalService';
import { AppHeader } from '@/shared/components/AppHeader';
import { AppFilter, type FilterField } from '@/shared/components/AppFilter';
import { AppTable, type ColumnDef } from '@/shared/components/AppTable';
import { AppModalContainer } from '@/shared/components/AppModalContainer';
import { FormRenderer } from './FormRenderer';
import { useModuleCRUD } from './useModuleCRUD';
import type { ModuleConfig, DrawerState } from './types';

interface CRUDPageProps<T extends Record<string, unknown>> {
  config: ModuleConfig<T>;
}

export function CRUDPage<T extends Record<string, unknown>>({ config }: CRUDPageProps<T>) {
  const crud = useModuleCRUD({ config });
  const [drawer, setDrawer] = useState<DrawerState>({
    open: false,
    mode: 'create',
    editingId: null,
    editingData: null,
  });

  const handleCreate = () => {
    setDrawer({ open: true, mode: 'create', editingId: null, editingData: null });
  };

  const handleEdit = (row: T) => {
    const id = String(row[config.rowKey] ?? '');
    setDrawer({ open: true, mode: 'edit', editingId: id, editingData: row as Record<string, unknown> });
  };

  const handleDelete = async (row: T) => {
    const id = String(row[config.rowKey] ?? '');
    const confirmed = await showConfirm('Xác nhận xóa', 'Hành động này không thể hoàn tác.');
    if (confirmed) {
      try {
        await crud.deleteItem(id);
        await showSuccess('Đã xóa', 'Xóa thành công.');
      } catch (err) {
        await showError('Lỗi', err instanceof Error ? err.message : 'Xóa thất bại.');
      }
    }
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    try {
      if (drawer.mode === 'create') {
        await crud.createItem(data);
      } else {
        await crud.updateItem(drawer.editingId!, data);
      }
      setDrawer({ open: false, mode: 'create', editingId: null, editingData: null });
      await showSuccess('Thành công', drawer.mode === 'create' ? 'Tạo mới thành công.' : 'Cập nhật thành công.');
    } catch (err) {
      await showError('Lỗi', err instanceof Error ? err.message : 'Thao tác thất bại.');
    }
  };

  const handleCloseDrawer = () => {
    setDrawer({ open: false, mode: 'create', editingId: null, editingData: null });
  };

  // Map config columns → AppTable ColumnDef
  const tableColumns: ColumnDef<T>[] = useMemo(
    () =>
      config.columns.map((col) => ({
        field: col.key,
        name: col.title,
        width: col.width,
        align: col.align,
        checked: true,
        render: col.render ? (value: unknown, row: T) => col.render!(value, row, 0) : undefined,
      })),
    [config.columns],
  );

  const filterFields: FilterField[] = useMemo(() => {
    if (!config.filters) return [];
    return config.filters.map((f) => ({
      name: f.name,
      label: f.label,
      type: f.type === 'select' ? 'select' : 'text',
      placeholder: f.placeholder,
      options: f.options?.map((opt) => ({ label: opt.label, value: opt.value })),
    }));
  }, [config.filters]);

  const hasActiveFilters = useMemo(
    () => Boolean(crud.searchTerm) || Object.values(crud.filters).some((v) => v !== ''),
    [crud.searchTerm, crud.filters],
  );

  return (
    <Box>
      <AppHeader
        title={config.pageTitle}
        subtitle={config.pageSubtitle}
        createLabel={config.createButtonLabel}
        onCreate={handleCreate}
        showCreate={config.enableCreate !== false}
      />

      {(config.searchPlaceholder || filterFields.length > 0) && (
        <AppFilter
          filters={filterFields}
          values={crud.filters}
          searchTerm={crud.searchTerm}
          searchPlaceholder={config.searchPlaceholder}
          onFilterChange={crud.setFilter}
          onSearchChange={crud.setSearchTerm}
          onReset={crud.resetFilters}
        />
      )}

      <AppTable
        id={config.rowKey}
        Columns={tableColumns}
        items={crud.data}
        isQueryLoading={crud.isLoading}
        cellActionProps={{
          handleEdit: config.enableEdit !== false ? handleEdit : undefined,
          handleDelete: config.enableDelete !== false ? handleDelete : undefined,
        }}
        isFiltered={hasActiveFilters}
        onClearFilters={hasActiveFilters ? crud.resetFilters : undefined}
        page={crud.page}
        pageSize={crud.pageSize}
        total={crud.total}
        onPageChange={crud.setPage}
        onPageSizeChange={crud.setPageSize}
      />

      <AppModalContainer
        open={drawer.open}
        onClose={handleCloseDrawer}
        title={drawer.mode === 'create' ? config.formTitle.create : config.formTitle.edit}
        subtitle={config.formSubtitle?.[drawer.mode]}
        actions={
          <>
            <Button variant="outlined" onClick={handleCloseDrawer}>Hủy</Button>
            <Button variant="contained" type="submit" form="crud-form" disabled={crud.isSubmitting}>
              {crud.isSubmitting ? 'Đang xử lý...' : drawer.mode === 'create' ? 'Tạo mới' : 'Lưu'}
            </Button>
          </>
        }
      >
        <FormRenderer
          formId="crud-form"
          fields={config.formFields}
          schema={config.validationSchema}
          defaultValues={drawer.mode === 'edit' ? (drawer.editingData ?? undefined) : undefined}
          onSubmit={handleSubmit}
        />
      </AppModalContainer>
    </Box>
  );
}
