import { z } from 'zod';

// ============ FIELD CONFIG ============

export interface FieldOption {
  label: string;
  value: string;
}

interface BaseFieldConfig {
  name: string;
  label: string;
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  colSpan?: 1 | 2;
}

export interface TextFieldConfig extends BaseFieldConfig {
  type: 'text' | 'email' | 'password' | 'url';
}

export interface TextAreaFieldConfig extends BaseFieldConfig {
  type: 'textarea';
  rows?: number;
}

export interface SelectFieldConfig extends BaseFieldConfig {
  type: 'select';
  options: FieldOption[];
}

export interface DateFieldConfig extends BaseFieldConfig {
  type: 'date' | 'datetime';
}

export interface NumberFieldConfig extends BaseFieldConfig {
  type: 'number';
  min?: number;
  max?: number;
}

export type FieldConfig =
  | TextFieldConfig
  | TextAreaFieldConfig
  | SelectFieldConfig
  | DateFieldConfig
  | NumberFieldConfig;

// ============ FILTER CONFIG ============

export interface FilterConfig {
  name: string;
  label: string;
  type: 'text' | 'select' | 'date-range';
  options?: FieldOption[];
  placeholder?: string;
}

// ============ TABLE COLUMN CONFIG ============

export interface TableColumnConfig<T = Record<string, unknown>> {
  key: string;
  title: string;
  width?: string;
  align?: 'left' | 'center' | 'right';
  render?: (value: unknown, row: T, index: number) => React.ReactNode;
}

// ============ MODULE CONFIG ============

export interface ModuleConfig<T extends Record<string, unknown>> {
  moduleName: string;
  pageTitle: string;
  pageSubtitle?: string;

  apiEndpoint: string;

  columns: TableColumnConfig<T>[];
  rowKey: string;
  defaultPageSize?: number;

  formFields: FieldConfig[];
  validationSchema: z.ZodSchema;
  formTitle: { create: string; edit: string };
  formSubtitle?: { create: string; edit: string };

  filters?: FilterConfig[];
  searchPlaceholder?: string;

  enableCreate?: boolean;
  enableEdit?: boolean;
  enableDelete?: boolean;
  createButtonLabel?: string;

  transformBeforeSubmit?: (data: Record<string, unknown>) => Record<string, unknown>;
  transformAfterFetch?: (data: T[]) => T[];
}

// ============ DRAWER STATE ============

export interface DrawerState {
  open: boolean;
  mode: 'create' | 'edit';
  editingId: string | null;
  editingData: Record<string, unknown> | null;
}

// ============ API TYPES ============

export interface ListQueryParams {
  page: number;
  pageSize: number;
  search?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  [filterKey: string]: string | number | undefined;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
}
