import { useState, useEffect, useMemo, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createModuleService } from './createModuleService';
import type { ModuleConfig, ListQueryParams } from './types';

interface UseModuleCRUDOptions<T extends Record<string, unknown>> {
  config: ModuleConfig<T>;
}

export function useModuleCRUD<T extends Record<string, unknown>>({
  config,
}: UseModuleCRUDOptions<T>) {
  const queryClient = useQueryClient();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(config.defaultPageSize || 10);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [filters, setFilters] = useState<Record<string, string>>({});

  const service = useMemo(
    () => createModuleService<T>(config.apiEndpoint, config.pageTitle),
    [config.apiEndpoint, config.pageTitle],
  );

  // Debounce search 300ms
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Reset page on filter/search change
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, filters]);

  const queryParams: ListQueryParams = useMemo(() => {
    const params: ListQueryParams = { page, pageSize };
    if (debouncedSearch) params.search = debouncedSearch;
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== '') params[key] = value;
    });
    return params;
  }, [page, pageSize, debouncedSearch, filters]);

  const queryKey = [config.moduleName, 'list', queryParams];

  const { data: queryData, isLoading } = useQuery({
    queryKey,
    queryFn: () => service.getList(queryParams),
  });

  const rawData = queryData?.data ?? [];
  const data = config.transformAfterFetch ? config.transformAfterFetch(rawData) : rawData;
  const total = queryData?.total ?? 0;

  const invalidateList = () => queryClient.invalidateQueries({ queryKey: [config.moduleName, 'list'] });

  const createMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) => {
      const transformed = config.transformBeforeSubmit ? config.transformBeforeSubmit(payload) : payload;
      return service.create(transformed as Partial<T>);
    },
    onSuccess: invalidateList,
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, payload }: { id: string; payload: Record<string, unknown> }) => {
      const transformed = config.transformBeforeSubmit ? config.transformBeforeSubmit(payload) : payload;
      return service.update(id, transformed as Partial<T>);
    },
    onSuccess: invalidateList,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => service.delete(id),
    onSuccess: invalidateList,
  });

  const setFilter = useCallback((key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);

  const resetFilters = useCallback(() => {
    setFilters({});
    setSearchTerm('');
  }, []);

  return {
    data,
    total,
    isLoading,
    page,
    pageSize,
    setPage,
    setPageSize,
    filters,
    searchTerm,
    setFilter,
    setSearchTerm,
    resetFilters,
    createItem: createMutation.mutateAsync,
    updateItem: (id: string, payload: Record<string, unknown>) =>
      updateMutation.mutateAsync({ id, payload }),
    deleteItem: deleteMutation.mutateAsync,
    isSubmitting: createMutation.isPending || updateMutation.isPending || deleteMutation.isPending,
  };
}
