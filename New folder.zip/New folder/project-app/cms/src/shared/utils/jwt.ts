/**
 * Decode a JWT payload (base64url) without verifying the signature.
 * Signature verification is the backend's responsibility — here we only need
 * the claims to display basic user info.
 */
export function decodeJwt<T = Record<string, unknown>>(token: string): T | null {
  try {
    const payload = token.split('.')[1];
    if (!payload) return null;
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
    const json = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => `%${('00' + c.charCodeAt(0).toString(16)).slice(-2)}`)
        .join(''),
    );
    return JSON.parse(json) as T;
  } catch {
    return null;
  }
}
