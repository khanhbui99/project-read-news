import type { StoredUser } from '@/shared/services/storageService';

/** Resolve a display name from the raw user object (tries common field names) */
export function getUserName(user: StoredUser | null): string {
  if (!user) return 'Người dùng';
  return (
    (user.fullName as string) ||
    (user.displayName as string) ||
    (user.name as string) ||
    (user.username as string) ||
    'Người dùng'
  );
}

/** Resolve an avatar URL from the raw user object */
export function getUserAvatar(user: StoredUser | null): string | undefined {
  if (!user) return undefined;
  return (user.avatar as string) || (user.avatarUrl as string) || undefined;
}

/** Resolve a role label from the raw user object */
export function getUserRole(user: StoredUser | null): string {
  if (!user) return '';
  return (user.roleName as string) || (user.role as string) || '';
}
