import { useState, useMemo } from 'react';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import type { AutocompleteRenderInputParams } from '@mui/material/Autocomplete';
import { AppLabel } from './Styled';

export interface SelectOption {
  label: string;
  value: string;
}

interface BaseProps {
  options: SelectOption[];
  label?: string;
  placeholder?: string;
  loading?: boolean;
  disabled?: boolean;
  error?: boolean;
  helperText?: string;
  required?: boolean;
  size?: 'small' | 'medium';
  isLabelTop?: boolean;
}

interface SingleProps extends BaseProps {
  multiple?: false;
  value?: string | null;
  onChange?: (value: string | null) => void;
}

interface MultipleProps extends BaseProps {
  multiple: true;
  value?: string[];
  onChange?: (value: string[]) => void;
}

type Props = SingleProps | MultipleProps;

export function AppSelectSearch(props: Props) {
  const {
    options,
    label,
    placeholder,
    loading = false,
    disabled = false,
    error = false,
    helperText,
    required = false,
    size = 'small',
    isLabelTop = true,
  } = props;

  const [inputValue, setInputValue] = useState('');

  const filteredOptions = useMemo(() => {
    if (!inputValue) return options;
    const lower = inputValue.toLowerCase();
    return options.filter((opt) => opt.label.toLowerCase().includes(lower));
  }, [options, inputValue]);

  const renderInput = (params: AutocompleteRenderInputParams) => (
    <TextField
      {...params}
      label={isLabelTop ? undefined : label}
      placeholder={placeholder}
      error={error}
      helperText={helperText}
      required={isLabelTop ? undefined : required}
      slotProps={{
        input: {
          ...params.InputProps,
          endAdornment: (
            <>
              {loading && <CircularProgress color="inherit" size={18} />}
              {params.InputProps.endAdornment}
            </>
          ),
        },
      }}
    />
  );

  const autocomplete = props.multiple ? (
    <Autocomplete
      multiple
      options={filteredOptions}
      value={options.filter((opt) => props.value?.includes(opt.value))}
      onChange={(_, newValue) => props.onChange?.(newValue.map((v) => v.value))}
      inputValue={inputValue}
      onInputChange={(_, val) => setInputValue(val)}
      getOptionLabel={(opt) => opt.label}
      isOptionEqualToValue={(opt, val) => opt.value === val.value}
      loading={loading}
      disabled={disabled}
      size={size}
      renderInput={renderInput}
    />
  ) : (
    <Autocomplete
      options={filteredOptions}
      value={options.find((opt) => opt.value === props.value) || null}
      onChange={(_, newValue) => (props as SingleProps).onChange?.(newValue?.value ?? null)}
      inputValue={inputValue}
      onInputChange={(_, val) => setInputValue(val)}
      getOptionLabel={(opt) => opt.label}
      isOptionEqualToValue={(opt, val) => opt.value === val.value}
      loading={loading}
      disabled={disabled}
      size={size}
      renderInput={renderInput}
    />
  );

  if (isLabelTop && label) {
    return (
      <Box>
        <AppLabel required={required}>{label}</AppLabel>
        {autocomplete}
      </Box>
    );
  }

  return autocomplete;
}
