import { useState } from 'react';
import Box from '@mui/material/Box';
import Skeleton from '@mui/material/Skeleton';

interface AppImageProps {
  src: string;
  alt?: string;
  width?: number | string;
  height?: number | string;
  borderRadius?: number | string;
  objectFit?: 'cover' | 'contain' | 'fill' | 'none';
  fallback?: string;
}

export function AppImage({
  src,
  alt = '',
  width = '100%',
  height = 200,
  borderRadius = 8,
  objectFit = 'cover',
  fallback,
}: AppImageProps) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const handleLoad = () => setLoading(false);
  const handleError = () => {
    setLoading(false);
    setError(true);
  };

  const displaySrc = error && fallback ? fallback : src;

  return (
    <Box sx={{ position: 'relative', width, height, borderRadius, overflow: 'hidden' }}>
      {loading && (
        <Skeleton
          variant="rectangular"
          animation="wave"
          sx={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}
        />
      )}
      <img
        src={displaySrc}
        alt={alt}
        onLoad={handleLoad}
        onError={handleError}
        style={{
          width: '100%',
          height: '100%',
          objectFit,
          display: loading ? 'none' : 'block',
          borderRadius: typeof borderRadius === 'number' ? `${borderRadius}px` : borderRadius,
        }}
      />
      {error && !fallback && (
        <Box
          sx={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            bgcolor: 'grey.100',
            color: 'text.disabled',
            fontSize: 12,
          }}
        >
          Không tải được ảnh
        </Box>
      )}
    </Box>
  );
}
