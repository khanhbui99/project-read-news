import Typography, { type TypographyProps } from '@mui/material/Typography';
import { createElement } from 'react';

type FontSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
type FontWeight = 'light' | 'normal' | 'medium' | 'semibold' | 'bold';
type TextColor = 'primary' | 'secondary' | 'disabled' | 'error' | 'success' | 'white' | 'inherit';

const FONT_SIZES: Record<FontSize, number> = {
  xs: 11,
  sm: 12.5,
  md: 14,
  lg: 16,
  xl: 18,
  '2xl': 22,
  '3xl': 28,
};

const FONT_WEIGHTS: Record<FontWeight, number> = {
  light: 300,
  normal: 400,
  medium: 500,
  semibold: 600,
  bold: 700,
};

const TEXT_COLORS: Record<TextColor, string> = {
  primary: 'text.primary',
  secondary: 'text.secondary',
  disabled: 'text.disabled',
  error: 'error.main',
  success: 'success.main',
  white: '#fff',
  inherit: 'inherit',
};

interface AppTextProps extends Omit<TypographyProps, 'color'> {
  size?: FontSize;
  weight?: FontWeight;
  color?: TextColor;
  italic?: boolean;
  align?: 'left' | 'center' | 'right';
  noWrap?: boolean;
  lineClamp?: number;
}

export function AppText({
  size = 'md',
  weight = 'normal',
  color = 'primary',
  italic = false,
  align,
  noWrap = false,
  lineClamp,
  sx,
  ...props
}: AppTextProps) {
  return createElement(Typography, {
    ...props,
    sx: {
      fontSize: FONT_SIZES[size],
      fontWeight: FONT_WEIGHTS[weight],
      color: TEXT_COLORS[color],
      fontStyle: italic ? 'italic' : undefined,
      textAlign: align,
      ...(noWrap ? { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } : {}),
      ...(lineClamp ? {
        display: '-webkit-box',
        WebkitLineClamp: lineClamp,
        WebkitBoxOrient: 'vertical',
        overflow: 'hidden',
      } : {}),
      ...((sx as object) ?? {}),
    },
  });
}

interface AppTitleProps extends Omit<TypographyProps, 'color'> {
  size?: FontSize;
  weight?: FontWeight;
  color?: TextColor;
  align?: 'left' | 'center' | 'right';
}

export function AppTitle({
  size = 'xl',
  weight = 'bold',
  color = 'primary',
  align,
  sx,
  ...props
}: AppTitleProps) {
  return createElement(Typography, {
    variant: 'h5',
    ...props,
    sx: {
      fontSize: FONT_SIZES[size],
      fontWeight: FONT_WEIGHTS[weight],
      color: TEXT_COLORS[color],
      textAlign: align,
      ...((sx as object) ?? {}),
    },
  });
}

interface AppCaptionProps extends Omit<TypographyProps, 'color'> {
  size?: FontSize;
  weight?: FontWeight;
  color?: TextColor;
}

export function AppCaption({
  size = 'xs',
  weight = 'normal',
  color = 'secondary',
  sx,
  ...props
}: AppCaptionProps) {
  return createElement(Typography, {
    variant: 'caption',
    ...props,
    sx: {
      fontSize: FONT_SIZES[size],
      fontWeight: FONT_WEIGHTS[weight],
      color: TEXT_COLORS[color],
      ...((sx as object) ?? {}),
    },
  });
}

interface AppLabelProps extends Omit<TypographyProps, 'color'> {
  size?: FontSize;
  weight?: FontWeight;
  color?: TextColor;
  required?: boolean;
}

export function AppLabel({
  size = 'sm',
  weight = 'medium',
  color = 'primary',
  required = false,
  children,
  sx,
  ...props
}: AppLabelProps) {
  return createElement(Typography, {
    variant: 'body2',
    ...props,
    sx: {
      fontSize: FONT_SIZES[size],
      fontWeight: FONT_WEIGHTS[weight],
      color: TEXT_COLORS[color],
      mb: 0.5,
      ...((sx as object) ?? {}),
    },
  }, children, required ? createElement('span', { style: { color: '#dc3545', marginLeft: 4 } }, '*') : null);
}
