import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import FilterListIcon from '@mui/icons-material/FilterList';
import ClearIcon from '@mui/icons-material/Clear';
import { AppTextField } from './AppTextField';
import { AppSelectSearch, type SelectOption } from './AppSelectSearch';

export interface FilterField {
  name: string;
  label: string;
  type: 'text' | 'select';
  placeholder?: string;
  options?: SelectOption[];
}

interface AppFilterProps {
  filters: FilterField[];
  values: Record<string, string>;
  searchTerm?: string;
  searchPlaceholder?: string;
  onFilterChange: (name: string, value: string) => void;
  onSearchChange?: (value: string) => void;
  onReset?: () => void;
  showReset?: boolean;
}

export function AppFilter({
  filters,
  values,
  searchTerm,
  searchPlaceholder = 'Tìm kiếm...',
  onFilterChange,
  onSearchChange,
  onReset,
  showReset = true,
}: AppFilterProps) {
  const hasActiveFilters = Object.values(values).some((v) => v !== '') || (searchTerm && searchTerm !== '');

  return (
    <Stack direction="row" spacing={1.5} sx={{ mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
      {onSearchChange && (
        <AppTextField
          placeholder={searchPlaceholder}
          value={searchTerm ?? ''}
          onChange={(e) => onSearchChange(e.target.value)}
          sx={{ minWidth: 220 }}
          slotProps={{
            input: {
              startAdornment: <FilterListIcon sx={{ mr: 1, color: 'text.disabled', fontSize: 20 }} />,
            },
          }}
        />
      )}

      {filters.map((filter) => {
        if (filter.type === 'select' && filter.options) {
          return (
            <AppSelectSearch
              key={filter.name}
              options={filter.options}
              value={values[filter.name] || null}
              onChange={(val) => onFilterChange(filter.name, val ?? '')}
              label={filter.label}
              placeholder={filter.placeholder}
              size="small"
            />
          );
        }

        return (
          <AppTextField
            key={filter.name}
            placeholder={filter.placeholder || filter.label}
            value={values[filter.name] || ''}
            onChange={(e) => onFilterChange(filter.name, e.target.value)}
            sx={{ minWidth: 160 }}
          />
        );
      })}

      {showReset && hasActiveFilters && onReset && (
        <Button
          size="small"
          variant="text"
          startIcon={<ClearIcon />}
          onClick={onReset}
          sx={{ whiteSpace: 'nowrap' }}
        >
          Xóa bộ lọc
        </Button>
      )}
    </Stack>
  );
}
