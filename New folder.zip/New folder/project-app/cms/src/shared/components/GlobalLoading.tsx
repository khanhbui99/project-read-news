import { useEffect, useState } from 'react';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import { subscribeLoading } from '@/shared/services/loadingService';

export function GlobalLoading() {
  const [loading, setLoading] = useState(false);

  useEffect(() => subscribeLoading(setLoading), []);

  return (
    <Backdrop open={loading} sx={{ zIndex: (theme) => theme.zIndex.modal + 1 }}>
      <CircularProgress color="primary" />
    </Backdrop>
  );
}
