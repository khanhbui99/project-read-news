import { forwardRef, useId } from 'react';
import Box from '@mui/material/Box';

interface AppCheckboxProps {
  checked?: boolean;
  indeterminate?: boolean;
  onChange?: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
  id?: string;
  name?: string;
  'aria-label'?: string;
}

/**
 * Custom HTML checkbox (per CMS convention — not MUI Checkbox).
 * Uses theme tokens for colors, supports focus-visible ring and indeterminate state.
 */
export const AppCheckbox = forwardRef<HTMLInputElement, AppCheckboxProps>(
  ({ checked = false, indeterminate = false, onChange, label, disabled, id, name, ...rest }, ref) => {
    const autoId = useId();
    const inputId = id ?? autoId;
    const isActive = checked || indeterminate;

    return (
      <Box
        component="label"
        htmlFor={inputId}
        sx={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 1,
          cursor: disabled ? 'not-allowed' : 'pointer',
          opacity: disabled ? 0.5 : 1,
          fontSize: 13,
          lineHeight: 1.4,
          color: 'text.primary',
          userSelect: 'none',
          minHeight: 32,
          '&:hover .app-checkbox-box': {
            borderColor: disabled ? undefined : 'primary.main',
          },
        }}
      >
        <Box sx={{ position: 'relative', width: 18, height: 18, flexShrink: 0 }}>
          <Box
            component="input"
            ref={ref}
            type="checkbox"
            id={inputId}
            name={name}
            checked={checked}
            disabled={disabled}
            onChange={(e) => onChange?.((e.target as HTMLInputElement).checked)}
            sx={{
              position: 'absolute',
              inset: 0,
              width: '100%',
              height: '100%',
              m: 0,
              opacity: 0,
              cursor: 'inherit',
              '&:focus-visible + .app-checkbox-box': {
                boxShadow: (theme) => `0 0 0 3px ${theme.palette.primary.main}33`,
              },
            }}
            {...rest}
          />
          <Box
            className="app-checkbox-box"
            sx={{
              width: 18,
              height: 18,
              borderRadius: 0.75,
              border: 2,
              borderColor: isActive ? 'primary.main' : 'action.disabled',
              bgcolor: isActive ? 'primary.main' : 'transparent',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: (theme) =>
                theme.transitions.create(['background-color', 'border-color', 'box-shadow'], {
                  duration: theme.transitions.duration.shortest,
                }),
            }}
          >
            {indeterminate ? (
              <Box sx={{ width: 8, height: 2, borderRadius: 1, bgcolor: 'primary.contrastText' }} />
            ) : (
              checked && (
                <Box
                  component="svg"
                  width="12"
                  height="12"
                  viewBox="0 0 12 12"
                  fill="none"
                  aria-hidden="true"
                  sx={{ color: 'primary.contrastText' }}
                >
                  <path
                    d="M2 6L5 9L10 3"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </Box>
              )
            )}
          </Box>
        </Box>
        {label && <span>{label}</span>}
      </Box>
    );
  },
);

AppCheckbox.displayName = 'AppCheckbox';
