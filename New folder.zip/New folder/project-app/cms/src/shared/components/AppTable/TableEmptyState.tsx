import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import InboxIcon from '@mui/icons-material/Inbox';
import SearchOffIcon from '@mui/icons-material/SearchOff';

interface TableEmptyStateProps {
  title?: string;
  description?: string;
  /** When true, shows a "no search results" variant instead of "no data" */
  filtered?: boolean;
  actionLabel?: string;
  onAction?: () => void;
}

export function TableEmptyState({
  title,
  description,
  filtered = false,
  actionLabel,
  onAction,
}: TableEmptyStateProps) {
  const Icon = filtered ? SearchOffIcon : InboxIcon;
  const resolvedTitle = title ?? (filtered ? 'Không tìm thấy kết quả' : 'Chưa có dữ liệu');
  const resolvedDescription =
    description ??
    (filtered
      ? 'Thử điều chỉnh từ khóa hoặc bộ lọc để xem thêm kết quả.'
      : 'Dữ liệu sẽ xuất hiện tại đây sau khi được thêm vào.');

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 1,
        py: 7,
        px: 3,
      }}
    >
      <Box
        sx={{
          width: 56,
          height: 56,
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          bgcolor: 'action.hover',
          color: 'text.disabled',
          mb: 0.5,
        }}
      >
        <Icon sx={{ fontSize: 28 }} />
      </Box>

      <Typography variant="subtitle2" fontWeight={600} color="text.primary">
        {resolvedTitle}
      </Typography>
      <Typography variant="caption" color="text.secondary" sx={{ maxWidth: 320, textAlign: 'center' }}>
        {resolvedDescription}
      </Typography>

      {actionLabel && onAction && (
        <Button size="small" variant="outlined" onClick={onAction} sx={{ mt: 1.5 }}>
          {actionLabel}
        </Button>
      )}
    </Box>
  );
}
