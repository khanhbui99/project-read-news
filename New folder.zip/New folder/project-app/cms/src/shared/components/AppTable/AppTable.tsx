import { useState, useEffect, useMemo, useRef, useCallback, type KeyboardEvent } from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableSortLabel from '@mui/material/TableSortLabel';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Pagination from '@mui/material/Pagination';
import Fade from '@mui/material/Fade';
import LinearProgress from '@mui/material/LinearProgress';
import { LoadingTable } from './LoadingTable';
import { TableEmptyState } from './TableEmptyState';
import { TableCellAction, type ExtraAction } from './TableCellAction';
import { TableCellHeaderAction, type ColumnDef } from './TableCellHeaderAction';
import { AppCheckbox } from '../AppCheckbox';

export type { ColumnDef };

const ACTION_COL_WIDTH = 116;
const SELECT_COL_WIDTH = 40;

export type SortDirection = 'asc' | 'desc';

export interface SortState {
  field: string;
  direction: SortDirection;
}

interface CellActionConfig<T> {
  handleEdit?: (row: T) => void;
  handleDelete?: (row: T) => void;
  handleDetail?: (row: T) => void;
  extraActions?: (row: T) => ExtraAction[];
  extendElement?: (row: T) => React.ReactNode;
}

interface AppTableProps<T extends Record<string, unknown>> {
  id?: string;
  Columns: ColumnDef<T>[];
  items: T[];
  isQueryLoading?: boolean;
  hiddenAction?: boolean;
  cellActionProps?: CellActionConfig<T>;

  emptyTitle?: string;
  emptyText?: string;
  isFiltered?: boolean;
  onClearFilters?: () => void;

  onRowClick?: (row: T, index: number) => void;

  sort?: SortState | null;
  onSortChange?: (sort: SortState | null) => void;
  sortableFields?: string[];

  selectable?: boolean;
  selectedIds?: string[];
  onSelectionChange?: (ids: string[]) => void;
  bulkActions?: React.ReactNode;

  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  pageSizeOptions?: number[];
}

function formatCellValue(value: unknown): string {
  if (value === null || value === undefined || value === '') return '—';
  if (typeof value === 'boolean') return value ? 'Có' : 'Không';
  return String(value);
}

export function AppTable<T extends Record<string, unknown>>({
  id = 'id',
  Columns = [],
  items = [],
  isQueryLoading = false,
  hiddenAction = false,
  cellActionProps = {},
  emptyTitle,
  emptyText,
  isFiltered = false,
  onClearFilters,
  onRowClick,
  sort = null,
  onSortChange,
  sortableFields,
  selectable = true,
  selectedIds = [],
  onSelectionChange,
  bulkActions,
  page,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 20, 50, 100],
}: AppTableProps<T>) {
  const prevColumnsRef = useRef<ColumnDef<T>[] | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [columns, setColumns] = useState<ColumnDef<T>[]>(Columns);
  const [activeRow, setActiveRow] = useState<string | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);

  // Merge incoming Columns while preserving user's visibility choices
  useEffect(() => {
    if (prevColumnsRef.current === null) {
      prevColumnsRef.current = Columns;
      setColumns(Columns);
      return;
    }
    setColumns((prev) => {
      if (!Array.isArray(Columns) || !Columns.length) return prev;
      return Columns.map((col) => {
        const existing = prev.find((c) => c.field === col.field);
        return existing ? { ...col, checked: existing.checked } : col;
      });
    });
  }, [Columns]);

  // Detect horizontal scroll to toggle sticky column shadow
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const maxScroll = el.scrollWidth - el.clientWidth;
      setIsScrolled(maxScroll > 1 && el.scrollLeft < maxScroll - 1);
    };
    onScroll();
    el.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      el.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, [items.length, columns]);

  const visibleColumns = useMemo(() => columns.filter((c) => c.checked), [columns]);
  const pageCount = useMemo(() => Math.max(1, Math.ceil(total / (pageSize || 1))), [total, pageSize]);

  const start = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const end = Math.min(page * pageSize, total);
  const colSpan = visibleColumns.length + (hiddenAction ? 0 : 1) + (selectable ? 1 : 0);

  const rowIds = useMemo(() => items.map((row) => String(row[id] ?? '')), [items, id]);
  const allSelected = rowIds.length > 0 && rowIds.every((rid) => selectedIds.includes(rid));
  const someSelected = rowIds.some((rid) => selectedIds.includes(rid));
  const hasSelection = selectable && selectedIds.length > 0;

  const isSortable = useCallback(
    (field: string) => Boolean(onSortChange) && (!sortableFields || sortableFields.includes(field)),
    [onSortChange, sortableFields],
  );

  const handleSort = (field: string) => {
    if (!onSortChange) return;
    if (sort?.field !== field) onSortChange({ field, direction: 'asc' });
    else if (sort.direction === 'asc') onSortChange({ field, direction: 'desc' });
    else onSortChange(null);
  };

  const toggleAllRows = (checked: boolean) => {
    if (!onSelectionChange) return;
    if (checked) onSelectionChange(Array.from(new Set([...selectedIds, ...rowIds])));
    else onSelectionChange(selectedIds.filter((sid) => !rowIds.includes(sid)));
  };

  const toggleRow = (rowId: string, checked: boolean) => {
    if (!onSelectionChange) return;
    onSelectionChange(checked ? [...selectedIds, rowId] : selectedIds.filter((sid) => sid !== rowId));
  };

  const handleRowActivate = (row: T, index: number, rowId: string) => {
    setActiveRow(rowId);
    onRowClick?.(row, index);
  };

  const handleRowKeyDown = (
    e: KeyboardEvent<HTMLTableRowElement>,
    row: T,
    index: number,
    rowId: string,
  ) => {
    if (!onRowClick) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleRowActivate(row, index, rowId);
    }
  };

  const stickyShadow = isScrolled ? { boxShadow: '-6px 0 8px -4px rgba(15, 23, 42, 0.12)' } : {};

  return (
    <Paper
      elevation={0}
      sx={{
        border: 1,
        borderColor: 'divider',
        borderRadius: 1.5,
        overflow: 'hidden',
        position: 'relative',
      }}
    >
      {/* Bulk action bar */}
      {hasSelection && (
        <Fade in>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: 1.5,
              px: 2,
              py: 1.25,
              bgcolor: 'primary.main',
              color: 'primary.contrastText',
            }}
          >
            <Typography variant="body2" fontWeight={500}>
              Đã chọn {selectedIds.length} bản ghi
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>{bulkActions}</Box>
          </Box>
        </Fade>
      )}

      {/* Refetch indicator — keeps rows visible while updating */}
      {isQueryLoading && items.length > 0 && (
        <LinearProgress
          sx={{ height: 2, position: 'absolute', top: 0, left: 0, right: 0, zIndex: 4 }}
        />
      )}

      <TableContainer ref={scrollRef} sx={{ maxWidth: '100%', minHeight: 480 }}>
        <Table stickyHeader size="small" sx={{ minWidth: 640 }}>
          <TableHead>
            <TableRow
              sx={{
                '& th': {
                  bgcolor: 'grey.50',
                  fontWeight: 600,
                  fontSize: 12.5,
                  letterSpacing: 0.2,
                  textTransform: 'uppercase',
                  color: 'text.secondary',
                  whiteSpace: 'nowrap',
                  py: 1.5,
                  borderBottom: 'none',
                },
              }}
            >
              {selectable && (
                <TableCell padding="checkbox" width={SELECT_COL_WIDTH} sx={{ pl: 1.5 }}>
                  <AppCheckbox
                    checked={allSelected}
                    indeterminate={!allSelected && someSelected}
                    onChange={toggleAllRows}
                    aria-label="Chọn tất cả dòng"
                  />
                </TableCell>
              )}

              {visibleColumns.map((col) => (
                <TableCell
                  key={col.field}
                  width={col.width}
                  align={col.align}
                  sx={{ minWidth: col.minWidth }}
                  sortDirection={sort?.field === col.field ? sort!.direction : false}
                >
                  {isSortable(col.field) ? (
                    <TableSortLabel
                      active={sort?.field === col.field}
                      direction={sort?.field === col.field ? sort!.direction : 'asc'}
                      onClick={() => handleSort(col.field)}
                      sx={{ '&, &:hover, &.Mui-active': { color: 'inherit' } }}
                    >
                      {col.name}
                    </TableSortLabel>
                  ) : (
                    col.name
                  )}
                </TableCell>
              ))}

              {!hiddenAction && (
                <TableCell
                  width={ACTION_COL_WIDTH}
                  align="right"
                  sx={{
                    position: 'sticky',
                    right: 0,
                    zIndex: 3,
                    bgcolor: 'grey.50',
                    borderLeft: 1,
                    borderLeftColor: 'divider',
                    pr: 1.5,
                    ...stickyShadow,
                  }}
                >
                  <TableCellHeaderAction
                    value={columns as ColumnDef[]}
                    onChange={(updated: ColumnDef[]) => setColumns(updated as ColumnDef<T>[])}
                  />
                </TableCell>
              )}
            </TableRow>
          </TableHead>

          <TableBody>
            {isQueryLoading && items.length === 0 ? (
              <LoadingTable cols={colSpan} rows={Math.min(pageSize, 8)} />
            ) : items.length > 0 ? (
              items.map((row, index) => {
                const rowId = String(row[id] ?? index);
                const isSelected = selectedIds.includes(rowId);
                const isActive = activeRow === rowId;

                return (
                  <TableRow
                    key={rowId}
                    hover
                    selected={isSelected}
                    tabIndex={onRowClick ? 0 : -1}
                    onClick={onRowClick ? () => handleRowActivate(row, index, rowId) : undefined}
                    onKeyDown={(e) => handleRowKeyDown(e, row, index, rowId)}
                    sx={{
                      cursor: onRowClick ? 'pointer' : 'default',
                      '& td': { borderBottom: 'none' },
                      ...(isActive && !isSelected ? { bgcolor: 'action.hover' } : {}),
                      '&:focus-visible': {
                        outline: 2,
                        outlineColor: 'primary.main',
                        outlineOffset: -2,
                      },
                      '&:hover .app-sticky-cell': { bgcolor: 'action.hover' },
                      '&.Mui-selected .app-sticky-cell': { bgcolor: 'action.selected' },
                    }}
                  >
                    {selectable && (
                      <TableCell
                        padding="checkbox"
                        sx={{ pl: 1.5 }}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <AppCheckbox
                          checked={isSelected}
                          onChange={(checked) => toggleRow(rowId, checked)}
                          aria-label={`Chọn dòng ${index + 1}`}
                        />
                      </TableCell>
                    )}

                    {visibleColumns.map((col) => (
                      <TableCell
                        key={col.field}
                        align={col.align}
                        sx={{
                          fontSize: 13,
                          py: 1.5,
                          color: 'text.primary',
                          maxWidth: col.width ?? 320,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {typeof col.render === 'function'
                          ? col.render(row[col.field], row)
                          : formatCellValue(row[col.field])}
                      </TableCell>
                    ))}

                    {!hiddenAction && (
                      <TableCell
                        className="app-sticky-cell"
                        align="right"
                        sx={{
                          position: 'sticky',
                          right: 0,
                          zIndex: 1,
                          bgcolor: 'background.paper',
                          borderLeft: 1,
                          borderLeftColor: 'divider',
                          py: 0.75,
                          pr: 1.5,
                          transition: (t) => t.transitions.create(['background-color', 'box-shadow']),
                          ...stickyShadow,
                        }}
                      >
                        <TableCellAction
                          id={rowId}
                          handleEdit={
                            cellActionProps.handleEdit
                              ? () => cellActionProps.handleEdit!(row)
                              : undefined
                          }
                          handleDelete={
                            cellActionProps.handleDelete
                              ? () => cellActionProps.handleDelete!(row)
                              : undefined
                          }
                          handleDetail={
                            cellActionProps.handleDetail
                              ? () => cellActionProps.handleDetail!(row)
                              : undefined
                          }
                          extraActions={cellActionProps.extraActions?.(row)}
                          extendElement={cellActionProps.extendElement?.(row)}
                        />
                      </TableCell>
                    )}
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={colSpan} sx={{ borderBottom: 0, p: 0 }}>
                  <TableEmptyState
                    title={emptyTitle}
                    description={emptyText}
                    filtered={isFiltered}
                    actionLabel={isFiltered && onClearFilters ? 'Xóa bộ lọc' : undefined}
                    onAction={onClearFilters}
                  />
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Footer */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexDirection: { xs: 'column', sm: 'row' },
          gap: 1.5,
          px: 2,
          py: 1.5,
          borderTop: 1,
          borderColor: 'divider',
          bgcolor: 'grey.50',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Typography variant="caption" color="text.secondary" sx={{ whiteSpace: 'nowrap' }}>
            {total === 0 ? 'Không có bản ghi' : `Hiển thị ${start} – ${end} / ${total} bản ghi`}
          </Typography>
          <Select
            size="small"
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            aria-label="Số dòng mỗi trang"
            sx={{
              minWidth: 96,
              height: 30,
              fontSize: 12.5,
              bgcolor: 'background.paper',
              '& .MuiSelect-select': { py: 0.5 },
            }}
          >
            {pageSizeOptions.map((opt) => (
              <MenuItem key={opt} value={opt} sx={{ fontSize: 13 }}>
                {opt} / trang
              </MenuItem>
            ))}
          </Select>
        </Box>

        <Pagination
          size="small"
          shape="rounded"
          color="primary"
          count={pageCount}
          page={page}
          disabled={total === 0}
          siblingCount={1}
          boundaryCount={1}
          onChange={(_, value) => onPageChange(value)}
          sx={{ '& .MuiPaginationItem-root': { fontSize: 12.5 } }}
        />
      </Box>
    </Paper>
  );
}
