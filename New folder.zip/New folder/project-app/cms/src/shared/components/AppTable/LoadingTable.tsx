import { useMemo } from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';
import Skeleton from '@mui/material/Skeleton';

interface LoadingTableProps {
  cols: number;
  rows?: number;
}

// Deterministic widths so skeletons look organic without re-randomizing each render
const WIDTH_PATTERN = ['85%', '60%', '72%', '45%', '90%', '55%'];

export function LoadingTable({ cols = 0, rows = 8 }: LoadingTableProps) {
  const rowList = useMemo(() => Array.from({ length: rows }), [rows]);
  const colList = useMemo(() => Array.from({ length: cols }), [cols]);

  return (
    <>
      {rowList.map((_, rowIndex) => (
        <TableRow key={`skeleton-row-${rowIndex}`}>
          {colList.map((__, colIndex) => (
            <TableCell key={`skeleton-cell-${rowIndex}-${colIndex}`} sx={{ py: 1.5 }}>
              <Skeleton
                variant="text"
                animation="wave"
                width={WIDTH_PATTERN[(rowIndex + colIndex) % WIDTH_PATTERN.length]}
                height={20}
              />
            </TableCell>
          ))}
        </TableRow>
      ))}
    </>
  );
}
