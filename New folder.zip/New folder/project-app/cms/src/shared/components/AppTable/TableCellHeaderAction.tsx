import { useState, useMemo, type MouseEvent } from 'react';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import Tooltip from '@mui/material/Tooltip';
import Badge from '@mui/material/Badge';
import SettingsIcon from '@mui/icons-material/Settings';
import SearchIcon from '@mui/icons-material/Search';
import { AppCheckbox } from './AppCheckbox';

export interface ColumnDef<T = Record<string, unknown>> {
  field: string;
  name: string;
  width?: number | string;
  minWidth?: number;
  align?: 'left' | 'center' | 'right';
  checked: boolean;
  /** If true, user cannot uncheck this column (always visible) */
  required?: boolean;
  render?: (value: unknown, row: T) => React.ReactNode;
}

interface TableCellHeaderActionProps {
  value: ColumnDef[];
  onChange: (columns: ColumnDef[]) => void;
  onChecked?: (open: boolean) => void;
}

export function TableCellHeaderAction({ value, onChange, onChecked }: TableCellHeaderActionProps) {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [search, setSearch] = useState('');

  const open = Boolean(anchorEl);

  const handleOpen = (e: MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    setAnchorEl(e.currentTarget);
    onChecked?.(true);
  };

  const handleClose = () => {
    setAnchorEl(null);
    setSearch('');
    onChecked?.(false);
  };

  const toggleable = useMemo(() => value, [value]);

  const filtered = useMemo(() => {
    if (!search.trim()) return toggleable;
    const lower = search.trim().toLowerCase();
    return toggleable.filter((col) => col.name.toLowerCase().includes(lower));
  }, [toggleable, search]);

  const visibleCount = useMemo(() => value.filter((c) => c.checked).length, [value]);
  const hiddenCount = value.length - visibleCount;

  const nonRequiredCols = useMemo(() => value.filter((c) => !c.required), [value]);
  const allChecked = nonRequiredCols.length > 0 && nonRequiredCols.every((c) => c.checked);
  const someChecked = nonRequiredCols.some((c) => c.checked);

  const toggle = (field: string, checked: boolean) => {
    const col = value.find((c) => c.field === field);
    if (col?.required) return; // required columns cannot be unchecked
    if (!checked && visibleCount <= 1) return;
    onChange(value.map((c) => (c.field === field ? { ...c, checked } : c)));
  };

  const toggleAll = (checked: boolean) => {
    if (!checked) {
      // Keep required columns + first non-required visible
      const firstNonReq = nonRequiredCols[0]?.field;
      onChange(
        value.map((col) =>
          col.required ? col : { ...col, checked: col.field === firstNonReq },
        ),
      );
      return;
    }
    onChange(value.map((col) => ({ ...col, checked: true })));
  };

  return (
    <>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
        <Tooltip title="Tùy chỉnh cột hiển thị" arrow>
          <Badge
            badgeContent={hiddenCount || undefined}
            color="primary"
            overlap="circular"
            sx={{ '& .MuiBadge-badge': { fontSize: 10, height: 16, minWidth: 16 } }}
          >
            <IconButton
              size="small"
              onClick={handleOpen}
              aria-label="Tùy chỉnh cột hiển thị"
              aria-haspopup="dialog"
              aria-expanded={open}
              sx={{
                width: 32,
                height: 32,
                borderRadius: 1,
                color: open ? 'primary.main' : 'text.secondary',
                bgcolor: open ? 'action.selected' : 'transparent',
                '&:hover': { bgcolor: 'action.hover', color: 'primary.main' },
              }}
            >
              <SettingsIcon sx={{ fontSize: 18 }} />
            </IconButton>
          </Badge>
        </Tooltip>
      </Box>

      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{
          paper: {
            sx: { width: 280, borderRadius: 1.5, boxShadow: 8, overflow: 'hidden' },
          },
        }}
      >
        <Box sx={{ px: 2, pt: 1.75, pb: 1 }}>
          <Typography variant="subtitle2" fontWeight={600} gutterBottom>
            Cột hiển thị
          </Typography>
          <TextField
            autoFocus
            fullWidth
            size="small"
            placeholder="Tìm cột..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ fontSize: 18, color: 'text.disabled' }} />
                </InputAdornment>
              ),
            }}
            sx={{ '& .MuiInputBase-input': { fontSize: 13 } }}
          />
        </Box>

        <Divider />

        {!search && (
          <>
            <Box sx={{ px: 2, py: 1 }}>
              <AppCheckbox
                checked={allChecked}
                indeterminate={!allChecked && someChecked}
                onChange={toggleAll}
                label="Chọn tất cả"
              />
            </Box>
            <Divider />
          </>
        )}

        <Box sx={{ maxHeight: 260, overflowY: 'auto', px: 2, py: 0.75 }}>
          {filtered.length === 0 ? (
            <Typography
              variant="caption"
              color="text.disabled"
              sx={{ display: 'block', py: 2, textAlign: 'center' }}
            >
              Không tìm thấy cột phù hợp
            </Typography>
          ) : (
            filtered.map((col) => {
              const isRequired = !!col.required;
              return (
                <AppCheckbox
                  key={col.field}
                  id={`col-${col.field}`}
                  checked={col.checked}
                  disabled={isRequired}
                  onChange={(checked) => toggle(col.field, checked)}
                  label={col.name}
                />
              );
            })
          )}
        </Box>

        <Divider />
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            px: 1.5,
            py: 1,
            bgcolor: 'action.hover',
          }}
        >
          <Typography variant="caption" color="text.secondary">
            {visibleCount}/{value.length} cột
          </Typography>
          <Button size="small" onClick={() => toggleAll(true)} sx={{ fontSize: 12 }}>
            Hiện tất cả
          </Button>
        </Box>
      </Popover>
    </>
  );
}
