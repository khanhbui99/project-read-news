import { useState, type MouseEvent } from 'react';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import EditIcon from '@mui/icons-material/EditOutlined';
import DeleteIcon from '@mui/icons-material/DeleteOutlineOutlined';
import VisibilityIcon from '@mui/icons-material/VisibilityOutlined';
import MoreVertIcon from '@mui/icons-material/MoreVert';

export interface ExtraAction {
  label: string;
  icon?: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
  disabled?: boolean;
}

export interface TableCellActionProps {
  id: string;
  handleEdit?: () => void;
  handleDelete?: () => void;
  handleDetail?: () => void;
  extraActions?: ExtraAction[];
  extendElement?: React.ReactNode;
}

const iconBtnSx = {
  width: 32,
  height: 32,
  borderRadius: 1,
  transition: (theme: { transitions: { create: (p: string[]) => string } }) =>
    theme.transitions.create(['background-color', 'color']),
};

export function TableCellAction({
  handleEdit,
  handleDelete,
  handleDetail,
  extraActions,
  extendElement,
}: TableCellActionProps) {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const stop = (e: MouseEvent) => e.stopPropagation();

  const openMenu = (e: MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    setAnchorEl(e.currentTarget);
  };

  const closeMenu = () => setAnchorEl(null);

  const runAction = (fn: () => void) => {
    closeMenu();
    fn();
  };

  return (
    <Box
      onClick={stop}
      sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 0.25 }}
    >
      {handleDetail && (
        <Tooltip title="Xem chi tiết" arrow>
          <IconButton
            size="small"
            aria-label="Xem chi tiết"
            onClick={handleDetail}
            sx={{
              ...iconBtnSx,
              color: 'text.secondary',
              '&:hover': { bgcolor: 'action.hover', color: 'text.primary' },
            }}
          >
            <VisibilityIcon sx={{ fontSize: 18 }} />
          </IconButton>
        </Tooltip>
      )}

      {handleEdit && (
        <Tooltip title="Chỉnh sửa" arrow>
          <IconButton
            size="small"
            aria-label="Chỉnh sửa"
            onClick={handleEdit}
            sx={{
              ...iconBtnSx,
              color: 'primary.main',
              '&:hover': { bgcolor: 'primary.main', color: 'primary.contrastText' },
            }}
          >
            <EditIcon sx={{ fontSize: 18 }} />
          </IconButton>
        </Tooltip>
      )}

      {handleDelete && (
        <Tooltip title="Xóa" arrow>
          <IconButton
            size="small"
            aria-label="Xóa"
            onClick={handleDelete}
            sx={{
              ...iconBtnSx,
              color: 'error.main',
              '&:hover': { bgcolor: 'error.main', color: 'error.contrastText' },
            }}
          >
            <DeleteIcon sx={{ fontSize: 18 }} />
          </IconButton>
        </Tooltip>
      )}

      {extraActions && extraActions.length > 0 && (
        <>
          <Tooltip title="Thao tác khác" arrow>
            <IconButton
              size="small"
              aria-label="Thao tác khác"
              onClick={openMenu}
              sx={{
                ...iconBtnSx,
                color: 'text.secondary',
                '&:hover': { bgcolor: 'action.hover', color: 'text.primary' },
              }}
            >
              <MoreVertIcon sx={{ fontSize: 18 }} />
            </IconButton>
          </Tooltip>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={closeMenu}
            onClick={stop}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            slotProps={{ paper: { sx: { minWidth: 180, borderRadius: 1.5 } } }}
          >
            {extraActions.map((action) => (
              <MenuItem
                key={action.label}
                disabled={action.disabled}
                onClick={() => runAction(action.onClick)}
                sx={{ fontSize: 13, color: action.danger ? 'error.main' : undefined }}
              >
                {action.icon && (
                  <ListItemIcon sx={{ color: action.danger ? 'error.main' : undefined }}>
                    {action.icon}
                  </ListItemIcon>
                )}
                <ListItemText primaryTypographyProps={{ fontSize: 13 }}>{action.label}</ListItemText>
              </MenuItem>
            ))}
          </Menu>
        </>
      )}

      {extendElement}
    </Box>
  );
}
