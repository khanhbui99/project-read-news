import { useState, type MouseEvent } from 'react';
import Box from '@mui/material/Box';
import Avatar from '@mui/material/Avatar';
import Popover from '@mui/material/Popover';
import Divider from '@mui/material/Divider';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import LogoutIcon from '@mui/icons-material/Logout';
import { AppText, AppCaption } from '../Styled';
import { OrgRoleCard } from './OrgRoleCard';
import { useGlobalStore } from '@/shared/stores/globalStore';
import { getUserName, getUserAvatar, getUserRole } from '@/shared/utils/userDisplay';
import type { OrgChart } from '@/modules/auth/service';
import { useLogout } from '@/modules/auth/hooks/useLogout';

export function HeaderUserMenu() {
  const logout = useLogout();
  const user = useGlobalStore((s) => s.user);
  const orgCharts = useGlobalStore((s) => s.orgCharts);
  const activeOrg = useGlobalStore((s) => s.activeOrg);
  const setActiveOrg = useGlobalStore((s) => s.setActiveOrg);

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const displayName = getUserName(user);
  const avatarUrl = getUserAvatar(user);
  const displayRole = activeOrg?.roleName ?? getUserRole(user) ?? '';

  const handleOpen = (e: MouseEvent<HTMLElement>) => setAnchorEl(e.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleSelectOrg = (org: OrgChart) => {
    setActiveOrg({ id: org.id, name: org.name, roleName: org.roleName, orgName: org.orgName });
    handleClose();
  };

  const handleLogout = () => {
    handleClose();
    logout();
  };

  return (
    <>
      {/* Trigger */}
      <Box
        onClick={handleOpen}
        aria-haspopup="menu"
        aria-expanded={open}
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1.25,
          pl: 1,
          pr: 0.5,
          py: 0.5,
          borderRadius: 1.5,
          cursor: 'pointer',
          transition: 'background-color 120ms ease',
          '&:hover': { bgcolor: 'action.hover' },
        }}
      >
        <Avatar sx={{ width: 40, height: 40 }} alt={displayName} src={avatarUrl} />
        <Box sx={{ display: { xs: 'none', sm: 'block' }, lineHeight: 1.2, width: 140 }}>
          <AppText size="md" weight="bold" noWrap>
            {displayName}
          </AppText>
          <AppCaption size="sm" color="secondary" noWrap>
            {displayRole}
          </AppCaption>
        </Box>
        {open ? (
          <KeyboardArrowUpIcon sx={{ fontSize: 22, color: 'text.secondary' }} />
        ) : (
          <KeyboardArrowDownIcon sx={{ fontSize: 22, color: 'text.secondary' }} />
        )}
      </Box>

      {/* Dropdown */}
      <Popover
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{
          paper: { sx: { mt: 1, width: 320, borderRadius: 2, boxShadow: '0 8px 32px rgba(0,0,0,0.12)', p: 1.5 } },
        }}
      >
        {/* Profile block */}
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 1,
            p: 2,
            borderRadius: 2,
            bgcolor: 'grey.50',
            mb: 1.5,
          }}
        >
          <Avatar
            sx={{ width: 72, height: 72, border: 3, borderColor: 'warning.light' }}
            alt={displayName}
            src={avatarUrl}
          />
          <AppText size="lg" weight="bold" align="center">
            {displayName}
          </AppText>
        </Box>

        {/* Org roles */}
        {orgCharts.length > 0 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, mb: 1.5 }}>
            {orgCharts.map((org) => (
              <OrgRoleCard
                key={String(org.id)}
                org={org}
                active={String(activeOrg?.id) === String(org.id)}
                onSelect={handleSelectOrg}
              />
            ))}
          </Box>
        )}

        <Divider sx={{ mb: 1 }} />

        {/* Logout */}
        <Box
          onClick={handleLogout}
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 2,
            p: 1.5,
            borderRadius: 2,
            cursor: 'pointer',
            transition: 'background-color 120ms ease',
            '&:hover': { bgcolor: 'action.hover' },
          }}
        >
          <LogoutIcon sx={{ fontSize: 22, color: 'error.main' }} />
          <AppText size="md">Đăng xuất</AppText>
        </Box>
      </Popover>
    </>
  );
}
