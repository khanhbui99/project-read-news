import Box from '@mui/material/Box';
import RadioButtonCheckedIcon from '@mui/icons-material/RadioButtonChecked';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import { AppText, AppCaption } from '../Styled';
import type { OrgChart } from '@/modules/auth/service';

interface OrgRoleCardProps {
  org: OrgChart;
  active: boolean;
  onSelect: (org: OrgChart) => void;
}

/** Selectable org/role card shown in the user dropdown */
export function OrgRoleCard({ org, active, onSelect }: OrgRoleCardProps) {
  return (
    <Box
      onClick={() => onSelect(org)}
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        p: 1.5,
        borderRadius: 2,
        cursor: 'pointer',
        border: 1,
        borderColor: active ? 'success.main' : 'divider',
        bgcolor: active ? 'success.light' : 'transparent',
        transition: 'background-color 120ms ease, border-color 120ms ease',
        '&:hover': { bgcolor: active ? 'success.light' : 'action.hover' },
      }}
    >
      {active ? (
        <RadioButtonCheckedIcon sx={{ color: 'primary.main', fontSize: 22 }} />
      ) : (
        <RadioButtonUncheckedIcon sx={{ color: 'text.disabled', fontSize: 22 }} />
      )}
      <Box sx={{ minWidth: 0 }}>
        <AppText size="md" weight="semibold" color={active ? 'primary' : 'primary'} noWrap>
          {org.roleName ?? org.name}
        </AppText>
        {org.orgName && (
          <AppCaption size="xs" color="secondary" noWrap>
            {org.orgName}
          </AppCaption>
        )}
      </Box>
    </Box>
  );
}
