import Button, { type ButtonProps } from '@mui/material/Button';
import { styled, keyframes } from '@mui/material/styles';

const shimmer = keyframes`
  0% { left: -100%; }
  100% { left: 100%; }
`;

const StyledButton = styled(Button)(() => ({
  position: 'relative',
  overflow: 'hidden',
  '&::after': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '-100%',
    width: '100%',
    height: '100%',
    background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)',
    animation: `${shimmer} 2.5s ease-in-out infinite`,
    pointerEvents: 'none',
  },
  '&:not(:hover)::after': {
    animation: 'none',
    opacity: 0,
  },
}));

export interface AppButtonProps extends ButtonProps {
  shimmerOnHover?: boolean;
}

export function AppButton({ shimmerOnHover = true, sx, ...props }: AppButtonProps) {
  if (!shimmerOnHover) {
    return <Button sx={sx} {...props} />;
  }
  return <StyledButton sx={sx} {...props} />;
}
