import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import Box from '@mui/material/Box';
import dayjs, { type Dayjs } from 'dayjs';
import { AppLabel } from './Styled';

interface AppDatePickerProps {
  value?: string | null;
  onChange?: (value: string | null) => void;
  label?: string;
  placeholder?: string;
  error?: boolean;
  helperText?: string;
  disabled?: boolean;
  required?: boolean;
  minDate?: string;
  maxDate?: string;
  format?: string;
  size?: 'small' | 'medium';
  isLabelTop?: boolean;
}

export function AppDatePicker({
  value,
  onChange,
  label,
  error = false,
  helperText,
  disabled = false,
  required = false,
  minDate,
  maxDate,
  format = 'DD/MM/YYYY',
  size = 'small',
  isLabelTop = true,
}: AppDatePickerProps) {
  const dayjsValue = value ? dayjs(value) : null;

  const handleChange = (newValue: Dayjs | null) => {
    onChange?.(newValue ? newValue.format('YYYY-MM-DD') : null);
  };

  const picker = (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DatePicker
        value={dayjsValue}
        onChange={handleChange}
        label={isLabelTop ? undefined : label}
        format={format}
        disabled={disabled}
        minDate={minDate ? dayjs(minDate) : undefined}
        maxDate={maxDate ? dayjs(maxDate) : undefined}
        slotProps={{
          textField: {
            size,
            fullWidth: true,
            error,
            helperText,
            required: isLabelTop ? undefined : required,
          },
        }}
      />
    </LocalizationProvider>
  );

  if (isLabelTop && label) {
    return (
      <Box>
        <AppLabel required={required}>{label}</AppLabel>
        {picker}
      </Box>
    );
  }

  return picker;
}
