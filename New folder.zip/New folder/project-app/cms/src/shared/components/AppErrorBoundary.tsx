import { Component, type ReactNode } from 'react';
import Box from '@mui/material/Box';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import { AppButton } from './AppButton';
import { AppTitle, AppText } from './Styled';
import { env } from '@/shared/config/env';
import { CHUNK_RELOAD_FLAG } from '@/routers/constants';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  info: string | null;
}

/**
 * Global error boundary.
 * - DEV: hiển thị chi tiết lỗi (message + stack) để tiện debug, KHÔNG che giấu.
 * - PROD: hiển thị màn hình thân thiện, ẩn stack trace; lỗi chunk/asset thử
 *   hard reload 1 lần (asset mới sau khi redeploy).
 */
export class AppErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null, info: null };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, info: null };
  }

  componentDidCatch(error: Error, info: { componentStack?: string }) {
    this.setState({ info: info.componentStack ?? null });

    // DEV: giữ nguyên lỗi để debug, không auto-reload che mất bug thật.
    if (env.isDev) {
      console.error('[AppErrorBoundary] Caught error:', error, info);
      return;
    }

    // PROD: lỗi tải chunk/asset → thử hard reload 1 lần.
    const isChunkError =
      /loading chunk|dynamically imported module|failed to fetch/i.test(error.message);

    if (isChunkError && !sessionStorage.getItem(CHUNK_RELOAD_FLAG)) {
      sessionStorage.setItem(CHUNK_RELOAD_FLAG, '1');
      window.location.reload();
    }
    // Real error logging could be wired here (Sentry, etc.)
  }

  handleReload = () => {
    sessionStorage.removeItem(CHUNK_RELOAD_FLAG);
    window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    // DEV: màn hình chi tiết cho lập trình viên.
    if (env.isDev) {
      const { error, info } = this.state;
      return (
        <Box sx={{ minHeight: '100vh', p: 3, bgcolor: 'grey.900', color: 'grey.100', overflow: 'auto' }}>
          <AppTitle size="xl" color="white">
            [DEV] Runtime error
          </AppTitle>
          <AppText size="md" color="white" sx={{ mt: 1, fontWeight: 600 }}>
            {error?.name}: {error?.message}
          </AppText>
          {error?.stack && (
            <Box
              component="pre"
              sx={{
                mt: 2,
                p: 2,
                borderRadius: 1,
                bgcolor: 'rgba(0,0,0,0.5)',
                fontSize: 12,
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
              }}
            >
              {error.stack}
            </Box>
          )}
          {info && (
            <Box
              component="pre"
              sx={{
                mt: 2,
                p: 2,
                borderRadius: 1,
                bgcolor: 'rgba(0,0,0,0.5)',
                fontSize: 12,
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
              }}
            >
              {info}
            </Box>
          )}
          <AppButton variant="contained" color="error" onClick={this.handleReload} sx={{ mt: 2 }}>
            Tải lại trang
          </AppButton>
        </Box>
      );
    }

    // PROD: màn hình thân thiện, ẩn chi tiết kỹ thuật.
    return (
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 2,
          p: 3,
          bgcolor: 'grey.50',
        }}
      >
        <Box
          sx={{
            width: 72,
            height: 72,
            borderRadius: '50%',
            bgcolor: 'error.light',
            color: 'error.main',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            mb: 1,
          }}
        >
          <ErrorOutlineIcon sx={{ fontSize: 36 }} />
        </Box>

        <AppTitle size="xl" align="center">
          Đã có lỗi xảy ra
        </AppTitle>
        <AppText size="md" color="secondary" align="center" sx={{ maxWidth: 420 }}>
          Hệ thống gặp sự cố không mong muốn. Vui lòng tải lại trang. Nếu tình trạng vẫn tiếp diễn,
          hãy liên hệ quản trị viên.
        </AppText>

        <AppButton variant="contained" onClick={this.handleReload} sx={{ mt: 2 }}>
          Tải lại trang
        </AppButton>
      </Box>
    );
  }
}
