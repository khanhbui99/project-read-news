import Box from '@mui/material/Box';
import CloudOffIcon from '@mui/icons-material/CloudOff';
import LogoutIcon from '@mui/icons-material/Logout';
import { AppButton } from './AppButton';
import { AppTitle, AppText } from './Styled';

interface MenuErrorScreenProps {
  onRetry?: () => void;
  onLogout: () => void;
}

export function MenuErrorScreen({ onRetry, onLogout }: MenuErrorScreenProps) {
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 2,
        p: 3,
        bgcolor: 'grey.50',
      }}
    >
      <Box
        sx={{
          width: 72,
          height: 72,
          borderRadius: '50%',
          bgcolor: 'error.light',
          color: 'error.main',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          mb: 1,
        }}
      >
        <CloudOffIcon sx={{ fontSize: 36 }} />
      </Box>

      <AppTitle size="xl" align="center">
        Không tải được dữ liệu hệ thống
      </AppTitle>
      <AppText size="md" color="secondary" align="center" sx={{ maxWidth: 420 }}>
        Không thể tải danh sách menu sau nhiều lần thử. Vui lòng kiểm tra kết nối mạng và thử lại,
        hoặc đăng xuất để đăng nhập lại.
      </AppText>

      <Box sx={{ display: 'flex', gap: 1.5, mt: 2 }}>
        {onRetry && (
          <AppButton variant="contained" onClick={onRetry}>
            Thử lại
          </AppButton>
        )}
        <AppButton variant="outlined" color="error" startIcon={<LogoutIcon />} onClick={onLogout}>
          Đăng xuất
        </AppButton>
      </Box>
    </Box>
  );
}
