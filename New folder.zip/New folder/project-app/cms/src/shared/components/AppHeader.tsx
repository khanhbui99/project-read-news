import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import { AppTitle, AppText } from './Styled';

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  createLabel?: string;
  onCreate?: () => void;
  showCreate?: boolean;
  actions?: React.ReactNode;
}

export function AppHeader({
  title,
  subtitle,
  createLabel = 'Tạo mới',
  onCreate,
  showCreate = true,
  actions,
}: AppHeaderProps) {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
      <Box>
        <AppTitle size="2xl">{title}</AppTitle>
        {subtitle && (
          <AppText size="sm" color="secondary" sx={{ mt: 0.25 }}>{subtitle}</AppText>
        )}
      </Box>
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
        {actions}
        {showCreate && onCreate && (
          <Button variant="contained" startIcon={<AddIcon />} onClick={onCreate}>
            {createLabel}
          </Button>
        )}
      </Box>
    </Box>
  );
}
