import { useEffect, useState } from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
import { subscribeModal, closeModal, getModalState } from '@/shared/services/modalService';

export function ModalConfirm() {
  const [state, setState] = useState(getModalState());

  useEffect(() => subscribeModal(setState), []);

  if (!state) return null;

  const isConfirm = state.type === 'confirm';

  return (
    <Dialog open onClose={() => closeModal(false)} maxWidth="xs" fullWidth>
      <DialogTitle>{state.title}</DialogTitle>
      <DialogContent>
        <DialogContentText>{state.message}</DialogContentText>
      </DialogContent>
      <DialogActions>
        {isConfirm ? (
          <>
            <Button onClick={() => closeModal(false)}>Hủy</Button>
            <Button variant="contained" onClick={() => closeModal(true)}>Xác nhận</Button>
          </>
        ) : (
          <Button variant="contained" onClick={() => closeModal(true)}>OK</Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
