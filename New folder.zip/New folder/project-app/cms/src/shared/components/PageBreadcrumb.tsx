import { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import Box from '@mui/material/Box';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { AppText } from './Styled';
import type { MenuItem } from '@/shared/hooks/useMenu';

interface PageBreadcrumbProps {
  items: MenuItem[];
}

/** Build breadcrumb trail from nested menu matching current path */
function findTrail(items: MenuItem[], pathname: string, trail: string[] = []): string[] | null {
  for (const item of items) {
    const nextTrail = [...trail, item.name];
    if (item.url === pathname) return nextTrail;
    if (item.children) {
      const found = findTrail(item.children, pathname, nextTrail);
      if (found) return found;
    }
  }
  return null;
}

/** Left-side page breadcrumb shown in the header (format: A / B / C) */
export function PageBreadcrumb({ items }: PageBreadcrumbProps) {
  const location = useLocation();

  const trail = useMemo(
    () => findTrail(items, location.pathname) ?? [],
    [items, location.pathname],
  );

  if (trail.length === 0) return null;

  const title = trail[trail.length - 1];
  const parents = trail.slice(0, -1);

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
      {/* Page title */}
      <AppText size="lg" weight="bold" noWrap>
        {title}
      </AppText>

      {/* Parent trail */}
      {parents.length > 0 && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.25, mt: 0.25 }}>
          {parents.map((name, index) => (
            <Box key={`${name}-${index}`} sx={{ display: 'flex', alignItems: 'center', gap: 0.25 }}>
              <AppText size="xs" color="secondary" noWrap>
                {name}
              </AppText>
              <NavigateNextIcon sx={{ fontSize: 14, color: 'text.disabled' }} />
            </Box>
          ))}
          <AppText size="xs" color="disabled" noWrap>
            {title}
          </AppText>
        </Box>
      )}
    </Box>
  );
}
