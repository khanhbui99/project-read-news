import { useState, useMemo, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Dialog from '@mui/material/Dialog';
import Box from '@mui/material/Box';
import InputBase from '@mui/material/InputBase';
import Divider from '@mui/material/Divider';
import Tooltip from '@mui/material/Tooltip';
import SearchIcon from '@mui/icons-material/Search';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import { AppText, AppCaption } from './Styled';
import type { MenuItem } from '@/shared/hooks/useMenu';

interface FlatMenuEntry {
  id: number;
  name: string;
  url: string;
  parentLabel: string;
  group: string;
  /** Nesting depth (0 = top level). Used for indentation. */
  depth: number;
}

interface ModalMenuSearchProps {
  open: boolean;
  onClose: () => void;
  items: MenuItem[];
}

/**
 * Flatten menu into searchable LEAF entries only.
 * A node that has children is NOT itself listed — only its leaves are.
 */
function flattenForSearch(
  items: MenuItem[],
  parentLabel = 'Root Menu',
  group = '',
  depth = 0,
): FlatMenuEntry[] {
  const result: FlatMenuEntry[] = [];
  for (const item of items) {
    const currentGroup = group || item.name;
    const hasChildren = item.children && item.children.length > 0;

    if (hasChildren) {
      // Skip the parent itself, only include its descendants
      result.push(...flattenForSearch(item.children!, item.name, currentGroup, depth + 1));
    } else if (item.url) {
      result.push({
        id: item.id,
        name: item.name,
        url: item.url,
        parentLabel,
        group: currentGroup,
        depth,
      });
    }
  }
  return result;
}

export function ModalMenuSearch({ open, onClose, items }: ModalMenuSearchProps) {
  const navigate = useNavigate();
  const [keyword, setKeyword] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const listRef = useRef<HTMLDivElement | null>(null);

  const allEntries = useMemo(() => flattenForSearch(items), [items]);

  const results = useMemo(() => {
    const term = keyword.trim().toLowerCase();
    if (!term) return allEntries;
    return allEntries.filter((entry) => entry.name.toLowerCase().includes(term));
  }, [allEntries, keyword]);

  useEffect(() => {
    if (open) {
      setKeyword('');
      setActiveIndex(0);
    }
  }, [open]);

  useEffect(() => {
    const container = listRef.current;
    const activeEl = container?.querySelector<HTMLElement>('[data-active="true"]');
    activeEl?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex, results]);

  const goTo = (entry?: FlatMenuEntry) => {
    if (!entry) return;
    navigate(entry.url);
    onClose();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((prev) => (prev + 1) % Math.max(results.length, 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((prev) => (prev - 1 + results.length) % Math.max(results.length, 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      goTo(results[activeIndex]);
    }
  };

  const shouldShowGroup = (index: number) =>
    index === 0 || results[index].group !== results[index - 1].group;

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullWidth
      maxWidth="sm"
      transitionDuration={150}
      slotProps={{
        paper: {
          sx: {
            borderRadius: 2,
            overflow: 'hidden',
            // Centered dialog with a fixed height on desktop for a stable layout
            display: 'flex',
            flexDirection: 'column',
            height: { xs: 'auto', sm: 560 },
            maxHeight: '80vh',
            m: 2,
          },
        },
        backdrop: {
          sx: { backgroundColor: 'rgba(0,0,0,0.4)' },
        },
      }}
    >
      {/* Search input */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, px: 2.5, py: 1.75 }}>
        <SearchIcon sx={{ fontSize: 20, color: 'text.disabled' }} />
        <InputBase
          autoFocus
          fullWidth
          value={keyword}
          onChange={(e) => {
            setKeyword(e.target.value);
            setActiveIndex(0);
          }}
          onKeyDown={handleKeyDown}
          placeholder="Tìm kiếm menu"
          sx={{ fontSize: 14 }}
        />
        <Tooltip title="Dùng ↑ ↓ để di chuyển, Enter để mở" arrow>
          <HelpOutlineIcon sx={{ fontSize: 18, color: 'primary.main', cursor: 'help' }} />
        </Tooltip>
      </Box>

      <Divider />

      {/* Results */}
      <Box ref={listRef} sx={{ flex: 1, overflowY: 'auto', py: 0.5 }}>
        {results.length === 0 ? (
          <Box sx={{ py: 5, textAlign: 'center' }}>
            <AppText size="sm" color="disabled">
              Không tìm thấy menu phù hợp
            </AppText>
          </Box>
        ) : (
          results.map((entry, index) => {
            const isActive = index === activeIndex;
            return (
              <Box key={`${entry.id}-${entry.url}`}>
                {shouldShowGroup(index) && (
                  <Box sx={{ px: 2.5, pt: 1.5, pb: 0.75 }}>
                    <AppText size="sm" weight="bold" color="primary">
                      {entry.group}
                    </AppText>
                  </Box>
                )}
                <Box
                  data-active={isActive}
                  onClick={() => goTo(entry)}
                  onMouseEnter={() => setActiveIndex(index)}
                  sx={{
                    // Indent sub-items by depth
                    pl: 2.5 + entry.depth * 2,
                    pr: 2.5,
                    py: 1,
                    cursor: 'pointer',
                    borderLeft: 3,
                    borderColor: isActive ? 'primary.main' : 'transparent',
                    bgcolor: isActive ? 'primary.light' : 'transparent',
                    transition: 'background-color 120ms ease',
                    '&:hover': { bgcolor: isActive ? 'primary.light' : 'action.hover' },
                  }}
                >
                  <AppText size="md" weight={isActive ? 'semibold' : 'normal'} color={isActive ? 'primary' : 'primary'}>
                    {entry.name}
                  </AppText>
                  <AppCaption size="xs" color="disabled">
                    {entry.parentLabel}
                  </AppCaption>
                </Box>
              </Box>
            );
          })
        )}
      </Box>
    </Dialog>
  );
}
