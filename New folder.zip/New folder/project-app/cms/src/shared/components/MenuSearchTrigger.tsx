import Box from '@mui/material/Box';
import SearchIcon from '@mui/icons-material/Search';
import { AppText } from './Styled';

interface MenuSearchTriggerProps {
  onClick: () => void;
}

export function MenuSearchTrigger({ onClick }: MenuSearchTriggerProps) {
  return (
    <Box
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.5,
        minWidth: { sm: 200, lg: 300 },
        px: 2,
        py: 1.25,
        borderRadius: 2,
        bgcolor: 'grey.100',
        cursor: 'pointer',
        transition: (theme) => theme.transitions.create('background-color'),
        '&:hover': { bgcolor: 'grey.200' },
        '&:focus-visible': { outline: 2, outlineColor: 'primary.main', outlineOffset: 2 },
      }}
    >
      <SearchIcon sx={{ fontSize: 20, color: 'text.secondary' }} />
      <AppText size="md" color="secondary" sx={{ flex: 1, display: { xs: 'none', sm: 'block' } }}>
        Tìm kiếm menu
      </AppText>
      <Box
        sx={{
          display: { xs: 'none', sm: 'flex' },
          alignItems: 'center',
          px: 1,
          py: 0.25,
          borderRadius: 1,
          bgcolor: 'background.paper',
          border: 1,
          borderColor: 'grey.300',
        }}
      >
        <AppText size="sm" weight="medium" color="secondary">
          Ctrl K
        </AppText>
      </Box>
    </Box>
  );
}
