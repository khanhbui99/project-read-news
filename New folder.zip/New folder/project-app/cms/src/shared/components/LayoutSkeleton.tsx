import Box from '@mui/material/Box';
import Skeleton from '@mui/material/Skeleton';

const DRAWER_WIDTH = 300;
const SIDEBAR_TINT = 'rgba(255,255,255,0.18)';
const SIDEBAR_TINT_SOFT = 'rgba(255,255,255,0.10)';

/**
 * Full-page skeleton mirroring AdminLayout while the dynamic menu resolves.
 */
export function LayoutSkeleton() {
  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'grey.50' }}>
      {/* ===== Sidebar ===== */}
      <Box
        sx={{
          width: DRAWER_WIDTH,
          flexShrink: 0,
          bgcolor: 'primary.main',
          display: { xs: 'none', md: 'flex' },
          flexDirection: 'column',
        }}
      >
        {/* Brand */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, height: 64, px: 2.5 }}>
          <Skeleton variant="rounded" width={36} height={36} sx={{ bgcolor: SIDEBAR_TINT }} />
          <Box sx={{ flex: 1 }}>
            <Skeleton width="55%" height={14} sx={{ bgcolor: SIDEBAR_TINT }} />
            <Skeleton width="70%" height={10} sx={{ bgcolor: SIDEBAR_TINT_SOFT, mt: 0.5 }} />
          </Box>
        </Box>
        <Box sx={{ height: '1px', bgcolor: SIDEBAR_TINT_SOFT }} />

        {/* Menu groups */}
        <Box sx={{ px: 1.5, py: 2, display: 'flex', flexDirection: 'column', gap: 3 }}>
          {[3, 4, 2].map((count, groupIndex) => (
            <Box key={groupIndex} sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {Array.from({ length: count }).map((_, itemIndex) => (
                <Box key={itemIndex} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, px: 1, py: 0.5 }}>
                  <Skeleton variant="rounded" width={24} height={24} sx={{ bgcolor: SIDEBAR_TINT, flexShrink: 0 }} />
                  <Skeleton
                    width={`${55 + ((itemIndex * 13) % 35)}%`}
                    height={14}
                    sx={{ bgcolor: SIDEBAR_TINT }}
                  />
                </Box>
              ))}
            </Box>
          ))}
        </Box>
      </Box>

      {/* ===== Main ===== */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Header */}
        <Box
          sx={{
            height: 64,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            gap: 2,
            px: 3,
            bgcolor: '#fff',
            boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
          }}
        >
          <Skeleton variant="rounded" width={300} height={44} sx={{ borderRadius: 2 }} />
          <Skeleton variant="circular" width={40} height={40} />
          <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
            <Skeleton width={80} height={14} />
            <Skeleton width={50} height={10} sx={{ mt: 0.5 }} />
          </Box>
        </Box>

        {/* Content */}
        <Box sx={{ flex: 1, p: { xs: 2, md: 3 } }}>
          {/* Page header */}
          <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 2, mb: 3 }}>
            <Box>
              <Skeleton width={280} height={30} />
              <Skeleton width={360} height={16} sx={{ mt: 1 }} />
            </Box>
            <Skeleton variant="rounded" width={150} height={40} sx={{ borderRadius: 1.5 }} />
          </Box>

          {/* Filter bar */}
          <Box sx={{ display: 'flex', gap: 1.5, mb: 2, flexWrap: 'wrap' }}>
            <Skeleton variant="rounded" width={260} height={40} sx={{ borderRadius: 1.5 }} />
            <Skeleton variant="rounded" width={160} height={40} sx={{ borderRadius: 1.5 }} />
            <Skeleton variant="rounded" width={160} height={40} sx={{ borderRadius: 1.5 }} />
          </Box>

          {/* Table card */}
          <Box sx={{ border: 1, borderColor: 'divider', borderRadius: 1.5, overflow: 'hidden', bgcolor: '#fff' }}>
            {/* Head */}
            <Box sx={{ display: 'flex', gap: 3, px: 2, py: 1.75, bgcolor: 'grey.100' }}>
              {[16, 28, 22, 18, 10].map((w, i) => (
                <Skeleton key={i} width={`${w}%`} height={14} />
              ))}
            </Box>
            {/* Rows */}
            {Array.from({ length: 8 }).map((_, rowIndex) => (
              <Box
                key={rowIndex}
                sx={{
                  display: 'flex',
                  gap: 3,
                  px: 2,
                  py: 2,
                  borderTop: 1,
                  borderColor: 'divider',
                }}
              >
                {[16, 28, 22, 18, 10].map((w, colIndex) => (
                  <Skeleton
                    key={colIndex}
                    width={`${Math.max(8, w - ((rowIndex + colIndex) % 3) * 3)}%`}
                    height={16}
                  />
                ))}
              </Box>
            ))}
          </Box>

          {/* Footer / pagination */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
            <Skeleton width={220} height={16} />
            <Box sx={{ display: 'flex', gap: 1 }}>
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} variant="rounded" width={30} height={30} />
              ))}
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
