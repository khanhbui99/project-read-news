import Drawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import CloseIcon from '@mui/icons-material/Close';
import { AppText, AppCaption } from './Styled';

type Position = 'right' | 'left' | 'top' | 'bottom';

interface AppModalContainerProps {
  open: boolean;
  onClose: () => void;
  position?: Position;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
}

const widthByPosition = (position: Position) => {
  if (position === 'top' || position === 'bottom') return '100%';
  return { xs: '100%', sm: '80%', md: '55%', lg: '45%', xl: '40%' };
};

export function AppModalContainer({
  open,
  onClose,
  position = 'right',
  title,
  subtitle,
  children,
  actions,
}: AppModalContainerProps) {
  const isHorizontal = position === 'left' || position === 'right';

  return (
    <Drawer
      anchor={position}
      open={open}
      onClose={onClose}
      slotProps={{
        paper: {
          sx: {
            width: isHorizontal ? widthByPosition(position) : '100%',
            height: !isHorizontal ? { xs: '90vh', md: '60vh' } : '100%',
            display: 'flex',
            flexDirection: 'column',
          },
        },
      }}
    >
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', p: 2, flexShrink: 0 }}>
        <Box>
          {title && <AppText size="lg" weight="semibold">{title}</AppText>}
          {subtitle && <AppCaption size="sm" color="secondary">{subtitle}</AppCaption>}
        </Box>
        <IconButton onClick={onClose} aria-label="Đóng">
          <CloseIcon />
        </IconButton>
      </Box>
      <Divider />

      {/* Body */}
      <Box sx={{ flex: 1, overflow: 'auto', p: 3 }}>
        {children}
      </Box>

      {/* Footer actions */}
      {actions && (
        <>
          <Divider />
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1.5, p: 2, flexShrink: 0 }}>
            {actions}
          </Box>
        </>
      )}
    </Drawer>
  );
}
