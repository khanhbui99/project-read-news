import { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Collapse from '@mui/material/Collapse';
import Skeleton from '@mui/material/Skeleton';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import type { MenuItem } from '@/shared/hooks/useMenu';

interface SidebarMenuProps {
  items: MenuItem[];
  loading?: boolean;
  level?: number;
  onNavigate?: () => void;
}

const activeItemSx = {
  bgcolor: 'rgba(255,255,255,0.22)',
  color: '#fff',
  boxShadow: 'inset 3px 0 0 #fff',
};

export function SidebarMenu({ items, loading = false, level = 0, onNavigate }: SidebarMenuProps) {
  if (loading) {
    return (
      <Box sx={{ px: 2, py: 1 }}>
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} variant="rectangular" height={36} sx={{ borderRadius: 1, mb: 0.75 }} />
        ))}
      </Box>
    );
  }

  return (
    <List disablePadding sx={{ pl: level > 0 ? 1.5 : 0 }}>
      {items.map((item) => (
        <SidebarMenuItem key={item.id} item={item} level={level} onNavigate={onNavigate} />
      ))}
    </List>
  );
}

interface SidebarMenuItemProps {
  item: MenuItem;
  level: number;
  onNavigate?: () => void;
}

function SidebarMenuItem({ item, level, onNavigate }: SidebarMenuItemProps) {
  const location = useLocation();
  const hasChildren = item.children && item.children.length > 0;
  const isActive = location.pathname === item.url;
  const isChildActive = hasChildren && item.children!.some((c) => isPathActive(location.pathname, c));

  const isSelfOrChildActive = isActive || Boolean(isChildActive);

  const [open, setOpen] = useState(isChildActive);

  // Auto-open parent when child route becomes active (e.g. direct navigation)
  useEffect(() => {
    if (isChildActive && !open) {
      setOpen(true);
    }
  }, [isChildActive]);

  const handleClick = () => {
    if (hasChildren) {
      setOpen((prev) => !prev);
    } else {
      onNavigate?.();
    }
  };

  // Icon slot is always 24x24 with an 8px gap to the label
  const iconSlotSx = {
    minWidth: 32, // 24px icon + 8px gap
    width: 32,
    mr: 0,
    color: 'inherit',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-start',
    '& > *': { width: 24, height: 24 },
  };

  // Determine icon: level 0 uses API icon, sub-levels use bullet dot
  const renderIcon = () => {
    if (level > 0) {
      return (
        <ListItemIcon sx={iconSlotSx}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <FiberManualRecordIcon sx={{ fontSize: 6 }} />
          </Box>
        </ListItemIcon>
      );
    }
    if (item.icon && item.icon.startsWith('http')) {
      return (
        <ListItemIcon sx={iconSlotSx}>
          <Box
            component="img"
            src={item.icon}
            alt=""
            sx={{ width: 24, height: 24, objectFit: 'contain', filter: 'brightness(10)' }}
          />
        </ListItemIcon>
      );
    }
    return null;
  };

  return (
    <>
      <ListItemButton
        component={hasChildren ? 'div' : Link}
        to={hasChildren ? undefined : item.url}
        onClick={handleClick}
        selected={isActive}
        sx={{
          borderRadius: 1,
          mb: 0.25,
          py: 0.75,
          pl: 1.5 + level * 1,
          color: '#fff',
          transition: 'background-color 150ms ease',
          '&:hover': { bgcolor: 'rgba(255,255,255,0.10)' },
          '&.Mui-selected': activeItemSx,
          '&.Mui-selected:hover': { bgcolor: 'rgba(255,255,255,0.26)' },
        }}
      >
        {renderIcon()}
        <ListItemText
          primary={item.name}
          slotProps={{
            primary: {
              sx: {
                fontSize: 14,
                fontWeight: isSelfOrChildActive ? 700 : 500,
                lineHeight: 1.4,
                wordBreak: 'break-word',
              },
            },
          }}
        />
        {hasChildren && (
          open
            ? <ExpandLess sx={{ fontSize: 18, transition: 'transform 250ms ease' }} />
            : <ExpandMore sx={{ fontSize: 18, transition: 'transform 250ms ease' }} />
        )}
      </ListItemButton>

      {hasChildren && (
        <Collapse in={open} timeout={250} unmountOnExit easing={{ enter: 'ease-out', exit: 'ease-in' }}>
          <SidebarMenu items={item.children!} level={level + 1} onNavigate={onNavigate} />
        </Collapse>
      )}
    </>
  );
}

function isPathActive(pathname: string, item: MenuItem): boolean {
  if (pathname === item.url) return true;
  if (item.children) return item.children.some((c) => isPathActive(pathname, c));
  return false;
}
