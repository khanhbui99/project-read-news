import TextField, { type TextFieldProps } from '@mui/material/TextField';
import Box from '@mui/material/Box';
import { forwardRef } from 'react';
import { AppLabel } from './Styled';

type AppTextFieldProps = Omit<TextFieldProps, 'label'> & {
  errorMessage?: string;
  label?: string;
  isLabelTop?: boolean;
};

export const AppTextField = forwardRef<HTMLDivElement, AppTextFieldProps>(
  ({ errorMessage, helperText, label, isLabelTop = true, required, ...props }, ref) => {
    if (isLabelTop && label) {
      return (
        <Box>
          <AppLabel required={required}>{label}</AppLabel>
          <TextField
            ref={ref}
            size="small"
            fullWidth
            error={!!errorMessage}
            helperText={errorMessage || helperText}
            required={required}
            {...props}
          />
        </Box>
      );
    }

    return (
      <TextField
        ref={ref}
        size="small"
        fullWidth
        label={label}
        error={!!errorMessage}
        helperText={errorMessage || helperText}
        required={required}
        {...props}
      />
    );
  },
);

AppTextField.displayName = 'AppTextField';
