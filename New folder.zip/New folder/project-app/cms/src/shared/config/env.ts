import { z } from 'zod';

const envSchema = z.object({
  VITE_API_BASE_URL: z.string().url(),
  VITE_APP_TITLE: z.string().default('CMS Admin'),
  VITE_APP_VERSION: z.string().default('1.0.0'),
  VITE_UPLOAD_MAX_SIZE: z.coerce.number().default(10485760),
  VITE_API_TIMEOUT: z.coerce.number().default(15000),
  VITE_TOKEN_KEY: z.string().default('IL_ADMIN_TOKEN'),
  VITE_REFRESH_TOKEN_KEY: z.string().default('IL_ADMIN_REFRESH_TOKEN'),
  VITE_BASE_PATH: z.string().default('/cms'),
});

const parsed = envSchema.safeParse(import.meta.env);

if (!parsed.success) {
  console.error('❌ Invalid environment variables:', parsed.error.flatten().fieldErrors);
  throw new Error('Invalid environment variables');
}

export const env = {
  apiBaseUrl: parsed.data.VITE_API_BASE_URL,
  apiTimeout: parsed.data.VITE_API_TIMEOUT,
  basePath: parsed.data.VITE_BASE_PATH,
  appTitle: parsed.data.VITE_APP_TITLE,
  appVersion: parsed.data.VITE_APP_VERSION,
  uploadMaxSize: parsed.data.VITE_UPLOAD_MAX_SIZE,
  tokenKey: parsed.data.VITE_TOKEN_KEY,
  refreshTokenKey: parsed.data.VITE_REFRESH_TOKEN_KEY,
  // Cờ môi trường (từ Vite): DEV hiện lỗi chi tiết để debug, PROD ẩn chi tiết.
  mode: import.meta.env.MODE,
  isDev: import.meta.env.DEV,
  isProd: import.meta.env.PROD,
} as const;
