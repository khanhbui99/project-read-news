import { useQuery } from '@tanstack/react-query';
import { fetchMenu, type MenuItemRaw, type MenuTab } from '@/shared/services/menuService';
import { useGlobalStore } from '@/shared/stores/globalStore';

export interface MenuItem {
  id: number;
  name: string;
  url: string;
  icon: string;
  hidden: boolean;
  component?: string;
  orders?: number;
  children?: MenuItem[];
}

function mapMenuItems(items: MenuItemRaw[]): MenuItem[] {
  return items
    .filter((item) => !item.hidden)
    .sort((a, b) => (a.orders ?? 0) - (b.orders ?? 0))
    .map((item) => ({
      id: item.id,
      name: item.name,
      url: item.url,
      icon: item.icon,
      hidden: item.hidden,
      component: item.component,
      orders: item.orders ?? 0,
      children: item.child && item.child.length > 0 ? mapMenuItems(item.child) : undefined,
    }));
}

export function useMenu() {
  const token = useGlobalStore((s) => s.token);
  const isAuthenticated = Boolean(token);

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['menu'],
    queryFn: fetchMenu,
    enabled: isAuthenticated, // only fetch after login
    retry: 3, // retry 3 times before failing
    retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 8000),
    staleTime: 5 * 60 * 1000,
  });

  const menuTabs: MenuTab[] = data?.data?.menuTab ?? [];
  const routerMap = data?.data?.router ?? {};

  // Get menu items for a specific tab value (e.g. "STUDENT")
  const getMenuByTab = (tabValue: string): MenuItem[] => {
    const rawItems = routerMap[tabValue] ?? [];
    return mapMenuItems(rawItems);
  };

  // Get all menu items across all tabs
  const getAllMenuItems = (): MenuItem[] => {
    const allItems = Object.values(routerMap).flat();
    return mapMenuItems(allItems);
  };

  return {
    menuTabs,
    routerMap,
    getMenuByTab,
    getAllMenuItems,
    isAuthenticated,
    isLoading,
    isError,
    error,
    refetch,
  };
}
