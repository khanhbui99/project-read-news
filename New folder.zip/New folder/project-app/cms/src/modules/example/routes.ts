import type { ComponentType } from 'react';

/**
 * Route-map của module example: tên component (do API menu trả về) → lazy import.
 * Registry trung tâm chỉ cần spread map này, không phải khai từng dòng thủ công.
 */
export const exampleRoutes: Record<string, () => Promise<{ default: ComponentType }>> = {
  Dashboard: () => import('./pages/DashboardPage'),
  StandardCodeFacility: () => import('./pages/StandardCodePage'),
};
