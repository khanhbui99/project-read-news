import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

export default function DashboardPage() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={700}>Dashboard</Typography>
      <Typography variant="body2" color="text.secondary" mt={1}>
        Trang tổng quan — đang phát triển.
      </Typography>
    </Box>
  );
}
