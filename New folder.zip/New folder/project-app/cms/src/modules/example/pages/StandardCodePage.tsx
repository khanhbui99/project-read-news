import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

export default function StandardCodePage() {
  return (
    <Box>
      <Typography variant="h5" fontWeight={700}>Danh mục tài sản</Typography>
      <Typography variant="body2" color="text.secondary" mt={1}>
        Module StandardCodeFacility — đang phát triển.
      </Typography>
    </Box>
  );
}
