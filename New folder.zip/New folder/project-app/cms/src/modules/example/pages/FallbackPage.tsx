import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import ConstructionIcon from '@mui/icons-material/Construction';

export default function FallbackPage() {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: 400, gap: 2 }}>
      <ConstructionIcon sx={{ fontSize: 48, color: 'text.disabled' }} />
      <Typography variant="h6" color="text.secondary">
        Trang này đang được phát triển
      </Typography>
      <Typography variant="body2" color="text.disabled">
        Component chưa được đăng ký trong hệ thống.
      </Typography>
    </Box>
  );
}
