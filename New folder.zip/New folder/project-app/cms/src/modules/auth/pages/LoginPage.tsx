import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { AuthBrandPanel } from '../components/AuthBrandPanel';
import { LoginForm } from '../components/LoginForm';
import { useLogin } from '../hooks/useLogin';

export default function LoginPage() {
  const { control, errors, isSubmitting, submitError, onSubmit } = useLogin();

  return (
    <Box
      sx={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        p: { xs: 2, md: 4 },
        background: 'linear-gradient(135deg, #cfeffb 0%, #7ec8e8 100%)',
      }}
    >
      <Paper
        elevation={0}
        sx={{
          width: '100%',
          maxWidth: 900,
          display: 'flex',
          borderRadius: 3,
          overflow: 'hidden',
          boxShadow: '0 20px 60px rgba(0,0,0,0.15)',
        }}
      >
        <AuthBrandPanel />
        <LoginForm
          control={control}
          errors={errors}
          isSubmitting={isSubmitting}
          submitError={submitError}
          onSubmit={onSubmit}
        />
      </Paper>
    </Box>
  );
}
