import apiClient from '@/shared/services/apiClient';
import type { StoredUser, ActiveOrg } from '@/shared/services/storageService';
import { apiUrl } from '@/shared/services/apiUrl';
import { handleApiError } from '@/shared/services/handleApiError';
import { decodeJwt } from '@/shared/utils/jwt';

export interface LoginPayload {
  email: string;
  password: string;
}

export interface OrgChart {
  id: string | number;
  name: string;
  roleName?: string;
  orgName?: string;
  avatar?: string;
}

export interface LoginResult {
  token: string;
  refreshToken?: string;
  user?: StoredUser;
  orgCharts: OrgChart[];
  activeOrg?: ActiveOrg;
}

interface JwtClaims {
  sub?: string;
  id?: string | number;
  name?: string;
  fullName?: string;
  email?: string;
  username?: string;
  avatar?: string;
  role?: string;
}

interface OrgChartApi {
  id?: string | number;
  name?: string;
  roleName?: string;
  role?: string;
  orgName?: string;
  organizationName?: string;
  avatar?: string;
}

interface LoginApiResponse {
  data?: {
    token?: string;
    accessToken?: string;
    refreshToken?: string;
    user?: Record<string, unknown>;
    account?: Record<string, unknown>;
    orgCharts?: OrgChartApi[];
    orgChart?: OrgChartApi[];
  };
  meta?: { code?: string };
}

function mapOrgCharts(list: OrgChartApi[] | undefined): OrgChart[] {
  if (!Array.isArray(list)) return [];
  return list.map((o) => ({
    id: o.id ?? '',
    name: o.name ?? o.roleName ?? o.role ?? '',
    roleName: o.roleName ?? o.role,
    orgName: o.orgName ?? o.organizationName,
    avatar: o.avatar,
  }));
}

export async function loginRequest(payload: LoginPayload): Promise<LoginResult> {
  try {
    const { data } = await apiClient.post<LoginApiResponse>(apiUrl.orgChart.login, payload);

    const token = data?.data?.token ?? data?.data?.accessToken;
    if (!token) {
      throw new Error('Đăng nhập thất bại: không nhận được token.');
    }

    // Store the FULL user object from the response (no info lost).
    // Fall back to JWT claims if the response has no user object.
    const rawUser = data?.data?.user ?? data?.data?.account;
    const claims = decodeJwt<JwtClaims>(token) ?? {};

    const user: StoredUser | undefined = rawUser
      ? (rawUser as StoredUser)
      : Object.keys(claims).length
        ? {
            id: String(claims.sub ?? claims.id ?? ''),
            name: claims.name ?? claims.fullName ?? claims.username ?? payload.email,
            email: claims.email ?? payload.email,
            role: claims.role ?? 'Admin',
            avatar: claims.avatar,
          }
        : undefined;

    const orgCharts = mapOrgCharts(data?.data?.orgCharts ?? data?.data?.orgChart);

    // Default to the first org chart
    const first = orgCharts[0];
    const activeOrg: ActiveOrg | undefined = first
      ? { id: first.id, name: first.name, roleName: first.roleName, orgName: first.orgName }
      : undefined;

    return {
      token,
      refreshToken: data?.data?.refreshToken,
      user,
      orgCharts,
      activeOrg,
    };
  } catch (error) {
    // silent: lỗi đăng nhập hiển thị inline trong form (useLogin), tránh báo trùng
    throw handleApiError(error, 'Đăng nhập', { silent: true });
  }
}
