import { useState } from 'react';
import { Controller, type Control, type FieldErrors } from 'react-hook-form';
import Box from '@mui/material/Box';
import Alert from '@mui/material/Alert';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import VisibilityIcon from '@mui/icons-material/VisibilityOutlined';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOffOutlined';
import LoginIcon from '@mui/icons-material/Login';
import { AppTextField } from '@/shared/components/AppTextField';
import { AppButton } from '@/shared/components/AppButton';
import { AppTitle, AppText } from '@/shared/components/Styled';
import type { LoginFormValues } from '@/modules/auth/validation';

interface LoginFormProps {
  control: Control<LoginFormValues>;
  errors: FieldErrors<LoginFormValues>;
  isSubmitting: boolean;
  submitError: string | null;
  onSubmit: () => void;
}

/** Right form panel of the login screen */
export function LoginForm({ control, errors, isSubmitting, submitError, onSubmit }: LoginFormProps) {
  const [showPassword, setShowPassword] = useState(false);
console.log('render')
  return (
    <Box
      sx={{
        flex: 1,
        p: { xs: 4, md: 6 },
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
      }}
    >
      <AppTitle size="2xl">Đăng nhập</AppTitle>
      <AppText size="sm" color="secondary" sx={{ mt: 1, mb: 4 }}>
        Chào mừng trở lại! Vui lòng đăng nhập để tiếp tục.
      </AppText>

      {submitError && (
        <Alert severity="error" sx={{ mb: 2, fontSize: 14 }}>
          {submitError}
        </Alert>
      )}

      <Box
        component="form"
        onSubmit={(e) => {
          e.preventDefault();
          onSubmit();
        }}
        sx={{ display: 'flex', flexDirection: 'column', gap: 2.5 }}
      >
        <Controller
          name="email"
          control={control}
          render={({ field }) => (
            <AppTextField
              {...field}
              label="Tên đăng nhập"
              placeholder="Nhập tên đăng nhập"
              isLabelTop
              required
              autoComplete="username"
              errorMessage={errors.email?.message}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <PersonOutlineIcon sx={{ fontSize: 20, color: 'text.disabled' }} />
                    </InputAdornment>
                  ),
                },
              }}
            />
          )}
        />

        <Controller
          name="password"
          control={control}
          render={({ field }) => (
            <AppTextField
              {...field}
              type={showPassword ? 'text' : 'password'}
              label="Mật khẩu"
              placeholder="Nhập mật khẩu"
              isLabelTop
              required
              autoComplete="current-password"
              errorMessage={errors.password?.message}
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockOutlinedIcon sx={{ fontSize: 20, color: 'text.disabled' }} />
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        aria-label={showPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'}
                        onClick={() => setShowPassword((prev) => !prev)}
                      >
                        {showPassword ? (
                          <VisibilityOffIcon sx={{ fontSize: 18 }} />
                        ) : (
                          <VisibilityIcon sx={{ fontSize: 18 }} />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
            />
          )}
        />

        <AppButton
          type="submit"
          variant="contained"
          size="large"
          disabled={isSubmitting}
          fullWidth
          startIcon={<LoginIcon />}
          sx={{ mt: 1, py: 1.25 }}
        >
          {isSubmitting ? 'Đang đăng nhập...' : 'Đăng nhập'}
        </AppButton>
      </Box>
    </Box>
  );
}
