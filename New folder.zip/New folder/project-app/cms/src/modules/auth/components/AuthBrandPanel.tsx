import Box from '@mui/material/Box';
import SchoolIcon from '@mui/icons-material/School';
import { AppTitle, AppText } from '@/shared/components/Styled';
import { AUTH_FEATURES, BRAND } from '../constants';

/** Left brand panel of the login screen (hidden on mobile) */
export function AuthBrandPanel() {
  return (
    <Box
      sx={{
        flex: 1,
        display: { xs: 'none', md: 'flex' },
        flexDirection: 'column',
        p: 5,
        color: '#fff',
        background: (theme) =>
          `linear-gradient(160deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
      }}
    >
      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 4 }}>
        <Box
          sx={{
            width: 72,
            height: 72,
            borderRadius: 3,
            bgcolor: '#fff',
            color: 'primary.main',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            mb: 2,
          }}
        >
          <SchoolIcon sx={{ fontSize: 40 }} />
        </Box>
        <AppTitle size="2xl" color="white" align="center">
          {BRAND.name}
        </AppTitle>
        <AppText size="sm" color="white" align="center" sx={{ mt: 1, opacity: 0.9 }}>
          {BRAND.subtitle1}
        </AppText>
        <AppText size="sm" color="white" align="center" sx={{ opacity: 0.9 }}>
          {BRAND.subtitle2}
        </AppText>
      </Box>

      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mt: 'auto' }}>
        {AUTH_FEATURES.map((f) => (
          <Box key={f.title} sx={{ display: 'flex', gap: 1.5 }}>
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: 2,
                bgcolor: 'rgba(255,255,255,0.15)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              {f.icon}
            </Box>
            <Box>
              <AppText size="md" weight="semibold" color="white">
                {f.title}
              </AppText>
              <AppText size="sm" color="white" sx={{ opacity: 0.85 }}>
                {f.desc}
              </AppText>
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
}
