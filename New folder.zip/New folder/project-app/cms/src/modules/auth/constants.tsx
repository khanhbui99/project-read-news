import VerifiedUserIcon from '@mui/icons-material/VerifiedUserOutlined';
import TrendingUpIcon from '@mui/icons-material/TrendingUpOutlined';
import EmojiObjectsIcon from '@mui/icons-material/EmojiObjectsOutlined';
import InsightsIcon from '@mui/icons-material/InsightsOutlined';

export interface AuthFeature {
  icon: React.ReactNode;
  title: string;
  desc: string;
}

export const AUTH_FEATURES: AuthFeature[] = [
  {
    icon: <VerifiedUserIcon sx={{ fontSize: 22 }} />,
    title: 'Quản lý trường học toàn diện',
    desc: 'Số hóa mọi quy trình quản trị từ hành chính đến học vụ',
  },
  {
    icon: <TrendingUpIcon sx={{ fontSize: 22 }} />,
    title: 'Nâng cao chất lượng học sinh',
    desc: 'Theo dõi, phân tích và cải thiện kết quả học tập liên tục',
  },
  {
    icon: <EmojiObjectsIcon sx={{ fontSize: 22 }} />,
    title: 'Phát triển giáo dục toàn diện',
    desc: 'Hỗ trợ giảng dạy hiện đại, phương pháp sư phạm tiên tiến',
  },
  {
    icon: <InsightsIcon sx={{ fontSize: 22 }} />,
    title: 'Đánh giá & Báo cáo thông minh',
    desc: 'Dữ liệu thời gian thực, báo cáo chi tiết, ra quyết định chính xác',
  },
];

export const BRAND = {
  name: 'THCS CẦU GIẤY',
  subtitle1: 'Hệ Thống Quản Trị',
  subtitle2: 'Trường Học Số - Cầu Giấy Digital School',
};
