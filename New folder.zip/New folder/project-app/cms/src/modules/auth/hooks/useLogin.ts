import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useGlobalStore } from '@/shared/stores/globalStore';
import { authStorage } from '@/shared/services/storageService';
import { loginSchema, type LoginFormValues } from '@/modules/auth/validation';
import { loginRequest } from '@/modules/auth/service';

/** Encapsulates login form state + submit logic */
export function useLogin() {
  const navigate = useNavigate();
  const setToken = useGlobalStore((s) => s.setToken);
  const setUser = useGlobalStore((s) => s.setUser);
  const setOrgCharts = useGlobalStore((s) => s.setOrgCharts);
  const setActiveOrg = useGlobalStore((s) => s.setActiveOrg);

  const [submitError, setSubmitError] = useState<string | null>(null);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  const onSubmit = form.handleSubmit(async (values) => {
    setSubmitError(null);
    try {
      const result = await loginRequest({ email: values.email, password: values.password });

      setToken(result.token);
      if (result.refreshToken) authStorage.setRefreshToken(result.refreshToken);
      if (result.user) setUser(result.user);

      setOrgCharts(result.orgCharts);

      // Keep the previously chosen org if it's still valid; otherwise default to first.
      const stored = authStorage.getActiveOrg();
      const storedStillValid =
        stored && result.orgCharts.some((o) => String(o.id) === String(stored.id));
      const nextActive = storedStillValid ? stored : result.activeOrg;
      if (nextActive) setActiveOrg(nextActive);

      navigate('/', { replace: true });
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Đăng nhập thất bại. Vui lòng thử lại.');
    }
  });

  return {
    control: form.control,
    errors: form.formState.errors,
    isSubmitting: form.formState.isSubmitting,
    submitError,
    onSubmit,
  };
}
