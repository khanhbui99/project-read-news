import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGlobalStore } from '@/shared/stores/globalStore';
import { PATHS } from '@/routers/paths';
import { env } from '@/shared/config/env';

/**
 * Đăng xuất dùng chung: clear auth state + điều hướng về trang login.
 * Dùng ở mọi nơi cần logout (header menu, interceptor 401, nút đăng xuất...).
 */
export function useLogout() {
  const navigate = useNavigate();
  const clearAuth = useGlobalStore((s) => s.logout);

  return useCallback(() => {
    clearAuth();
    navigate(`${env.basePath}${PATHS.LOGIN}`, { replace: true });
  }, [clearAuth, navigate]);
}
