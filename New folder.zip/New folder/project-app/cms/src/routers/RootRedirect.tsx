import { Navigate } from 'react-router-dom';
import { useMenu } from '@/shared/hooks/useMenu';
import { findFirstLeafUrl } from './menuResolver';
import { PATHS } from './paths';

/** Điều hướng "/" tới URL menu lá đầu tiên có sẵn */
export function RootRedirect() {
  const { getAllMenuItems } = useMenu();
  const firstUrl = findFirstLeafUrl(getAllMenuItems());

  // Không có menu hợp lệ hoặc trùng ROOT → không điều hướng (tránh vòng lặp)
  if (!firstUrl || firstUrl === PATHS.ROOT) {
    return null;
  }

  return <Navigate to={firstUrl} replace />;
}
