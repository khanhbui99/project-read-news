import { Suspense, lazy, type ComponentType } from 'react';
import { PageLoader } from './PageLoader';
import { CHUNK_RELOAD_FLAG } from './constants';

/**
 * Import một module lazy có retry.
 * Nếu không tải được chunk (thường xảy ra sau khi deploy đổi tên file hash),
 * force hard reload 1 lần để trình duyệt lấy asset mới. Cờ CHUNK_RELOAD_FLAG
 * chặn vòng lặp reload vô hạn.
 */
async function importWithRetry<T>(
  factory: () => Promise<T>,
  retries = 3,
  delay = 500,
): Promise<T> {
  try {
    const mod = await factory();
    // Thành công → xóa cờ reload cho các lần điều hướng sau
    sessionStorage.removeItem(CHUNK_RELOAD_FLAG);
    return mod;
  } catch (err) {
    // Còn lượt → chờ rồi thử lại (backoff nhân đôi)
    if (retries > 0) {
      await new Promise((resolve) => setTimeout(resolve, delay));
      return importWithRetry(factory, retries - 1, delay * 2);
    }

    // Hết lượt — nhiều khả năng chunk cũ sau redeploy → thử reload 1 lần
    const alreadyReloaded = sessionStorage.getItem(CHUNK_RELOAD_FLAG);
    if (!alreadyReloaded) {
      sessionStorage.setItem(CHUNK_RELOAD_FLAG, '1');
      window.location.reload();
      // Trả promise không bao giờ resolve để không render gì trước khi reload
      return new Promise<T>(() => {});
    }

    // Đã reload mà vẫn lỗi → đẩy lên ErrorBoundary xử lý
    throw err;
  }
}

/** Bọc 1 factory import thành phần tử lazy + Suspense với loader chung */
export function lazyLoad(factory: () => Promise<{ default: ComponentType }>) {
  const LazyComponent = lazy(() => importWithRetry(factory));
  return (
    <Suspense fallback={<PageLoader />}>
      <LazyComponent />
    </Suspense>
  );
}
