/**
 * Hằng số đường dẫn tĩnh (không phụ thuộc menu động).
 * Route động của các module resolve qua DynamicPage + registry.
 */
export const PATHS = {
  LOGIN: '/auth/login',
  ROOT: '/',
} as const;
