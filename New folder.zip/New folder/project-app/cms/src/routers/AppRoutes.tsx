import { useMemo, Suspense, lazy } from 'react';
import { useRoutes, type RouteObject } from 'react-router-dom';
import { useMenu } from '@/shared/hooks/useMenu';
import { PageLoader } from './PageLoader';
import { buildRoutesFromMenu } from './menuResolver';
import { fallbackFactory } from './registry';

// Trang fallback 404 (lazy, tạo 1 lần ngoài component)
const FallbackPage = lazy(fallbackFactory);

/**
 * Render toàn bộ route ĐƯỢC MAP TỪ MENU (thay cho việc dò theo pathname).
 * - Chỉ item có component hợp lệ mới được đưa vào route (xem buildRoutesFromMenu).
 * - Path không khớp route nào → catch-all '*' hiện FallbackPage (404).
 * useMemo để chỉ build lại danh sách route khi cây menu thay đổi.
 */
export function AppRoutes() {
  const { getAllMenuItems } = useMenu();
  const items = getAllMenuItems();

  const routes: RouteObject[] = useMemo(() => {
    const menuRoutes = buildRoutesFromMenu(items);
    // Catch-all cuối danh sách cho các path không khớp (404 thật)
    return [...menuRoutes, { path: '*', element: <FallbackPage /> }];
  }, [items]);

  const element = useRoutes(routes);

  return <Suspense fallback={<PageLoader />}>{element}</Suspense>;
}
