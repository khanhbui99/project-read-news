import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';

/**
 * Loader dùng chung cho mọi trường hợp lazy-load trang (Suspense fallback).
 * Tách riêng để không lặp lại ở `lazyLoad` và `DynamicPage`.
 */
export function PageLoader() {
  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 300 }}>
      <CircularProgress />
    </Box>
  );
}
