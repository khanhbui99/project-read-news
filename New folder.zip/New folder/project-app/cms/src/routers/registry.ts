import type { ComponentType } from 'react';
import { exampleRoutes } from '@/modules/example/routes';
import { chatRoutes } from '@/modules/chat/routes';

/**
 * Registry ánh xạ TÊN component (do API menu trả về) → hàm lazy import trang.
 * Mỗi module tự khai route-map của mình trong `modules/{name}/routes.ts`;
 * ở đây chỉ SPREAD lại — thêm module mới chỉ cần import + spread 1 dòng.
 * LƯU Ý: tên component (API) không có trong registry sẽ KHÔNG được init route.
 */
export const componentRegistry: Record<string, () => Promise<{ default: ComponentType }>> = {
  ...exampleRoutes,
  ...chatRoutes,
};

/** Trang fallback cho 404 (path không khớp route nào đã init) */
export const fallbackFactory = () => import('@/modules/example/pages/FallbackPage');
