import { Navigate, useLocation } from 'react-router-dom';
import { useMenu } from '@/shared/hooks/useMenu';
import { useLogout } from '@/modules/auth/hooks/useLogout';
import { LayoutSkeleton } from '@/shared/components/LayoutSkeleton';
import { MenuErrorScreen } from '@/shared/components/MenuErrorScreen';
import { AdminLayout } from '@/layouts/AdminLayout';
import { PATHS } from './paths';

/**
 * Guard khu vực admin:
 * - Chưa đăng nhập → redirect /login
 * - Menu đang tải → skeleton
 * - Menu lỗi (sau retry) → màn hình lỗi
 * - Menu sẵn sàng → AdminLayout (tự render <Outlet /> cho route con)
 */
export function AuthGate() {
  const location = useLocation();
  const { isAuthenticated, isLoading, isError, refetch } = useMenu();
  const logout = useLogout();

  if (!isAuthenticated) {
    return <Navigate to={PATHS.LOGIN} replace state={{ from: location.pathname }} />;
  }

  if (isError) {
    return <MenuErrorScreen onRetry={() => refetch()} onLogout={logout} />;
  }

  if (isLoading) {
    return <LayoutSkeleton />;
  }

  // AdminLayout tự render <Outlet /> cho route con đã match
  return <AdminLayout />;
}
