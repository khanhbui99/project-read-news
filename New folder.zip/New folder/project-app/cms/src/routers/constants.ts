/**
 * Cờ (sessionStorage) chống reload vô hạn khi tải chunk thất bại.
 * Dùng chung giữa `lazyLoad` (khi retry hết) và `AppErrorBoundary` (khi bắt lỗi chunk)
 * để tránh magic string rải rác nhiều nơi.
 */
export const CHUNK_RELOAD_FLAG = 'cms_chunk_reloaded';
