import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { NormalLayout } from '@/layouts/NormalLayout';
import { env } from '@/shared/config/env';
import { AuthGate } from './AuthGate';
import { AppRoutes } from './AppRoutes';
import { RootRedirect } from './RootRedirect';
import { lazyLoad } from './lazyLoad';
import { PATHS } from './paths';

// Lazy import trang login (public)
const loginFactory = () => import('@/modules/auth/pages/LoginPage');

/**
 * Router ổn định duy nhất (tạo 1 lần):
 * - PATHS.LOGIN → public (NormalLayout)
 * - còn lại → AuthGate (redirect /login nếu chưa auth; skeleton khi tải menu;
 *   màn hình lỗi khi thất bại; ngược lại AdminLayout + nội dung động).
 * basename lấy từ env.basePath để đồng bộ với cấu hình môi trường (không hardcode).
 */
const router = createBrowserRouter(
  [
    {
      element: <NormalLayout />,
      children: [{ path: PATHS.LOGIN, element: lazyLoad(loginFactory) }],
    },
    {
      element: <AuthGate />,
      children: [
        { path: PATHS.ROOT, element: <RootRedirect /> },
        // '*' → AppRoutes: map toàn bộ route hợp lệ từ menu + fallback 404
        { path: '*', element: <AppRoutes /> },
      ],
    },
  ],
  { basename: env.basePath },
);

export function AppRouterProvider() {
  return <RouterProvider router={router} />;
}

export { lazyLoad } from './lazyLoad';
export { PATHS } from './paths';
