import { lazy, type ComponentType, type LazyExoticComponent, type ReactElement, createElement } from 'react';
import type { RouteObject } from 'react-router-dom';
import type { MenuItem } from '@/shared/hooks/useMenu';
import { env } from '@/shared/config/env';
import { componentRegistry } from './registry';

/**
 * Đào vào children để lấy URL của menu lá đầu tiên (dùng cho redirect từ '/').
 * @returns url lá đầu tiên, hoặc null nếu menu rỗng.
 */
export function findFirstLeafUrl(items: MenuItem[]): string | null {
  const first = items[0];
  if (!first) return null;
  if (first.children && first.children.length > 0) return findFirstLeafUrl(first.children);
  return first.url || null;
}

// Cache component lazy theo tên để cùng 1 trang không bị tạo lại nhiều lần
const lazyCache = new Map<string, LazyExoticComponent<ComponentType>>();

/** Lấy (hoặc tạo + cache) component lazy theo tên từ registry */
function getLazyElement(componentName: string): ReactElement {
  if (!lazyCache.has(componentName)) {
    lazyCache.set(componentName, lazy(componentRegistry[componentName]));
  }
  // key theo tên để React remount đúng khi đổi trang
  return createElement(lazyCache.get(componentName)!, { key: componentName });
}

/**
 * Build danh sách route TỪ cây menu.
 * LƯU Ý QUAN TRỌNG: chỉ item có `component` VÀ component đó tồn tại trong registry
 * mới được init thành route. Item không có component (hoặc chưa đăng ký) → BỎ QUA,
 * KHÔNG đưa vào router (tránh tạo route rỗng / trỏ tới trang không tồn tại).
 * Duyệt đệ quy cả children (menu cha thường chỉ là nhóm, không có trang).
 */
export function buildRoutesFromMenu(items: MenuItem[]): RouteObject[] {
  const routes: RouteObject[] = [];

  for (const item of items) {
    const canRegister = Boolean(item.url) && Boolean(item.component) && item.component! in componentRegistry;

    if (canRegister) {
      routes.push({ path: item.url, element: getLazyElement(item.component!) });
    } else if (env.isDev && item.url && item.component) {
      // DEV: cảnh báo item menu có trang nhưng component chưa đăng ký trong registry
      // → giúp phát hiện sai/thiếu tên component để thêm vào registry.ts
      console.warn(
        `[router] Menu item "${item.name}" (url=${item.url}) có component="${item.component}" ` +
          `nhưng CHƯA đăng ký trong componentRegistry → route bị bỏ qua.`,
      );
    }

    // Đệ quy children — route được làm phẳng theo url tuyệt đối do menu trả về url đầy đủ
    if (item.children && item.children.length > 0) {
      routes.push(...buildRoutesFromMenu(item.children));
    }
  }

  return routes;
}
