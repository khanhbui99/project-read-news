import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './app/App';
import { env } from '@/shared/config/env';

// Set document title from environment (per-environment app name)
document.title = env.appTitle;

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
