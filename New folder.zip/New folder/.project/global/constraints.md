# Global Constraints

## Business
- Never invent business requirements.
- API contracts shared between platforms — changes need approval.
- Permission/role logic must be consistent across platforms.

## Architecture
- No new architecture for one task.
- No alternative state management without approval.
- No direct API calls from presentation components.
- No duplicated business logic.

## Workflow
- Every task declares target: `web`, `mobile`, or `both`.
- Task `web` → only modify `web/` source.
- Task `mobile` → only modify `mobile/` source.
- Task `both` → may modify both, ensure sync.
- UI/UX may improve HOW, never change WHAT.
- Only Final Gate can declare DONE.
