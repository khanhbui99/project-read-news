# AI Workflow Definition

## Two Execution Modes

### Mode 1 — Automatic (/work)
```
User Request → /work → Task Agent → task.md (DRAFT) → User Approval (APPROVED) → Router → Execute
```
- task_assessment = true
- approval_required = true
- NO APPROVAL = NO IMPLEMENTATION

### Mode 2 — Direct Command (/ui, /logic, /task, /feature, /module)
```
/command <requirement> → Execute Level Workflow directly
```
- task_assessment = false
- approval_required = false
- forced_level = command level
- Skip Task Agent, skip task.md, skip approval

## Command → Level Mapping
| Command | Level | Workflow |
|---------|-------|----------|
| /ui | L1 | UI/UX → Check → Done |
| /logic | L2 | Logic → Test → Done |
| /task | L3 | Req → Logic + UI/UX → QA → Done |
| /feature | L4 | Req → Plan Review → Logic + UI/UX → QA → Final Gate |
| /module | L5 | Module Plan → Review → L4s → QA → Final Gate |

## Rules
- Do NOT mix modes
- Direct commands: no reclassification, no task agent, no approval
- If direct command impossible due to missing info → STOP and report
- Automatic mode: scope change → NEEDS_REVIEW → wait user

## Status Values
- DRAFT: Task assessed, awaiting user approval
- APPROVED: User approved, workflow may execute
- IN_PROGRESS: Implementation underway
- NEEDS_REVIEW: Scope changed, awaiting user re-approval
- BLOCKED: Cannot proceed, issue reported
- PASS: Successfully completed
- FAIL: Did not pass Final Gate

## Task History
Completed tasks archived to: `.workflow/tasks/<TASK-ID>/`

## Retry Limits
- Total iterations: 8
- Same failure: 2
- On exceed: BLOCKED

## Scope Protection
If scope changes during implementation:
STOP → NEEDS_REVIEW → wait user
