# Product Manifest (Global)

## Product
THCS Cầu Giấy — School Management App

## Platforms
- Web (React + styled-components)
- CMS (React + MUI)
- Mobile (Flutter)

## Business Domain
Education management system for THCS Cầu Giấy middle school.

## API
REST — shared API contracts between Web and Mobile.

## Theme / Branding
Primary color: Ocean Blue (#0077B6)

## Environments
- development
- staging
- production

## Architecture Principle
Module-based (modules/ + shared/).
Each platform implements independently but shares:
- API contracts
- Business rules
- Data types (conceptually equivalent)
- i18n translations (same keys)

## Global Constraints
- No unauthorized dependency.
- No unauthorized architecture change.
- No API contract change without approval.
- No business-rule invention.
- Reuse existing components/services.
- When task targets `both`: types and API contracts must stay in sync.
