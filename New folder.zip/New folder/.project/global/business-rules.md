# Business Rules

## Product
THCS Cầu Giấy — School Management App

## Core Business Rules

1. User authentication is required for protected features.
2. Role-based access: Student, Teacher, Parent, Admin.
3. Notifications must be delivered to both web and mobile.
4. Messages are private between participants.
5. Academic data is read-only for Students and Parents.
6. Admin has full CRUD on all entities.

## Data Rules
- Student/Teacher/Parent are linked by class/school.
- All timestamps in UTC, display in local timezone.
- Soft delete for critical data (never hard delete).

## Permission Model
- Authenticated users only access their own data + shared resources.
- Admin can impersonate for support.
- API enforces permission server-side (client only hides UI).

## Business Constraints
- Never invent new business rules during implementation.
- Business rules are the same across web and mobile.
- If a rule is unclear, Requirement Planner must clarify with user.
