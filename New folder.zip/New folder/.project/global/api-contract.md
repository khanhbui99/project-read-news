# API Contract

## Base URL
- Development: `http://localhost:8080/api`
- Staging: `https://staging-api.thcscaugiay.edu.vn/api`
- Production: `https://api.thcscaugiay.edu.vn/api`

## Authentication
- Bearer token in Authorization header.
- Refresh token flow: POST /auth/refresh.
- 401 response → attempt refresh → retry original request.
- If refresh fails → logout.

## Response Format
```json
{
  "data": <T>,
  "message": "string (optional)",
  "success": true
}
```

## Error Format
```json
{
  "message": "Error description",
  "errors": { "field": ["error message"] },
  "statusCode": 422
}
```

## Common Status Codes
- 200: Success
- 201: Created
- 401: Unauthorized (token expired/invalid)
- 403: Forbidden (no permission)
- 404: Not found
- 422: Validation error (field-level)
- 500: Server error

## Pagination
```json
{
  "data": [...],
  "total": 100,
  "page": 1,
  "pageSize": 20,
  "totalPages": 5
}
```

## Contract Rules
- API contracts are shared between web and mobile.
- Changes require approval from both platforms.
- Client never modifies API contracts unilaterally.
- Both platforms must use the same endpoint paths and response shapes.
