# CMS Dependencies

Root: `project-app/cms/` — `package.json`

## Runtime
| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.1.0 | UI framework |
| react-dom | ^19.1.0 | DOM rendering |
| react-router-dom | ^7.1.0 | SPA routing (basename `/cms`) |
| @mui/material | ^7.1.0 | UI components |
| @mui/icons-material | ^7.1.0 | Icons |
| @mui/x-data-grid | ^8.0.0 | Data tables |
| @mui/x-date-pickers | ^8.0.0 | Date/time pickers |
| @emotion/react | ^11.14.0 | CSS-in-JS (MUI dep) |
| @emotion/styled | ^11.14.0 | Styled (MUI dep) |
| @tanstack/react-query | ^5.62.0 | Server state |
| react-hook-form | ^7.54.0 | Form state |
| @hookform/resolvers | ^3.10.0 | Zod resolver |
| zod | ^3.24.0 | Schema validation |
| axios | ^1.7.9 | HTTP client |
| dayjs | ^1.11.13 | Date utility |
| zustand | ^5.0.0 | Client state |

## Dev
| Package | Version | Purpose |
|---------|---------|---------|
| vite | ^6.0.0 | Build tool |
| typescript | ^5.7.0 | Type checking |
| @types/react | ^19.0.0 | React types |
| @types/react-dom | ^19.0.0 | ReactDOM types |
| @vitejs/plugin-react | ^4.3.4 | Vite React plugin |

## Scripts
| Script | Command |
|--------|---------|
| dev | `vite --mode development` |
| dev:staging | `vite --mode staging` |
| build | `tsc && vite build --mode production` |
| build:staging | `tsc && vite build --mode staging` |
| build:dev | `tsc && vite build --mode development` |
| preview | `vite preview` |
| typecheck | `tsc --noEmit` |

## Rules
- No styled-components (use MUI `sx` / `styled`)
- No additional UI library beyond MUI
- Custom HTML only for checkbox (`AppCheckbox`)
- Font SVN_Gilroy self-hosted in `public/fonts/`
