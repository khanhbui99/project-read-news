# Kiến trúc CMS

Thư mục gốc: `project-app/cms/`

## Tổng quan
Trang quản trị React độc lập, tách riêng khỏi `project-app/web/`.
Chạy dưới base path `/cms`.

## Công nghệ
- React 19 + TypeScript (strict)
- MUI (Material UI) v7 — toàn bộ shared components
- MUI X DataGrid / DatePickers v8
- TanStack Query v5 — server state
- React Hook Form + Zod — form + validation
- Zustand v5 — client state
- react-router-dom v7 — routing (basename `/cms`)
- Axios — HTTP client
- Vite 6 — build tool
- Font: SVN_Gilroy (self-host trong `public/fonts/`)

## Theme
- Màu chủ đạo: `#006494`
- Cỡ chữ mặc định: 14
- Sidebar: nền màu chủ đạo, chữ trắng
- Header + content: nền trắng, header có shadow nhẹ

## Luồng Auth & khởi tạo
1. `main.tsx` → `App.tsx` (ErrorBoundary → Providers → Router + overlay global)
2. Router là **một instance ổn định** (không tạo lại), gồm:
   - `/login` → `NormalLayout` (public)
   - `*` → `AuthGate`
3. `AuthGate`:
   - Chưa có token → redirect `/login`
   - Menu đang tải → `LayoutSkeleton`
   - Menu lỗi sau 3 lần retry → `MenuErrorScreen` (thử lại / đăng xuất)
   - Sẵn sàng → `AdminLayout` (render `<Outlet />`)
4. Đăng nhập → giải mã JWT / đọc user object → lưu full user + orgCharts + activeOrg
5. Menu chỉ gọi sau khi đăng nhập (`enabled: isAuthenticated`)
6. Đăng xuất dùng chung qua hook `useLogout` (`modules/auth`) — clear auth state + điều hướng `PATHS.LOGIN`; dùng ở mọi nơi (header menu, xử lý 401...)

## Routing động
Menu lấy từ API (cây n cấp). Toàn bộ route được MAP TRƯỚC từ menu (không dò theo pathname). `src/routers/` tách nhỏ theo trách nhiệm để dễ maintain:
- `index.tsx` — định nghĩa router tree + `RouterProvider`, `basename = env.basePath`
- `registry.ts` — gom route-map của các module bằng spread (`...exampleRoutes`, `...chatRoutes`); mỗi module tự khai `modules/{name}/routes.ts` (tên component API → lazy import)
- `menuResolver.ts` — `buildRoutesFromMenu` (build danh sách route từ cây menu, có cache lazy) + `findFirstLeafUrl`
- `AppRoutes` — build toàn bộ route từ menu qua `useRoutes`; path không khớp → fallback 404 (`*`)
- `RootRedirect` — `/` → menu lá đầu tiên
- `lazyLoad` — retry 3 lần rồi force reload 1 lần (chunk cũ sau deploy); dùng cờ `CHUNK_RELOAD_FLAG` (`constants.ts`) chung với `AppErrorBoundary`
- `PageLoader` — loader Suspense dùng chung
- `AuthGate` — guard, dùng hook `useLogout` chung

**LƯU Ý quan trọng:** chỉ item menu có `component` VÀ component đó đăng ký trong `registry` mới được init route. Item không có component (hoặc chưa đăng ký) → BỎ QUA, không đưa vào router.

## Các pattern chính
- Trang CRUD config-driven (`ModuleConfig` → `CRUDPage`)
- Hệ thống template dùng chung tại `src/shared/templates/`
- Store Zustand theo module + `globalStore`
- Tất cả endpoint khai báo trong `shared/services/apiUrl.ts` (chỉ path)
- Domain API lấy từ biến môi trường `VITE_API_BASE_URL` qua `shared/config/env.ts` → `apiClient` (`API_DOMAIN = env.apiBaseUrl`)
- Cấu hình theo môi trường (domain, timeout, token key, title, base path) khai báo trong `.env.*`, validate ở `shared/config/env.ts`, type ở `src/vite-env.d.ts`
- Tất cả key storage tập trung ở `shared/services/storageService.ts`
- Checkbox custom HTML (`AppCheckbox`); các input khác dùng MUI wrapper
- Typography qua `Styled.ts` (`AppTitle`/`AppText`/`AppCaption`/`AppLabel`) với
  props `size`/`weight`/`color` — không style font inline
- Overlay global (`GlobalLoading`, `ModalConfirm`) mount 1 lần ở `App.tsx`

## Xử lý lỗi theo môi trường
Dựa trên `env.isDev` / `env.isProd` (từ `import.meta.env.DEV/PROD`):
- DEV: `AppErrorBoundary` hiển thị chi tiết lỗi (message + stack + component stack) để debug, KHÔNG auto-reload che bug; `apiClient` log chi tiết request/response lỗi ra console
- PROD: `AppErrorBoundary` chỉ hiện màn hình thân thiện (ẩn stack); lỗi tải chunk/asset thử hard reload 1 lần; `apiClient` không log chi tiết
- Cờ môi trường lấy tập trung tại `shared/config/env.ts` (`env.mode/isDev/isProd`)
- Mọi hàm gọi API bọc `try/catch` + `handleApiError` (`shared/services/handleApiError.ts`): log DEV, `showError` cho người dùng, rồi ném lại lỗi cho caller

## Responsive
- Sidebar: permanent drawer ≥ md, temporary drawer < md
- Header: ẩn breadcrumb + tìm kiếm menu nhanh khi < md
- User menu: ẩn tên/role khi < sm (chỉ avatar), block cố định 140px ≥ sm
