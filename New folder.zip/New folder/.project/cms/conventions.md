# Quy ước CMS

## NGUYÊN TẮC TỐI THƯỢNG

### 0. Dễ maintain là ưu tiên SỐ 1
Khi sửa hoặc xử lý bất kỳ đoạn code nào, LUÔN đặt tính dễ bảo trì lên hàng đầu:
- Tách trách nhiệm rõ ràng, tránh trùng lặp (DRY) — logic/hằng số dùng chung → gom về 1 nơi
- Đặt tên rõ nghĩa, file nhỏ gọn, một file một trách nhiệm
- Không hardcode giá trị lặp lại → dùng hằng số/biến môi trường/theme token
- Ưu tiên giải pháp dễ đọc, dễ sửa hơn là giải pháp "khôn" nhưng khó hiểu
- Khi refactor: giữ nguyên hành vi runtime + API export, chỉ cải thiện cấu trúc

### 0b. Task từ L2 trở lên: PHẢI có plan + comment review
- Với task từ mức L2 (logic) trở lên: TRƯỚC khi code phải trình bày PLAN thực hiện (các bước, file ảnh hưởng) và chờ duyệt
- Code viết ra PHẢI có comment (tiếng Việt) giải thích cho từng khối/hàm quan trọng để người review đọc lại hiểu ngay ý đồ
- Comment mô tả "tại sao" và "làm gì", không lặp lại y hệt code

## QUY TẮC BẮT BUỘC (KHÔNG ĐƯỢC VI PHẠM)

### 1. Luôn dùng shared components của hệ thống
- BẮT BUỘC dùng: AppTable, AppTextField, AppSelectSearch, AppDatePicker, AppCheckbox, AppFilter, AppHeader, AppModalContainer, AppImage
- KHÔNG dùng MUI trực tiếp (TextField, Select, Table...) trong pages/components của module — phải dùng App* wrapper
- KHÔNG tự viết lại component đã có trong shared/
- Cần component mới → tạo trong shared/components/ với prefix App

### 2. Validation bắt buộc dùng React Hook Form + Zod
- KHÔNG validate bằng if/else, regex tay hay state thủ công
- Mọi form PHẢI có Zod schema → resolve qua @hookform/resolvers
- Dùng FormRenderer cho form config-driven
- Form custom → vẫn phải dùng useForm + zodResolver
- Khi form có validation → PHẢI tách schema ra file `validation.ts` riêng của module
  (KHÔNG viết inline schema trong page/component/hook)
- File `validation.ts` chứa Zod schema + type suy ra: `export type XFormValues = z.infer<typeof xSchema>`
- Tham khảo `modules/auth/validation.ts`

### 3. Module phải chia component (dễ maintain)
Khi tạo module mới, PHẢI theo đúng cấu trúc, tách theo trách nhiệm — Page KHÔNG viết monolithic:
```
modules/{name}/
├── components/       # UI block riêng của module (Panel, Form, Card...)
├── hooks/            # Logic tách khỏi UI (use{Name}, form state, submit...)
├── pages/            # Page mỏng — chỉ compose components + gọi hook
├── stores/           # Zustand store riêng
├── styles/           # BẮT BUỘC: styled() cho mọi style trong module (KHÔNG dùng sx)
├── config.ts         # ModuleConfig (module CRUD: columns, fields, schema, filters)
├── constants.tsx     # Data tĩnh (feature list, options, labels...)
├── types.ts          # Type/interface riêng của module (khi có type domain riêng)
├── validation.ts     # Zod schema (khi form có validation)
├── service.ts        # Gọi API
├── helper.ts         # Utils riêng
└── index.ts          # Barrel: CHỈ export page (export { default as XPage })
```
- Page chỉ compose (layout + ghép component), KHÔNG chứa logic phức tạp
- Logic form/submit/API → tách vào hooks/use{Name}.ts
- UI block lặp lại/lớn → tách component riêng trong components/
- Data tĩnh → constants.tsx (không hardcode trong JSX)
- Tham khảo modules/auth làm chuẩn

### 4. Quy ước folder cho component
Nếu 1 component tổng tạo NHIỀU file (sub-component/hook/helper chỉ dùng riêng cho nó) → BẮT BUỘC gom thành folder cùng tên, export qua index:
```
shared/components/
├── AppTable/            # Folder vì có nhiều file phụ trợ
│   ├── index.tsx        # Component chính + re-export types
│   ├── LoadingTable.tsx
│   ├── TableCellAction.tsx
│   ├── TableCellHeaderAction.tsx
│   └── TableEmptyState.tsx
├── AppTextField.tsx     # File đơn vì đứng độc lập
└── ...
```
- Component đơn (1 file) → {Name}.tsx
- Component tổng có nhiều file phụ trợ → {Name}/index.tsx + các file con trong cùng folder
- Import từ ngoài luôn qua folder: `import { AppTable } from '@/shared/components/AppTable'`

### 5. Quy ước đặt tên Dialog/Modal
Tất cả dialog/modal PHẢI đặt tên theo format `Modal{Name}`:
- ModalConfirm, ModalMenuSearch, ModalUserForm, ModalArticleDetail...
- Dialog có nhiều file phụ trợ → folder `Modal{Name}/index.tsx`
- KHÔNG dùng {Name}Dialog, {Name}Popup, ConfirmModal (sai thứ tự)

### 6. Quy ước truy cập Storage (BẮT BUỘC)
TẤT CẢ key localStorage / sessionStorage / cookie phải khai báo và truy cập qua
`shared/services/storageService.ts` — KHÔNG đọc/ghi trực tiếp ở nơi khác:
- Khai báo key trong `STORAGE_KEYS`
- Truy cập qua helper: `storage.get/set/remove`, `storage.getJSON/setJSON`
- Typed accessor theo domain: `authStorage.getToken()`, `authStorage.getUser()`...
- CẤM: `localStorage.getItem('...')` / `sessionStorage.setItem('...')` / `document.cookie` rải rác
- Cần key mới → thêm vào STORAGE_KEYS + tạo accessor tương ứng

### 7. Quy ước API endpoint (BẮT BUỘC)
TẤT CẢ endpoint phải khai báo tại `shared/services/apiUrl.ts` — KHÔNG hardcode URL ở service/hook/component:
- Khai báo trong object `apiUrl`, gom nhóm theo SERVICE (orgChart, learning...)
- Chỉ chứa PATH tương đối — domain lấy từ biến môi trường qua apiClient (`API_DOMAIN = env.apiBaseUrl`)
- Endpoint có param → dùng function: `detail: (id) => \`${SERVICE}/articles/${id}\``
- CẤM: `axios.get('https://...')` hoặc hardcode full URL rải rác
- Service chỉ import `apiUrl.{service}.{endpoint}` và gọi qua apiClient

### 8b. Quy ước xử lý lỗi khi gọi API (BẮT BUỘC)
TẤT CẢ hàm gọi API PHẢI nằm trong `try/catch` và thông báo lỗi — KHÔNG để lỗi rơi tự do:
- Bọc mỗi lời gọi `apiClient.*` trong `try { ... } catch (error) { throw handleApiError(error, '<mô tả>'); }`
- Dùng helper chung `shared/services/handleApiError.ts`:
  - Log chi tiết ở DEV (`env.isDev`)
  - Hiện thông báo lỗi cho người dùng qua `showError` (modal)
  - Ném lại lỗi (return `Error`) để caller (TanStack Query, hook...) vẫn biết request thất bại
- Tham số `context` = mô tả hành động tiếng Việt (vd: `'Tải danh sách menu'`, `'Tạo bài viết'`)
- Trường hợp lỗi đã hiển thị inline (vd form đăng nhập) → dùng `handleApiError(error, ctx, { silent: true })` để tránh báo trùng
- CẤM: gọi `apiClient.*` trần không có try/catch, hoặc nuốt lỗi mà không thông báo/không ném lại

### 8. Quy ước Type riêng của module (BẮT BUỘC)
Khi module có type/interface RIÊNG (entity, DTO, enum, union đặc thù của domain) → PHẢI khai báo trong `modules/{name}/types.ts` — KHÔNG rải rác type trong page/component/hook/service:
- File `types.ts` gom toàn bộ type dùng chung trong module (entity, request/response, props dùng chung...)
- Type suy ra từ Zod schema vẫn đặt tại `validation.ts` (`export type XFormValues = z.infer<...>`)
- Import type qua barrel hoặc trực tiếp: `import type { Article } from '../types'`
- CẤM: khai báo `interface`/`type` domain rải rác nhiều file, hoặc lặp lại type ở nhiều nơi
- Type chỉ dùng cục bộ trong 1 file (props của 1 component) → được phép khai báo tại file đó
- Type dùng chung TOÀN hệ thống → đặt tại `shared/` (không phải types.ts của module)

### 9. Quy ước Biến môi trường (BẮT BUỘC)
TẤT CẢ cấu hình theo môi trường phải qua biến môi trường Vite (`VITE_*`) — KHÔNG hardcode giá trị môi trường trong code:
- Khai báo biến trong `.env.development` / `.env.staging` / `.env.production` (prefix `VITE_`)
- Validate + parse tập trung tại `shared/config/env.ts` (Zod schema) → export object `env`
- Khai báo kiểu cho `import.meta.env` trong `src/vite-env.d.ts`
- Truy cập qua `import { env } from '@/shared/config/env'` — CẤM đọc `import.meta.env.VITE_*` rải rác
- Đang áp dụng: `apiClient` (baseURL = `env.apiBaseUrl`, timeout = `env.apiTimeout`),
  `storageService` (token key = `env.tokenKey/refreshTokenKey`), `main.tsx` (title = `env.appTitle`),
  `vite.config.ts` (base = `VITE_BASE_PATH` qua `loadEnv`)
- Thêm biến mới → cập nhật đủ 3 nơi: file `.env.*`, schema `env.ts`, type `vite-env.d.ts`

## TypeScript
- Bật strict mode
- Không dùng `any` — dùng `unknown` + type guard
- Interface cho props, Type cho union

## Styling (QUAN TRỌNG)
- Chỉ dùng MUI (không styled-components lib riêng)
- TRONG MODULE: HẠN CHẾ TỐI ĐA VIỆC SỬ DỤNG `sx` để style. BẮT BUỘC tạo `styled()` trong `modules/{name}/styles/`
  - Mỗi page có file styled riêng: `modules/{name}/styles/{Page}.styles.ts` (hoặc gom `styles/index.ts` nếu ít)
  - Component trong module import styled component từ `styles/`, KHÔNG viết `sx` inline
  - Kể cả style động → truyền qua props của styled component (`styled(Box)<{ $active?: boolean }>`), KHÔNG dùng `sx`
- Style dùng toàn hệ thống → `shared/components/Styled.ts`
- `sx` chỉ được chấp nhận trong `shared/components/` (App* wrapper) cho chỉnh nhỏ, KHÔNG dùng trong module
- KHÔNG hardcode màu/spacing → dùng theme token (`theme.palette`, `theme.spacing`)
- Theme qua MUI `createTheme` trong providers.tsx
- BẮT BUỘC: khi làm việc phải sử dụng theme hệ thống. Không có màu tương ứng thì khai báo thêm, không khai báo trực tiếp

## Components
- Shared: prefix App{Name} (AppTextField, AppTable, AppImage...)
- Modal: format Modal{Name} (ModalConfirm, ModalMenuSearch...)
- Checkbox custom duy nhất: AppCheckbox (HTML, không phải MUI)
- Prop `isLabelTop` trên tất cả form input (AppTextField, AppSelectSearch, AppDatePicker)
- Typography qua Styled.ts (AppTitle/AppText/AppCaption/AppLabel) với props size/weight/color

## Forms
- React Hook Form + Zod schema (BẮT BUỘC)
- FormRenderer cho form config-driven
- Controller wrap MUI input

## State
- Zustand cho client state
  - Global: src/shared/stores/globalStore.ts
  - Theo module: src/modules/{name}/stores/{name}Store.ts
- TanStack Query cho server state (qua useModuleCRUD)

## Routing
- Router tập trung trong src/routers/
- Lazy loading qua helper lazyLoad()
- Module index.ts CHỈ export page: `export { default as PageName } from './pages/PageName'`

## Barrel index.ts của module (BẮT BUỘC)
- `modules/{name}/index.ts` CHỈ export page (`export { default as XPage }`) phục vụ router/lazy load
- HẠN CHẾ TỐI ĐA export phần khác (hook, service, validation, constants, type) — KHÔNG re-export nếu không thật sự cần
- Cần dùng hook/service/type của module ở nơi khác → import TRỰC TIẾP theo path:
  `import { useLogout } from '@/modules/auth/hooks/useLogout'`
  `import type { OrgChart } from '@/modules/auth/service'`
- Lý do: giữ ranh giới module rõ ràng, tránh phụ thuộc chéo ngầm + giảm bundle qua barrel

## Đặt tên
- Component: PascalCase
- Page: PascalCase + hậu tố Page
- Store: camelCase + hậu tố Store
- Service: camelCase + hậu tố Service
- Config: camelCase + hậu tố Config

## Thứ tự import
1. React/Node built-in
2. MUI
3. Thư viện third-party
4. @/shared
5. @/modules
6. Relative

## config.ts (Module Config) — Format chuẩn
Tham khảo modules/example/config.ts:
- Interface entity type
- Zod validation schema
- Object ModuleConfig gồm: moduleName, pageTitle, apiEndpoint, columns, formFields, validationSchema, formTitle, filters, search
- Columns: { key, title, width?, required? }
- Column có required: true → không cho ẩn trong panel tùy chỉnh cột
