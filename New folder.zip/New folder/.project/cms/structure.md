# Cấu trúc mã nguồn CMS

Thư mục gốc: `project-app/cms/`

```text
project-app/cms/
├── .env.development / .env.staging / .env.production  # VITE_* theo môi trường
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts          # base = VITE_BASE_PATH (loadEnv), alias @ → src
├── public/
│   └── fonts/              # SVN-Gilroy.css + file woff2
└── src/
    ├── main.tsx            # Điểm khởi chạy (set document.title = env.appTitle)
    ├── vite-env.d.ts       # Khai kiểu biến môi trường (import.meta.env)
    ├── app/
    │   ├── App.tsx         # ErrorBoundary + Providers + Router + overlay global
    │   └── providers.tsx   # MUI ThemeProvider, QueryClient, ThemeContext
    ├── routers/
    │   ├── index.tsx       # Router ổn định duy nhất (basename = env.basePath)
    │   ├── paths.ts        # Hằng số PATHS (đường dẫn tĩnh)
    │   ├── constants.ts    # CHUNK_RELOAD_FLAG (dùng chung với ErrorBoundary)
    │   ├── registry.ts     # Gom (spread) route-map của các module + fallback 404
    │   ├── menuResolver.ts # buildRoutesFromMenu / findFirstLeafUrl (logic cây menu)
    │   ├── PageLoader.tsx  # Loader dùng chung cho Suspense
    │   ├── AuthGate.tsx    # Guard auth → skeleton / error / AdminLayout (dùng useLogout)
    │   ├── AppRoutes.tsx   # Map TẤT CẢ route hợp lệ từ menu (useRoutes) + fallback 404
    │   ├── RootRedirect.tsx# '/' → menu lá đầu tiên (menuResolver)
    │   └── lazyLoad.tsx    # Lazy import có retry + force reload (PageLoader chung)
    ├── layouts/
    │   ├── AdminLayout.tsx # Sidebar + header (breadcrumb, search, chuông, user)
    │   └── NormalLayout.tsx# Layout trơn cho trang standalone (login)
    ├── modules/
    │   ├── auth/           # Cấu trúc module CHUẨN (tham khảo)
    │   │   ├── components/ # AuthBrandPanel, LoginForm
    │   │   ├── hooks/      # useLogin, useLogout (logout dùng chung)
    │   │   ├── pages/      # LoginPage
    │   │   ├── constants.tsx
    │   │   ├── types.ts    # Type/interface riêng của module (nếu có)
    │   │   ├── validation.ts # Zod schema
    │   │   ├── service.ts  # Gọi API
    │   │   └── index.ts    # Barrel export
    │   ├── articles/       # Module CRUD config-driven
    │   └── example/        # Trang template/demo
    ├── shared/
    │   ├── components/
    │   │   ├── AppTable/            # Folder: index + LoadingTable, TableCellAction,
    │   │   │                        #   TableCellHeaderAction, TableEmptyState
    │   │   ├── HeaderUserMenu/      # Folder: index + OrgRoleCard
    │   │   ├── AppButton.tsx
    │   │   ├── AppCheckbox.tsx      # Checkbox custom HTML (không dùng MUI)
    │   │   ├── AppDatePicker.tsx
    │   │   ├── AppErrorBoundary.tsx
    │   │   ├── AppFilter.tsx
    │   │   ├── AppHeader.tsx
    │   │   ├── AppImage.tsx
    │   │   ├── AppModalContainer.tsx
    │   │   ├── AppSelectSearch.tsx
    │   │   ├── AppTextField.tsx
    │   │   ├── GlobalLoading.tsx
    │   │   ├── LayoutSkeleton.tsx
    │   │   ├── MenuErrorScreen.tsx
    │   │   ├── MenuSearchTrigger.tsx
    │   │   ├── ModalConfirm.tsx
    │   │   ├── ModalMenuSearch.tsx
    │   │   ├── PageBreadcrumb.tsx
    │   │   ├── SidebarMenu.tsx
    │   │   └── Styled.ts            # AppTitle, AppText, AppCaption, AppLabel
    │   ├── config/
    │   │   └── env.ts              # Validate + export biến môi trường (Zod)
    │   ├── hooks/
    │   │   └── useMenu.ts          # Query menu (chỉ khi đã auth, retry 3)
    │   ├── services/
    │   │   ├── apiClient.ts        # Axios instance — baseURL/timeout từ env + interceptor
    │   │   ├── apiUrl.ts           # Tất cả endpoint path gom theo service
    │   │   ├── handleApiError.ts   # Xử lý lỗi API chung (log DEV + showError + rethrow)
    │   │   ├── loadingService.ts
    │   │   ├── menuService.ts
    │   │   ├── modalService.ts
    │   │   └── storageService.ts   # STORAGE_KEYS (token key từ env) + storage/authStorage
    │   ├── stores/
    │   │   └── globalStore.ts      # Zustand: auth, orgCharts, menu, UI
    │   ├── templates/
    │   │   ├── CRUDPage.tsx        # Trang CRUD config-driven
    │   │   ├── FormRenderer.tsx    # Form động từ FieldConfig
    │   │   ├── createModuleService.ts
    │   │   ├── useModuleCRUD.ts
    │   │   ├── types.ts
    │   │   └── index.ts
    │   └── utils/
    │       ├── jwt.ts              # decodeJwt
    │       └── userDisplay.ts      # getUserName/Avatar/Role
    ├── assets/
    │   ├── icons/index.ts
    │   └── images/index.ts
    └── styles/                     # (rỗng — MUI theme lo styling)
```

## Quy ước cấu trúc Module
```text
modules/{name}/
├── components/       # Các UI block riêng của module
├── hooks/            # Logic tách khỏi UI
├── pages/            # Page mỏng — chỉ compose
├── stores/           # Zustand store riêng
├── styles/           # BẮT BUỘC: styled() cho mọi style (module KHÔNG dùng sx)
├── config.ts         # ModuleConfig (module CRUD)
├── constants.tsx     # Data tĩnh
├── types.ts          # Type/interface riêng của module (khi có type domain riêng)
├── validation.ts     # Zod schema (khi form có validation)
├── routes.ts         # Route-map: tên component (API) → lazy import (nếu module có trang)
├── service.ts        # Gọi API
├── helper.ts         # Utils riêng
└── index.ts          # Barrel: CHỈ export page (export { default as XPage })
```
Tham khảo `modules/auth` làm chuẩn.
Module có trang hiển thị qua menu → khai `routes.ts` (map tên component API → lazy import),
rồi spread vào `routers/registry.ts` (không khai component thủ công ở registry).
Barrel `index.ts` CHỈ export page — hook/service/type/constants import trực tiếp theo path, không re-export qua barrel nếu không cần.

## Đặt tên
- Component: PascalCase (`AppTextField.tsx`)
- Component có nhiều file phụ trợ → folder `{Name}/index.tsx`
- Page: PascalCase + hậu tố `Page` (`LoginPage.tsx`)
- Modal: `Modal{Name}` (`ModalConfirm`, `ModalMenuSearch`)
- Store: camelCase + hậu tố `Store` (`globalStore.ts`)
- Service: camelCase + hậu tố `Service` (`storageService.ts`)
- Config: camelCase + hậu tố `Config` (`articlesConfig`)
- Routes: camelCase + hậu tố `Routes`

## Export
- Shared component: named export
- Page: `export default` (cho lazy loading)
- Service/Hook: named export
- Module: barrel `index.ts` re-export các page
